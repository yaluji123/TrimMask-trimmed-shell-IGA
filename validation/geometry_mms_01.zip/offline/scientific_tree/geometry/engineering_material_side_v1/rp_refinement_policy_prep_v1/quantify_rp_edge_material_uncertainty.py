"""Read frozen RP/geometry files; retain exact nominal labels and report distances."""
from pathlib import Path
from fractions import Fraction as F
from collections import Counter
import importlib.util, sys, json, hashlib, math

HERE = Path(__file__).resolve().parent
PREP = HERE.parents[2]
CAPTURE = PREP / 'runtime/runs/engineering_hull4x_input_only_v2/capture'
PROTOTYPE = HERE / 'actual_hull4x_greville_prototype.json'
OUT = HERE / 'rp_edge_material_uncertainty.json'

def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod

M = module('oe_rp_uncertainty_geometry', HERE.parent / 'owner_interval_classifier.py')
R = module('oe_rp_uncertainty_basis', HERE.parent / 'rp_increment_v2/rp_rank_census.py')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
decode = lambda a: tuple(F(x['exact']) for x in a)

def point_segment(p, a, b):
    d = M.sub(b, a)
    t = max(F(0), min(F(1), M.dot(M.sub(p, a), d) / M.dot(d, d)))
    nearest = M.add(a, M.mul(d, t))
    return M.dot(M.sub(p, nearest), M.sub(p, nearest)), nearest

def segment_segment(a, b, c, d):
    candidates = [point_segment(p, c, d)[0] for p in (a, b)]
    candidates += [point_segment(p, a, b)[0] for p in (c, d)]
    u, v, w = M.sub(b, a), M.sub(d, c), M.sub(a, c)
    aa, bb, cc, dd, ee = M.dot(u, u), M.dot(u, v), M.dot(v, v), M.dot(u, w), M.dot(v, w)
    det = aa * cc - bb * bb
    if det:
        t, z = (bb * ee - cc * dd) / det, (aa * ee - bb * dd) / det
        if 0 <= t <= 1 and 0 <= z <= 1:
            delta = M.sub(M.add(a, M.mul(u, t)), M.add(c, M.mul(v, z)))
            candidates.append(M.dot(delta, delta))
    return min(candidates)

def boundary_distances(surface, uv0, uv1, ring):
    a, b = surface.point(uv0), surface.point(uv1)
    segments = [(surface.point(c), surface.point(d)) for c, d in M.edges(ring)]
    distances = [segment_segment(a, b, c, d) for c, d in segments]
    endpoint_bounds = [max(point_segment(p, c, d)[0] for p in (a, b)) for c, d in segments]
    chosen = min(range(len(segments)), key=lambda i: endpoint_bounds[i])
    c, d = segments[chosen]
    normal = M.cross3(surface.normal, M.sub(d, c))
    signed = [M.dot(M.sub(p, c), normal) for p in (a, b)]
    min_normal = F(0) if signed[0] * signed[1] <= 0 else min(map(abs, signed))
    mid = M.mul(M.add(a, b), F(1, 2))
    return {
        'minimum_distance_over_closed_interval_mm': math.sqrt(float(min(distances))),
        'minimum_distance_squared_exact_mm2': str(min(distances)),
        'uniform_distance_upper_bound_mm': math.sqrt(float(endpoint_bounds[chosen])),
        'upper_bound_witness_ring_edge_zero_based': chosen,
        'upper_bound_proof': 'distance to one convex boundary segment is convex along the straight interval; its maximum endpoint distance bounds every point',
        'midpoint_distance_mm': math.sqrt(float(min(point_segment(mid, x, y)[0] for x, y in segments))),
        'witness_supporting_line_minimum_in_surface_normal_offset_mm': float(min_normal) / M.norm(normal),
        'witness_supporting_line_maximum_in_surface_normal_offset_mm': max(map(lambda x: abs(float(x)), signed)) / M.norm(normal),
        'normal_offset_is_to_supporting_line_not_a_claim_of_orthogonal_foot_inside_segment': True,
    }

def main():
    assert not OUT.exists(), 'Preserve previous analysis; fresh output required'
    assert segment_segment((F(0), F(0), F(0)), (F(1), F(0), F(0)), (F(0), F(1), F(0)), (F(1), F(1), F(0))) == 1
    assert segment_segment((F(0), F(0), F(0)), (F(1), F(1), F(0)), (F(0), F(1), F(0)), (F(1), F(0), F(0))) == 0
    prototype = json.loads(PROTOTYPE.read_text(encoding='utf-8-sig'))
    assert all(sha(CAPTURE / name) == expected for name, expected in prototype['input_sha256'].items())
    rp = json.loads((CAPTURE / 'rp_collected_samples.json').read_text())
    reports = []
    for prior in prototype['reports']:
        owner, group = prior['owner'], prior['group']
        geometry = json.loads((CAPTURE / f'trim_geometry_{owner}.json').read_text())
        surface = M.Surface(geometry)
        topology = prior['topology']
        uv0, uv1 = decode(topology['line_uv_start']), decode(topology['line_uv_end'])
        whole_length = M.norm(M.sub(surface.point(uv1), surface.point(uv0)))
        samples = [s for g in rp['groups'] if g['group_id'] == group for s in g['samples'] if int(s['owner_shell_handle']) == owner]
        diagnostics = []
        for sample in samples:
            uv = tuple(map(M.q, sample['uv']))
            nominal = surface.point(uv)
            B = R.value_basis(geometry, sample['uv'])
            controls = list(map(M.q, geometry['control_global_Vg']))
            actual = tuple(sum(B[i] * controls[3 * i + c] for i in range(len(B))) for c in range(3))
            observed = tuple(map(M.q, sample['evaluated_world_xyz']))
            source = tuple(map(M.q, sample['source_world_xyz']))
            diagnostics.append({'sample_index': sample['sample_index'], 'stored_mapping_distance_mm': sample['mapping_distance'], 'stored_mapping_tolerance_mm': sample['mapping_tolerance'], 'recomputed_stored_world_gap_mm': M.norm(M.sub(observed, source)), 'independent_NURBS_to_stored_evaluation_residual_mm': M.norm(M.sub(actual, observed)), 'independent_NURBS_to_nominal_affine_defect_mm': M.norm(M.sub(actual, nominal)), 'source_world_to_nominal_affine_residual_mm': M.norm(M.sub(source, nominal)), 'source_world_affine_plane_residual_mm': surface.inverse(source)[1]})
        voids = []
        for segment in topology['segments']:
            if segment['classification'] != 'no_material_either_side':
                continue
            a, b = decode(segment['uv_start']), decode(segment['uv_end'])
            middle = M.mul(M.add(a, b), F(1, 2))
            outer = boundary_distances(surface, a, b, surface.outer) if surface.outer else None
            holes = [boundary_distances(surface, a, b, hole) for hole in surface.holes]
            assert outer is not None
            assert not any(M.inside(hole, middle) for hole in surface.holes)
            assert outer['uniform_distance_upper_bound_mm'] < surface.defect
            voids.append({'t0': segment['t0'], 't1': segment['t1'], 'uv_start': segment['uv_start'], 'uv_end': segment['uv_end'], 'physical_longitudinal_length_mm': float(F(segment['t1']['exact']) - F(segment['t0']['exact'])) * whole_length, 'original_exact_nominal_classification': segment['classification'], 'carrier_interval_boundary_distances': boundary_distances(surface, a, b, surface.rings[0]), 'outer_boundary_distances': outer, 'hole_boundary_distances': holes, 'nominal_midpoint_outer_membership': M.inside(surface.outer, middle), 'nominal_midpoint_hole_membership': [M.inside(hole, middle) for hole in surface.holes], 'interpretation': 'UNCERTAIN_ROUNDING_SCALE_OUTER_BOUNDARY_OFFSET; exact nominal void label retained, real material gap not established'})
        reports.append({'group': group, 'owner': owner, 'edge': prior['edge'], 'whole_edge_length_mm': whole_length, 'original_exact_nominal_material_side_classes': prior['material_side_classes'], 'nominal_void_interval_count': len(voids), 'nominal_void_total_longitudinal_length_mm': sum(v['physical_longitudinal_length_mm'] for v in voids), 'nominal_void_intervals': voids, 'material_outer_uv_decimal': geometry['outer_loop'], 'material_holes_uv_decimal': geometry['hole_loops'], 'whole_edge_outer_boundary_distances': boundary_distances(surface, uv0, uv1, surface.outer) if surface.outer else None, 'whole_edge_hole_boundary_distances': [boundary_distances(surface, uv0, uv1, hole) for hole in surface.holes], 'surface_affine_control_hull_defect_mm': surface.defect, 'classifier_existing_affine_fit_acceptance_tolerance_mm': surface.tol, 'topology_endpoint_plane_residuals_mm': topology['endpoint_plane_residual_mm'], 'existing_RP_mapping_tolerances_mm': sorted({s['mapping_tolerance'] for s in samples}), 'max_stored_mapping_distance_mm': max(s['mapping_distance'] for s in samples), 'max_independent_NURBS_to_stored_evaluation_residual_mm': max(s['independent_NURBS_to_stored_evaluation_residual_mm'] for s in diagnostics), 'max_independent_NURBS_to_nominal_affine_defect_mm': max(s['independent_NURBS_to_nominal_affine_defect_mm'] for s in diagnostics), 'sample_backprojection_diagnostics': diagnostics, 'original_CAD_trim_curve_approximation_error_bound': None, 'real_void_or_full_material_edge_certified': False})
    void_edges = [r for r in reports if r['nominal_void_interval_count']]
    void_intervals = [v for r in void_edges for v in r['nominal_void_intervals']]
    assert len(reports) == 28 and len(void_edges) == 19 and len(void_intervals) == 22
    assert sum(v['physical_longitudinal_length_mm'] > 1e-8 for v in void_intervals) == 3
    summary = {'owner_edges': 28, 'nominal_void_owner_edges': 19, 'nominal_void_open_intervals': 22, 'rounding_scale_endpoint_sliver_intervals': 19, 'long_intervals_with_rounding_scale_transverse_offset': 3, 'long_interval_owner_group_pairs': [[r['group'], r['owner']] for r in void_edges if any(v['physical_longitudinal_length_mm'] > 1e-8 for v in r['nominal_void_intervals'])], 'long_interval_length_mm_each': max(v['physical_longitudinal_length_mm'] for v in void_intervals), 'maximum_uniform_outer_distance_bound_over_all_void_intervals_mm': max(v['outer_boundary_distances']['uniform_distance_upper_bound_mm'] for v in void_intervals), 'minimum_surface_affine_fit_defect_among_void_edges_mm': min(r['surface_affine_control_hull_defect_mm'] for r in void_edges), 'existing_RP_mapping_tolerance_mm': 1e-6, 'maximum_stored_RP_mapping_distance_mm': max(r['max_stored_mapping_distance_mm'] for r in reports), 'real_material_gaps_proven': 0, 'nominal_hole_crossings_on_RP_edges': 0}
    output = {'schema': 'oe-rp-edge-material-uncertainty-v1', 'status': 'ALL19_NOMINAL_VOID_EDGES_UNCERTAIN_AT_DECIMAL_GEOMETRY_BOUNDARY_SCALE', 'summary': summary, 'reports': reports, 'method': ['retain original exact nominal event partition and classifications', 'all distance products/projections use Fraction values of captured decimals before final square root', 'minimum boundary distance is exact segment-to-segment minimization with endpoints included', 'uniform interval upper bound uses a single boundary-segment witness and convex distance; no midpoint extrapolation', 'normal offset is in-surface perpendicular distance to the witness supporting line; plane residual reported separately', 'actual NURBS sample positions independently reconstruct captured knots/weights/controls'], 'uncertainty_scope': ['affine control-hull defect is a bound for the nominal affine surrogate versus the captured unit-weight B-spline, not an original CAD trimming error bound', 'RP mapping tolerance only checks mapping back to stored source points; it is not authority to snap, alter trim membership, or certify material topology', 'longitudinal interval length does not measure a transverse material gap', 'zero minimum distance can result from a closure endpoint touching the boundary; uniform upper bounds and all exact intervals are retained', 'no real hole crossing or positive material-gap lower bound is established by these19 nominal void labels'], 'input_sha256': {p.name: sha(p) for p in sorted(CAPTURE.iterdir()) if p.is_file()}, 'prototype_sha256': sha(PROTOTYPE), 'analysis_script_sha256': sha(Path(__file__)), 'no_snapping_or_tolerance_changes': True, 'exact_nominal_output_changed': False, 'RP_sampling_or_BC_or_source_or_capture_changed': False, 'Host_or_compiler_started': False, 'global_RP_rank_rigidity_or_engineering_accuracy_claimed': False}
    assert all(sha(CAPTURE / name) == expected for name, expected in output['input_sha256'].items())
    OUT.write_text(json.dumps(output, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps({'output': str(OUT), 'sha256': sha(OUT), 'summary': summary}, indent=2))

if __name__ == '__main__':
    main()
