"""Read exact completed current16 graph/h cases and finite seven-level STRI3; never queue jobs."""
from pathlib import Path
import argparse,csv,json,math,os
for key in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS']:os.environ[key]='1'
import numpy as np
from series_context_v7 import Context,common_arguments,require,read,sha,clean,SOURCE,RUNTIME,DOFS
import allgraph_weak_dual_link as weak_dual_link
OMITS=['all','1ec2','1ec5','1ec8']
FEM_SUMMARY_SHA='cfc0bb01cbd3702ec822121688120e8771400261f20abddd351380e21d2518d9'
FEM_PROTOCOL_SHA='5421f64d3dbc2da1352370ac7e8a616ccd70d68eccf46682bb721b60c110034b'

def relative_scalar(actual, reference):
    require(math.isfinite(actual) and math.isfinite(reference) and reference != 0, 'invalid scalar normalization')
    return dict(signed=(actual - reference) / abs(reference), absolute=abs(actual - reference) / abs(reference))

def relative_vector(actual, reference):
    require(len(actual) == len(reference) and all(math.isfinite(v) for v in [*actual, *reference]),
            'invalid same-point vector')
    denominator = math.sqrt(math.fsum(v * v for v in reference))
    require(denominator > 0, 'zero vector reference')
    return math.sqrt(math.fsum((a - b) ** 2 for a, b in zip(actual, reference))) / denominator

def validate_grid(entries):
    pairs = [(e['omit'], e['refine_factor']) for e in entries]
    require(len(entries) == 16 and len(set(pairs)) == 16 and
            set(pairs) == {(omit, h) for omit in OMITS for h in range(1, 5)},
            'exact full graph/three trees by h1/h2/h3/h4 grid required')
    require(len({e['run_dir'] for e in entries}) == 16, 'reused case in final 16 grid')

def aggregate(context,index_path):
    index=read(context.bind(index_path))
    require(index['schema']=='oe-current90f-completed-threepatch-series-index-v7'and index['status']=='ROOT_INDEX_OF_COMPLETED_CASES_NOT_JOB_QUEUE','complete input index only; template is not results')
    require(index['source_binding_sha256']==SOURCE and index['runtime_manifest_sha256']==RUNTIME,'exact index source/runtime')
    weak_dual_link.validate_links(weak_dual_link.req(index,'all_graph_complete_physical_weak_dual_reports'))
    entries=index['cases'];validate_grid(entries);controls=index['q5_controls']
    require(len(controls)==2 and {e['omit']for e in controls}=={'all','1ec8'}and all(e['refine_factor']==1 for e in controls),'original two-graph GL4/5 controls')
    require(len({e['run_dir']for e in entries+controls})==18,'18 distinct actual solved cases, no reused q5 control')
    fem=read(context.bind(context.prep/'runtime/stri3_reference_seven_level_summary_v1/summary.json',FEM_SUMMARY_SHA))
    protocol=read(context.bind(context.prep/'runtime/stri3_reference_candidates_0p125mm/CONVERGENCE_PROTOCOL.json',FEM_PROTOCOL_SHA))
    require(protocol['maximum_displacement_relative_change_target']==protocol['ALLSE_relative_change_target']==protocol['ALLIE_relative_change_target']==.001,'original three FEM thresholds')
    require(len(fem['rows'])==7 and fem['latest_three_quantity_protocol_met']is True and fem['original0p25_to0p125_protocol_NOT_MET_retained']is True and fem['rows'][-2]['adjacent_full_protocol_met']is False,'full seven-level qualification with old NOT_MET preserved')
    for item in fem['source_manifest']:context.bind(item['path'],item['sha256'])
    finest=fem['rows'][-1]
    for key,column in [('maximum_U_mm','adjacent_U_relative_change'),('ALLSE_Nmm','adjacent_ALLSE_relative_change'),('ALLIE_Nmm','adjacent_ALLIE_relative_change')]:
        change=abs(finest[key]-fem['rows'][-2][key])/abs(finest[key]);require(change==finest[column]and change<=.001,'stored finest FEM change/original threshold')
    peak_world=fem['latest_computed_peak_xyz_mm'];peak_reference_vector=fem['latest_computed_U_vector_at_peak_mm']
    gamma_world=[100.,0.,0.];gamma_reference_vector,gamma_reference_evidence=context.Gamma_reference(fem)
    # These remain explicitly historical55f controls, never relabelled current90f.
    historical={}
    for kind in ['baseline','bc-isolation']:
        report=context.report(index['historical_source_default_linkage_reports'][kind])
        require(report['status']=='PASS_BOUNDED_FINAL1212_THREEPATCH_'+kind.upper().replace('-','_')+'_ONLY'and report['kind']==kind and all(report['gates'].values())and report['general_method_or_continuum_accuracy_accepted']is False,'historical actual source-default linkage report')
        for item in report['input_manifest']:context.bind(item['path'],item['sha256'])
        historical[kind]=dict(report=report,accepted_as_current_runtime_experiment=False)
    cache={};rows=[];model_hashes=set()
    def load_case(entry,q):
        value=context.load_case(entry,q,require_flux=q==4);run=value['run'];post=value['post'];coefficients=value['coefficients'];arms=value['arms']
        original=read(context.bind(run/'original_input_before_after.json'));require(original['exact_sha_and_mtime_unchanged']is True and original['before']==original['after'],'immutable actual original DWG')
        context.bind(run/'input_model.dwg',original['before']['sha256']);model_hashes.add(original['before']['sha256'])
        for owner in context.reader.OWNERS:
            for stage in ['raw_bulk_before_support','bulk_after_support']:
                bulk=read(context.bind(value['packet']/f'bulk_measure_{stage}_{owner}.json'));require(bulk['valid']is True and bulk['actual_bulk_rectangular_gauss_order']==4,'actual original independent bulk GL4 fixture')
        sample_path=context.bind(run/'derived_work/displacement_samples.csv')
        with sample_path.open(encoding='utf-8-sig',newline='')as stream:samples=list(csv.DictReader(stream))
        require(samples and all(math.isfinite(float(r[k]))for r in samples for k in ['x','y','z','ux','uy','uz','umag']),'entire exported displacement field finite')
        peak=max(samples,key=lambda r:float(r['umag']));owner_Gamma=[]
        for arm in arms:
            operator=arm.operators(1.,0.);require(math.dist(operator['X'].tolist(),gamma_world)<=1e-8,'actual common physical Gamma endpoint')
            vector=(operator['U']@arm.coeff).tolist()
            owner_Gamma.append(dict(owner=hex(arm.handle),xyz_mm=operator['X'].tolist(),U_vector_mm=vector,relative_vector_difference_to_finest_FEM=relative_vector(vector,gamma_reference_vector)))
        from fixed_reference_points import actual_peak_traces
        retained_peak,other_peak_owners=actual_peak_traces(arms,peak_world)
        for trace in retained_peak:trace['relative_vector_difference_to_finest_FEM']=relative_vector(trace['U_vector_mm'],peak_reference_vector)
        flux=value['flux'];point_ledger=post['point_action_ledger']
        record=dict(case=run.name,omit=entry['omit'],refinement=entry['refine_factor'],boundary_gauss=q,DOF=len(coefficients),
          material_energy_Nmm=post['bulk']['material_strain_energy_N_mm'],material_energy_relative_difference_to_finest_FEM=relative_scalar(post['bulk']['material_strain_energy_N_mm'],finest['ALLSE_Nmm']),
          sample_peak_U_mm=float(peak['umag']),sample_peak_xyz_mm=[float(peak[k])for k in ['x','y','z']],sample_peak_vector_mm=[float(peak[k])for k in ['ux','uy','uz']],
          peak_magnitude_relative_difference=relative_scalar(float(peak['umag']),finest['maximum_U_mm']),sample_peak_at_FEM_peak=math.dist([float(peak[k])for k in ['x','y','z']],peak_world)<=1e-8,
          peak_scope='maximum of all exported actual samples, not certified continuous-domain supremum',all_three_owner_Gamma_vectors=owner_Gamma,
          fixed_FEM_peak_world_mm=peak_world,fixed_FEM_peak_retained_owner_traces=retained_peak,owners_not_containing_fixed_FEM_peak=other_peak_owners,
          all_pair_jumps=post['cluster']['jumps'],numerical_weak_balance=post['numerical_total_balance'],independent_loaded_RHS=post['loaded_full_RHS_residual'],
          raw_effective_force_relative_L2=post['cluster']['effective_force_sum_relative_L2'],raw_common_axis_moment_relative_L2=post['cluster']['common_axis_moment_sum_relative_L2'],
          raw_physical_flux_accepted=False,recovered_physical_clamp_balance_not_observed_reaction=post['recovered_clamp_balance'],
          point_operator_qualification=value['point_qualification'],point_action_and_reaction_ledger=point_ledger,
          completed_internal_quadratic_work_Nmm=post['loaded_full_RHS_residual']['independent_interface_quadratic_work_N_mm'],
          line_only_quadratic_work_Nmm=post['loaded_full_RHS_residual']['independent_line_quadratic_work_N_mm'],
          natural_point_quadratic_work_Nmm=post['loaded_full_RHS_residual']['actual_natural_point_quadratic_work_N_mm'],
          completed_boundary_internal_minus_rhs_work_Nmm=post['loaded_full_RHS_residual']['observed_boundary_internal_minus_rhs_work_N_mm'],
          point_work_not_mislabeled_material_energy=True,matrix_diagnostics=value['cluster']['matrix_diagnostics'],quadrature_crosscheck=post['quadrature_crosscheck'],
          full_flux_report_reference=entry['flux_report']if flux is not None else None,
          fixed8_and_all_GP_summary=[dict(order=r['order'],all_GP_count=r['all_GP_count'],all_endpoint_incidence_count=len(r['all_signed_span_endpoint_incidences']),
              internal_knot_readback=r['internal_one_sided_H_continuity_readback'],fixed_virtual_work=r['fixed_virtual_work'])for r in flux['quadrature_results']]if flux is not None else None,
          postprocess_reference=entry['postprocess'],structural_or_continuum_accuracy_accepted=False)
        value['record']=record;value['geometry']=[(a.handle,a.cp.tolist(),a.ku.tolist(),a.kv.tolist(),a.weights.tolist(),a.E,a.nu,a.thickness)for a in arms]
        return value
    for entry in sorted(entries,key=lambda e:(OMITS.index(e['omit']),e['refine_factor'])):
        value=load_case(entry,4);cache[entry['omit'],entry['refine_factor']]=value;rows.append(value['record'])
    require(len(model_hashes)==1,'mixed original models')
    for h in range(1,5):
        baseline=cache['all',h]
        for omit in OMITS[1:]:
            value=cache[omit,h];require(value['geometry']==baseline['geometry']and all(np.array_equal(a,b)for a,b in zip(value['patch_forces'],baseline['patch_forces'])),'graph changed geometry/material/actual pure external load')
    h_series=[]
    for omit in OMITS:
        group=[cache[omit,h]['record']for h in range(1,5)];changes=[]
        for coarse,fine in zip(group[:-1],group[1:]):
            changes.append(dict(coarse_h=coarse['refinement'],fine_h=fine['refinement'],peak_magnitude_relative_change=relative_scalar(coarse['sample_peak_U_mm'],fine['sample_peak_U_mm'])['absolute'],
              material_energy_relative_change=relative_scalar(coarse['material_energy_Nmm'],fine['material_energy_Nmm'])['absolute'],
              all_owner_same_Gamma_vector_relative_changes=[dict(owner=f['owner'],relative_change=relative_vector(c['U_vector_mm'],f['U_vector_mm']))for c,f in zip(coarse['all_three_owner_Gamma_vectors'],fine['all_three_owner_Gamma_vectors'])]))
        h_series.append(dict(omit=omit,ordered_cases=[r['case']for r in group],adjacent_changes=changes,
          reference_errors=[dict(refinement=r['refinement'],peak=r['peak_magnitude_relative_difference'],energy=r['material_energy_relative_difference_to_finest_FEM'])for r in group],no_new_h_acceptance_threshold_or_asymptotic_limit_inferred=True))
    q_results=[]
    for entry in controls:
        four=cache[entry['omit'],1];five=load_case(entry,5)
        require(four['geometry']==five['geometry']and all(np.array_equal(a,b)for a,b in zip(four['patch_forces'],five['patch_forces'])),'q4/q5 changed actual geometry/material/external F')
        report=context.report(entry['control_report'])
        require(report['status']=='PASS_BOUNDED_CURRENT90F_THREEPATCH_BC4_VS5_ONLY'and report['source_binding_sha256']==SOURCE and report['runtime_manifest_sha256']==RUNTIME and report['kind']=='bc4-vs5'and report['omit']==entry['omit']and report['left_case']==four['run'].name and report['right_case']==five['run'].name and all(report['gates'].values()),'current two-graph original-budget GL4/5 controls')
        for item in report['input_manifest']:context.bind(item['path'],item['sha256'])
        q_results.append(dict(omit=entry['omit'],q4_case=four['run'].name,q5_case=five['run'].name,actual_control=report,q5_observation=five['record'],individual_Native_ABC_exports_claimed=False))
    ordering=context.report(index['ordering_report'])
    require(ordering['status']=='PASS_CAPTURED_NUMERICAL_ORDER_CONTROLS_ONLY'and ordering['source_binding_sha256']==SOURCE and ordering['runtime_manifest_sha256']==RUNTIME and ordering['actual_changed_DOFs']==729 and all(ordering['gates'].values()),'current completed point/BC/K/F/U ordering evidence')
    for item in ordering['input_manifest']:context.bind(item['path'],item['sha256'])
    profiles={Path(item['path']).parent.resolve()for item in ordering['input_manifest']if Path(item['path']).name=='executed_profile.json'}
    alternate=index['ordering_alternate']
    require(alternate['complete']is True and alternate['omit']=='all'and alternate['refine_factor']==1 and alternate['boundary_gauss']==4 and alternate['cyclic_order']is True,'one actual completed current cyclic ordering case')
    expected_profiles={cache['all',1]['run'].resolve(),Path(alternate['run_dir']).resolve()}
    current_profiles={run for run in profiles if sha(context.bind(run/'applied_source_binding.json'))==SOURCE and sha(context.bind(run/'source_runtime_manifest.json'))==RUNTIME}
    require(len(expected_profiles)==2 and current_profiles==expected_profiles,'exact two actual current ordering profiles; historical inherited inputs remain separately bound')
    for run in sorted(current_profiles):context.profile_guard.case_identity(run,RUNTIME,'actual_bootstrap_module_hashes.json')
    ordering_profile_scope=dict(current_profiles=[str(run)for run in sorted(current_profiles)],historical_inherited_profiles=[str(run)for run in sorted(profiles-current_profiles)],historical_inputs_preserved=True)
    coarse={}
    for omit in ['all','1ec8']:coarse[omit]=context.coarse_qualification(index['coarse_B_qualifications'][omit],cache[omit,1]['run'])
    history_path=context.bind(context.prep/'tables/final_preparation_v1/Table4_actual_V5_four_graphs_4x_mechanics.csv')
    with history_path.open(encoding='utf-8-sig',newline='')as stream:history=list(csv.DictReader(stream))
    require(len(history)==4 and all(r['raw_flux_failure_not_relabelled_PASS']=='True'for r in history),'historical strong failures retained')
    context.bind(Path(__file__))
    weak_duals=weak_dual_link.attach_all_graph_duals(context,index,cache,rows)
    merged_inputs=weak_dual_link.merge_manifests(context.finish(),weak_duals.pop('additional_input_manifest'))
    return dict(status='COMPLETED_CURRENT90F_GRAPH_H_REFERENCE_OBSERVATIONS_NOT_CONTINUUM_ACCEPTANCE',source_binding_sha256=SOURCE,runtime_manifest_sha256=RUNTIME,
      graph_case_count=16,extra_GL5_control_count=2,ordering_case_count_separate=1,rows=rows,h_series=h_series,two_graph_GL4_GL5_controls=q_results,
      ordering_observation=ordering,ordering_profile_identity_readback=ordering_profile_scope,actual_coarse_B_qualifications=coarse,historical_source_default_linkage_reports=historical,
      source_default_provenance='literal55f/fec CPP capture with separate actual90f identical-config-header inheritance; not runtime export or DWG clone',
      seven_level_STRI3_reference=fem,finest_reference_is_finite_computed_not_exact_continuum=True,original_0p125_full_protocol_NOT_MET_preserved=True,
      all48_owner_same_Gamma_vectors_retained=True,common_Gamma_world_mm=gamma_world,common_Gamma_FEM_U_vector_mm=gamma_reference_vector,common_Gamma_reference_readback=gamma_reference_evidence,
      actual_FEM_peak_world_mm=peak_world,actual_FEM_peak_U_vector_mm=peak_reference_vector,actual_peak_kept_separate_and_only_retained_PATCH2_trace=True,
      all_pair_jumps_GP_endpoint_fixed8_evidence_retained=True,historical_raw_flux_failure_table=history,
      all_graph_complete_physical_weak_dual_linkage=weak_duals,all_graph_norms_not_populated_for_three_trees=True,
      weak_numeric_balance_not_substituted_for_raw_physical_flux=True,no_new_accuracy_thresholds_or_error_bounds=True,
      single_coarse_B_pass_not_promoted_to_all_h_accuracy=True,paper_or_general_endpoint_or_structural_accuracy_accepted=False,
      no_Host_compiler_solver_or_process_scan=True,input_manifest=merged_inputs,aggregator_source_sha256=sha(Path(__file__)))

def main():
    ap=argparse.ArgumentParser(description=__doc__);common_arguments(ap);weak_dual_link.arguments(ap);ap.add_argument('--case-index',type=Path,required=True);ap.add_argument('--out-dir',type=Path,required=True);args=ap.parse_args()
    require(Path(weak_dual_link.__file__).resolve()==Path(__file__).with_name('allgraph_weak_dual_link.py').resolve(),'exact local metadata hook import')
    context=Context(args);context.identity.fresh_output(args.out_dir);result=aggregate(context,args.case_index.resolve())
    args.out_dir.mkdir(parents=True,exist_ok=False)
    with(args.out_dir/'all16_graph_h_observations.csv').open('x',encoding='utf-8-sig',newline='')as stream:
        fields=['case','omit','refinement','boundary_gauss','DOF','material_energy_Nmm','sample_peak_U_mm','raw_effective_force_relative_L2','raw_common_axis_moment_relative_L2','raw_physical_flux_accepted']
        writer=csv.DictWriter(stream,fieldnames=fields);writer.writeheader();writer.writerows({k:r[k]for k in fields}for r in result['rows'])
    with(args.out_dir/'all_graph_only_complete_finite_physical_weak_duals.csv').open('x',encoding='utf-8-sig',newline='')as stream:
        fields=['omit','refinement','case','global_DOF','physical_free_DOF','eta_sqrt_Nmm','energy_normalized_eta','primary_value_source',
          'backend_eta_sqrt_Nmm','backend_energy_normalized_eta','arithmetic_delta_dual_sqrt_Nmm','original_material_quadratic_normalization_Nmm',
          'raw_force_absolute_L2','raw_force_relative_L2','raw_common_axis_moment_absolute_L2','raw_common_axis_moment_relative_L2','raw_physical_flux_accepted']
        writer=csv.DictWriter(stream,fieldnames=fields);writer.writeheader()
        writer.writerows({k:row[k]for k in fields}for row in result['all_graph_complete_physical_weak_dual_linkage']['observations'])
    with(args.out_dir/'all48_owner_same_Gamma_vectors.csv').open('x',encoding='utf-8-sig',newline='')as stream:
        fields=['case','omit','refinement','owner','x_mm','y_mm','z_mm','ux_mm','uy_mm','uz_mm','relative_vector_difference_to_finest_FEM'];writer=csv.DictWriter(stream,fieldnames=fields);writer.writeheader()
        for row in result['rows']:
            for tip in row['all_three_owner_Gamma_vectors']:
                writer.writerow(dict(case=row['case'],omit=row['omit'],refinement=row['refinement'],owner=tip['owner'],**dict(zip(['x_mm','y_mm','z_mm'],tip['xyz_mm'])),**dict(zip(['ux_mm','uy_mm','uz_mm'],tip['U_vector_mm'])),relative_vector_difference_to_finest_FEM=tip['relative_vector_difference_to_finest_FEM']))
    with(args.out_dir/'all16_fixed_FEM_peak_retained_PATCH2_vectors.csv').open('x',encoding='utf-8-sig',newline='')as stream:
        fields=['case','omit','refinement','owner','x_mm','y_mm','z_mm','ux_mm','uy_mm','uz_mm','relative_vector_difference_to_finest_FEM'];writer=csv.DictWriter(stream,fieldnames=fields);writer.writeheader()
        for row in result['rows']:
            for trace in row['fixed_FEM_peak_retained_owner_traces']:
                writer.writerow(dict(case=row['case'],omit=row['omit'],refinement=row['refinement'],owner=trace['owner'],**dict(zip(['x_mm','y_mm','z_mm'],trace['xyz_mm'])),**dict(zip(['ux_mm','uy_mm','uz_mm'],trace['U_vector_mm'])),relative_vector_difference_to_finest_FEM=trace['relative_vector_difference_to_finest_FEM']))
    with(args.out_dir/'final16_graph_h_and_finite_reference.json').open('x',encoding='utf-8')as stream:json.dump(clean(result),stream,indent=2,allow_nan=False)
    print(json.dumps(dict(status=result['status'],path=str(args.out_dir))));return 0

if __name__=='__main__':raise SystemExit(main())

