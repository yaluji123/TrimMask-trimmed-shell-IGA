"""Exact binary64-input geometry/encoding layers. No Native or field algebra."""
from fractions import Fraction as F
from math import isqrt, isfinite
from bisect import bisect_right
import re

U = F(1, 2**53)
TINY = F(1, 2**1075)
BUDGET = F(1, 10**13)  # Unchanged parent arithmetic budget.

def q(x):
    value = float(x)
    assert isfinite(value)
    return F.from_float(value)

def add(a,b): return [a[0]+b[0],a[1]+b[1]]
def mul(a,b):
    x=[a[i]*b[j] for i in (0,1) for j in (0,1)]
    return [min(x),max(x)]
def div(a,b):
    assert b[0]>0
    return mul(a,[1/b[1],1/b[0]])
def rounded(a):
    # Round-to-nearest binary64 bound; covers subnormals as well. No fitted epsilon.
    e=U/(1-U)*max(abs(x) for x in a)+TINY
    return [a[0]-e,a[1]+e]
def singleton(x):return [x,x]
def contains(box,x):return box[0]<=x<=box[1]
def sqrt_box(x):
    assert x>=0
    scale=10**60
    a=isqrt((x.numerator*scale*scale)//x.denominator)
    lo=F(a,scale)
    return [lo,lo if lo*lo==x else F(a+1,scale)]
def norm_box(v):return sqrt_box(sum((x*x for x in v),F(0)))
def ipow(a,k):
    if k==0:return [F(1),F(1)]
    values=[a[0]**k,a[1]**k]
    if not k%2 and a[0]<=0<=a[1]:values.append(F(0))
    return [min(values),max(values)]

def parse_rule(path):
    text=path.read_text(encoding='utf-8-sig')
    result=[];tokens=[]
    for name in ['gaussA','gaussC']:
        body=re.search(r'const double '+name+r'\[7\]\[6\]\s*=\s*\{(.*?)\};',text,re.S).group(1)
        rows=re.findall(r'\{([^{}]+)\}',body)
        assert len(rows)==7
        raw=[x.strip() for x in rows[4].split(',')]
        assert len(raw)==6 and list(map(float,raw[4:]))==[0.,0.]
        result.append([q(x) for x in raw[:4]]);tokens.append(raw[:4])
    return result[0],result[1],tokens

def rule_moments(g,c):
    return [sum((c[i]/2*((g[i]+1)/2)**k for i in range(4)),F(0)) for k in range(8)]

def node_weight_boxes(a,b,g,c):
    length=rounded(singleton(b-a))
    z=rounded(singleton(g+1))
    z=rounded(mul(z,singleton(F(1,2))))
    x=rounded(mul(z,length));x=rounded(add(x,singleton(a)))
    w=rounded(mul(length,singleton(F(1,2))))
    w=rounded(mul(w,singleton(c)))
    return x,w

def encoded_layers(a,b,t,g,c):
    assert b>a and len(t)==4
    d=b-a;z=[(x-a)/d for x in t]
    ideal=rule_moments(g,c)
    observed=[sum((c[i]/2*z[i]**k for i in range(4)),F(0))for k in range(8)]
    boxes=[node_weight_boxes(a,b,g[i],c[i]) for i in range(4)]
    normalized=[[(x-a)/d for x in box[0]] for box in boxes]
    forward=[]
    for k in range(8):
        forward.append(sum((abs(c[i]/2)*max(abs(ipow(normalized[i],k)[j]-((g[i]+1)/2)**k)for j in(0,1))for i in range(4)),F(0)))
    return {'ideal':ideal,'encoded':observed,'encoding_delta':[x-y for x,y in zip(observed,ideal)],'source_node_boxes':[x[0]for x in boxes],'source_weight_boxes':[x[1]for x in boxes],'actual_nodes_inside_source_forward_boxes':[contains(boxes[i][0],t[i])for i in range(4)],'source_forward_moment_abs_bounds':forward,'normalized_encoded_nodes':z}

def points(c):
    raw=c['control_global_xyz']
    return [tuple(map(q,p))for p in raw]if raw and isinstance(raw[0],list)else [tuple(map(q,raw[i:i+3]))for i in range(0,len(raw),3)]

class Curve:
    """Exact de Boor of captured polynomial curve, independent of Native basis summation."""
    def __init__(self,c):
        assert c['extraction_complete']and not c['rational']and all(q(w)==1 for w in c['weights'])
        self.p=int(c['degree']);self.K=list(map(q,c['knots']));self.P=points(c)
        assert self.p==3 and len(self.K)==len(self.P)+self.p+1
        self.D=[]
        for i in range(len(self.P)-1):
            den=self.K[i+self.p+1]-self.K[i+1]
            self.D.append(tuple(self.p*(self.P[i+1][j]-self.P[i][j])/den if den else F(0) for j in range(3)))
        self.lo,self.hi=self.K[self.p],self.K[len(self.P)]
        self.affine_speed=div(norm_box(tuple(self.P[-1][i]-self.P[0][i] for i in range(3))),singleton(self.hi-self.lo))

    @staticmethod
    def evaluate(P,K,p,x,left=False):
        n=len(P);assert K[p]<=x<=K[n]
        span=bisect_right(K,x)-1
        if left and x in K and x>K[p]:span=next(i-1 for i,k in enumerate(K)if k==x)
        span=max(p,min(n-1,span))
        d=[list(P[j+span-p])for j in range(p+1)]
        for r in range(1,p+1):
            for j in range(p,r-1,-1):
                index=j+span-p;den=K[index+p-r+1]-K[index]
                alpha=(x-K[index])/den if den else F(0)
                d[j]=[(1-alpha)*d[j-1][axis]+alpha*d[j][axis] for axis in range(3)]
        return tuple(d[p])

    def location(self,x):return self.evaluate(self.P,self.K,self.p,x)
    def derivative(self,x,left=False):return self.evaluate(self.D,self.K[1:-1],self.p-1,x,left)
    def speed(self,x):return norm_box(self.derivative(x))

    def literal_arc_and_moment_boxes(self,a,b):
        # One quadratic Bernstein enclosure per original knot-piece: no adaptive tuning.
        cuts=sorted({a,b,*[x for x in self.K if a<x<b]});arc=[F(0),F(0)];mom=[[F(0),F(0)]for _ in range(8)]
        for l,r in zip(cuts,cuts[1:]):
            for index in range(1):
                x=l;y=r;mid=(x+y)/2
                d0=self.derivative(x);d2=self.derivative(y,left=True);dm=self.derivative(mid)
                d1=tuple(2*dm[j]-(d0[j]+d2[j])/2 for j in range(3))
                lo2=F(0);hi2=F(0)
                for j in range(3):
                    low=min(d0[j],d1[j],d2[j]);high=max(d0[j],d1[j],d2[j])
                    lo2+=0 if low<=0<=high else min(low*low,high*high)
                    hi2+=max(low*low,high*high)
                speed=[sqrt_box(lo2)[0],sqrt_box(hi2)[1]]
                arc=add(arc,mul(speed,singleton(y-x)))
                z0,z1=(x-a)/(b-a),(y-a)/(b-a)
                for k in range(8):
                    measure=(b-a)*(z1**(k+1)-z0**(k+1))/F(k+1)
                    mom[k]=add(mom[k],mul(speed,singleton(measure)))
        assert arc[0]>0
        return arc,[div(m,arc)for m in mom]

def diagnostics(a,b,t,ds,g,c,curve):
    layer=encoded_layers(a,b,t,g,c);Laff=mul(curve.affine_speed,singleton(b-a))
    literal_speeds=[curve.speed(x)for x in t]
    captured=[];literal=[];Jdifference=[]
    for k in range(8):
        captured.append(div(singleton(sum((ds[i]*layer['normalized_encoded_nodes'][i]**k for i in range(4)),F(0))),Laff))
        numerator=[F(0),F(0)]
        for i in range(4):numerator=add(numerator,mul(literal_speeds[i],singleton((b-a)*c[i]/2*layer['normalized_encoded_nodes'][i]**k)))
        literal.append(div(numerator,Laff))
        Jdifference.append([captured[-1][0]-literal[-1][1],captured[-1][1]-literal[-1][0]])
    arc,literal_moment=curve.literal_arc_and_moment_boxes(a,b)
    return {**layer,'nominal_affine_length_box_mm':Laff,'literal_curve_arc_length_box_mm':arc,'literal_curve_normalized_moment_boxes':literal_moment,'captured_ds_affine_denominator_moment_boxes':captured,'captured_ds_minus_encoded_constantJ_moment_boxes':[[captured[k][j]-layer['encoded'][k]for j in(0,1)]for k in range(8)],'literal_curve_Q4_affine_denominator_moment_boxes':literal,'captured_minus_literal_curve_Q4_boxes':Jdifference,'literal_curve_GP_speed_boxes_mm_per_param':literal_speeds,'no_nominal_affine_length_claimed_as_literal_curve_truth':True}

def preregistered(g,c):
    values=rule_moments(g,c);assert all(abs(v-F(1,k+1))<=BUDGET/F(k+1)for k,v in enumerate(values))
    rows=[]
    for a,b in [(F(0),F(1)),(F(1,4),F(1,4)+F(1,2**30)),(F(-3),F(-3)+F(1,2**25))]:
        t=[q((float(g[i])+1.)*.5*(float(b)-float(a))+float(a))for i in range(4)]
        d=encoded_layers(a,b,t,g,c)
        assert all(d['actual_nodes_inside_source_forward_boxes'])
        assert all(abs(d['encoding_delta'][k])<=d['source_forward_moment_abs_bounds'][k]for k in range(8))
        rows.append({'positive':'shifted_or_narrow_panel_encoding_enclosure','a':str(a),'b':str(b),'all8_source_bounds_cover':True})
    fixture={'degree':3,'knots':[0,0,0,0,1,1,1,1],'control_global_xyz':[0,0,0,1,0,0,2,0,0,3,0,0],'weights':[1]*4,'rational':False,'extraction_complete':True}
    curve=Curve(fixture);arc,mom=curve.literal_arc_and_moment_boxes(F(0),F(1))
    assert arc==[F(3),F(3)]and all(box==[F(1,k+1)]*2 for k,box in enumerate(mom))
    rows.append({'positive':'independent_cubic_Bezier_straight_curve_arc_and_moments','passed':True})
    a,b=F(0),F(1);t=[(x+1)/2 for x in g];ds=[w/2 for w in c]
    tests=[('wrong_node_order',lambda:all(encoded_layers(a,b,[t[1],t[0],*t[2:]],g,c)['actual_nodes_inside_source_forward_boxes'])),('perturbed_node',lambda:all(encoded_layers(a,b,[t[0]+F(1,10**6),*t[1:]],g,c)['actual_nodes_inside_source_forward_boxes'])),('wrong_weight',lambda:abs(sum([ds[0]*F(1001,1000),*ds[1:]])-1)<=BUDGET),('missing_fourth_node',lambda:len(t[:-1])==4)]
    for label,test in tests:assert not test();rows.append({'negative':label,'rejected':True})
    return rows
