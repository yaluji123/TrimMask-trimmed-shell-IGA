;;; Read the original stored Xrecord only. No import, save, refinement or solve.
(vl-load-com)

(defun oe-profile-write-status (directory status detail / file)
  (setq file (open (strcat directory "/profile_capture_status.json") "w"))
  (if file
    (progn
      (write-line
        (strcat "{\"status\":\"" status "\",\"detail\":\"" detail
                "\",\"profile_imported\":false,\"DWG_saved\":false,\"solver_started\":false}") file)
      (close file)))
  (princ (strcat "\n[IGA][StoredProfileCapture] " status)))

(defun oe-capture-original-profile (directory / record chain count payload header file valid)
  (setq record (dictsearch (namedobjdict) "IGA_NONLINEAR_ANALYSIS_PROFILE"))
  (if (not record)
    (oe-profile-write-status directory
      "ORIGINAL_PROFILE_XRECORD_MISSING_NO_DEFAULTS_INVENTED" "missing_stored_profile")
    (progn
      (setq chain (vl-remove-if-not '(lambda (item) (member (car item) '(90 1))) record))
      (setq valid
        (and (>= (length chain) 5)
             (= (caar chain) 90) (= (cdar chain) 1)
             (= (car (cadr chain)) 1)
             (= (cdr (cadr chain)) "iga.nonlinear.analysis_profile")
             (= (car (caddr chain)) 1)
             (= (car (cadddr chain)) 90)))
      (if valid
        (progn
          (setq header (cdr (caddr chain)))
          (setq count (cdr (cadddr chain)))
          (setq chain (cddddr chain))
          (setq valid
            (and (>= count 1) (<= count 4096) (= (length chain) count)
                 (= (strlen header) 16)
                 (vl-every '(lambda (code)
                     (or (and (>= code 48) (<= code 57))
                         (and (>= code 97) (<= code 102)))) (vl-string->list header))
                 (vl-every '(lambda (item) (= (car item) 1)) chain)))))
      (if valid
        (progn
          (setq payload (apply 'strcat (mapcar 'cdr chain)))
          (setq valid (vl-every '(lambda (code) (and (>= code 0) (<= code 127)))
                                (vl-string->list payload)))))
      (if (not valid)
        (oe-profile-write-status directory "REJECTED_INVALID_ORIGINAL_PROFILE_XRECORD" "stored_header_or_chunks_invalid")
        (progn
          (setq file (open (strcat directory "/original_stored_profile.json") "w"))
          (if (not file)
            (oe-profile-write-status directory "REJECTED_PROFILE_CAPTURE_WRITE" "cannot_open_payload_file")
            (progn
              (write-line payload file)
              (close file)
              (setq file (open (strcat directory "/original_profile_header_hash.txt") "w"))
              (if (not file)
                (oe-profile-write-status directory "REJECTED_PROFILE_CAPTURE_WRITE" "cannot_open_header_file")
                (progn
                  (write-line header file)
                  (close file)
                  (oe-profile-write-status directory
                    "CAPTURED_ORIGINAL_STORED_PROFILE_RAW_NOT_IMPORTED_OR_VALIDATED"
                    "original_complete_chunks_exported")))))))))
  (princ))
