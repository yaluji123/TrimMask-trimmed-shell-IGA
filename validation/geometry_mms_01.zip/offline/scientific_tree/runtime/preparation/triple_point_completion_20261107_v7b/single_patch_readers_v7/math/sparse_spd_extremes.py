"""Numerical SPD check by unpivoted symmetric LU/LDL structure, then extremal pairs."""
import numpy as np
from scipy.sparse import csc_matrix,diags
from scipy.sparse.linalg import splu,eigsh,LinearOperator,norm
def extremes(matrix):
 S=csc_matrix(matrix);assert S.shape[0]==S.shape[1]and S.shape[0]>1 and np.isfinite(S.data).all();sym=float(norm(S-S.T)/max(norm(S),np.finfo(float).tiny));assert sym<1e-10
 lu=splu(S,permc_spec='MMD_AT_PLUS_A',diag_pivot_thresh=0.,options={'SymmetricMode':True,'Equil':False});assert np.array_equal(lu.perm_r,lu.perm_c),'symmetric permutation without numerical row pivot required'
 L=lu.L;U=lu.U;D=U.diagonal();assert np.isfinite(D).all()and np.all(D>0),'nonpositive LDL pivot';assert np.max(np.abs(L.diagonal()-1))<1e-12
 relation=float(norm(U-diags(D)@L.T)/norm(U));assert relation<1e-10,'U must equal D*L^T numerically'
 # Deterministic factor-solve residuals are checked without forming a dense product.
 errors=[]
 for offset in [0.37,1.13]:
  b=np.sin(np.arange(S.shape[0])+offset);x=lu.solve(b);errors.append(float(np.linalg.norm(S@x-b)/(np.linalg.norm(S.data)*np.linalg.norm(x)+np.linalg.norm(b))))
 assert max(errors)<1e-10
 inverse=LinearOperator(S.shape,matvec=lu.solve,dtype=np.float64);low,vector=eigsh(S,k=1,sigma=0.,which='LM',OPinv=inverse,tol=1e-10);high=eigsh(S,k=1,which='LA',return_eigenvectors=False,tol=1e-9)
 residual=float(np.linalg.norm(S@vector[:,0]-low[0]*vector[:,0]));assert low[0]>0 and residual<1e-8
 return low,vector,high,dict(method='SPD positive LDL pivots and symmetric factor relation; inverse iteration only after SPD check',symmetric_permutation=True,minimum_LDL_pivot=float(D.min()),U_minus_D_LT_relative=relation,deterministic_factor_backward_errors=errors,minimum_eigenpair_residual=residual,LU_L_nnz=L.nnz,LU_U_nnz=U.nnz,no_matrix_shift_or_regularization=True)
def self_check():
 from scipy.sparse import csr_matrix
 A=csr_matrix([[3.,1.],[1.,2.]]);lo,_,hi,q=extremes(A);exact=np.linalg.eigvalsh(A.toarray());assert np.max(np.abs([lo[0]-exact[0],hi[0]-exact[1]]))<1e-12
 rejected=0
 for bad in [np.diag([-10.,.1,2.]),np.diag([0.,1.,2.]),np.array([[1.,.3],[0.,1.]])]:
  try:extremes(csr_matrix(bad))
  except(AssertionError,RuntimeError):rejected+=1
 assert rejected==3
 return dict(SPD_extremes_match_dense=True,indefinite_singular_and_nonsymmetric_rejected=rejected)
if __name__=='__main__':print(self_check())
