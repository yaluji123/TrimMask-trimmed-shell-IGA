"""Independent flat-KL component audit. Does not load CAD or alter frozen source."""
import csv
import hashlib
import json
import math
import importlib.util
import sys
from functools import lru_cache
from pathlib import Path

import numpy as np
try:
    import mpmath
except ModuleNotFoundError:
    # Reuse the installed pure-Python dependency without changing the runtime.
    spec=importlib.util.spec_from_file_location('mpmath',r'D:\Anaconda3\Lib\site-packages\mpmath\__init__.py',submodule_search_locations=[r'D:\Anaconda3\Lib\site-packages\mpmath'])
    mpmath=importlib.util.module_from_spec(spec);sys.modules['mpmath']=mpmath;spec.loader.exec_module(mpmath)
import sympy as sp

HERE = Path(__file__).resolve().parent
SRC = Path(r'D:\BaiduSyncdisk\CODEX\IGAforCAD\validation\oe_revision_targeted_20260930\controlled_source_public98\IGAforCAD')
SOURCE_NAMES = ['Curves.cpp', 'Curves.h', 'Solver.cpp', 'igaPaletteCouplingAssembly.cpp', 'igaPaletteChildDlg.cpp']
EPS = np.finfo(float).eps


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def gauss(a, b, order=6):
    z, w = np.polynomial.legendre.leggauss(order)
    return list(zip(a + (z + 1) * (b-a) / 2, w * (b-a) / 2))


def integrate_square(expr, x, y):
    return float(sp.integrate(expr, (x, 0, 1), (y, 0, 1)))


def green_identity_checks():
    x, y, s = sp.symbols('x y s', real=True)
    nu = sp.Rational(3, 10)
    edges = [(s, 0, 0, -1), (1, s, 1, 0), (1-s, 1, 0, 1), (0, 1-s, -1, 0)]
    result = []
    for name, u, v in [('constant_bending', x*x, x*x),
                        ('corner_twist', x*y, x*y),
                        ('variable_twist_shear', x*x*y*y+x**3*y, x*y+x*x+2*y)]:
        H = sp.hessian(u, (x,y))
        Hv = sp.hessian(v, (x,y))
        C = (1-nu)*H + nu*sp.trace(H)*sp.eye(2)
        M = -C
        f = sp.diff(u,x,4)+2*sp.diff(u,x,2,y,2)+sp.diff(u,y,4)
        domain = integrate_square(sum(C[i,j]*Hv[i,j] for i in range(2) for j in range(2)),x,y)
        bulk = integrate_square(f*v,x,y)
        source_work = sp.Integer(0)
        corrected_work = sp.Integer(0)
        reduced_without_corner = sp.Integer(0)
        projected_raw_shear = sp.Integer(0)
        corner = sp.Integer(0)
        for xe, ye, nx, ny in edges:
            n = sp.Matrix([nx,ny]);t = sp.Matrix([-ny,nx])
            mnn=(n.T*M*n)[0];mnt=(n.T*M*t)[0]
            q=-(nx*sp.diff(sp.trace(H),x)+ny*sp.diff(sp.trace(H),y))
            vn=nx*sp.diff(v,x)+ny*sp.diff(v,y)
            vt=-ny*sp.diff(v,x)+nx*sp.diff(v,y)
            dtmnt=-ny*sp.diff(mnt,x)+nx*sp.diff(mnt,y)
            sub={x:xe,y:ye}
            source_work += sp.integrate((q*v+mnn*vn+mnt*vt).subs(sub),(s,0,1))
            corrected_work += sp.integrate((q*v-mnn*vn-mnt*vt).subs(sub),(s,0,1))
            reduced_without_corner += sp.integrate(((q+dtmnt)*v-mnn*vn).subs(sub),(s,0,1))
            projected_raw_shear += sp.integrate((q*v-mnn*vn).subs(sub),(s,0,1))
            endpoint=(mnt*v).subs(sub)
            corner += endpoint.subs(s,0)-endpoint.subs(s,1)
        source_res = float(domain-bulk-source_work)
        corrected_res = float(domain-bulk-corrected_work)
        reduced_res = float(domain-bulk-reduced_without_corner-corner)
        assert abs(corrected_res)<1e-12 and abs(reduced_res)<1e-12
        assert abs(source_res)>1e-5
        result.append({'case':name,'domain_bilinear':domain,'independent_body_work':bulk,
                       'source_boundary_work':float(source_work),'source_green_residual':source_res,
                       'source_status':'FAIL', 'moment_sign_candidate_residual':corrected_res,
                       'full_unreduced_candidate_status':'PASS_COMPONENT',
                       'reduced_without_corner_residual':float(domain-bulk-reduced_without_corner),
                       'normal_rotation_only_raw_shear_residual':float(domain-bulk-projected_raw_shear),
                       'independent_corner_work':float(corner),'reduced_with_corner_residual':reduced_res})
    return result


def knots(n, p=3):
    spans=n-p
    return np.array([0.]*(p+1)+[i/spans for i in range(1,spans)]+[1.]*(p+1))


def basis(t, k, p=3):
    n=len(k)-p-1
    @lru_cache(None)
    def b(i,degree,deriv):
        if deriv>degree or i<0 or i+degree+1>=len(k):
            return 0.
        if degree==0:
            return float(deriv==0 and (k[i]<=t<k[i+1] or t==1. and i==n-1))
        d1=k[i+degree]-k[i];d2=k[i+degree+1]-k[i+1]
        if deriv==0:
            return ((t-k[i])/d1*b(i,degree-1,0) if d1 else 0.)+((k[i+degree+1]-t)/d2*b(i+1,degree-1,0)if d2 else 0.)
        return (degree/d1*b(i,degree-1,deriv-1)if d1 else 0.)-(degree/d2*b(i+1,degree-1,deriv-1)if d2 else 0.)
    return np.array([[b(i,p,d)for i in range(n)]for d in range(4)])


def derivatives(u,v,k,L,W):
    bu=basis(u,k);bv=basis(v,k)
    return {(a,b):np.outer(bu[a],bv[b]).ravel()/L**a/W**b
            for a,b in [(0,0),(1,0),(0,1),(2,0),(1,1),(0,2),(3,0),(2,1),(1,2),(0,3)]}


def operators(d,nx,ny,E,t,nu,correct_moment=False):
    count=len(d[(0,0)]);N=np.zeros((6,count*3));V=np.zeros_like(N)
    ids=np.arange(count)*3
    for row in range(3):N[row,ids+row]=d[(0,0)]
    N[3,ids+2]=d[(0,1)];N[4,ids+2]=-d[(1,0)]
    Dm=E*t/(1-nu*nu)*np.array([[1,nu,0],[nu,1,0],[0,0,(1-nu)/2]])
    Bm=np.zeros((3,count*3))
    Bm[0,ids]=d[(1,0)];Bm[1,ids+1]=d[(0,1)]
    Bm[2,ids]=d[(0,1)];Bm[2,ids+1]=d[(1,0)]
    stress=Dm@Bm
    V[0]=nx*stress[0]+ny*stress[2];V[1]=nx*stress[2]+ny*stress[1]
    D=E*t**3/(12*(1-nu*nu))
    V[2,ids+2]=-D*(nx*(d[(3,0)]+d[(1,2)])+ny*(d[(2,1)]+d[(0,3)]))
    hxx=d[(2,0)];hyy=d[(0,2)];hxy=d[(1,1)]
    mnn=-D*((nx*nx+nu*ny*ny)*hxx+(ny*ny+nu*nx*nx)*hyy+2*(1-nu)*nx*ny*hxy)
    mnt=-D*(1-nu)*(-nx*ny*hxx+nx*ny*hyy+(nx*nx-ny*ny)*hxy)
    V[3,ids+2]=nx*mnt+ny*mnn
    V[4,ids+2]=ny*mnt-nx*mnn
    if correct_moment:V[3:6]*=-1
    return N,V


def assemble_flat(n=13,L=100.,W=100.,E=206000.,t=7.,nu=.3):
    k=knots(n);count=n*n;ndof=count*3;K=np.zeros((ndof,ndof))
    Dm=E*t/(1-nu*nu)*np.array([[1,nu,0],[nu,1,0],[0,0,(1-nu)/2]])
    Db=t*t/12*Dm
    domain=[]
    breaks=np.unique(k)
    for a,b in zip(breaks[:-1],breaks[1:]):
        for c,e in zip(breaks[:-1],breaks[1:]):
            for u,wu in gauss(a,b,4):
                for v,wv in gauss(c,e,4):
                    d=derivatives(u,v,k,L,W);w=wu*wv*L*W
                    active=np.flatnonzero(d[(0,0)]!=0);ids=(active[:,None]*3+np.arange(3)).ravel()
                    bm=np.zeros((3,len(ids)));bb=np.zeros_like(bm)
                    bm[0,0::3]=d[(1,0)][active];bm[1,1::3]=d[(0,1)][active]
                    bm[2,0::3]=d[(0,1)][active];bm[2,1::3]=d[(1,0)][active]
                    bb[0,2::3]=d[(2,0)][active];bb[1,2::3]=d[(0,2)][active];bb[2,2::3]=2*d[(1,1)][active]
                    K[np.ix_(ids,ids)]+=(bm.T@Dm@bm+bb.T@Db@bb)*w
                    domain.append((u*L,v*W,w,d))
    edges=[]
    for edge in range(4):
        for a,b in zip(breaks[:-1],breaks[1:]):
            for s,ws in gauss(a,b,6):
                u,v,nx,ny,ds=[(s,0.,0.,-1.,L),(1.,s,1.,0.,W),(1.-s,1.,0.,1.,L),(0.,1.-s,-1.,0.,W)][edge]
                edges.append((edge,u*L,v*W,ws*ds,derivatives(u,v,k,L,W),nx,ny))
    gx=np.array([np.mean(k[i+1:i+4])for i in range(n)])*L
    gy=np.array([np.mean(k[i+1:i+4])for i in range(n)])*W
    X,Y=np.meshgrid(gx,gy,indexing='ij');R=np.zeros((ndof,6));ix=np.arange(count)*3
    R[ix,0]=1;R[ix+1,1]=1;R[ix+2,2]=1
    R[ix+2,3]=Y.ravel();R[ix+2,4]=-X.ravel();R[ix,5]=-Y.ravel();R[ix+1,5]=X.ravel()
    Q=np.linalg.qr(R,mode='complete')[0];Z=Q[:,6:]
    return {'K':K,'domain':domain,'edges':edges,'knots':k,'R':R,'Z':Z,'params':(L,W,E,t,nu)}


def boundary_matrices(model,correct_moment=False,reference_length=1.):
    K=model['K'];ndof=len(K);P=np.zeros_like(K);C=np.zeros_like(K);rows=[]
    L,W,E,t,nu=model['params']
    for edge,x,y,w,d,nx,ny in model['edges']:
        if edge!=3:continue
        N,V=operators(d,nx,ny,E,t,nu,correct_moment)
        N[3:6]*=reference_length;V[3:6]/=reference_length
        P+=w*(N.T@N);C+=w*(V.T@N);rows.append(math.sqrt(w)*V)
    R=np.vstack(rows)
    return P,C,R


def generalized_bound(K,R,Z=None):
    if Z is None:Z=np.eye(len(K))
    G=Z.T@K@Z
    vals,vec=np.linalg.eigh((G+G.T)/2)
    threshold=100*EPS*len(G)*max(np.max(np.abs(vals)),1.)
    if vals[0]<=threshold:
        raise ValueError(f'Energy metric is not positive on declared quotient: {vals[0]} <= {threshold}')
    T=Z@vec/np.sqrt(vals)
    B=R@T
    lam=float(np.linalg.norm(B,2)**2)
    return lam


def spectral_support_check(model):
    K=model['K'];P,C,R=boundary_matrices(model)
    active=np.flatnonzero(np.any(P!=0,axis=0))
    union=np.union1d(active,np.flatnonzero(np.any(R!=0,axis=0)))
    full=generalized_bound(K,R,model['Z'])
    cropped=generalized_bound(K[np.ix_(active,active)],R[:,active])
    union_crop=generalized_bound(K[np.ix_(union,union)],R[:,union])
    interior=np.setdiff1d(np.arange(len(K)),union)
    # Exact energy relaxation. Quotient the physical rigid traces without adding
    # physical boundary clamps to either the original patch or its trace.
    kuu=K[np.ix_(union,union)];kuj=K[np.ix_(union,interior)]
    schur=kuu-kuj@np.linalg.solve(K[np.ix_(interior,interior)],kuj.T)
    qi=np.linalg.qr(model['R'][union],mode='complete')[0][:,6:]
    schur_bound=generalized_bound(schur,R[:,union],qi)
    assert abs(schur_bound/full-1)<1e-8
    B=R@(model['Z'])
    G=model['Z'].T@K@model['Z'];ev,U=np.linalg.eigh((G+G.T)/2)
    T=model['Z']@U/np.sqrt(ev)
    _,_,vh=np.linalg.svd(R@T,full_matrices=False)
    witness=T@vh[0]
    a=float(np.linalg.norm(R@witness)**2);energy=float(witness@K@witness)
    violation=a-cropped*energy
    assert full>=cropped*(1-1e-8) and full>=union_crop*(1-1e-8)
    return {'dofs':len(K),'analytic_rigid_modes':6,
            'rigid_energy_relative_residual':float(np.linalg.norm(K@model['R'])/(np.linalg.norm(K)*np.linalg.norm(model['R']))),
            'rigid_flux_relative_residual':float(np.linalg.norm(R@model['R'])/(np.linalg.norm(R)*np.linalg.norm(model['R']))),
            'N_trace_support':len(active),'N_V_union_support':len(union),
            'principal_N_support_lambda':cropped,'principal_union_lambda':union_crop,
            'exact_relaxed_Schur_quotient_lambda':schur_bound,
            'Schur_vs_whole_patch_relative_difference':abs(schur_bound/full-1),
            'whole_patch_quotient_lambda':full,'full_over_N_principal':full/cropped,
            'full_over_union_principal':full/union_crop,
            'witness_full_flux_norm_squared':a,'witness_domain_energy':energy,
            'N_principal_bound_violation':violation,
            'N_principal_is_full_energy_bound':violation<=1e-8*max(a,1.)}


def manufactured_functions(params,amplitude):
    L,W,E,t,nu=params
    x,y=sp.symbols('x y',real=True);X=x/L;Y=y/W
    u=amplitude*(X**2*Y+sp.Rational(3,10)*X*Y**2)
    v=amplitude*(sp.Rational(7,10)*X**2+sp.Rational(1,5)*X**2*Y**2)
    w=amplitude*(X**4*Y**2+sp.Rational(3,10)*X**2*Y**4)
    stress=E*t/(1-nu*nu)*sp.Matrix([sp.diff(u,x)+nu*sp.diff(v,y),nu*sp.diff(u,x)+sp.diff(v,y),(1-nu)/2*(sp.diff(u,y)+sp.diff(v,x))])
    f=sp.Matrix([-sp.diff(stress[0],x)-sp.diff(stress[2],y),-sp.diff(stress[2],x)-sp.diff(stress[1],y),E*t**3/(12*(1-nu*nu))*(sp.diff(w,x,4)+2*sp.diff(w,x,2,y,2)+sp.diff(w,y,4))])
    D=E*t**3/(12*(1-nu*nu));H=sp.hessian(w,(x,y));CH=D*((1-nu)*H+nu*sp.trace(H)*sp.eye(2))
    q=sp.Matrix([-sp.diff(CH[0,0],x)-sp.diff(CH[0,1],y),-sp.diff(CH[1,0],x)-sp.diff(CH[1,1],y)])
    return tuple(sp.lambdify((x,y),value,'numpy')for value in [sp.Matrix([u,v,w]),f,stress,CH,q])


def independent_load(model,amplitude):
    field,body,stress,CH,q=manufactured_functions(model['params'],amplitude)
    count=len(model['K'])//3;ix=np.arange(count)*3;F=np.zeros(count*3)
    for x,y,w,d in model['domain']:
        f=np.asarray(body(x,y),dtype=float).ravel()
        for c in range(3):F[ix+c]+=w*d[(0,0)]*f[c]
    # Natural load is independently evaluated from the continuum Green formula.
    for edge,x,y,w,d,nx,ny in model['edges']:
        if edge==3:continue
        sig=np.asarray(stress(x,y),dtype=float).ravel();h=np.asarray(CH(x,y),dtype=float)
        qb=np.asarray(q(x,y),dtype=float).ravel()
        F[ix]+=w*d[(0,0)]*(nx*sig[0]+ny*sig[2])
        F[ix+1]+=w*d[(0,0)]*(nx*sig[2]+ny*sig[1])
        hn=h@np.array([nx,ny])
        F[ix+2]+=w*(d[(0,0)]*float(qb@np.array([nx,ny]))+d[(1,0)]*hn[0]+d[(0,1)]*hn[1])
    return F,field


def solve_case(model,correct_moment,reference_length,full_bound,amplitude,alpha=210.):
    K=model['K'];P,C,R=boundary_matrices(model,correct_moment,reference_length)
    if full_bound:
        lam=generalized_bound(K,R,model['Z'])
    else:
        active=np.flatnonzero(np.any(P!=0,axis=0));lam=generalized_bound(K[np.ix_(active,active)],R[:,active])
    A=K-C-C.T+alpha*lam*P
    F,field=independent_load(model,amplitude)
    solution=np.linalg.solve(A,F)
    ev=np.linalg.eigvalsh((A+A.T)/2)
    error=0.;exact=0.;point_error=0.
    L,W,_,_,_=model['params'];k=model['knots'];ix=np.arange(len(K)//3)*3
    for u in np.linspace(0,1,13):
        for v in np.linspace(0,1,13):
            d=derivatives(float(u),float(v),k,L,W);computed=np.array([d[(0,0)]@solution[ix+c]for c in range(3)])
            target=np.asarray(field(u*L,v*W),dtype=float).ravel()
            error+=float(np.linalg.norm(computed-target)**2);exact+=float(np.linalg.norm(target)**2)
            point_error=max(point_error,float(abs(computed[2]-target[2])))
    trace_residual=math.sqrt(max(float(solution@P@solution),0.))
    return {'lambda':lam,'min_eigenvalue':float(ev[0]),'condition_2':float(ev[-1]/ev[0]),
            'symmetric_relative_error':float(np.linalg.norm(A-A.T)/np.linalg.norm(A)),
            'algebraic_relative_residual':float(np.linalg.norm(A@solution-F)/np.linalg.norm(F)),
            'sampled_relative_displacement_error':math.sqrt(error/exact),
            'sampled_w_max_abs_error_in_working_length_units':point_error,
            'scaled_boundary_trace_L2':trace_residual,
            'strain_energy':float(solution@K@solution/2)},A,F,solution


def unit_and_solve_checks(mm_model):
    m_model=assemble_flat(n=13,L=.1,W=.1,E=206000.e6,t=.007)
    rows=[];data={}
    variants=[('legacy_original',False,False,False),
              ('work_conjugate_only',False,True,False),
              ('canonical_green_full_energy_candidate',True,True,True)]
    for name,correct,physical_scale,full in variants:
        pairs=[]
        for units,model,length,amplitude in [('N_mm',mm_model,1.,.1),('N_m',m_model,.001,.0001)]:
            ell=length if physical_scale else 1.
            report,A,F,u=solve_case(model,correct,ell,full,amplitude)
            rows.append({'variant':name,'units':units,'reference_length_numeric':ell,**report})
            pairs.append((A,F,u))
            if units=='N_mm' and name=='canonical_green_full_energy_candidate':
                P,C,R=boundary_matrices(model,correct,ell)
                np.savez_compressed(HERE/'flat507_component_packet.npz',K=model['K'],
                    P=P,C=C,V_weighted=R,rigid=model['R'],quotient=model['Z'],
                    augmented=A,independent_force=F,solution=u,knots=model['knots'],
                    params=np.asarray(model['params']),reference_length=ell,alpha=210.)
        amm,fmm,umm=pairs[0];am,fm,um=pairs[1]
        data[name]={'physical_matrix_covariance_error':float(np.linalg.norm(am/1000-amm)/np.linalg.norm(amm)),
                    'physical_load_covariance_error':float(np.linalg.norm(fm-fmm)/np.linalg.norm(fmm)),
                    'converted_solution_relative_difference':float(np.linalg.norm(um*1000-umm)/np.linalg.norm(umm))}
    assert data['work_conjugate_only']['physical_matrix_covariance_error']<1e-9
    assert data['canonical_green_full_energy_candidate']['physical_matrix_covariance_error']<1e-9
    assert data['legacy_original']['physical_matrix_covariance_error']>1e-4
    return rows,data


def exact_bending_residual_check(model):
    L,W,E,t,nu=model['params'];n=13;k=model['knots']
    greville=np.array([np.mean(k[i+1:i+4])for i in range(n)])
    collocation=np.array([basis(float(x),k)[0]for x in greville])
    cx=np.linalg.solve(collocation,greville**2)
    cx[np.abs(cx)<1e-14]=0.
    U=.1;c=np.zeros(len(model['K']));ix=np.arange(n*n)*3
    c[ix+2]=U*np.outer(cx,np.ones(n)).ravel()
    D=E*t**3/(12*(1-nu*nu));CH=np.diag([2*D*U/L**2,2*D*nu*U/L**2])
    F=np.zeros_like(c)
    for edge,x,y,w,d,nx,ny in model['edges']:
        if edge==3:continue
        hn=CH@np.array([nx,ny])
        F[ix+2]+=w*(d[(1,0)]*hn[0]+d[(0,1)]*hn[1])
    results={}
    for name,correct in [('legacy_source_moment',False),('canonical_moment_candidate',True)]:
        P,C,R=boundary_matrices(model,correct,1.)
        lam=generalized_bound(model['K'],R,model['Z'])
        A=model['K']-C-C.T+210*lam*P
        residual=A@c-F
        results[name]={'absolute_residual_norm':float(np.linalg.norm(residual)),
                       'relative_to_independent_natural_load':float(np.linalg.norm(residual)/np.linalg.norm(F)),
                       'left_clamped_trace_norm':float(np.linalg.norm(P@c)),
                       'independent_body_load_is_zero':True}
    assert results['legacy_source_moment']['relative_to_independent_natural_load']>1e-3
    assert results['canonical_moment_candidate']['relative_to_independent_natural_load']<1e-9
    return results


def main():
    HERE.mkdir(exist_ok=True)
    manifest={name:digest(SRC/name)for name in SOURCE_NAMES}
    result={'scope':'Independent flat KL specializations and continuous manufactured loads; no CAD or native plugin execution',
            'source_directory':str(SRC),'source_sha256':manifest,
            'runtime':{'python':sys.version,'executable':sys.executable,'numpy':np.__version__,'sympy':sp.__version__,'mpmath':mpmath.__version__,'mpmath_path':mpmath.__file__},
            'green_identity':green_identity_checks()}
    model=assemble_flat()
    result['exact_representable_bending_residual']=exact_bending_residual_check(model)
    result['spectral_support']=spectral_support_check(model)
    result['singular_pencil_counterexample']={'K':[[1,0],[0,0]],'A':[[2,0],[0,6]],
        'finite_QZ_ratio':2,'test_vector':[0,1],'A_quadratic':6,'lambda_K_quadratic':0,
        'finite_ratio_is_trace_bound':False}
    sentinel=1e12;T=np.array([[1,1],[1,-1]],dtype=float)/math.sqrt(2)
    transformed=T@np.array([sentinel,sentinel])
    result['constraint_mask_counterexample']={'free_sentinel':sentinel,'raw_both_free':True,
        'source_transformed_values':transformed.tolist(),'source_active_flags':(np.abs(transformed)<1e8).tolist(),
        'status':'FAIL_PARTIAL_MASK_COVARIANCE'}
    rows,units=unit_and_solve_checks(model)
    result['unit_covariance']=units
    result['manufactured_linear_solves']=rows
    result['status']='CORE_FAILURES_RETAINED_CANDIDATES_COMPONENT_ONLY'
    assert all(digest(SRC/name)==h for name,h in manifest.items())
    result['frozen_source_unchanged']=True
    result['script_sha256']=digest(Path(__file__))
    (HERE/'mechanics_results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    with (HERE/'manufactured_solves.csv').open('w',newline='',encoding='utf-8-sig')as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    print(json.dumps({'green_identity':result['green_identity'],'spectral_support':result['spectral_support'],
                      'unit_covariance':units,'manufactured_linear_solves':rows,'status':result['status']},ensure_ascii=False,indent=2))


if __name__=='__main__':main()
