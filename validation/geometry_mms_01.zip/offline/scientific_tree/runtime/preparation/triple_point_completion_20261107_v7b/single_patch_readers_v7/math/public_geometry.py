"""Reuse frozen Fraction moment/area mathematics on the final nine captures."""
from pathlib import Path
import argparse,csv,hashlib,importlib.util,json,sys

HERE=Path(__file__).resolve().parent
ROOT=Path(r'D:\BaiduSyncdisk\CODEX\投稿\二次修稿\准备工作')
SOURCE='90f72156bd9f1430e25177e91b6a69b89c4434f81934dfdee19b20eef2a96566'
RUNTIME='50999199bb7bf6770b7446beae7c5e2600294276d6ba858ab7a616f873bf5a84'
OLD=ROOT/'geometry/native98/actual_duffy_v5/protocol_corrections_v1'
NAMES=['duffy_ref_v3','ear7_v1','clipper7_v1','autoclip7_v1','autoear7_v1',
       'ear3_v2','mask6_v1','mask12_v1','mask24_v1']

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def save(p,q):
    assert not p.exists(),p
    p.write_text(json.dumps(q,indent=2,default=str,allow_nan=False),encoding='utf-8')
def module(name,digest):
    p=OLD/(name+'.py');assert sha(p)==digest
    s=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(s)
    sys.modules[name]=m;s.loader.exec_module(m);return m

def run(index,out_dir,context):
    assert not out_dir.exists();out_dir.mkdir(parents=True);a=argparse.Namespace(out_dir=out_dir)
    m=module('validate_native_moments','12dfb3be4f4b991c38395414c741265874a67c61689f6bad31b15867b483ad29')
    raw=module('verify_raw_bulk_area','796a67a2ffc30e4376a6b1c4004fbe7e0d2437613e8a8bdd3b768c46b9baa390')
    save(a.out_dir/'original_math_self_tests.json',dict(
        moments=m.self_test(a.out_dir/'synthetic_log_controls'),raw_area=raw.self_test()))
    inputs={};results=[]
    def bind(p,digest=None):
        h=sha(p);assert digest is None or h==digest,p
        assert str(p) not in inputs or inputs[str(p)]==h
        inputs[str(p)]=h;return p
    original=m.load(bind(ROOT/'geometry/native98/raw/trim_geometry_819.json'))
    from single_patch_context_v7 import METHODS
    for suffix in METHODS:
        entry=index['public_profiles'][suffix];case=context.case(entry,'quadrature',suffix,False);label=case.name
        neutral=entry['neutral_report'];identity=read(context.bind(neutral['path'],neutral['sha256']));assert identity['status']=='DATA_IDENTITY_FINAL_RUNTIME_CASE_ONLY'and identity['source_binding_sha256']==SOURCE and identity['runtime_manifest_sha256']==RUNTIME and Path(identity['case']).resolve()==case.resolve()
        bind(case/'source_runtime_manifest.json',RUNTIME);bind(case/'applied_source_binding.json',SOURCE)
        proc=read(bind(case/'process_result.json'));assert proc['exit_code']==0 and proc['natural_owned_child_exit']
        assert read(bind(case/'owned_process_resource_observations.json'))['within_declared_observed_memory']
        origin=read(bind(case/'original_input_before_after.json'))
        assert origin['exact_sha_and_mtime_unchanged'] and origin['before']['sha256']=='96478f849637db80e7ca03dbf5900e6878db8c77cd69aec84a7661e6abd9bc23'
        bind(case/'input_model.dwg',origin['before']['sha256'])
        plan=read(bind(case/'launch_plan.json'));env=plan['explicit_IGA_child_environment']
        assert env['IGA_OE_BULK_MEASURE_AUDIT']=='1' and env['IGA_OE_BOUNDARY_DOMAIN_V2']=='1'
        for name in ['stdout.log','stderr.log']:bind(case/name)
        assert not m.audit_log_errors(case)
        profile=read(bind(case/'executed_profile.json'))
        assert profile['enableGeoNonlinear'] is False and profile['enableGeoNLReanalysis'] is False
        g=m.load(bind(case/'input_audit/load_stage_geometry_819.json'))
        captured=m.load(bind(case/'capture/trim_geometry_819.json'))
        for key in ['shell_handle','degree_u','degree_v','controls_u','controls_v','knots_u','knots_v','control_global_Vg','weights']:
            assert m.ieee(g[key])==m.ieee(original[key]),(label,key)
        for key in ['outer_loop','hole_loops','outer_is_full_frame','outer_nontrivial']:
            assert m.ieee(captured[key])==m.ieee(original[key]),(label,key)
        p=bind(case/'source_diagnostics_after/trim_cell_diagnostics.csv')
        with p.open(encoding='utf-8-sig',newline='')as f:rows=list(csv.DictReader(f))
        assert len(rows)==98 and len({(r['shellH'],r['element'])for r in rows})==98
        isref=suffix=='duffy_ref'
        assert (env.get('IGA_OE_TRI_REFERENCE_DUFFY_GL6')=='1')==isref
        p=case/'input_audit/cut_cell_polynomial_moments_819.jsonl'
        assert not isref or p.is_file(),'Duffy reference must have actual moments'
        if p.is_file():
            records=[m.parse(line) for line in bind(p).read_text().splitlines()]
            moment=m.inspect_records(records,rows,require_reference=isref,bulk_order=4)
            assert not moment['errors'],(label,moment['errors'])
            with (a.out_dir/(label+'_784_moments.csv')).open('x',encoding='utf-8-sig',newline='')as f:
                w=csv.DictWriter(f,fieldnames=list(moment['comparisons'][0]));w.writeheader();w.writerows(moment.pop('comparisons'))
        else:
            assert not isref and env.get('IGA_OE_CUT_MOMENT_AUDIT')!='1'
            moment=dict(status='NONREFERENCE_MOMENT_CAPTURE_NOT_REQUESTED_OR_CLAIMED',
                        scalar_comparisons=0,actual_current_moments_observed=False)
        probe=m.load(bind(case/'input_audit/bulk_measure_raw_bulk_before_support_819.json'))
        area=raw.examine(probe,g,'raw_bulk_before_support')
        errors=[e for e in area['errors'] if not e.startswith('raw bilinear material-area target1e-8 failed ')]
        assert not errors,(label,errors)
        assert not isref or not area['errors'],area['errors']
        result=dict(case=label,moments=moment,raw_area=area,
                    original_registered_geometry_exact_binary64_identity=True,
                    raw_area_target_met=not area['errors'],
                    low_order_reference_target_failure_preserved=True,
                    full_K_support_mask_or_PDE_accuracy_accepted=False)
        save(a.out_dir/(label+'_geometry_audit.json'),result);results.append(result)
    for p,h in inputs.items():context.bind(Path(p),h)
    context.finish()
    q=dict(status='PASS_FINAL1212_ALL9_BOUND_GEOMETRY_AND_MEASUREMENT_CAPTURE',
           source_binding_sha256=SOURCE,runtime_manifest_sha256=RUNTIME,rows=results,
           original_Fraction_mathematics_and_thresholds_reused_without_change=True,
           reference_Duffy_784_moment_and_three_raw_area_targets_passed=True,
           nonreference_accuracy_failures_not_relabelled_PASS=True,
           Host_compiler_or_solver_started=False,scientific_paper_acceptance=False,
           input_manifest=context.identity.manifest(),
           producer_sha256=sha(Path(__file__)))
    save(a.out_dir/'all_nine_geometry_and_raw_area.json',q)
    print(json.dumps(dict(status=q['status'],cases=len(results),
                         actual_scalar_moments=sum(r['moments']['scalar_comparisons']for r in results))))

if __name__=='__main__':raise SystemExit('Use read_single_patch_v7.py')
