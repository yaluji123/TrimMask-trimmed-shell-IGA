from pathlib import Path
import sys,json,math,csv,collections,argparse
from fractions import Fraction as F
HERE=Path(__file__).resolve().parent
sys.dont_write_bytecode=True
if hasattr(sys,'set_int_max_str_digits'):sys.set_int_max_str_digits(0)
sys.path.insert(0,str(HERE/'math'))
import exact_panel_core as C
from exact_observed_core import PAIRS
from line_input_math import edge_curve,replay_line_errors
from kahan_math import kahan

def need(ok,message):
 if not ok:raise ValueError(message)
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def rows(p):
 with Path(p).open(encoding='utf-8-sig',newline='')as f:return list(csv.DictReader(f))
def numbers(p,n):
 data=rows(p);need(len(data)==n,'complete coefficient/force vector');result={int(r['global_dof_zero_based']):float(r['value'])for r in data};need(len(result)==n and set(result)==set(range(n))and all(math.isfinite(x)for x in result.values()),'unique finite vector entries');return result

def main():
 ap=argparse.ArgumentParser(description='Check saved quadrature inputs and arithmetic; no integration, eigendecomposition or PDE solve.');ap.add_argument('--package-root',type=Path,default=HERE.parents[1]);a=ap.parse_args();root=a.package_root.resolve();links=read(HERE/'shared_public_data.json')
 for name,rel in links.items():need((root/rel).is_file(),'extract topic data first: '+name)
 # Original nine control vectors, full physical map, material and pure force.
 g=read(HERE/'plate9/common/geometry_material.json');registered=read(HERE/'plate9/common/registered_geometry.json');existing=read(root/links['registered_plate_geometry']);need(registered==existing,'same published registered polygon geometry')
 for k in ['degree_u','degree_v','controls_u','controls_v','knots_u','knots_v','weights','control_global_Vg']:need(g[k]==registered[k],'same actual plate carrier '+k)
 need((g['controls_u'],g['controls_v'],g['dofPN'])==(39,39,3),'original plate dimensions');mapping=rows(HERE/'plate9/common/patch_external_819.csv');need(len(mapping)==4563,'complete control map');seen=set();dofs=set()
 for r in mapping:
  cp=int(r['local_cp']);co=int(r['component']);gd=int(r['global_dof_zero_based']);need((cp,co)not in seen and 0<=cp<1521 and 0<=co<3 and int(r['shell_handle'])==819,'unique physical control/component');seen.add((cp,co));dofs.add(gd);need(gd==3*(int(r['Node_one_based'])-1)+co,'original Node/globalDOF relation');need(int(r['control_i'])==cp//39 and int(r['control_j'])==cp%39,'original row order');need([float(r[k])for k in ['cp_x','cp_y','cp_z']]==g['control_global_Vg'][3*cp:3*cp+3],'control geometry map')
 need(dofs==set(range(4563)),'all original DOFs covered');force=numbers(HERE/'plate9/common/pre_boundary_force.csv',4563);cases=read(HERE/'plate9/cases.json');need(len(cases)==9 and len(set(cases))==9,'all nine strategies');probes=0
 for name in cases:
  folder=HERE/'plate9/cases'/name;u=numbers(folder/'global_solution.csv',4563);need(all(u[int(r['global_dof_zero_based'])]==0 for r in mapping if int(r['component'])==2),'membrane uz retained and exactly zero');profile=read(folder/'executed_profile.json');need(profile['enableGeoNonlinear']is False,'recorded linear profile');p=read(folder/'bilinear_probe.json');need(p['stage']=='raw_bulk_before_support'and p['valid']is True and(p['m'],p['n'],p['matrix_rows'],p['matrix_cols'])==(39,39,4563,4563),'original bilinear probe');need(all(math.isfinite(float(p[k]))for k in ['E_N_per_mm2','nu','t_mm','epsilon','Qx_N_mm','Qy_N_mm','Qbiaxial_N_mm','areaX_mm2','areaY_mm2','areaBiaxial_mm2']),'finite raw probe values');need([float(p[k])for k in ['E_N_per_mm2','nu','t_mm']]==[float(g[k])for k in ['E','nu','constant_t']],'probe material identity');need(isinstance(read(folder/'physical_boundary_snapshots.json'),list),'physical BC snapshots');probes+=1
 # All raw accepted/final points and selected panels, with original source arithmetic.
 gp=rows(HERE/'line4/gp.csv');points=rows(HERE/'line4/points.csv');panels=rows(HERE/'line4/panels.csv');byuid={int(r['uid']):r for r in gp};accepted={int(r['uid']):r for r in points};rawpanels={(int(r['entry']),int(r['attempt']),int(r['batch']),int(r['panel'])):r for r in panels};need(len(gp)==len(byuid)==20512 and len(points)==len(accepted)==30672,'complete accepted/final UID inventory');need(set(byuid)<=set(accepted)and len(set(accepted)-set(byuid))==10160,'accepted outside final remains present')
 finalized={}
 with(HERE/'line4/events.jsonl').open()as stream:
  for line in stream:
   event=json.loads(line)
   if event.get('kind')=='matched_weight_finalized':
    key=int(event['uid']);need(key not in finalized,'unique matched weight finalization');finalized[key]=event
 need(len(finalized)==192,'all actual matched finalized weights')
 for uid,row in byuid.items():
  need(all(row[k]==accepted[uid][k]for k in ['entry','attempt','batch','u1','v1','u2','v2']),'same raw accepted/final UID coordinates')
  if uid in finalized:need(float(row['scale'])==float(finalized[uid]['actualfinalscale'])and float(accepted[uid]['scale'])==float(finalized[uid]['parametric_weight']),'actual matched parametric/final weight event')
  else:need(row['scale']==accepted[uid]['scale'],'unmatched accepted/final scale identity')
 registry=read(HERE/'line4/couples_registry_input_only.json');relations={int(x['registry_index']):x for x in registry['relations']};need(len(relations)==73,'all actual hull relations');props={int(x['entry']):x for x in read(HERE/'line4/entry_properties.json')};geos={int(p.stem.rsplit('_',1)[1]):read(p)for p in(HERE/'hull4x_geometry').glob('trim_geometry_*.json')};need(len(geos)==23,'complete shared hull geometry');cache={};observed_uids=set();panelcount=bad=0;maximum=0.;bound_checks=0
 with(HERE/'line4/panel_diagnostics.jsonl').open(encoding='utf-8')as f:
  for line in f:
   x=json.loads(line);entry=int(x['entry']);p=x['panel'];key=(entry,int(p['attempt']),int(p['batch']),int(p['panel']));need(rawpanels[key]==p and int(p['accepted_points'])==4,'unchanged raw four-point panel');uids=x['UIDs'];need(len(uids)==4 and not(observed_uids&set(uids)),'unique original panel GP association');observed_uids.update(uids);need(all(int(byuid[u]['entry'])==entry and int(byuid[u]['attempt'])==int(p['attempt'])and int(byuid[u]['batch'])==int(p['batch'])for u in uids),'panel belongs to actual final GP batch')
   master=int(x['integration_side_one_based'])-1;need(master==int(props[entry]['actual_integration_side_one_based'])-1,'actual integration side retained')
   if entry not in cache:
    rel=relations[entry];rawcurves=[s['curve']for s in rel['sides']]
    if x['route']=='matched':
     first=byuid[uids[0]];rawcurves=[edge_curve(geos[int(s['surface_handle']['decimal'])],int(first['edge'+str(i+1)]))for i,s in enumerate(rel['sides'])]
    cache[entry]=[C.Curve(c)for c in rawcurves]
   aa,bb=C.q(p['a']),C.q(p['b']);tt=[C.q(accepted[u]['s'+str(master+1)])for u in uids];ds=[C.q(byuid[u]['scale'])for u in uids];errors=replay_line_errors(aa,bb,tt,ds,cache[entry][master]);need(errors==x['parent_errors']==x['parent_error_replay'],'original eight saved float errors reproduced exactly');failed=max(errors)>1e-13;need(failed==x['parent_failed'],'original strict failure retained');bad+=failed;maximum=max(maximum,max(errors));enc=x['encoding'];need(x['parent_replay_bitwise_equal']and x['parent_1e13_moment_FAIL_unchanged'],'original saved replay conclusions')
   for ideal,encoded,delta in zip(enc['ideal'],enc['encoded'],enc['encoding_delta']):need(F(encoded)-F(ideal)==F(delta),'original saved encoded-minus-ideal moment identity');bound_checks+=1
   panelcount+=1
 need(panelcount==5128 and bad==456 and observed_uids==set(byuid),'all selected panels/failed records/GPs retained');need(maximum==7.784930478038632e-10,'original maximum scaled error');need(bound_checks==5128*8,'all original saved encoded moments')
 # Both faces and all original geometry tokens; the identical original Kahan update is used.
 native={}
 for p in(HERE/'cut_cell/native_moments').glob('*.jsonl'):
  with p.open()as f:
   for line in f:
    n=json.loads(line);key=(int(n['shellH']),int(n['element']));need(key not in native and n['valid']is True and len(n['signedLocalMoments'])==8,'complete unique original Native cut record');native[key]=n
 need(len(native)==606,'all606 original Native cut records');inventory=read(HERE/'cut_cell/native_moment_inventory.json');need(len(inventory)==23 and sum(x['records']for x in inventory)==606,'empty noncut files explicitly inventoried');bounds={};states={}
 for owner,g in geos.items():
  for c in g['cells']:
   key=(owner,int(c['element']));box=tuple(map(float,c['bounds']));bounds[owner,box]=key;states[key]={'bounds':box,'acc':[[0.,0.]for _ in PAIRS],'count':0}
 need(len(states)==8160,'all8160 original spans');pair_fields=['patch_handle','quadrature_index','index_u','index_v','u','v','w1','w2','weight','retained_domain','span_u0','span_u1','span_v0','span_v1'];gid=-1;gid_cell={};nonparam=0
 with(HERE/'cut_cell/geometric_GP.csv').open(encoding='utf-8',newline='')as f:
  rd=csv.DictReader(f)
  for neg in rd:
   pos=next(rd);need(neg['surface']=='SNEG'and pos['surface']=='SPOS'and all(neg[k]==pos[k]for k in pair_fields),'both physical-face geometry records unchanged');current=int(neg['quadrature_index']);need(current==gid+1,'all original sequential GP IDs');gid=current;owner=int(neg['patch_handle'],16);box=tuple(float(neg[k])for k in ['span_u0','span_u1','span_v0','span_v1']);key=bounds[owner,box];state=states[key];gid_cell[gid]=key;u,v,w1,w2=[float(neg[k])for k in ['u','v','w1','w2']];w=w1*w2;need(all(math.isfinite(x)for x in [u,v,w1,w2,w]),'finite geometric GP');nonparam+=float(neg['weight'])!=w;u0,u1,v0,v1=state['bounds'];s=(u-u0)/(u1-u0);t=(v-v0)/(v1-v0);sp=[1.];tp=[1.]
   for _ in range(6):sp.append(sp[-1]*s);tp.append(tp[-1]*t)
   for i,(p,q)in enumerate(PAIRS):kahan(state['acc'][i],w*sp[p]*tp[q])
   state['count']+=1
 need(gid+1==118272 and nonparam==0,'all original cached GP and parameter weight observation');index={p:i for i,p in enumerate(PAIRS)};rowcount=Nativevalues=0;statuses=collections.Counter()
 with(root/links['cut_moment_rows']).open(encoding='utf-8-sig',newline='')as f:
  for x in csv.DictReader(f):
   key=(int(x['owner']),int(x['element']));power=(int(x['a']),int(x['b']));i=index[power];state=states[key];need(F.from_float(state['acc'][i][0])==F(x['raw_cache_moment']),'raw GP cached moment arithmetic matches distributed Fraction');need(state['count']==int(x['count_per_face']),'original per-span GP count')
   if key in native:need(F.from_float(float(native[key]['signedLocalMoments'][i]))==F(x['Native_cut_moment']),'all606x8 original Native moment values');Nativevalues+=key in native
   else:need(x['Native_cut_moment']=='NOT_EMITTED_FULL_OR_ZERO','no invented noncut observer record')
   statuses[x['arithmetic_status']]+=1;rowcount+=1
 need(rowcount==65280 and Nativevalues==4848,'complete eight-moment rows');need(statuses['OPEN_ENCODING_RESOLUTION']==3238,'all original encoding-open rows retained');triangles=0;triangleids=set()
 with(root/links['cut_triangle_results']).open()as f:
  for line in f:
   x=json.loads(line);ids=x['GLOBAL_GP_ids'];key=(int(x['owner']),int(x['element']));need(len(ids)==36 and len(set(ids))==36 and not(triangleids&set(ids))and all(gid_cell[i]==key for i in ids),'all original Rule36 triangle GP associations');triangleids.update(ids);triangles+=1
 need(triangles==1200 and len(triangleids)==43200,'all measured triangles/GPs');table=read(HERE/'cut_cell/rule36_literal_table.json')['literal_decimal_tokens'];need(len(table)==36 and all(len(r)==4 for r in table),'original36x4 literal table');need(all(all(math.isfinite(float(v))for v in r)and float(r[3])>0 for r in table),'finite original table literals');recorded=read(root/links['cut_recorded_result']);need(recorded['status']=='OPEN_ENCODING_OR_RAW_GEOMETRY_REPRESENTATION'and len(recorded['raw_representation_differences_above_same_arithmetic_budget'])==1706,'original raw-representation open status retained')
 print(json.dumps({'status':'SAVED_QUADRATURE_INPUTS_AND_ARITHMETIC_CHECKED','strategies':9,'coefficients_each':4563,'shared_force_entries':4563,'bilinear_probes':probes,'line_panels':panelcount,'line_failed_panels':bad,'line_maximum_scaled_error':maximum,'line_final_GP':len(byuid),'line_accepted_outside_final':10160,'saved_encoding_moment_identities_checked':bound_checks,'cut_geometric_GP':gid+1,'physical_face_rows':2*(gid+1),'Native_cut_records':len(native),'Native_cut_scalar_moments':Nativevalues,'all_span_moment_rows':rowcount,'preserved_encoding_OPEN_rows':3238,'preserved_raw_representation_differences':1706,'Rule36_triangles':triangles,'new_PDE_solve_eigendecomposition_or_reference_integration':False},indent=2))
if __name__=='__main__':main()
