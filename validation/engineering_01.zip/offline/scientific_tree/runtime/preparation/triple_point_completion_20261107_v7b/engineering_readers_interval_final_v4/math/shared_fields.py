"""Evaluate frozen Native solutions at the shared physical display centroids."""
from pathlib import Path
import os
for key in ('OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS'):os.environ[key]='1'
import argparse,csv,hashlib,importlib.util,json,math
import numpy as np
from scipy.interpolate import BSpline
HERE=Path('new_analysis/actual_inputs/prep/mechanics/candidate/matched_FEM_IGA_stress_protocol_v1');ROOT=Path('投稿/二次修稿/准备工作')
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(p):
 h=hashlib.sha256()
 with p.open('rb')as f:
  for b in iter(lambda:f.read(1<<20),b''):h.update(b)
 return h.hexdigest()
def load_module(name,p,expected):
 assert sha(p)==expected;s=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
def parity_and_boundary(loop,uv):
 inside=np.zeros(len(uv),dtype=bool);boundary=np.zeros(len(uv),dtype=bool);p=np.asarray(loop,float);eps=1e-9*(float(np.max(np.ptp(p,axis=0)))+1.)
 for a,b in zip(p,np.roll(p,-1,axis=0)):
  d=b-a
  if float(d@d)==0.:continue
  alpha=np.clip(((uv-a)@d)/float(d@d),0.,1.);boundary|=np.linalg.norm(uv-a-alpha[:,None]*d,axis=1)<=eps
  crossing=(a[1]>uv[:,1])!=(b[1]>uv[:,1])
  if b[1]!=a[1]:inside^=crossing&(uv[:,0]<(b[0]-a[0])*(uv[:,1]-a[1])/(b[1]-a[1])+a[0])
 return inside,boundary

def evaluate(g,L,U,uv):
 m,n=g['controls_u'],g['controls_v'];X=np.asarray(g['control_global_Vg']).reshape(m,n,3);Ul=U@L.T;Ul=Ul.reshape(m,n,3);Xl=X@L.T
 B=[BSpline(g['knots_u'],np.eye(m),3)(uv[:,0],nu=d)for d in range(3)];C=[BSpline(g['knots_v'],np.eye(n),3)(uv[:,1],nu=d)for d in range(3)]
 def e(A,i,j):return np.einsum('ki,ijc,kj->kc',B[i],A,C[j],optimize=True)
 xyz=e(X,0,0);value=e(U.reshape(m,n,3),0,0);J=np.stack([e(Xl,1,0)[:,:2],e(Xl,0,1)[:,:2]],axis=2);inv=np.linalg.inv(J);G=np.stack([e(Ul,1,0),e(Ul,0,1)],axis=2)@inv
 epsilon=np.column_stack([G[:,0,0],G[:,1,1],G[:,0,1]+G[:,1,0]])
 HP=np.empty((len(uv),2,2));HP[:,0,0]=e(Ul,2,0)[:,2];HP[:,0,1]=HP[:,1,0]=e(Ul,1,1)[:,2];HP[:,1,1]=e(Ul,0,2)[:,2]
 geo=np.empty((len(uv),2,2,2));geo[:,:,0,0]=e(Xl,2,0)[:,:2];geo[:,:,0,1]=geo[:,:,1,0]=e(Xl,1,1)[:,:2];geo[:,:,1,1]=e(Xl,0,2)[:,:2]
 adjusted=HP-G[:,2,0,None,None]*geo[:,0]-G[:,2,1,None,None]*geo[:,1];H=inv.transpose(0,2,1)@adjusted@inv;kappa=np.column_stack([H[:,0,0],H[:,1,1],2*H[:,0,1]])
 return xyz,value,epsilon,kappa

def main():
 case=FAMILY;out=OUTPUT;assert not out.exists()
 plan=read(HERE/'shared_centroid_display_v1'/case/'display_plan.json');csvpath=Path(plan['triangle_csv']['path']);assert sha(csvpath)==plan['triangle_csv']['sha256']
 with csvpath.open(encoding='utf-8-sig',newline='')as f:tri=list(csv.DictReader(f))
 world=np.array([[float(r[k])for k in('cx_mm','cy_mm','cz_mm')]for r in tri]);normal=np.array([[float(r[k])for k in('nx','ny','nz')]for r in tri]);thickness=np.array([float(r['thickness_mm'])for r in tri]);N=len(tri)
 native=NATIVE;state=('panel_state'if case=='panel'else'linear_state');stressfile=STRESS_REPORT;geo={int(p.stem.rsplit('_',1)[1]):read(p)for p in(native/'capture').glob('trim_geometry_*.json')};props={int(q['shell_handle']):q for q in read(native/'capture/engineering_input_only_manifest.json')['surfaces']};frames={int(k):np.asarray(v)for k,v in read(stressfile)['frames'].items()};fields={}
 with(native/'derived_work'/state/'control_point_solution.csv').open(encoding='utf-8',newline='')as f:
  for r in csv.DictReader(f):fields.setdefault(int(r['owner']),{})[int(r['local_cp'])]=[float(r[k])for k in('ux','uy','uz')]
 chosen=np.full(N,-1,dtype=int);uv_all=np.full((N,2),np.nan);multiplicity=np.zeros(N,dtype=int);alternatives={}
 for owner,g in sorted(geo.items()):
  m,n=g['controls_u'],g['controls_v'];X=np.asarray(g['control_global_Vg']).reshape(m,n,3);lo=np.array([g['knots_u'][3],g['knots_v'][3]]);hi=np.array([g['knots_u'][m],g['knots_v'][n]]);A=np.column_stack([(X[-1,0]-X[0,0])/(hi[0]-lo[0]),(X[0,-1]-X[0,0])/(hi[1]-lo[1])]);uv=lo+(world-X[0,0])@np.linalg.pinv(A).T;projection=X[0,0]+(uv-lo)@A.T
  good=(np.linalg.norm(projection-world,axis=1)<=1e-8)&(np.abs(normal@frames[owner][2])>=1-1e-8)&(thickness==props[owner]['constant_t'])&np.all((uv>=lo)&(uv<=hi),axis=1);ids=np.flatnonzero(good)
  if len(ids)==0:continue
  if g['has_outer']:
   inside,boundary=parity_and_boundary(g['outer_loop'],uv[ids]);good[ids]&=inside|boundary
  for hole in g['hole_loops']:
   ids=np.flatnonzero(good);inside,boundary=parity_and_boundary(hole,uv[ids]);good[ids]&=~inside|boundary
  ids=np.flatnonzero(good);multiplicity[ids]+=1
  for i in ids:
   if chosen[i]>=0:alternatives.setdefault(int(i),[int(chosen[i])]).append(owner)
  fresh=ids[chosen[ids]<0];chosen[fresh]=owner;uv_all[fresh]=uv[fresh]
 missing=np.flatnonzero(chosen<0);assert len(missing)==0,('uncovered shared physical centroid samples',len(missing),missing[:20].tolist())
 stress=load_module('frozen_scalar_stress_reference',ROOT/'mechanics/candidate/panel_mesh_family_v1/check_panel_family_stress.py','838ddc209389c1e789118ddb366d7e97caac82da69a9877e016e6cdd11503bfa');physics=load_module('frozen_cartesian_chain_reference',ROOT/'mechanics/candidate/endpoint_vertex988_source_v1/checker/check_actual_endpoint_capture.py','c4892fb0b822bbee5ab43f97dde4010e5664ecb7bc347dccaa07599e823f33ff')
 value=np.zeros((N,3));negative=np.zeros((N,3,3));positive=np.zeros((N,3,3));mises=np.zeros((N,2));fit=np.zeros(N);checks=[]
 for owner,g in sorted(geo.items()):
  ids=np.flatnonzero(chosen==owner)
  if not len(ids):continue
  L=frames[owner];U=np.asarray([fields[owner][i]for i in range(g['controls_u']*g['controls_v'])]);p=props[owner];D=p['E']/(1-p['nu']**2)*np.array([[1.,p['nu'],0.],[p['nu'],1.,0.],[0.,0.,(1-p['nu'])/2]])
  for begin in range(0,len(ids),256):
   part=ids[begin:begin+256];xyz,u,eps,kap=evaluate(g,L,U,uv_all[part]);fit[part]=np.linalg.norm(xyz-world[part],axis=1);assert np.max(fit[part])<=1e-8;value[part]=u
   for raw_index,fiber in enumerate((-.5,.5)):
    s=(eps-p['constant_t']*fiber*kap)@D.T;S=s[:,0,None,None]*np.outer(L[0],L[0])+s[:,1,None,None]*np.outer(L[1],L[1])+s[:,2,None,None]*(np.outer(L[0],L[1])+np.outer(L[1],L[0]));vm=np.sqrt(s[:,0]**2-s[:,0]*s[:,1]+s[:,1]**2+3*s[:,2]**2);same=(normal[part]@L[2])>0
    neg=(raw_index==0)==same;negative[part[neg]]=S[neg];positive[part[~neg]]=S[~neg];mises[part[neg],0]=vm[neg];mises[part[~neg],1]=vm[~neg]
  for index in ids[[0,(len(ids)-1)//2,len(ids)-1]]:
   _,_,eps,kap=evaluate(g,L,U,uv_all[index:index+1]);expected_e,expected_k=stress.independent_components(g,L,U,*uv_all[index],physics);error=max(np.linalg.norm(eps[0]-expected_e)/max(1.,np.linalg.norm(expected_e)),np.linalg.norm(kap[0]-expected_k)/max(1.,np.linalg.norm(expected_k)));assert error<=1e-9;checks.append(dict(owner=owner,index=int(index),independent_scalar_chain_relative_error=float(error)))
 out.mkdir(parents=True);names=['element_1x','owner','u','v','world_residual_mm','ux_mm','uy_mm','uz_mm','U_magnitude_mm']+[face+'_'+name+'_MPa'for face in('SNEG','SPOS')for name in('sxx','syy','szz','sxy','sxz','syz','Mises')]+['maximum_face_Mises_MPa','retained_owner_count']
 with(out/'fields.csv').open('w',newline='',encoding='utf-8')as f:
  writer=csv.DictWriter(f,fieldnames=names);writer.writeheader()
  for i,r in enumerate(tri):
   d=dict(element_1x=int(r['element_1x']),owner=int(chosen[i]),u=uv_all[i,0],v=uv_all[i,1],world_residual_mm=fit[i],ux_mm=value[i,0],uy_mm=value[i,1],uz_mm=value[i,2],U_magnitude_mm=float(np.linalg.norm(value[i])),maximum_face_Mises_MPa=float(mises[i].max()),retained_owner_count=int(multiplicity[i]))
   for label,S,vv in [('SNEG',negative[i],mises[i,0]),('SPOS',positive[i],mises[i,1])]:d.update({label+'_'+n+'_MPa':float(v)for n,v in zip(('sxx','syy','szz','sxy','sxz','syz','Mises'),(S[0,0],S[1,1],S[2,2],S[0,1],S[0,2],S[1,2],vv))})
   writer.writerow(d)
 report=dict(status='NATIVE_ANALYTIC_FIELDS_AT_SHARED_PHYSICAL_CENTROIDS_ONLY',case=case,points=N,uncovered=0,multiple_owner_samples=len(alternatives),multiple_owner_ids=alternatives,selection_rule='lowest actual retained owner ID among parallel-plane same-thickness candidates; geometry-only, no FEM value used',SNEG_SPOS_labels_in_CSV_aligned_to_FEM_positive_geometric_normal=True,max_world_residual_mm=float(fit.max()),scalar_chain_checks=checks,source_native_case=str(native),source_stress_qualification_sha256=sha(stressfile),source_triangle_sha256=sha(csvpath),output_csv_sha256=sha(out/'fields.csv'),script_sha256=sha(Path(__file__)),original_CAD_error_or_peak_convergence_or_FEM_accuracy_certified=False)
 (out/'status.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8');print(json.dumps({k:v for k,v in report.items()if k not in('multiple_owner_ids','scalar_chain_checks')}))
if __name__=='__main__':raise SystemExit('Use read_engineering_mode4_v7.py with current strict preflight')
