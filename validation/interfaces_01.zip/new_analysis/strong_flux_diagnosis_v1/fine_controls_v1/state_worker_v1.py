import sys
import traceback
from boot_v1 import start, state_factor_budget
resources = start()
import numpy as np
from scipy import sparse
from scipy.sparse.linalg import splu, svds, LinearOperator
from common_v1 import *

coarse = sys.argv[1] == "coarse"
alpha = 210. if coarse else float(sys.argv[1]); assert alpha in (105., 210., 420.)
level = 1 if coarse else 4
OUT = HERE/("coarse_statecheck_v1" if coarse else f"alpha{int(alpha)}_v1")
OUT.mkdir(exist_ok=False)
save(OUT/"RESOURCE_PREFLIGHT.json", resources)
result = {"status": "STATE_NOT_QUALIFIED", "level": level, "alphaB": alpha, "resources": resources}
try:
    run, cluster, arms, betas, packet, bulk = load(level)
    del bulk
    n = cluster["actual_global_dofs"]
    if coarse:
        K = matrix(run/"input_audit/patch_order_global_K.csv", n, 200000)
        F = vector(run/"input_audit/patch_order_global_F.csv", n)
    else:
        assert read(HERE/"coarse_statecheck_v1/results.json")["status"] == "QUALIFIED_UNSHIFTED_ACTUAL_SPARSE_STATE"
        K = sparse.load_npz(bind(HERE/"actual_packet_v1/actual_K.npz"))
        F = np.load(bind(HERE/"actual_packet_v1/actual_F.npz"))["F"]
        if alpha != 210.:
            audit = read(HERE/"fine_rowaudit_v1/results.json")
            assert audit["status"] == "INDEPENDENT_COMPLETE_PHYSICAL_ROW_MATRIX_MATCHED"
            P = sparse.load_npz(bind(HERE/"fine_rowaudit_v1/PBC.npz"))
            K = K+(alpha-210.)*audit["lambda_BC"]*P
    native = vector(run/"input_audit/global_solution.csv", n)
    assert np.isfinite(K.data).all() and K.shape == (n, n)
    lu = splu(K.tocsc())
    fill = int(lu.L.nnz+lu.U.nnz)
    profile = {"actual_input_nnz": int(K.nnz), "actual_L_nnz": int(lu.L.nnz), "actual_U_nnz": int(lu.U.nnz),
               "actual_L_plus_U_nnz": fill, "observed_memory_after_factor": memory(),
               "permutation": "SuperLU default COLAMD", "actual_matrix_unmodified_by_caller": True}
    save(OUT/"ACTUAL_FACTOR_PROFILE.json", profile)
    state_factor_budget(K.nnz, fill)
    U = lu.solve(F)
    tau = max(1e-12, 64*n*np.finfo(float).eps)
    backtol = max(1e-14, 128*n*np.finfo(float).eps)
    residual = K@U-F
    backward = norm(residual)/(norm(K)*norm(U)+norm(F))
    assert np.isfinite(U).all() and backward <= backtol
    spectral = None
    if alpha == 210.:
        inv = LinearOperator((n, n), matvec=lu.solve, rmatvec=lambda x: lu.solve(x, trans="T"))
        v0 = np.random.default_rng(0).standard_normal(n); v0 /= norm(v0)
        u, s, vh = svds(inv, k=1, which="LM", tol=1e-11, maxiter=2000, v0=v0, solver="arpack")
        inverse_sigma = float(s[0]); sigma = 1/inverse_sigma
        invres = max(norm(inv@vh[0]-inverse_sigma*u[:, 0]), norm(inv.rmatvec(u[:, 0])-inverse_sigma*vh[0]))/inverse_sigma
        assert sigma > 0 and invres <= tau
        if coarse:
            q = read(PREP/"cluster_gl4_all_h1_actual_K_qualification_v1/actual_coarse_point_qualification.json")
            saved_sigma = q["full_actual_K_numeric_SPD"]["minimum_singular_value"]
            relative_sigma = abs(sigma/saved_sigma-1)
            assert relative_sigma <= 1e-10
        else:
            relative_sigma = None
        rn = K@native-F
        native_backward = norm(rn)/(norm(K)*norm(native)+norm(F))
        coefficient_bound = max(tau, 8*(norm(rn)+norm(residual))/(sigma*norm(U)))
        coefficient_error = norm(native-U)/norm(U)
        assert native_backward <= backtol and coefficient_bound < 1e-4 and coefficient_error <= coefficient_bound
        spectral = {"method": "largest singular value of unshifted sparse inverse operator",
                    "sigma_min_numeric": sigma, "inverse_triplet_relative_residual": invres,
                    "coarse_saved_sigma_relative_difference": relative_sigma,
                    "native_backward": native_backward, "coefficient_relative_difference": coefficient_error,
                    "original_rule_coefficient_bound": coefficient_bound,
                    "inconclusive_cutoff_unchanged": 1e-4, "not_interval_spectral_certificate": True}
    sparse.save_npz(OUT/"controlled_K.npz", K)
    np.savez_compressed(OUT/"state.npz", U=U, F=F, original_native_U=native)
    result.update(status="QUALIFIED_UNSHIFTED_ACTUAL_SPARSE_STATE", n=n, actual_factor_profile=profile,
        normwise_backward=backward, original_backward_tolerance=backtol, spectral_and_native_reproduction=spectral,
        F_array_sha256=__import__('hashlib').sha256(F.tobytes()).hexdigest(),
        only_alpha_penalty_changed=alpha != 210.,
        state_factor_and_no_Riesz_factor_in_this_process=True)
except Exception as e:
    result.update(failure=repr(e), traceback=traceback.format_exc())
finally:
    verify_inputs(); result.update(input_sha256=PINS, observed_memory=memory())
    save(OUT/"results.json", result)
    print(__import__('json').dumps(clean({k:v for k,v in result.items() if k not in ("input_sha256","traceback")}), indent=2))
if result["status"] != "QUALIFIED_UNSHIFTED_ACTUAL_SPARSE_STATE": raise SystemExit(2)
