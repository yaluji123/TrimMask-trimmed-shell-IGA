"""One explicitly selected fresh Core capture. No build, queue, retry or kill."""


from pathlib import Path


from datetime import datetime


import argparse,csv,json,math,os,re,shutil,subprocess,time,uuid


import newfamily_replay_guard as guard


import sys


HERE=Path(__file__).resolve().parent;ROOT=guard.ROOT


sys.path.insert(0,str(ROOT/'runtime/preparation/triple_point_completion_20261107_v7b'))


build_source=guard.build_source


ASCII=Path(r'D:\BaiduSyncdisk\CODEX\oe_round2_stage_20261104')


CORE=Path(r'C:\Program Files\Autodesk\AutoCAD 2025\accoreconsole.exe')


need,sha,read,save=guard.need,guard.sha,guard.read,guard.save


BINDING=build_source.BINDING;BINDING_SHA=build_source.BINDING_SHA


INPUTS=Path(r'D:\BaiduSyncdisk\CODEX\IGAforCAD\validation\convergence_rerun_current_20260802\perforated_stiffened_plate_displacement_controlled')


MODELS={'state1x':(Path(r'D:\BaiduSyncdisk\CODEX\TrimMask-trimmed-shell-IGA\data\cad\dwg\perforated_stiffened_plate_1x_displacement_controlled.dwg'),'d77d03506e0a18e27f65a6d63aee6271f7440c87074cb551dd17c859dc23ad80'),'state2x':(INPUTS/'perforated_stiffened_plate_displacement_2x_current.dwg','09d9365998dfb033c505e4ab20c37a36c151ddea6305153ac2e0cfbcf42e2e2d'),'state4x':(INPUTS/'perforated_stiffened_plate_displacement_4x_current.dwg','f87d695f623053dd09f355c559621fd62f079dfeae43c09589d442929016bee3')}


DOFS={'state1x':12243,'state2x':36462,'state4x':123744}


ENDPOINT=ROOT/'mechanics/candidate/endpoint_vertex988_source_v1'


TRIM=ROOT/'mechanics/candidate/trimmed_source_component_v1'


TRIM_GUARD=ROOT/'mechanics/candidate/trimmed_source_component_env_guard_v1'


POINT=ROOT/'mechanics/actual_hull4x_endpoint988_recovered_v1/native_point_source_v1'


P4='f94cdddef84bf494edf28adcafbd88b9848a415ce211a4a1c3a1bb8d75bde3fa'


P4MARK='[IGA][OEExistingP4AssemblyAuditV1] capture_complete=1 bulk_number_load_BC_coupling=1 globalK=0 KKT=0 solve=0.'


def identity(p):return {'sha256':sha(p),'bytes':p.stat().st_size,'mtime_ns':p.stat().st_mtime_ns}


def spec(kind,case):


 need(kind in MODELS,'only three exact Panel models')


 capture=case/'capture'


 extra={'IGA_OE_GEOMETRY_DIRECTORY':str(capture),'IGA_OE_COUPLE_GEOMETRY_DIRECTORY':str(capture),'IGA_OE_P4_CAPTURE_V1':'1','IGA_OE_P4_CAPTURE_DIRECTORY':str(case/'p4'),'IGA_OE_P4_PROTOCOL_SHA256':P4,'IGA_OE_REAL_CAD_LINE_WORK_V1':'1','IGA_OE_CHECKED_SPECTRAL_STATUS_V1':'1','IGA_OE_REQUIRE_VALIDATED_MAPPING':'1','IGA_OE_BOUNDARY_PROBE_JSONL':str(case/'bulk_domain.jsonl'),'IGA_OE_PANEL_P4_CAPTURE_V1':'1','IGA_OE_PANEL_POINT_COMPONENT_V1':'1','IGA_OE_PANEL_BULK_SURFACE_CAPTURE_V1':'1','IGA_OE_PANEL_BULK_SURFACE_DIRECTORY':str(case/'raw_bulk_surface'),'IGA_OE_PANEL_STATE_V1':'1','IGA_OE_PANEL_STATE_DIRECTORY':str(ASCII/case.name/'panel_state'),'IGA_OE_PANEL_PARENT_POINT_QUALIFICATION':str(ROOT/'mechanics/candidate/panel_point_native_v1/ACTUAL_PANEL_POINT_INDEPENDENT_REPORT.json'),'IGA_OE_PANEL_POINT_PLAN_TSV':str(ROOT/'mechanics/candidate/panel_signed_point_preparation_v1/point_operator_proposal_v1/point_topology.tsv'),'IGA_OE_PANEL_POINT_DIRECTORY':str(case/'point'),'IGA_OE_PANEL_ENDPOINT_REQUEST_TSV':str(ROOT/'mechanics/candidate/panel_endpoint_passive_v1/requests/panel_endpoint_requests.tsv'),'IGA_OE_PANEL_INPUT_DWG':str(ASCII/case.name/'model.dwg'),'IGA_OE_PANEL_INPUT_CERTIFICATE':str(ROOT/'mechanics/candidate/actual_panel_capture_v1/PANEL1X_INPUT_CERTIFICATE.json')}


 if kind!='state1x':extra.update(IGA_OE_PANEL_MESH_STATE_V1='1',IGA_OE_PANEL_MESH_LEVEL=kind[-2:],IGA_OE_PANEL_MESH_INPUT_DWG=str(ASCII/case.name/'model.dwg'),IGA_OE_PANEL_MESH_INPUT_CERTIFICATE=str(ROOT/'runtime/preparation/panel_mesh_input_execution_v1'/('PANEL'+kind[-2:].upper()+'_INPUT_AUDIT.json')))


 return kind,('IgaExportOEPanelLinearStateV1Local'if kind=='state1x'else'IgaExportOEPanelMeshLinearStateV1Local'),'before_actual_panel_state_v1',extra,'[IGA][OEPanelLinearStateV1] state_complete=1 actual_point=1 raw_bulk=36 surfaceBC=2 globalK=1 KKT=0 solve=1.',ASCII/case.name/'panel_state/state_complete.json'








def component_source_contracts():


 need(sha(ROOT/'mechanics/candidate/panel_mesh_family_v1/check_panel_family_stress.py')=='838ddc209389c1e789118ddb366d7e97caac82da69a9877e016e6cdd11503bfa','pre-Native physical family stress checker')


 need(sha(ROOT/'mechanics/candidate/panel_mesh_family_v1/check_panel_family_point.py')=='c6479f1b098f518a1bf11bd0aab967e944f268276847c0b5fe154a6fe0c2d6e6','pre-Native complete physical family point checker')


 need(sha(ROOT/'mechanics/candidate/panel_mesh_family_v1/check_panel_family_state.py')=='fcc3cfab8c8990d41694ea45f8b51f27e861ceec7931364aca79eb2052607767','pre-Native independent state algebra checker')


 need(sha(ROOT/'mechanics/candidate/panel_point_native_v1/ACTUAL_PANEL_POINT_INDEPENDENT_REPORT.json')=='2fc2ff1282ed28fae8116477f3308ee1c1e5bb98abf33ceb5717e166102976d0','actual parent point qualification')


 need(sha(ROOT/'mechanics/candidate/panel_point_native_v1/check_panel_point_oracle.py')=='b623494f80aa48339c2e3736eb4e27749aeb9e26048de4cb3d4730fac7f6f47c','pre-Native full physicalPanelpoint checker')


 plan=ROOT/'mechanics/candidate/panel_signed_point_preparation_v1/point_operator_proposal_v1/point_topology.tsv'


 need(plan.stat().st_size==15979 and sha(plan)=='69ac703c04960e5c24e01dc3e63aba7d59d109b66bbd439afd779151beac8576','bounded60/184/168 topology')


 need(sha(ROOT/'mechanics/candidate/receiver_and_tensor_fix_v1/SOURCE_CONTROL_PACKET.json')=='90bc2cd6bc1f5a5a314173f1efcb738b63b8e4580795b5cb26388b6905723ad8','observed receiver/tensor source proposal')


 need(read(ROOT/'mechanics/candidate/receiver_and_tensor_fix_v1/component_attempt_v1/test_stdout.json')['checks']==141,'pureCPP tensor component only')


 need(sha(ROOT/'mechanics/candidate/actual_panel_capture_rp_mode_v2/ACTUAL_APPLIED_SOURCE_BINDING.json')=='805ce010690c242e5a1075ac878d80f694b424b2ea7132e93e079e611134ec13','new no-RP caller source binding')


 packet=ROOT/'mechanics/candidate/actual_panel_capture_v1/SOURCE_CONTROL_PACKET.json'


 need(sha(packet)=='ecf18f15058368b4153bc7e8e8d5e38c4938088c16aec250a46f0edce12c0640','Panel source proposal identity')


 need(sha(ROOT/'mechanics/candidate/actual_panel_capture_v1/PANEL1X_INPUT_CERTIFICATE.json')=='6e7de6fc3ad8a7ae2697b1ceb7371df72c6546859d0ab3d217d2b160c027e7e9','measured Panel input certificate')





def error_lines(stdout,stderr):


 return [line for line in(stdout+'\n'+stderr).splitlines()if '[ERR]'in line]





def copy_reporting(case,which):
 return guard.copy_reporting(case,which)


def main():


 ap=argparse.ArgumentParser(description=__doc__)


 ap.add_argument('--kind',choices=['state1x','state2x','state4x'],required=True);ap.add_argument('--label',required=True);ap.add_argument('--analysis-profile',type=Path);ap.add_argument('--analysis-profile-sha');ap.add_argument('--profile-recipe-receipt',type=Path);ap.add_argument('--profile-role',choices=['baseline','engineering_mode4'])


 ap.add_argument('--runtime-stage',type=Path);ap.add_argument('--manifest',type=Path,required=True);ap.add_argument('--manifest-sha256',required=True);ap.add_argument('--build-log',type=Path)


 ap.add_argument('--window',type=Path);ap.add_argument('--window-sha256');ap.add_argument('--execute',action='store_true');a=ap.parse_args();guard.fixed_args(a,'panel4x')
 guard.configure(a.manifest,a.manifest_sha256,a.runtime_stage)


 need(re.fullmatch('[a-z][a-z0-9_]{0,79}',a.label),'safe fresh case label')


 case=ROOT/'runtime/runs'/a.label;work=ASCII/a.label;model,command,event,extra,marker,complete=spec(a.kind,case)


 analysis_profile=None;recipe=None;expected_mode=None;recipe_inheritance=None


 if any(x is not None for x in(a.analysis_profile,a.analysis_profile_sha,a.profile_recipe_receipt,a.profile_role)):


  need(all(x is not None for x in(a.analysis_profile,a.analysis_profile_sha,a.profile_recipe_receipt,a.profile_role)),'complete explicit engineering source-default recipe arguments')


  need(sha(a.analysis_profile)==a.analysis_profile_sha,'selected complete engineering profile bytes')


  analysis_profile=read(a.analysis_profile);recipe=read(a.profile_recipe_receipt);expected_mode=3 if a.profile_role=='baseline' else 4
  recipe_inheritance=guard.profile_inheritance(a.profile_recipe_receipt)


  need(recipe['status']=='SOURCE_DEFAULT_FULL_PROFILE_RECIPE_ONLY_NOT_RUNTIME_EXPORT' and recipe['baseline_origin']=='CPP_CAPTURE_OF_FROZEN_SOURCE_DEFAULTS' and recipe_inheritance['current_source_binding_sha256']==BINDING_SHA and recipe_inheritance['qualified_runtime_manifest_sha256']==guard.MANIFEST_SHA and recipe['actual_Native_configuration_exported'] is False and recipe['original_DWG_profile_cloned'] is False,'explicit source-default recipe only, no unknown original clone')


  need(recipe['outputs'][a.profile_role]['sha256']==a.analysis_profile_sha and recipe['outputs'][a.profile_role]['profile_hash']==analysis_profile['hash'] and analysis_profile['TrimQuadratureMode']==expected_mode and analysis_profile['enableGeoNonlinear'] is False and re.fullmatch('[0-9a-f]{16}',analysis_profile['hash']) is not None,'specific baseline/mode4 complete recipe identity')


 if not a.execute:print(json.dumps({'status':'PLAN_ONLY_NO_CORE','kind':a.kind,'case':str(case),'command':command,'expected_negative':a.kind=='line_zero','no_queue_retry_or_kill':True}));return 0


 body=None;owns=False;pid=None;lock=ROOT/'runtime/engineering_heavy_attempt.lock'


 try:


  need(all(x is not None for x in(a.runtime_stage,a.manifest,a.manifest_sha256,a.build_log,a.window,a.window_sha256)),'explicit selected runtime/window identities')


  need(not case.exists()and not work.exists()and not lock.exists(),'fresh one case/work and exclusive lock')


  build_source.source();component_source_contracts()


  need(a.runtime_stage.is_absolute()and str(a.runtime_stage).isascii()and a.runtime_stage.resolve()==guard.RUNTIME_STAGE,'new verified ASCII stage, not old06017')




  build,records=guard.verify_manifest(a.manifest,a.manifest_sha256,a.runtime_stage,expected_source_root=guard.SOURCE_ROOT);need(sha(a.build_log)==build['build_log_sha256'],'actual verified build log')


  need(next(x for x in build['runtime']if x['name']=='IGAforCAD.crx')['sha256']!='06017cabfae2cc4124a65074667d67f566f98fd262c9a3186dca6e6538a1ce6c','new compiled runtime required')


  contract=guard.module('next_strict_modules_and_log_contract',ROOT/'runtime/preparation/interior_fixture_module_identity_v1/module_identity_contract.py','81751e343247b51d3bc52cf0d1f6fd2da8fbe3f444a39948ff56daef19682774')


  memory_module=build_source.sampler();memory=memory_module.startup_memory();large=True;startup=128<<30;limit=64<<30


  need(min(memory.values())>=startup and shutil.disk_usage(ASCII).free>=32<<30,'new selected startup RAM/commit/D space')


  source,expected=MODELS[model];before=identity(source);need(before['sha256']==expected,'immutable original model')


  selected_window,_,_=guard.selected(a.window,a.window_sha256,'panel',a.label,BINDING_SHA)


  need(selected_window['runtime_manifest_sha256']==a.manifest_sha256,'Root-selected frozen runtime manifest')


  expected_parameters=dict(kind=a.kind)


  if analysis_profile is not None:expected_parameters.update(analysis_profile_sha256=a.analysis_profile_sha,profile_recipe_receipt_sha256=sha(a.profile_recipe_receipt),profile_role=a.profile_role)


  need(selected_window['parameters']==expected_parameters,'exact engineering model and explicit-profile recipe parameters')


  need(selected_window['configured_CPU']==1 and selected_window['process_limit_bytes']==limit and selected_window['startup_RAM_commit_bytes']==startup,'original engineering CPU/startup/memory declarations')


  need(a.manifest_sha256==guard.MANIFEST_SHA and build['actual_source_binding_sha256']==BINDING_SHA==guard.BINDING_SHA and build['actual_source_count']==318,'actual316canonical+2overlay engineering CRX identity; DBX parent90f')


  live=guard.scan(a.window,a.window_sha256,'panel',a.label,BINDING_SHA)


  save(HERE/'case_preflight_audits'/(a.label+'_before.json'),live);need(not live['blocked'],'RESOURCE_SLOT_BLOCKED: '+json.dumps(live['blocked']))


  payload=json.dumps({'owner':'next_manual_'+a.kind,'launcher':os.getpid(),'nonce':uuid.uuid4().hex}).encode()


  with lock.open('xb')as f:f.write(payload)


  body=payload;immediate=guard.scan(a.window,a.window_sha256,'panel',a.label,BINDING_SHA)


  save(HERE/'case_preflight_audits'/(a.label+'_immediate.json'),immediate);need(not immediate['blocked'],'RESOURCE_SLOT_BECAME_BUSY: '+json.dumps(immediate['blocked']))


  case.mkdir();owns=True;work.mkdir();(case/'capture').mkdir();(case/'module_identity').mkdir()


  if large:(case/'p4').mkdir();(case/'point').mkdir();(case/'raw_bulk_surface').mkdir();(work/'panel_state').mkdir();copy_reporting(case,'before')


  shutil.copy2(source,case/'input_model.dwg');shutil.copy2(source,work/'model.dwg');need(sha(case/'input_model.dwg')==sha(work/'model.dwg')==expected,'strict prelaunch model copies')


  for src,name in[(Path(__file__),'executed_runner.py'),(BINDING,'applied_physical_source_binding_316_plus_2.json'),(a.manifest,'source_runtime_manifest.json'),(a.build_log,'verified_build.log'),(a.window,'root_selected_window.json')]:shutil.copy2(src,case/name)
  if analysis_profile is not None:save(case/'source_default_recipe_inheritance.json',recipe_inheritance)


  flags={'IGA_SKIP_USER_COM_REGISTRATION':'1','IGA_SOLVER_STRICT_REPRODUCIBILITY':'1','IGA_ASSEMBLY_THREADS':'1','IGA_SOLVER_THREADS':'1','IGA_PARDISO_THREADS':'1','IGA_OE_MODULE_IDENTITY_DIRECTORY':str(case/'module_identity'),'IGA_OE_EXPECTED_CRX_PATH':str(a.runtime_stage/'IGAforCAD.crx'),'IGA_OE_EXPECTED_DBX_PATH':str(a.runtime_stage/'JYH_IGAEntity.dbx')};flags.update(extra)


  # Bootstrap gate precedes the whole command, including endpoint Inventory/RP.


  script='\n'.join([f'(arxload "{(a.runtime_stage/n).as_posix()}")'for n in('JYH_IGAEntity.dbx','IGAforCAD.crx')]+['IgaExportOELoadedModuleIdentity',f'(if (= (getenv "IGA_OE_MODULE_GATE_OK") "1") (command "{command}") (princ "MODULE_GATE_REJECTED_NO_WORK"))','_.QUIT','_Y',''])


  if analysis_profile is not None:


   capture_source=ROOT/'report_draft/21_readonly_requirement_audit_20261107/source_only_graph_profile_capture/capture_original_profile.lsp'


   gate_source=ROOT/'report_draft/21_readonly_requirement_audit_20261107/source_default_profile_recipe/engineering_import_v2/engineering_profile_guard.lsp'


   need(sha(capture_source)=='a54720635512109739cb19fe09bbe75a9daf72eab5d0f2783530210b635b5104' and sha(gate_source)=='20ed38add03937c2343cd0f77ded77d6c069db052592f1f6bb150cedcf184664','exact original-profile capture and engineering preimport guard sources')


   for profile_src,name in[(capture_source,'capture_original_profile.lsp'),(gate_source,'engineering_profile_guard.lsp')]:shutil.copy2(profile_src,work/name);shutil.copy2(profile_src,case/('executed_'+name))


   baseline=Path(recipe['outputs']['baseline']['path']);need(sha(baseline)==recipe['outputs']['baseline']['sha256'],'actual frozen source-default baseline file')


   shutil.copy2(baseline,work/'source_default_baseline.json');shutil.copy2(a.analysis_profile,work/'analysis_profile.json');shutil.copy2(a.analysis_profile,case/'executed_profile.json');shutil.copy2(a.profile_recipe_receipt,case/'profile_recipe_receipt.json');(work/'profile_before_import').mkdir()


   flags['IGA_ANALYSIS_PROFILE_JSON']=str(work/'analysis_profile.json')


   hash_gate='(and (setq oe_selected_profile (dictsearch (namedobjdict) "IGA_NONLINEAR_ANALYSIS_PROFILE")) (= (cdr (nth 2 (vl-remove-if-not (function (lambda (item) (member (car item) (quote (90 1))))) oe_selected_profile))) "'+analysis_profile['hash']+'"))'


   profile_body=f'(if (oe-engineering-preimport-allowed "{(work/"profile_before_import").as_posix()}" "{(work/"source_default_baseline.json").as_posix()}" "{recipe["outputs"]["baseline"]["profile_hash"]}") (progn (command "IgaImportAnalysisProfileHeadless") (if {hash_gate} (progn (oe-engineering-gate-status "{(work/"profile_before_import").as_posix()}" "IMPORT_HASH_MATCHED_NUMERIC_COMMAND_SELECTED" T T T) (command "{command}")) (oe-engineering-gate-status "{(work/"profile_before_import").as_posix()}" "IMPORT_HASH_REJECTED_NO_NUMERIC_COMMAND" T T nil))))'


   script='\n'.join([f'(arxload "{(a.runtime_stage/n).as_posix()}")'for n in('JYH_IGAEntity.dbx','IGAforCAD.crx')]+['IgaExportOELoadedModuleIdentity',f'(if (= (getenv "IGA_OE_MODULE_GATE_OK") "1") (progn (load "{(work/"capture_original_profile.lsp").as_posix()}") (load "{(work/"engineering_profile_guard.lsp").as_posix()}") {profile_body}) (princ "MODULE_GATE_REJECTED_NO_WORK"))','_.QUIT','_Y',''])


  (work/'run.scr').write_text(script,encoding='ascii');shutil.copy2(work/'run.scr',case/'executed.scr')


  env={k:v for k,v in os.environ.items()if not k.upper().startswith('IGA_')};env.update(flags)


  env.update(OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',OMP_DYNAMIC='FALSE',MKL_DYNAMIC='FALSE',PATH=str(a.runtime_stage)+';'+env.get('PATH',''))


  cmd=[str(CORE),'/i',str(work/'model.dwg'),'/s',str(work/'run.scr'),'/l','en-US']


  save(case/'launch_plan.json',{'status':'ONE_ROOT_SELECTED_MANUAL_CASE','kind':a.kind,'command':cmd,'runtime_stage':str(a.runtime_stage),'manifest_sha256':a.manifest_sha256,'source_binding_sha256':BINDING_SHA,'window_sha256':a.window_sha256,'explicit_IGA_child_environment':flags,'inherited_IGA_flags_cleared':True,'live_guard':live,'immediate_guard':immediate,'configured_threads':1,'observed_process_memory_declaration_bytes':limit,'startup_RAM_commit':memory,'OS_hard_cap_installed':False,'original_P4_protocol_sha256':P4 if large else None,'new_raw_perrelation_bytes':128<<20 if large else None,'new_Cmap_entry_limit':2000000 if large else None,'new_Cmap_and_global_vector_growth_not_claimed_inside_old_observer_counter':large,'expected_negative':False,'input_geometry_used_by_component':a.kind!='off','known_major_component_bytes':(256<<20)if a.kind!='off'else None,'no_global_K_KKT_or_state_solve':False,'numerical_or_engineering_accepted':False})


  samples=[];clock=time.perf_counter();started=datetime.now().astimezone().isoformat()


  with(case/'stdout.raw.log').open('wb')as out,(case/'stderr.raw.log').open('wb')as err:


   child=subprocess.Popen(cmd,cwd=work,env=env,stdout=out,stderr=err,creationflags=subprocess.CREATE_NO_WINDOW);pid=child.pid;guard.core_started(child,CORE)


   save(case/'process_started.json',{'pid':pid,'started':started,'actual_Core_identity':guard.CORE_ID,**guard.CORE_START,'automatic_retry':False});print('One selected '+a.kind+' Core PID '+str(pid),flush=True)


   while child.poll()is None:samples.append(memory_module.sample(child));time.sleep(.25)


   code=child.wait();samples.append(memory_module.sample(child));guard.core_ended(child)


  gate_file=work/'profile_before_import/profile_preimport_gate.json'


  preimport_rejected=analysis_profile is not None and gate_file.exists() and read(gate_file)['status']=='PREIMPORT_REJECTED_UNKNOWN_ORIGINAL_PROFILE_NO_IMPORT_NO_SOLVE'


  save(case/'process_result.json',{'pid':pid,'exit_code':code,'natural_owned_child_exit':True,**guard.CORE_END,'all_processes_naturally_exited_claimed':False,'wall_seconds_instrumented_not_benchmark':time.perf_counter()-clock,'global_K_state_solve_performed_but_not_independently_accepted':not preimport_rejected,'profile_preimport_rejected_no_solve':preimport_rejected})


  good=[x for x in samples if x['available']];need(good,'owned memory sampling unavailable');peak=max(max(x['PeakWorkingSetSize'],x['PeakPagefileUsage'],x['PrivateUsage'])for x in good)


  save(case/'owned_process_resource_observations.json',{'samples':samples,'sampled_maximum_of_private_OSpeakcommit_OSpeakWS':peak,'declared_process_memory_bytes':limit,'within_declared_observed_memory':peak<=limit,'NOT_OS_enforced_hardcap':True})


  after=identity(source);save(case/'original_input_before_after.json',{'before':before,'after':after,'exact_sha_and_mtime_unchanged':before==after});need(before==after and sha(case/'input_model.dwg')==expected,'original immutable input changed')


  derived=[]


  for f in sorted(work.rglob('*')):


   if f.is_file():


    t=case/'derived_work'/f.relative_to(work);t.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(f,t);derived.append({'path':str(t.relative_to(case)),'sha256':sha(t),'role':'derived_not_original_input'})


  save(case/'derived_work_roles.json',{'files':derived,'postwork_model_not_input_identity':True})


  if large:copy_reporting(case,'after')


  logs={}


  for stem in('stdout','stderr'):


   raw=case/(stem+'.raw.log');text,encoding=contract.decode_raw_log(raw.read_bytes());dest=case/(stem+'.log');dest.write_bytes(text.encode('utf-8'))


   logs[stem]={'encoding':encoding,'raw_sha256':sha(raw),'derived_sha256':sha(dest),'strict_decode':True,'errors_ignored_or_markers_invented':False}


  save(case/'log_decode_receipt.json',logs);contract.verify_logs(case)


  for name in (['bootstrap'] if preimport_rejected else dict.fromkeys(['bootstrap',event])):


   result=contract.inspect_modules(case,build,a.runtime_stage,name,pid)


   save(case/('actual_loaded_module_hashes.json'if name==event else'actual_bootstrap_module_hashes.json'),result);need(not result['errors'],'actual bootstrap/module path/hash gate')


  stdout=(case/'stdout.log').read_text();stderr=(case/'stderr.log').read_text()


  # Lisp echoes the branch token; actual module, marker and structured gates decide.


  need(code==0 and peak<=limit,'owned exit/resource gate')


  if preimport_rejected:


   need(not complete.exists() and not (case/'p4/complete.json').exists() and not (case/'point/point_complete.json').exists(),'unknown original profile must stop before numerical commands')


   save(case/'profile_preimport_rejection_receipt.json',dict(status='ENGINEERING_ORIGINAL_PROFILE_PREIMPORT_REJECTION_FACTS_ONLY',family='panel',kind=a.kind,profile_imported=False,DWG_saved=False,solver_started=False,numerical_command_selected=False,scientific_acceptance=False))


   build_source.source();print(json.dumps(dict(status='ENGINEERING_PREIMPORT_REJECTED_NO_IMPORT_NO_SOLVE_FACTS_ONLY',case=str(case))));return 0


  need(complete.is_file(),'structured completion missing')


  need(stdout.count(marker)==1 and not error_lines(stdout,stderr),'positive strict log completion')


  state=read(complete)


  need(state['actual_Panel_linear_state_complete']and state['global_K_assembled_and_solved']and state['no_RP_or_KKT']and state['point_matrix_appended_once']and state['capture_scopes_ended_before_global']and state['structural_dofs']==DOFS[a.kind] and state['stress_skipped_records']==0 and not state['independent_algebra_FEM_accuracy_or_PDE_stability_accepted'],'actual Panel state serialization only')


  point=read(case/'point/point_complete.json')


  need(point['actual_Native_point_assembly_complete']and point['groups']==60 and point['unique_owner_points']==184 and point['Gamma_endpoints']==168 and point['actual_current_gamma_observed']and point['actual_zero_preboundary_structural_F_observed']and not point['global_K_KKT_state_or_engineering_accepted'],'actual finitePanel point capture only')


  done=read(case/'p4/complete.json')


  need(done['capture_complete']is True and done['ordinary_batch_returned']is True and done['fatal_latch']is False,'actual complete Panel assembly batch')


  need(done['no_global_K']and done['no_KKT']and done['no_solve']and done['legacy_opaque_entries']==done['cache_opaque_entries']==0,'passive fresh fully observed routes only')


  need(done['model_scope']==dict(model_sha256=expected,shells=36,CP=DOFS[a.kind]//3,relations=84)and done['visited_entries']==done['registry_entries']==84,'measured Panel census, not Hull role')


  if analysis_profile is not None:


   with(case/'source_diagnostics_after/trim_experiment_summary.csv').open(encoding='utf-8-sig',newline='')as stream:observed=list(csv.DictReader(stream))


   need(len(observed)==1 and int(observed[0]['trimMode'])==expected_mode and int(observed[0]['quadGaussN'])==4 and int(observed[0]['triGaussNGlobal'])==7,'actual engineering mode/bulk/triangle rule readback; stale advisor file is not authority')


  build_source.source()


  print(json.dumps({'status':'SERIALIZED_PENDING_INDEPENDENT_NUMERIC_READER','case':str(case),'pid':pid,'engineering_acceptance':False}));return 0


 except Exception as e:


  save(case/'failure_preserved.json'if owns else HERE/('PREFLIGHT_REJECTED_CASE_'+a.label+'.json'),{'status':'FAILED_OR_INCOMPLETE_NOT_ACCEPTED','error':repr(e),'owned_PID':pid,'automatic_retry_or_kill':False})


  print(repr(e));return 1


 finally:


  if owns:save(case/'capture_artifact_manifest.json',{'files':[{'path':str(f.relative_to(case)),'bytes':f.stat().st_size,'sha256':sha(f)}for f in sorted(case.rglob('*'))if f.is_file()and f.name!='capture_artifact_manifest.json'],'file_presence_not_acceptance':True})


  if body is not None:need(lock.read_bytes()==body,'owned lock changed');lock.unlink()


if __name__=='__main__':raise SystemExit(main())


