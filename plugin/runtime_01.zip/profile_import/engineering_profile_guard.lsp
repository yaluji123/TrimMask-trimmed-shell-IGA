;;; Loaded after the frozen read-only original-profile capture helper.
(vl-load-com)

(defun oe-profile-first-line (path / file value)
  (setq file (open path "r"))
  (if file (progn (setq value (read-line file)) (close file) value) nil))

(defun oe-engineering-gate-status (directory status allowed imported selected / file)
  (setq file (open (strcat directory "/profile_preimport_gate.json") "w"))
  (if file
    (progn
      (write-line (strcat "{\"status\":\"" status "\",\"preimport_source_allowed\":"
        (if allowed "true" "false") ",\"explicit_profile_import_invoked\":"
        (if imported "true" "false") ",\"numeric_command_selected\":"
        (if selected "true" "false") "}") file)
      (close file)))
  (princ))

(defun oe-engineering-preimport-allowed (directory baseline-file baseline-hash / record allowed)
  (oe-capture-original-profile directory)
  (setq record (dictsearch (namedobjdict) "IGA_NONLINEAR_ANALYSIS_PROFILE"))
  (setq allowed
    (and (findfile (strcat directory "/profile_capture_status.json"))
      (or (not record)
        (and
          (equal (oe-profile-first-line (strcat directory "/original_stored_profile.json"))
                 (oe-profile-first-line baseline-file))
          (equal (oe-profile-first-line (strcat directory "/original_profile_header_hash.txt")) baseline-hash)))))
  (if allowed
    (oe-engineering-gate-status directory "PREIMPORT_MISSING_OR_EXACT_SOURCE_BASELINE" T nil nil)
    (oe-engineering-gate-status directory "PREIMPORT_REJECTED_UNKNOWN_ORIGINAL_PROFILE_NO_IMPORT_NO_SOLVE" nil nil nil))
  allowed)
