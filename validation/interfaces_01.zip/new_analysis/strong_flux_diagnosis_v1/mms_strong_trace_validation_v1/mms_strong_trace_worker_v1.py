"""Original actual-K MMS sparse solve and original raw-strong evaluator check."""
from pathlib import Path
import csv
import hashlib
import importlib.util
import json
import math
import sys
import traceback
sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
PREP = ROOT/"runtime/preparation/triple_point_completion_20261107_v7b"
sys.path.insert(0, str(HERE.parent/"sources"))
from resource_guard import install, actual_budget
resources = install()
assert resources["OS_memory_job_installed"] and resources["CPU_affinity_cores"] == 1
resources["preflight"] = actual_budget(729, 59921)
import numpy as np
import sympy as sp
from scipy import sparse
from scipy.sparse.linalg import splu

inputs = {}


def bind(path):
    inputs[str(path)] = hashlib.sha256(path.read_bytes()).hexdigest()
    return path


def read(path):
    return json.loads(bind(path).read_text(encoding="utf-8-sig"))


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, bind(path))
    m = importlib.util.module_from_spec(spec); sys.modules[name] = m
    spec.loader.exec_module(m)
    return m


def norm(x):
    return float(np.linalg.norm(x.data if sparse.issparse(x) else x))


def clean(x):
    if isinstance(x, dict):
        return {k: clean(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [clean(v) for v in x]
    if isinstance(x, np.ndarray):
        return x.tolist()
    if isinstance(x, np.generic):
        return x.item()
    return x


def save(path, value):
    path.write_text(json.dumps(clean(value), indent=2, allow_nan=False)+"\n", encoding="utf-8")


core = module("cluster_physical_core", PREP/"independent_readers_v7/cluster_physical_core.py")
continuous = module("frozen_continuous_MMS", PREP/"actual_K_MMS_readers_v1/continuous_mms_families.py")
protocol = read(HERE/"PROTOCOL.json")
old_protocol = read(PREP/"actual_K_MMS_readers_v1/MMS_FALSIFICATION_PROTOCOL.json")
assert old_protocol["relative_MMS_budget"] == 1e-7
assert hashlib.sha256(Path(continuous.__file__).read_bytes()).hexdigest() == old_protocol["continuous_family_source_sha256"]
assert list(continuous.FAMILIES) == protocol["original_families"]


def arms_for(graph):
    run = ROOT/("runtime/runs/final90f_cluster_gl4_"+graph+"_h1_v1")
    cluster = read(run/"triple_cluster.json")
    arms = []
    for record in sorted(cluster["arms"], key=lambda x: int(x["handle"], 16)):
        owner = int(record["handle"], 16)
        geo = read(run/f"input_audit/load_stage_geometry_{owner}.json")
        mapping = np.array(record["global_dofmap"], dtype=int)
        arms.append(core.Arm(owner, np.array(geo["knots_u"]), np.array(geo["knots_v"]), 3, 3,
                             np.array(geo["control_global_Vg"]), np.array(geo["weights"]),
                             geo["E"], geo["nu"], geo["constant_t"], mapping, np.zeros(len(mapping))))
    return run, cluster, arms


_, _, analytic_arms = arms_for("all")
t = sp.Matrix([1, 0, 0])
e2 = [sp.Matrix([0, 1, 0]), sp.Matrix([0, 0, 1]), sp.Matrix([0, -1/sp.sqrt(2), 1/sp.sqrt(2)])]
ns = [sp.Matrix([0, 0, 1]), sp.Matrix([0, -1, 0]), sp.Matrix([0, -1/sp.sqrt(2), -1/sp.sqrt(2)])]
families = []
for kind in continuous.FAMILIES:
    fields, contract = continuous.family_contract(analytic_arms, kind)
    gs = []; mts = []; twists = []
    for f, radial, normal in zip(fields, e2, ns):
        q = f["symbolic"]
        g = (-q["N"][0, 1]*t-q["N"][1, 1]*radial
             +(-q["Q"][1]-sp.diff(q["M"][0, 1], continuous.X))*normal).subs(continuous.Y, 0)
        gs.append(g.applyfunc(sp.simplify))
        mts.append(sp.simplify(q["M"][1, 1].subs(continuous.Y, 0)))
        twists.append((-sp.diff(q["M"][0, 1], continuous.X)*normal).subs(continuous.Y, 0).applyfunc(sp.simplify))
    net_g = sum(gs, sp.zeros(3, 1)).applyfunc(sp.simplify)
    net_m = sp.simplify(sum(mts))
    force_excited = any(x != 0 for g in gs for x in g)
    moment_excited = any(x != 0 for x in mts)
    twist_excited = any(x != 0 for v in twists for x in v)
    entry = {"family": kind, "contract": contract,
             "owner_g_N_per_mm": [[str(x) for x in g] for g in gs],
             "owner_mt_N": [str(x) for x in mts],
             "owner_twist_gradient_g_N_per_mm": [[str(x) for x in v] for v in twists],
             "net_Gamma_force_source_N_per_mm": [str(x) for x in net_g],
             "net_Gamma_axial_moment_source_N": str(net_m),
             "force_analytic_excitation": force_excited,
             "axial_moment_analytic_excitation": moment_excited,
             "twist_gradient_analytic_excitation": twist_excited,
             "force_relative_status": "EXCITED" if force_excited else "N/A_ANALYTICALLY_UNEXCITED",
             "moment_relative_status": "EXCITED" if moment_excited else "N/A_ANALYTICALLY_UNEXCITED"}
    funcs = [(sp.lambdify(continuous.X, g, "numpy"), sp.lambdify(continuous.X, mt, "numpy"))
             for g, mt in zip(gs, mts)]
    families.append((fields, entry, funcs))

if sys.argv[1:] == ["--classify-only"]:
    assert not (HERE/"PLAN_FREEZE.json").exists()
    save(HERE/"FAMILY_SOURCE_CLASSIFICATION.json", {"status": "ANALYTIC_PRECOMMIT_NO_STATE_SOLVE",
         "families": [x[1] for x in families], "resources": resources,
         "no_family_has_nonzero_net_distributed_axial_moment_source": all(x[1]["net_Gamma_axial_moment_source_N"] == "0" for x in families),
         "state_solve_executed": False, "input_sha256": inputs,
         "source_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest()})
    print(json.dumps([x[1] for x in families], indent=2))
    raise SystemExit(0)

freeze = read(HERE/"PLAN_FREEZE.json")
for row in freeze["files"]:
    assert hashlib.sha256(Path(row["path"]).read_bytes()).hexdigest() == row["sha256"]
OUT = HERE/"run_v1"; OUT.mkdir(exist_ok=False)
results = []; negatives = []; inventory = []; arrays = {}


def matrix(path, n=729):
    rr = []; cc = []; vv = []; seen = set()
    with bind(path).open(encoding="utf-8-sig") as stream:
        for row in list(csv.reader(stream))[1:]:
            i, j, v = int(row[0]), int(row[1]), float(row[2])
            assert 0 <= i < n and 0 <= j < n and np.isfinite(v) and (i, j) not in seen
            seen.add((i, j)); rr.append(i); cc.append(j); vv.append(v)
    return sparse.coo_matrix((vv, (rr, cc)), shape=(n, n)).tocsr()


def evaluate(arms, coefficients, family_index, flux, label, graph, invalid=None):
    for arm in arms:
        arm.coeff = coefficients[arm.dofmap]
    entry = families[family_index][1]
    funcs = families[family_index][2]
    orders = []
    for q in flux["quadrature_results"]:
        fn = fd = mn = md = owner_fn = owner_mn = raw_fn = raw_fd = raw_mn = raw_md = 0.
        samples = []
        for gp in q["all_GP"]:
            x, u, w = gp["x_mm"], gp["u"], gp["weight_ds_mm"]
            ops = [arm.operators(u, 0., ell=1.) for arm in arms]
            g = [op["effective_force"]@arm.coeff for op, arm in zip(ops, arms)]
            mt = [float(arm.t@(op["m"]@arm.coeff)) for op, arm in zip(ops, arms)]
            if invalid in ("omit_twist_derivative_in_g", "reverse_twist_derivative_sign_in_g"):
                factor = 0. if invalid == "omit_twist_derivative_in_g" else -1.
                g = [op["T"]@arm.coeff+factor*np.cross(arm.t, op["ms"]@arm.coeff)
                     for op, arm in zip(ops, arms)]
            if invalid == "flip_owner0_axial_moment_sign":
                mt[0] *= -1
            expected_g = [np.asarray(fg(x), float).ravel() for fg, fm in funcs]
            expected_m = [float(fm(x)) for fg, fm in funcs]
            expected_net_g, expected_net_m = sum(expected_g), sum(expected_m)
            err_g, err_m = sum(g)-expected_net_g, sum(mt)-expected_net_m
            fn += w*(err_g@err_g); fd += w*sum(v@v for v in expected_g)
            mn += w*err_m**2; md += w*sum(v*v for v in expected_m)
            owner_fn += w*sum((a-b)@(a-b) for a, b in zip(g, expected_g))
            owner_mn += w*sum((a-b)**2 for a, b in zip(mt, expected_m))
            raw_fn += w*(sum(g)@sum(g)); raw_fd += w*sum(v@v for v in g)
            raw_mn += w*sum(mt)**2; raw_md += w*sum(v*v for v in mt)
            samples.append({"span": gp["span"], "u": u, "x_mm": x, "weight_ds_mm": w,
                "owner_g_N_per_mm": g, "owner_mt_N": mt,
                "analytic_owner_g_N_per_mm": expected_g, "analytic_owner_mt_N": expected_m,
                "Gamma_expected_force_N_per_mm": expected_net_g, "Gamma_expected_moment_N": expected_net_m,
                "source_subtracted_force_error_N_per_mm": err_g, "moment_error_N": err_m})
        row = {"order": q["order"], "all_original_GP_count": len(samples),
            "force_relative_status": entry["force_relative_status"],
            "moment_relative_status": entry["moment_relative_status"],
            "source_subtracted_force_absolute_L2_N_per_sqrt_mm": math.sqrt(fn),
            "moment_absolute_L2_N_sqrt_mm": math.sqrt(mn),
            "analytic_force_denominator": math.sqrt(fd), "analytic_moment_denominator": math.sqrt(md),
            "force_relative_balance_error": math.sqrt(fn/fd) if entry["force_analytic_excitation"] else None,
            "moment_relative_balance_error": math.sqrt(mn/md) if entry["axial_moment_analytic_excitation"] else None,
            "owner_force_relative_error": math.sqrt(owner_fn/fd) if entry["force_analytic_excitation"] else None,
            "owner_moment_relative_error": math.sqrt(owner_mn/md) if entry["axial_moment_analytic_excitation"] else None,
            "original_raw_force_relative_numeric": math.sqrt(raw_fn/raw_fd) if raw_fd > 0 else None,
            "original_raw_moment_relative_numeric": math.sqrt(raw_mn/raw_md) if raw_md > 0 else None}
        row["all_excited_metrics_within_original_MMS_budget"] = all(row[k] <= 1e-7 for k in
            ("force_relative_balance_error", "moment_relative_balance_error", "owner_force_relative_error", "owner_moment_relative_error") if row[k] is not None)
        save(OUT/f"{graph}_f{family_index}_{label}_GL{q['order']}.json", {"summary": row, "all_original_GP": samples})
        orders.append(row)
    return orders


try:
    # Independent physical F and coefficients are generated before touching K.
    physical = []
    negative_loads = {}
    for index, kind in enumerate(continuous.FAMILIES):
        F6, _, _ = continuous.physical_rhs(analytic_arms, kind, 6, 1.)
        F8, fs, ledger = continuous.physical_rhs(analytic_arms, kind, 8, 1.)
        exact, representation = continuous.exact_coefficients(analytic_arms, fs)
        assert norm(F6-F8)/norm(F8) <= 1e-7
        physical.append((F6, F8, exact, representation))
        arrays[f"f{index}_physical_F6"] = F6; arrays[f"f{index}_physical_F8"] = F8
        arrays[f"f{index}_exact_coefficients"] = exact
        save(OUT/f"f{index}_analytic_physical_load_ledger.json", ledger)
        for control in protocol["original_negative_controls"]:
            if control["family_index"] == index and control["name"] != "wrong_total_replacement_already_has_Gamma":
                bad, _, _ = continuous.physical_rhs(analytic_arms, kind, 8, 1., negative=control["name"])
                negative_loads[(index, control["name"])] = bad
    for graph in protocol["graphs"]:
        run, cluster, arms = arms_for(graph)
        assert all(np.array_equal(a.dofmap, b.dofmap) and np.array_equal(a.cp, b.cp)
                   for a, b in zip(arms, analytic_arms))
        old = read(PREP/f"actual_K_{graph}_h1_four_family_MMS_v1/results.json")
        assert old["source_binding_sha256"] == protocol["source_binding_sha256"]
        qualifier = read(Path(old["qualification_report"]))
        kval_path = run/"input_audit/patch_order_global_K.csv"
        manifest = {r["path"]: r["sha256"] for r in qualifier["input_manifest"]}
        assert hashlib.sha256(kval_path.read_bytes()).hexdigest() == manifest[str(kval_path)]
        K = matrix(kval_path); factor = splu(K.tocsc())
        assert K.shape == (729, 729)
        sigma = qualifier["full_actual_K_numeric_SPD"]["minimum_singular_value"]
        flux = read(PREP/f"cluster_gl4_{graph}_h1_flux_v1.json")
        assert [q["order"] for q in flux["quadrature_results"]] == [8, 10]
        raw = np.load(bind(PREP/f"actual_K_{graph}_h1_four_family_MMS_v1/actual_K_MMS_raw_vectors.npz"))
        for index, (F6, F8, exact, representation) in enumerate(physical):
            for name, val in ((f"f{index}_F6", F6), (f"f{index}_F8", F8), (f"f{index}_exact_coefficients", exact)):
                assert norm(raw[name]-val)/max(norm(val), np.finfo(float).tiny) <= 1e-7
            U = factor.solve(F8)
            r_exact, r_solve = K@exact-F8, K@U-F8
            backward = norm(r_solve)/(norm(K)*norm(U)+norm(F8))
            tau = max(1e-12, 64*729*np.finfo(float).eps)
            backward_tol = max(1e-14, 128*729*np.finfo(float).eps)
            coefficient_bound = max(tau, 8*(norm(r_exact)+norm(r_solve))/(sigma*norm(U)))
            coefficient_error = norm(U-exact)/norm(exact)
            assert norm(r_exact)/norm(F8) <= 1e-7 and backward <= backward_tol
            assert coefficient_bound < 0.0001 and coefficient_error <= coefficient_bound
            exact_metrics = evaluate(arms, exact, index, flux, "exact", graph)
            solved_metrics = evaluate(arms, U, index, flux, "solved", graph)
            results.append({"graph": graph, "family_index": index, "family": continuous.FAMILIES[index],
                "actual_K_exact_physicalF_relative": norm(r_exact)/norm(F8),
                "independent_sparse_backward": backward, "coefficient_relative_error": coefficient_error,
                "original_rule_coefficient_bound": coefficient_bound, "representation": representation,
                "exact_evaluator": exact_metrics, "solved_evaluator": solved_metrics})
            arrays[f"{graph}_f{index}_solved"] = U
            print("POSITIVE "+graph+" f"+str(index)+" solved and all original GL points evaluated", flush=True)
            for control in protocol["original_negative_controls"]:
                if control["family_index"] != index:
                    continue
                name = control["name"]
                item = {"graph": graph, "family_index": index, "control": name, "attempted": True, "executed": False}
                try:
                    if name == "wrong_total_replacement_already_has_Gamma":
                        sys.path.insert(0, str(PREP/"independent_readers_v7"))
                        points = module("point_physical_sparse_v7", PREP/"independent_readers_v7/point_physical_sparse_v7.py")
                        physical_points, _ = points.point_matrices(arms, 1., 729)
                        natural = matrix(run/"input_audit/triple_point_natural_b.csv")
                        badK = K-natural+physical_points["wrong_b_using_total"]
                        badF = F8
                        sensitivity = norm((badK-K)@exact)/norm(F8)
                        badU = splu(badK.tocsc()).solve(badF)
                    else:
                        badK = K; badF = negative_loads[(index, name)]
                        sensitivity = norm(badF-F8)/norm(F8)
                        assert norm(raw[f"f{index}_{name}_rhs"]-badF)/max(norm(badF), np.finfo(float).tiny) <= 1e-7
                        badU = factor.solve(badF)
                    assert np.isfinite(badU).all()
                    negative_backward = norm(badK@badU-badF)/(norm(badK)*norm(badU)+norm(badF))
                    assert negative_backward <= backward_tol
                    rejection = norm(badK@exact-badF)/norm(F8)
                    item.update(executed=True, independent_sensitivity=sensitivity,
                        sensitivity_exceeds_original_twice_budget=sensitivity > 2e-7,
                        exact_MMS_wrong_load_or_K_residual=rejection,
                        rejected_at_original_MMS_budget=rejection > 1e-7,
                        sparse_backward=negative_backward,
                        correct_analytic_source_strong=evaluate(arms, badU, index, flux, name, graph))
                    arrays[f"{graph}_f{index}_{name}_negative_state"] = badU
                except Exception as error:
                    item.update(failure=str(error), traceback=traceback.format_exc())
                negatives.append(item); inventory.append({k: item[k] for k in ("graph", "family_index", "control", "attempted", "executed")})
            for control in protocol["evaluator_only_negatives"]:
                if control["family_index"] == index:
                    name = control["name"]
                    neg = evaluate(arms, exact, index, flux, name, graph, invalid=name)
                    negatives.append({"graph": graph, "family_index": index, "control": name,
                        "executed": True, "evaluator_only_invalid_formula_no_state_solve": True,
                        "metrics": neg})
                    inventory.append({"graph": graph, "family_index": index, "control": name, "attempted": True, "executed": True,
                                      "evaluator_only": True})
    save(OUT/"POSITIVE_RESULTS.json", {"results": results, "resources": resources})
    save(OUT/"NEGATIVE_RESULTS.json", {"results": negatives})
except Exception as error:
    save(OUT/"FAILURE_PRESERVED.json", {"error": str(error), "traceback": traceback.format_exc(),
        "positive_results_completed": results, "negative_results_completed": negatives})
    raise
finally:
    np.savez_compressed(OUT/"INDEPENDENT_MMS_STATES_AND_PHYSICAL_LOADS.npz", **arrays)
    planned = [(g, c["family_index"], c["name"]) for g in protocol["graphs"]
               for c in protocol["original_negative_controls"]+protocol["evaluator_only_negatives"]]
    done = {(x["graph"], x["family_index"], x["control"]) for x in inventory if x["attempted"]}
    save(OUT/"NEGATIVE_EXECUTION_INVENTORY.json", {"executed": inventory,
        "not_executed": [{"graph": g, "family_index": i, "control": c} for g, i, c in planned if (g, i, c) not in done],
        "attempted_failed": [x for x in inventory if x["attempted"] and not x["executed"]],
        "not_executed_is_not_a_pass": True})
    for path, digest in inputs.items():
        assert hashlib.sha256(Path(path).read_bytes()).hexdigest() == digest
    import psutil
    observed_memory = psutil.Process().memory_info()._asdict()
    save(OUT/"INPUT_AND_SOURCE_SHA256.json", {"input_sha256": inputs,
        "resources": resources, "observed_process_memory": observed_memory,
        "worker_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "ordinary_load_strong_FAIL_not_relabelled": True,
        "CAD_or_compiler_or_Native_started": False})
