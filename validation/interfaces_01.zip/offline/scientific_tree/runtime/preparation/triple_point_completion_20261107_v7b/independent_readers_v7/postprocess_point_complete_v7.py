"""Read actual v7 point-completed fields; no compiler/CAD/solver, no input writes."""
import argparse,csv,json,os
from pathlib import Path
for name in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS']:os.environ[name]='1'
import numpy as np
import line_reader_v7 as reader
from cluster_physical_core import integrate_cluster,integrate_bulk_action,recovered_clamp_resultant,resultants
from point_identity_v7 import Identity,identity_arguments,require,clean,sha
from point_physical_sparse_v7 import qualify_points

def write_vector(path,vector):
    with Path(path).open('x',encoding='utf-8',newline='')as f:
        writer=csv.writer(f);writer.writerow(['global_dof_zero_based','value']);writer.writerows(enumerate(vector))

def process(args,identity):
    require(not args.out_dir.exists(),'fresh output required')
    run=args.run_dir.resolve();packet=args.load_dir.resolve()
    identity.fresh_output(args.out_dir,[run,packet])
    arms,F,u,positions,patchforces,betas,ell,cluster,inputs,scattererr=reader.load_actual(run,packet,identity)
    origin=np.asarray(args.moment_origin_mm,float);require(origin.shape==(3,)and np.isfinite(origin).all(),'moment origin')
    seal=reader.verify_boundary_file_seal(packet,run,inputs)
    require(reader.confirmed_clamp(run/'boundary_domain_probe.jsonl',inputs)is not None,'confirmed homogeneous whole PATCH0 clamp required')
    b0,binding=reader.observed_boundary_action(packet/'boundary_action_global.csv',arms,u,inputs);binding['file_identity_seal']=seal
    actual,physical,point_actions,point_report=qualify_points(run,packet,arms,ell,u,positions,cluster,identity)
    natural=point_actions['natural_joint_b'];essential_a=point_actions['essential_joint_a'];essential_far=point_actions['essential_PATCH0_far_corner']
    essential=essential_a+essential_far;boundary=b0+essential
    out=integrate_cluster(arms,betas,ell,args.gauss,origin)
    q2=min(16,args.gauss+2);second=integrate_cluster(arms,betas,ell,q2,origin)
    bulk=integrate_bulk_action(arms);bulk_action=bulk.pop('global_action')
    line=out.pop('numerical_canonical_cluster_action_global');line_second=second.pop('numerical_canonical_cluster_action_global')
    internal=line+natural;internal_second=line_second+natural
    residual=bulk_action+internal+boundary-F
    ef,em=resultants(F,positions,origin);bf,bm=resultants(boundary,positions,origin)
    fs=float(np.linalg.norm(ef)+np.linalg.norm(bf));ms=float(np.linalg.norm(em)+np.linalg.norm(bm))
    norm2=float(np.linalg.norm(residual));rhsnorm=float(np.linalg.norm(F));sum_norms=sum(np.linalg.norm(v)for v in [bulk_action,internal,boundary,F])
    def action_ledger(vector):
        f,m=resultants(vector,positions,origin)
        return dict(internal_action_force_N=f.tolist(),internal_action_moment_N_mm=m.tolist(),quadratic_work_N_mm=float(u@vector))
    line_work=float(u@line);natural_work=float(u@natural);essential_work=float(u@essential);external_work=float(u@F)
    clamp=reader.confirmed_clamp(run/'boundary_domain_probe.jsonl',inputs)
    rf,rm=recovered_clamp_resultant(arms[0],args.gauss,origin)
    data=dict(schema='oe-actual-threepatch-point-complete-postprocess-v7',
      status='POSTPROCESSED_OBSERVED_FIELDS_NOT_SCIENTIFIC_ACCEPTANCE',
      source_binding_sha256=identity.source_sha,runtime_manifest_sha256=identity.runtime_sha,source_root=str(identity.root),
      units=dict(length='mm',force='N',stress_modulus='N/mm^2',rotation='rad',work='N mm'),moment_origin_mm=origin.tolist(),
      actual_global_dofs=len(u),owner_packet_sha256=reader.PACKET_SHA,actual_owner_handles=[hex(a.handle)for a in arms],
      actual_materials=[dict(owner=hex(a.handle),E=a.E,nu=a.nu,t_mm=a.thickness)for a in arms],
      actual_Native_status=cluster['status'],structural_accuracy_accepted=False,endpoint_general_loaded_response='OPEN_PENDING_FULL_GRAPH_H_AND_INDEPENDENT_REFERENCE_VALIDATION',
      physical_line_core_sha256='e52b2ff82da8f02b4ef77d4676fb0388444ca036319f0b048108b2365e2c54ff',
      external_load_ledger=dict(policy='actual pre_boundary_force once; patch forces scatter crosscheck only; no recovered corner force added',
        patch_to_global_vector_difference_norm_N=scattererr,total_force_N=ef.tolist(),total_moment_N_mm=em.tolist(),external_generalized_work_N_mm=external_work,
        point_source_intent_not_inferred_from_equivalent_control_forces=True),bulk=bulk,cluster=out,
      quadrature_crosscheck=dict(orders=[args.gauss,q2],canonical_action_relative_difference=float(np.linalg.norm(internal-internal_second)/max(np.linalg.norm(internal_second),1e-300)),
        line_action_relative_difference=float(np.linalg.norm(line-line_second)/max(np.linalg.norm(line_second),1e-300)),
        quadratic_work_difference_N_mm=float(u@(internal-internal_second)),
        displacement_RMS_differences_mm=[a['displacement_RMS_mm']-b['displacement_RMS_mm']for a,b in zip(out['jumps'],second['jumps'])]),
      point_operator_qualification=point_report,point_action_ledger=dict(
        natural_joint_b=action_ledger(natural),essential_joint_a=action_ledger(essential_a),essential_PATCH0_far_corner=action_ledger(essential_far),
        line_only=action_ledger(line),completed_internal_line_plus_natural=action_ledger(internal),
        original_observed_BC=action_ledger(b0),completed_boundary_internal_minus_rhs=action_ledger(boundary),
        essential_support_reaction_sign='negative actual exported essential COO times SAME CASE U',
        point_reaction_derived_from_global_residual=False,external_F_modified=False,
        physical_expected_vs_actual_point_action_L2_N={name:float(np.linalg.norm((actual[name]-physical[name])@u))for name in actual}),
      recovered_clamp_balance=dict(boundary_evidence=clamp,method='historical recovered full Green traction/moment only; not full weak-boundary numerical reaction',
        recovered_support_force_N=rf.tolist(),recovered_support_moment_N_mm=rm.tolist(),external_plus_recovered_support_force_N=(ef+rf).tolist(),
        external_plus_recovered_support_moment_N_mm=(em+rm).tolist(),accepted_as_numerical_global_balance=False,
        raw_recovered_endpoint_traces_do_not_define_imposed_corner_sources=True),
      numerical_total_balance=dict(required_input_semantics='observed pre-coupling BC action plus actual essential_a/far COO times same-case U',
        support_reaction_sign='reaction=-(original_BC_action+essential_point_action)',total_force_N=(ef-bf).tolist(),total_moment_N_mm=(em-bm).tolist(),
        force_balance_relative_to_sum_of_resultant_norms=float(np.linalg.norm(ef-bf)/fs)if fs>0 else None,
        moment_balance_relative_to_sum_of_resultant_norms=float(np.linalg.norm(em-bm)/ms)if ms>0 else None,
        actual_boundary_internal_minus_rhs_work_N_mm=float(boundary@u),original_BC_work_N_mm=float(b0@u),essential_point_work_N_mm=essential_work,
        observed_action_binding=binding,point_reactions_from_actual_matrix_products=True),
      loaded_full_RHS_residual=dict(equation='independent_GL4_bulk + independent_line + actual_natural_b_COO_U + original_observed_BC + actual_essential_a_far_COO_U - actual_external_F',
        absolute_L2_N=norm2,absolute_Linf_N=float(np.linalg.norm(residual,np.inf)),relative_to_external_L2=norm2/rhsnorm if rhsnorm>0 else None,
        normalized_by_sum_of_action_L2_norms=float(norm2/sum_norms)if sum_norms>0 else None,work_residual_N_mm=float(u@residual),
        external_force_not_constructed_from_KU=True,independent_material_quadratic_work_N_mm=float(u@bulk_action),
        independent_line_quadratic_work_N_mm=line_work,actual_natural_point_quadratic_work_N_mm=natural_work,
        independent_interface_quadratic_work_N_mm=float(u@internal),observed_boundary_internal_minus_rhs_work_N_mm=float(u@boundary),actual_external_work_N_mm=external_work),
      all_raw_strong_metrics_and_all_pairs_retained=True,no_endpoint_singularity_claimed=True,
      actual_internal_matrix_role='line+natural_b',actual_boundary_matrix_role='original_BC+essential_a+essential_far',
      compiler_Native_or_solver_started=False)
    for p in inputs:identity.bind(p)
    identity.bind(Path(__file__));identity.verify_unchanged();data['input_manifest']=identity.manifest()
    args.out_dir.mkdir(parents=True,exist_ok=False)
    vectors={'independent_canonical_line_action.csv':line,'independent_canonical_interface_action.csv':internal,
      'independent_GL4_bulk_action.csv':bulk_action,'actual_natural_point_action.csv':natural,'actual_essential_point_action.csv':essential,
      'boundary_internal_minus_rhs_completed.csv':boundary,'completed_full_RHS_residual.csv':residual}
    for name,vector in vectors.items():write_vector(args.out_dir/name,vector)
    data['output_vectors']=[dict(file=name,sha256=sha(args.out_dir/name))for name in vectors]
    with(args.out_dir/'postprocess.json').open('x',encoding='utf-8')as f:json.dump(clean(data),f,indent=2,allow_nan=False)
    return data

def main():
    ap=argparse.ArgumentParser(description=__doc__);identity_arguments(ap)
    ap.add_argument('--run-dir',type=Path,required=True);ap.add_argument('--load-dir',type=Path,required=True)
    ap.add_argument('--out-dir',type=Path,required=True);ap.add_argument('--gauss',type=int,default=8)
    ap.add_argument('--moment-origin-mm',type=float,nargs=3,default=[0.,0.,0.]);args=ap.parse_args()
    require(4<=args.gauss<=16,'original line quadrature range')
    value=process(args,Identity(args));print(json.dumps(dict(status=value['status'],output=str(args.out_dir/'postprocess.json'))))

if __name__=='__main__':main()
