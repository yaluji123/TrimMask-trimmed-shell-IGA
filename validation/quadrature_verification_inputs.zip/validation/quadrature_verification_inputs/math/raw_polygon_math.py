"""Original Fraction polygon clipping and material-area functions."""
from fractions import Fraction as F

def q(x):return F.from_float(float(x))

def halfplane(poly,axis,bound,greater):
 if not poly:return []
 result=[]
 for p,r in zip(poly,poly[1:]+poly[:1]):
  a=p[axis]-bound;b=r[axis]-bound;pin=a>=0 if greater else a<=0;rin=b>=0 if greater else b<=0
  if pin:result.append(p)
  if pin!=rin:
   t=a/(a-b);result.append((p[0]+t*(r[0]-p[0]),p[1]+t*(r[1]-p[1])))
 return clean(result)

def rectangle_clip(poly,bounds):
 u0,u1,v0,v1=bounds
 for axis,bound,greater in[(0,u0,True),(0,u1,False),(1,v0,True),(1,v1,False)]:poly=halfplane(poly,axis,bound,greater)
 return poly

def area(poly):
 if len(poly)<3:return F(0)
 return abs(sum((p[0]*r[1]-r[0]*p[1]for p,r in zip(poly,poly[1:]+poly[:1])),F(0)))/2

def raw_material_area(g,bounds):
 u0,u1,v0,v1=bounds;carrier=[(u0,v0),(u1,v0),(u1,v1),(u0,v1)]
 outer=[tuple(map(q,p))for p in g['outer_loop']]if g['has_outer']else carrier
 value=area(rectangle_clip(outer,bounds))
 # This actual fixture has one hole only on owner1214. Do not silently adopt
 # arbitrary overlapping/outside holes as a general polygon-Boolean algorithm.
 if g['hole_loops']:assert int(g['shell_handle'])==1214 and len(g['hole_loops'])==1
 for hole in g['hole_loops']:value-=area(rectangle_clip([tuple(map(q,p))for p in hole],bounds))
 assert value>=0
 return value
