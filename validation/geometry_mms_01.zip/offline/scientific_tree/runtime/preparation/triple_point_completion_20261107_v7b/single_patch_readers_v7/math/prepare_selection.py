"""Create the timing selection only from the final-runtime independent exact oracle."""
from pathlib import Path
import json,hashlib,argparse
HERE=Path(__file__).resolve().parent;ROOT=Path('投稿/二次修稿/准备工作')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def run(oracle,output,index,context):
 a=argparse.Namespace(oracle=oracle,output=output);assert not a.output.exists();q=json.loads(context.bind(a.oracle).read_text());assert q['status']=='COMPLETED_SAME_ORACLE_ALL9_PREDECLARED_COSTSTUDY_GATES'and q['actual_profile_count']==9 and q['actual_binary']['sha256']=='d55a004bc4830d2ddadfad99b6e9ffd05511a5bf3f411c85a87179053a195f0b'
 selected=q['coststudy_selection'];assert selected['three_families_accuracy_eligible'];names={'automatic_clipper7':selected['automatic_positive_fitted_profile'],'clipper7':selected['positive_fitted_fixed_profile'],'fixed_mask12':selected['masked_first_passing']};assert names['fixed_mask12']==Path(index['public_profiles']['fixed_mask12']['run_dir']).name,'a different first-passing mask requires a separately frozen timing schedule'
 data={r['case']:r for r in q['profiles']};methods={}
 for method,name in names.items():
  row=data[name];assert row['accuracy_eligible_for_coststudy_only']and all(row['eligibility_gates'].values());case=ROOT/'runtime/runs'/name;assert sha(case/'source_runtime_manifest.json')=='50999199bb7bf6770b7446beae7c5e2600294276d6ba858ab7a616f873bf5a84';profile=ROOT/'runtime/quadrature_profiles'/(method+'.json');assert sha(case/'executed_profile.json')==sha(profile)
  methods[method]=dict(case=name,eligible=True,eligibility_gates=row['eligibility_gates'],profile_sha256=sha(profile),displacement_L2_upper=row['displacement_relative_L2_upper'],energy_seminorm_upper=row['energy_seminorm_relative_upper'],material_energy_gap_upper=row['independent_material_half_energy_gap_upper'])
 result=dict(status='PASS_FINAL1212_SAME_ACCURACY_TIMING_SELECTION',source_binding_sha256='90f72156bd9f1430e25177e91b6a69b89c4434f81934dfdee19b20eef2a96566',runtime_manifest_sha256='50999199bb7bf6770b7446beae7c5e2600294276d6ba858ab7a616f873bf5a84',oracle_sha256=sha(a.oracle),qualified_methods=methods,all_nine_profiles=q['profiles'],physical_thresholds_not_lowered=True,timing_not_seen_or_used_to_select=True,comparison_scope='same captured mesh, geometry, force and BC; not continuum accuracy certification',fixed_interleaved_schedule=['automatic_clipper7','clipper7','fixed_mask12','fixed_mask12','automatic_clipper7','clipper7','clipper7','fixed_mask12','automatic_clipper7'],source_sha256=sha(Path(__file__)))
 result['input_manifest']=context.finish()
 a.output.write_text(json.dumps(result,indent=2),encoding='utf-8');print(json.dumps(dict(status=result['status'],methods=methods)))
if __name__=='__main__':raise SystemExit('Use read_single_patch_v7.py')
