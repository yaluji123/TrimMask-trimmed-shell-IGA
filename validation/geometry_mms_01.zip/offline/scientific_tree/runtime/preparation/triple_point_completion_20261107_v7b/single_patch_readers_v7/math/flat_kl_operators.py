"""Independent cubic B-spline and flat Kirchhoff-Love trace operators.

The two mathematical functions are preserved verbatim from the recorded
independent component audit used by the triangle sparse reader.
This module defines operators only; it does not assemble or solve a model.
"""
from functools import lru_cache
import numpy as np


def basis(t, k, p=3):
    n=len(k)-p-1
    @lru_cache(None)
    def b(i,degree,deriv):
        if deriv>degree or i<0 or i+degree+1>=len(k):
            return 0.
        if degree==0:
            return float(deriv==0 and (k[i]<=t<k[i+1] or t==1. and i==n-1))
        d1=k[i+degree]-k[i];d2=k[i+degree+1]-k[i+1]
        if deriv==0:
            return ((t-k[i])/d1*b(i,degree-1,0) if d1 else 0.)+((k[i+degree+1]-t)/d2*b(i+1,degree-1,0)if d2 else 0.)
        return (degree/d1*b(i,degree-1,deriv-1)if d1 else 0.)-(degree/d2*b(i+1,degree-1,deriv-1)if d2 else 0.)
    return np.array([[b(i,p,d)for i in range(n)]for d in range(4)])


def operators(d,nx,ny,E,t,nu,correct_moment=False):
    count=len(d[(0,0)]);N=np.zeros((6,count*3));V=np.zeros_like(N)
    ids=np.arange(count)*3
    for row in range(3):N[row,ids+row]=d[(0,0)]
    N[3,ids+2]=d[(0,1)];N[4,ids+2]=-d[(1,0)]
    Dm=E*t/(1-nu*nu)*np.array([[1,nu,0],[nu,1,0],[0,0,(1-nu)/2]])
    Bm=np.zeros((3,count*3))
    Bm[0,ids]=d[(1,0)];Bm[1,ids+1]=d[(0,1)]
    Bm[2,ids]=d[(0,1)];Bm[2,ids+1]=d[(1,0)]
    stress=Dm@Bm
    V[0]=nx*stress[0]+ny*stress[2];V[1]=nx*stress[2]+ny*stress[1]
    D=E*t**3/(12*(1-nu*nu))
    V[2,ids+2]=-D*(nx*(d[(3,0)]+d[(1,2)])+ny*(d[(2,1)]+d[(0,3)]))
    hxx=d[(2,0)];hyy=d[(0,2)];hxy=d[(1,1)]
    mnn=-D*((nx*nx+nu*ny*ny)*hxx+(ny*ny+nu*nx*nx)*hyy+2*(1-nu)*nx*ny*hxy)
    mnt=-D*(1-nu)*(-nx*ny*hxx+nx*ny*hyy+(nx*nx-ny*ny)*hxy)
    V[3,ids+2]=nx*mnt+ny*mnn
    V[4,ids+2]=ny*mnt-nx*mnn
    if correct_moment:V[3:6]*=-1
    return N,V
