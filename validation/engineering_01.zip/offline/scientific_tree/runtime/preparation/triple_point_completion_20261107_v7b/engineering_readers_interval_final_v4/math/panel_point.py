"""Independent physical point oracle for same-geometry cubic Hull mesh family."""
import argparse,csv,hashlib,importlib.util,json,math
from collections import defaultdict
from pathlib import Path
import numpy as np

HERE=Path(r'D:\BaiduSyncdisk\CODEX\投稿\二次修稿\准备工作\mechanics\candidate\panel_mesh_family_v1');ROOT=Path(r'D:\BaiduSyncdisk\CODEX\投稿\二次修稿\准备工作')
POINT=ROOT/'mechanics/candidate/panel_signed_point_preparation_v1/point_operator_proposal_v1'
OLDMETA=ROOT/'runtime/runs/native_panel1x_endpoint1493_passive_v1/capture/endpoint_metadata.jsonl'
REFERENCE=ROOT/'mechanics/candidate/endpoint_vertex988_source_v1/checker/check_actual_endpoint_capture.py'

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def rows(p):
 with p.open(encoding='utf-8-sig',newline='')as f:return list(csv.DictReader(f))
def add(a,b,s=1.):
 c=dict(a)
 for k,v in b.items():c[k]=c.get(k,0.)+s*v
 return{k:v for k,v in c.items()if v!=0.}
def product(a,b):
 c=defaultdict(float)
 for(r,i),v in a.items():
  for(s,j),w in b.items():
   if r==s:c[i,j]+=v*w
 return dict(c)
def error(a,b):
 keys=a.keys()|b.keys();e=math.sqrt(math.fsum((a.get(k,0.)-b.get(k,0.))**2 for k in keys))/max(1.,math.sqrt(math.fsum(v*v for v in b.values())));assert e<=1e-9,('same independent local-row/matrix criterion',e);return e

def audit(case):
 assert sha(case/'applied_source_binding.json')=='90f72156bd9f1430e25177e91b6a69b89c4434f81934dfdee19b20eef2a96566'
 assert sha(REFERENCE)=='c4892fb0b822bbee5ab43f97dde4010e5664ecb7bc347dccaa07599e823f33ff'
 spec=importlib.util.spec_from_file_location('unchanged_independent_KL_N_M_physics',REFERENCE);physics=importlib.util.module_from_spec(spec);spec.loader.exec_module(physics)
 meta={x['uid']:x for line in OLDMETA.read_text().splitlines()if '"uid"'in line and(x:=json.loads(line)).get('status')=='ROWS_CAPTURED_LOCAL_CP3_ROLE_NOT_CERTIFIED'}
 geo={int(p.stem.rsplit('_',1)[1]):read(p)for p in(case/'capture').glob('trim_geometry_*.json')};assert len(geo)==36
 prop={x['shell_handle']:x for x in read(case/'capture/engineering_input_only_manifest.json')['surfaces']}
 cp={(int(r['owner']),int(r['local_cp'])):int(r['global_node'])-1 for r in rows(case/'p4/numbering.csv')}
 ncp=len(cp);assert ncp==EXPECTED_CP
 actual_rows=defaultdict(dict)
 for r in rows(case/'point/actual_point_rows.csv'):
  actual_rows[int(r['uid']),r['kind']][int(r['row']),int(r['global_CP3_dof'])]=float(r['value'])
 cache={};rowerr=[]
 def local(uid):
  if uid in cache:return cache[uid]
  m=meta[uid];owner=m['owner'];g=geo[owner];p=prop[owner];uv=np.asarray(m['selected_uv']);L=np.asarray(m['L3_rows']);assert np.allclose(L@L.T,np.eye(3),rtol=0,atol=1e-10)
  n,nn,J,H,normal=physics.kinematics(g,*uv,L);assert abs(n.sum()-1.)<1e-12
  N={}
  for i,j in zip(*np.nonzero(nn[:3])):N[int(i),3*cp[owner,int(j)//3]+int(j)%3]=float(nn[i,j])
  R={}
  if m['boundary_candidate']:
   # The admitted family has byte-exact primitive UV loops and the same affine
   # geometry/material. Reference te/mu/L3 are geometry coordinates, not old DOF rows.
   M=physics.moment(H,normal,L,np.asarray(m['outward_conormal_candidate']),p['E'],p['nu'],p['constant_t'])
   rv=np.cross(M.T,np.asarray(m['tangent'])).T
   for i,j in zip(*np.nonzero(rv)):R[int(i),3*cp[owner,int(j)//3]+int(j)%3]=float(rv[i,j])
  assert(uid,'N')in actual_rows;rowerr.append(error(actual_rows[uid,'N'],N))
  if R:assert(uid,'R0')in actual_rows;rowerr.append(error(actual_rows[uid,'R0'],R))
  cache[uid]=(N,R,owner);return cache[uid]
 plan=(POINT/'point_topology.tsv').read_text().splitlines();assert plan.pop(0)=='OE_ACTUAL_POINT_TOPOLOGY_V1';groups={};owners={};ends={}
 for line in plan:
  v=line.split('\t');kind=v[0];g=int(v[1])
  if kind=='G':groups[g]=int(v[2])
  elif kind=='O':owners[g,int(v[2])]=[int(v[3]),[]]
  elif kind=='R':owners[g,int(v[2])][1].append((int(v[3]),int(v[4])))
  elif kind=='E':ends[int(v[2]),int(v[3])]=[g,[int(v[4]),int(v[5])],[[],[]]]
  elif kind=='T':ends[int(v[2]),int(v[3])][2][int(v[4])].append((int(v[5]),int(v[6])))
  else:raise AssertionError(kind)
 assert len(groups)==60 and len(owners)==184 and len(ends)==168
 gamma={}
 for r in rows(case/'p4/real_line_blocks.csv'):
  assert r['form']=='Skew'
  if int(r['original_group_mask'])in(7,63):
   e=int(r['entry']);pair=(float(r['gamma1']),float(r['gamma2']));assert e not in gamma or gamma[e]==pair;gamma[e]=pair
 mode={}
 for r in rows(case/'p4/gp.csv'):
  e=int(r['entry']);m=int(r['flux_mode']);assert e not in mode or mode[e]==m;mode[e]=m
 assert len(mode)==84 and len(gamma)==84
 for e,m in mode.items():
  if m==3:assert e not in gamma;gamma[e]=(0.,0.)
 actual_gamma={(int(r['entry']),int(r['end'])):(float(r['gamma1']),float(r['gamma2']))for r in rows(case/'point/actual_point_gamma.csv')}
 assert all(actual_gamma[e,end]==gamma[e]for e,end in ends)
 total={};cg={}
 for(g,owner),(uid,terms)in owners.items():
  N,R,o=local(uid);assert o==owner;A,_,_=local(groups[g]);sumr={}
  for ruid,sign in terms:
   _,r,other=local(ruid);assert other==owner;sumr=add(sumr,r,sign)
  total=add(total,product(add(N,A,-1.),sumr))
 for(e,end),(g,uids,terms)in ends.items():
  n1,_,_=local(uids[0]);n2,_,_=local(uids[1]);w={}
  for side in(0,1):
   for uid,sign in terms[side]:w=add(w,local(uid)[1],(-1 if side else 1)*gamma[e][side]*sign)
  cg=add(cg,product(add(n1,n2,-1.),w))
 new=add(total,cg,-1.);skew=add({k:-v for k,v in new.items()},{(j,i):v for(i,j),v in new.items()})
 actual=defaultdict(dict)
 for r in rows(case/'point/actual_point_matrices.csv'):actual[r['channel']][int(r['row']),int(r['col'])]=float(r['value'])
 errors={k:error(actual[k],m)for k,m in [('Ctotal',total),('Cgamma',cg),('Cnew',new),('Skew',skew)]}
 return dict(status='PASS_INDEPENDENT_PANEL_POINT_N_M_R_AND_FULL_POINT_MATRICES_ONLY',CP=ncp,DOF=3*ncp,groups=60,unique_owner_points=184,Gamma_endpoints=168,independent_live_mesh_getters=len(cache),local_row_norm_max=max(rowerr),matrix_norm_errors=errors,actual_current_gamma_independently_replayed_from_P4=True,old_h4_discrete_row_coefficients_reused=False,RP_testspace_zero_waiver=False,global_state_algebra_FEM_accuracy_or_general_PDE_accepted=False,reader_sha256=sha(Path(__file__)))

if __name__=='__main__':raise SystemExit('Use read_engineering_mode4_v7.py with current strict preflight')
