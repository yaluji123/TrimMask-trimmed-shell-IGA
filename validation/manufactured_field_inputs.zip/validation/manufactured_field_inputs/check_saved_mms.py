"""Check saved manufactured-field matrices, vectors and raw trace arithmetic.

This reader performs matrix-vector products and point-operator algebra only.
It does not solve a state or call an eigensolver, CAD host or execution worker.
"""
from pathlib import Path
import argparse, json, math, sys
sys.dont_write_bytecode = True
import numpy as np
from scipy import sparse

HERE = Path(__file__).resolve().parent

def need(ok, message):
    if not ok:
        raise ValueError(message)

def load(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))

def relative_difference(a, b, scale):
    return float(np.linalg.norm(a-b)/max(scale, np.finfo(float).tiny))

def check_trace(path):
    data = load(path); samples = data['all_original_GP']; saved = data['summary']
    order = saved['order']; count = len(samples)
    need(count == {8: 48, 10: 60}[order], 'complete original point set')
    w = np.array([r['weight_ds_mm'] for r in samples])
    need(np.isfinite(w).all() and (w > 0).all() and abs(w.sum()-100.) < 1e-10, 'original line measure')
    g = np.array([r['owner_g_N_per_mm'] for r in samples]); m = np.array([r['owner_mt_N'] for r in samples])
    eg = np.array([r['analytic_owner_g_N_per_mm'] for r in samples]); em = np.array([r['analytic_owner_mt_N'] for r in samples])
    need(g.shape == eg.shape == (count, 3, 3) and m.shape == em.shape == (count, 3), 'all three owners')
    need(all(np.isfinite(x).all() for x in (g, m, eg, em)), 'finite physical traces')
    error_g = g.sum(1)-eg.sum(1); error_m = m.sum(1)-em.sum(1)
    need(np.allclose(error_g, [r['source_subtracted_force_error_N_per_mm'] for r in samples], rtol=1e-12, atol=1e-10), 'saved vector error identity')
    norm2 = lambda x: float(np.sum(w.reshape((count,)+(1,)*(x.ndim-1))*x*x))
    fn, fd, mn, md = norm2(error_g), norm2(eg), norm2(error_m), norm2(em)
    of, om = norm2(g-eg), norm2(m-em)
    rfn, rfd, rmn, rmd = norm2(g.sum(1)), norm2(g), norm2(m.sum(1)), norm2(m)
    values = dict(source_subtracted_force_absolute_L2_N_per_sqrt_mm=math.sqrt(fn),
        moment_absolute_L2_N_sqrt_mm=math.sqrt(mn), analytic_force_denominator=math.sqrt(fd), analytic_moment_denominator=math.sqrt(md),
        force_relative_balance_error=math.sqrt(fn/fd) if saved['force_relative_status']=='EXCITED' else None,
        moment_relative_balance_error=math.sqrt(mn/md) if saved['moment_relative_status']=='EXCITED' else None,
        owner_force_relative_error=math.sqrt(of/fd) if saved['force_relative_status']=='EXCITED' else None,
        owner_moment_relative_error=math.sqrt(om/md) if saved['moment_relative_status']=='EXCITED' else None,
        original_raw_force_relative_numeric=math.sqrt(rfn/rfd) if rfd>0 else None,
        original_raw_moment_relative_numeric=math.sqrt(rmn/rmd) if rmd>0 else None)
    errors=[]
    for key, value in values.items():
        need((value is None)==(saved[key] is None), 'unexcited metric remains N/A')
        if value is not None:
            errors.append(abs(value-saved[key])/max(1.,abs(saved[key])))
    need(max(errors) < 1e-12, 'saved trace summary arithmetic')
    return count, max(errors)

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--data-root',type=Path,default=HERE.parents[1])
    root=parser.parse_args().data_root.resolve()
    phase=root/'offline/scientific_tree/runtime/preparation/triple_point_completion_20261107_v7b'
    diagnostics=root/'new_analysis/strong_flux_diagnosis_v1'
    sys.path.insert(0,str(phase/'independent_readers_v7'))
    import cluster_physical_core as core
    import point_physical_sparse_v7 as points
    geometry={owner:load(HERE/f'geometry/load_stage_geometry_{owner}.json') for owner in (7867,7868,7869)}
    natural=sparse.load_npz(diagnostics/'baseline_210_v1/Knatural_b.npz')
    max_vector_difference=0.; checked_families=negative_vectors=0
    for graph in ('all','omit1ec8'):
        record=load(HERE/f'graphs/{graph}.json'); arms=[]; all_dofs=[]
        need(record['actual_global_dofs']==729 and record['ell']==1., 'recorded coarse dimension and scaling')
        for row in sorted(record['arms'],key=lambda x:int(x['handle'],16)):
            owner=int(row['handle'],16); g=geometry[owner]; mapping=np.asarray(row['global_dofmap'],int)
            need(g['controls_u']==g['controls_v']==9 and g['E']==row['E_observed'] and g['nu']==row['nu_observed'] and g['constant_t']==row['thickness_observed'], 'exact carrier and material binding')
            all_dofs.extend(mapping.tolist())
            arms.append(core.Arm(owner,np.array(g['knots_u']),np.array(g['knots_v']),g['degree_u'],g['degree_v'],np.array(g['control_global_Vg']),np.array(g['weights']),g['E'],g['nu'],g['constant_t'],mapping,np.zeros(len(mapping))))
        need(sorted(all_dofs)==list(range(729)), 'complete unique global DOF map')
        need(sum(r['selected_penalty'] for r in record['relations'])=={'all':3,'omit1ec8':2}[graph], 'actual penalty graph')
        K=sparse.load_npz(diagnostics/'baseline_210_v1/actual_K.npz' if graph=='all' else HERE/'K_omit1ec8.npz')
        need(K.shape==(729,729) and np.isfinite(K.data).all(), 'actual saved matrix')
        wrong=points.point_matrices(arms,1.,729)[0]['wrong_b_using_total']
        folder=phase/f'actual_K_{graph}_h1_four_family_MMS_v1'; report=load(folder/'results.json')
        need(report['original_relative_MMS_budget']==1e-7 and len(report['family_results'])==4, 'original families and tolerance')
        with np.load(folder/'actual_K_MMS_raw_vectors.npz',allow_pickle=False) as data:
            for f,row in enumerate(report['family_results']):
                exact=data[f'f{f}_exact_coefficients']; F8=data[f'f{f}_F8']; scale=float(np.linalg.norm(F8))
                need(exact.shape==F8.shape==(729,) and scale>0, 'physical input vector dimensions')
                residual=K@exact-F8; saved=data[f'f{f}_actual_K_residual']
                difference=relative_difference(residual,saved,scale); max_vector_difference=max(max_vector_difference,difference)
                need(difference<1e-11, 'original matrix action and saved residual')
                need(float(np.linalg.norm(saved)/scale)<=1e-7 and float(np.linalg.norm(data[f'f{f}_F6']-F8)/scale)<=1e-7, 'original MMS and GL6/GL8 gates')
                for control in row['negative_controls']:
                    name=control['control']
                    if name=='wrong_total_replacement_already_has_Gamma':
                        expected=(K-natural+wrong)@exact-F8; saved=data[f'f{f}_wrong_total_residual']
                    else:
                        expected=K@exact-data[f'f{f}_{name}_rhs']; saved=data[f'f{f}_{name}_residual']
                    difference=relative_difference(expected,saved,scale); max_vector_difference=max(max_vector_difference,difference)
                    need(difference<1e-11 and np.linalg.norm(saved)/scale>1e-7, 'original negative remains rejected')
                    negative_vectors+=1
                checked_families+=1
    run=diagnostics/'mms_strong_trace_validation_v1/run_v1'; trace_files=point_count=0; max_trace_difference=0.
    for path in sorted(run.glob('*.json')):
        if 'all_original_GP' not in load(path):
            continue
        count,error=check_trace(path); trace_files+=1; point_count+=count; max_trace_difference=max(max_trace_difference,error)
    inventory=load(run/'NEGATIVE_EXECUTION_INVENTORY.json')
    need(len(inventory['executed'])==14 and all(r['executed'] for r in inventory['executed']) and not inventory['not_executed'] and not inventory['attempted_failed'], 'all fourteen controls retained')
    need(checked_families==8 and negative_vectors==8 and trace_files==60 and point_count==3240, 'complete stored test inventory')
    print(json.dumps(dict(status='SAVED_MMS_MATRIX_VECTOR_AND_TRACE_ARITHMETIC_CHECKED',graphs=2,families=8,negative_MMS_vectors=negative_vectors,trace_files=trace_files,trace_points=point_count,evaluator_negative_controls=14,maximum_normalized_matrix_vector_difference=max_vector_difference,maximum_normalized_trace_summary_difference=max_trace_difference,state_solve_executed=False,eigendecomposition_executed=False),indent=2))

if __name__=='__main__':
    main()
