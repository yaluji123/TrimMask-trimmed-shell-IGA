# Complete finite-space weak residuals

After `python prepare_data.py --validation`, run `python validation/weak_residual_checks/check_saved_weak_residual.py`. NumPy and SciPy are required. This checks the original saved four-level physical residual equation, the saved Riesz coefficient equation and the reported dual-normalization arithmetic. It does not factor a matrix or solve a linear system.

The existing packets contain G, Kb, constraint/coordinate maps, actual displacement and load vectors, direct bulk actions and complete residual coordinates. The coarse packet already contains its Riesz coordinates. The three binary files add the exact saved two-vector outputs of the original fine-level calculations; the first vector is the physical-residual Riesz solution, and the second is the COO-versus-direct-action perturbation solution. The binary layout is an eight-byte RZSOL001 marker, a little-endian uint32 dimension, then two little-endian binary64 vectors.

The packet result records preserve their original historical OPEN stages. The separate four-level summary preserves the subsequent final observations; no intermediate status is overwritten. These finite spaces are not a continuous-dual certificate or a true-solution error bound. Original raw strong-flux failures remain separate.
