"""Read-only V4-native output reader; refuses missing/mixed source and stale formats.

Example: python postprocess_actual_cluster.py --run-dir ... --load-dir ... --out-dir NEW_DIR
The script never runs CAD, compiles, solves, or changes any input artifact.
"""
from __future__ import annotations
import argparse,csv,hashlib,json
from pathlib import Path
import numpy as np
from cluster_physical_core import Arm,OWNERS,RELATIONS,integrate_cluster,integrate_bulk_action,recovered_clamp_resultant,resultants

PACKET_SHA='bdc28e39b1cbfec38b24f2e9978e4300f6cef0656aa557ba4b12ca2830ba63ab'

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def finite(x,name):
    a=np.asarray(x,float)
    if not np.all(np.isfinite(a)):raise ValueError('nonfinite '+name)
    return a
def read_json(p):
    if p.stat().st_size>10*1024**2:raise ValueError('JSON size cap '+str(p))
    return json.loads(p.read_text(encoding='utf-8-sig'))
def vector_csv(p,n=None):
    with p.open(encoding='utf-8-sig',newline='') as f:
        r=csv.DictReader(f)
        if r.fieldnames!=['global_dof_zero_based','value']:raise ValueError('vector CSV schema '+str(p))
        rows=list(r)
    if n is None:n=len(rows)
    if not(1<=n<=7000) or len(rows)!=n:raise ValueError('vector dimensions')
    vals=np.zeros(n);seen=set()
    for row in rows:
        i=int(row['global_dof_zero_based'])
        if not 0<=i<n or i in seen:raise ValueError('duplicate or missing global DOF')
        seen.add(i);vals[i]=float(row['value'])
    return finite(vals,'vector')
def required_close(a,b,name,atol=1e-8,rtol=1e-12):
    if np.shape(a)!=np.shape(b) or not np.allclose(a,b,atol=atol,rtol=rtol):raise ValueError('source mismatch '+name)
def handle(x):return int(x['decimal']) if isinstance(x,dict) else int(str(x),16)

def load_actual(run,loads,identity):
    inputs=[]
    def j(p):inputs.append(p);return read_json(p)
    process=j(run/'process_result.json')
    if process.get('exit_code')!=0 or process.get('natural_owned_child_exit') is not True or process.get('all_processes_naturally_exited_claimed') is not False:raise ValueError('run not naturally completed')
    runtime_manifest=j(run/'source_runtime_manifest.json')
    identity.verify_run(run,runtime_manifest,inputs)
    cluster=j(run/'triple_cluster.json')
    if cluster.get('status')!='PASS_NATIVE_ASSEMBLY_CONTROLS' or cluster.get('actual_form')!='Sym':raise ValueError('Native cluster did not pass its own Sym assembly controls')
    if cluster.get('owner_packet_sha256')!=PACKET_SHA:raise ValueError('owner packet mismatch')
    if cluster.get('pairwise_consistency_assemblies')!=0 or cluster.get('cluster_consistency_assemblies')!=1:raise ValueError('unsupported consistency assembler')
    if cluster.get('uniform_cluster_weights') is None or not np.allclose(cluster['uniform_cluster_weights'],[1/3]*3):raise ValueError('nonuniform cluster unsupported')
    n=int(cluster['actual_global_dofs'])
    if n%3 or not 1<=n<=7000:raise ValueError('global dimension')
    xp=loads/'global_solution.csv';fp=loads/'pre_boundary_force.csv';inputs += [xp,fp]
    u=vector_csv(xp,n);F=vector_csv(fp,n)
    header_names={Path(x['path']).name for x in runtime_manifest.get('diagnostic_and_candidate_headers',[])}
    if not {'OEPassiveLineLoadAudit.h','OETripleClusterNativeV1.h'}.issubset(header_names):raise ValueError('runtime source manifest lacks actual passive-load/cluster source identity')
    registry=j(run/'capture/couples_registry_before_dispatch.json')
    if not registry.get('capture_complete'):raise ValueError('incomplete registry capture')
    reg={handle(r['couple_handle']):r for r in registry['relations']}
    arms=[];patchforces=[];scatter=np.zeros(n);positions=np.full((n//3,3),np.nan)
    observed={int(a['handle'],16):a for a in cluster['arms']}
    if set(observed)!=set(OWNERS):raise ValueError('actual owner set')
    for owner in OWNERS:
        meta=observed[owner];g=j(loads/f'load_stage_geometry_{owner}.json');trim=j(run/f'capture/trim_geometry_{owner}.json')
        if g.get('stage')!='after_Apply_load_before_Apply_BC' or g['shell_handle']!=owner or trim['shell_handle']!=owner:raise ValueError('load stage/owner')
        if g['dofPN']!=3 or not g['is_flat'] or g['isVarThk'] or trim['has_holes'] or not trim['outer_is_full_frame']:raise ValueError('unsupported actual domain/material')
        for a,b in [('degree_u','degree_u'),('degree_v','degree_v'),('controls_u','controls_u'),('controls_v','controls_v')]:
            if g[a]!=trim[b]:raise ValueError('geometry dimensions mixed')
        required_close(g['control_global_Vg'],trim['control_global_Vg'],'CP geometry')
        for k in ['knots_u','knots_v','weights']:required_close(g[k],trim[k],k,atol=1e-14)
        for k,kk in [('E','E_observed'),('nu','nu_observed'),('constant_t','thickness_observed')]:required_close(g[k],meta[kk],k,atol=1e-12)
        m=int(g['controls_u']);nn=int(g['controls_v']);dofmap=np.asarray(meta['global_dofmap'],int)
        if len(dofmap)!=3*m*nn or meta['dofPN_observed']!=3 or not meta['geometry_complete']:raise ValueError('missing actual Node map')
        p=loads/f'patch_external_{owner}.csv';inputs.append(p)
        with p.open(encoding='utf-8-sig',newline='') as f:rows=list(csv.DictReader(f))
        if len(rows)!=3*m*nn:raise ValueError('patch force row count')
        force=np.zeros(3*m*nn);seen=set();cp=finite(g['control_global_Vg'],'CP').reshape(-1,3)
        for row in rows:
            a=int(row['local_cp']);c=int(row['component']);i=3*a+c
            if i in seen or not 0<=a<m*nn or not 0<=c<3:raise ValueError('patch duplicate/control index')
            seen.add(i)
            if int(row['shell_handle'])!=owner or int(row['control_i'])!=a//nn or int(row['control_j'])!=a%nn:raise ValueError('patch identity')
            gdof=int(row['global_dof_zero_based']);node=int(row['Node_one_based'])
            if gdof!=dofmap[i] or gdof!=3*(node-1)+c or not 0<=gdof<n:raise ValueError('actual numbering mismatch')
            required_close([float(row[k]) for k in ['cp_x','cp_y','cp_z']],cp[a],'load CP')
            force[i]=float(row['actual_patch_F_N'])
            old=positions[node-1]
            if np.all(np.isfinite(old)):required_close(old,cp[a],'shared Node position')
            positions[node-1]=cp[a]
        finite(force,'patch force');np.add.at(scatter,dofmap,force)
        arm=Arm(owner,np.array(g['knots_u']),np.array(g['knots_v']),g['degree_u'],g['degree_v'],cp,np.array(g['weights']),g['E'],g['nu'],g['constant_t'],dofmap,u[dofmap])
        required_close(arm.origin,meta['origin'],'arm origin');required_close(arm.du,meta['du'],'arm du');required_close(arm.dv,meta['dv'],'arm dv')
        required_close(arm.normal,meta['normal'],'normal');required_close(arm.mu,meta['outward_conormal'],'outward conormal')
        arms.append(arm);patchforces.append(force)
    if not np.all(np.isfinite(positions)):raise ValueError('unobserved global coordinate')
    required_close(scatter,F,'patch-to-global external load',atol=1e-9,rtol=1e-12)
    selected=[]
    for rel in cluster['relations']:
        h=int(rel['handle'],16)
        if h not in RELATIONS or h not in reg:raise ValueError('relation identity')
        ids=tuple(OWNERS.index(int(v,16)) for v in rel['owners'])
        if tuple(sorted(ids))!=RELATIONS[h]:raise ValueError('relation owners')
        rr=reg[h]
        if {handle(rr['end1_handle']),handle(rr['end2_handle'])}!={OWNERS[i] for i in ids}:raise ValueError('registry owner mismatch')
        if rel.get('selected_penalty'):selected.append((h,RELATIONS[h]))
    selected.sort();vals=finite(cluster['selected_beta'],'selected beta')
    if len(vals)!=len(selected) or len(selected) not in (2,3) or np.any(vals<=0):raise ValueError('selected beta format')
    vertices=set(i for _,e in selected for i in e)
    if vertices!={0,1,2}:raise ValueError('selected graph disconnected')
    betas={e:float(b) for (_,e),b in zip(selected,vals)}
    return arms,F,u,positions,patchforces,betas,float(cluster['ell']),cluster,inputs,float(np.linalg.norm(scatter-F))

def confirmed_clamp(p,inputs):
    if not p.exists():return None
    inputs.append(p);events=[]
    with p.open(encoding='utf-8-sig') as f:
        for line in f:
            x=json.loads(line)
            if x.get('event')=='apply_snapshot':events.append(x)
    if len(events)!=1:return None
    e=events[0]
    if e.get('surface')!=OWNERS[0] or e.get('declared_owner')!=OWNERS[0] or e.get('declared_edge')!=4:return None
    if e.get('active_components')!=[True]*6 or e.get('prescribed_global')!=[0]*6:return None
    curve=e.get('curve');cp=np.asarray(curve['control_global'],float).reshape(-1,3) if curve else np.empty((0,3))
    if len(cp)<2 or np.max(abs(cp[:,0]))>1e-8 or np.max(abs(cp[:,2]))>1e-8:return None
    if abs(min(cp[:,1]))>1e-8 or abs(max(cp[:,1])-60)>1e-8:return None
    return dict(owner=hex(OWNERS[0]),edge='u_min',physical_boundary='PATCH0 x=0',entity=e.get('boundary_entity'),data='homogeneous all-six global payload; physical rank five')

def observed_boundary_action(path,arms,u,inputs,allow_synthetic_control=False):
    """Read the exact oe_boundary_action_v1 packet; independently re-evaluate it."""
    directory=path.parent
    def child(name,expected=None):
        if not isinstance(name,str) or Path(name).name!=name or Path(name).is_absolute():raise ValueError('boundary packet path must be a local basename')
        if expected is not None and name!=expected:raise ValueError('boundary packet filename identity')
        result=directory/name;inputs.append(result);return result
    metadata_path=directory/'boundary_action_metadata.json';inputs.append(metadata_path);meta=read_json(metadata_path)
    if meta.get('synthetic') is True and not allow_synthetic_control:raise ValueError('synthetic boundary packet is not actual Native evidence')
    if meta.get('schema')!='oe_boundary_action_v1' or meta.get('equation')!='aBC=(H_afterBC-H_beforeBC)*u_local-(F_afterBC-F_beforeBC)':raise ValueError('boundary action semantics/schema')
    if meta.get('global_dofs')!=len(u) or meta.get('solution_file')!='global_solution.csv' or meta.get('external_force_file')!='pre_boundary_force.csv' or meta.get('global_action_file')!=path.name:raise ValueError('boundary action source dimensions/files')
    flags=['audit_export_complete','all_Apply_BC_internal_changes_retained','interface_assembly_excluded_by_capture_phase']
    if any(meta.get(k) is not True for k in flags) or meta.get('small_values_pruned') is not False:raise ValueError('incomplete or altered boundary capture')
    if meta.get('before_stage')!='after_Apply_load_before_Apply_BC' or meta.get('after_stage')!='immediately_after_successful_Apply_BC_before_Apply_coupling':raise ValueError('boundary capture phase')
    entries={int(x['shell_handle']):x for x in meta['patches']}
    if len(meta['patches'])!=3 or set(entries)!=set(OWNERS):raise ValueError('boundary owner set')
    scatter=np.zeros(len(u));checks=[]
    for arm in arms:
        owner=arm.handle;m=entries[owner];nd=len(arm.coeff)
        if m['local_dofs']!=nd or m.get('identity_checked_before_after_and_at_solution') is not True:raise ValueError('boundary patch identity')
        hp=child(m['delta_H_file'],f'boundary_delta_H_{owner}.csv');fp=child(m['delta_F_file'],f'boundary_delta_F_{owner}.csv');lp=child(m['local_action_file'],f'boundary_action_local_{owner}.csv')
        child(m['pre_BC_mapping_file'],f'patch_external_{owner}.csv');child(m['geometry_file'],f'load_stage_geometry_{owner}.json')
        with fp.open(encoding='utf-8-sig',newline='') as f:
            reader=csv.DictReader(f)
            if reader.fieldnames!=['local_dof_zero_based','value_N']:raise ValueError('boundary deltaF schema')
            rows=list(reader)
        deltaf=np.zeros(nd);seen=set()
        for row in rows:
            i=int(row['local_dof_zero_based'])
            if not 0<=i<nd or i in seen:raise ValueError('boundary deltaF duplicate/index')
            seen.add(i);deltaf[i]=float(row['value_N'])
        if len(seen)!=nd:raise ValueError('boundary deltaF incomplete')
        finite(deltaf,'boundary deltaF')
        with lp.open(encoding='utf-8-sig',newline='') as f:
            reader=csv.DictReader(f);rows=list(reader)
            if reader.fieldnames!=['shell_handle','local_cp','component','Node_one_based','global_dof_zero_based','cp_x','cp_y','cp_z','u_local_mm','deltaF_N','aBC_N']:raise ValueError('boundary local action schema')
        if len(rows)!=nd:raise ValueError('boundary local action incomplete')
        actual=np.zeros(nd);seen=set()
        for row in rows:
            cp=int(row['local_cp']);c=int(row['component']);i=3*cp+c
            if not 0<=cp<arm.m*arm.n or not 0<=c<3 or i in seen:raise ValueError('boundary local duplicate/index')
            seen.add(i);g=int(row['global_dof_zero_based'])
            if int(row['shell_handle'])!=owner or g!=arm.dofmap[i] or g!=3*(int(row['Node_one_based'])-1)+c:raise ValueError('boundary actual Node identity')
            required_close([float(row[k]) for k in ['cp_x','cp_y','cp_z']],arm.cp[cp],'boundary CP')
            if float(row['u_local_mm'])!=u[g] or float(row['deltaF_N'])!=deltaf[i]:raise ValueError('boundary actual X/deltaF mixed run')
            actual[i]=float(row['aBC_N'])
        finite(actual,'boundary action')
        reconstructed=-deltaf.copy();operation_scale=abs(deltaf);seen=set();nnz=0
        with hp.open(encoding='utf-8-sig',newline='') as f:
            reader=csv.DictReader(f)
            if reader.fieldnames!=['local_row_zero_based','local_col_zero_based','value_N_per_mm']:raise ValueError('boundary deltaH schema')
            for row in reader:
                i=int(row['local_row_zero_based']);j=int(row['local_col_zero_based']);v=float(row['value_N_per_mm'])
                if not(0<=i<nd and 0<=j<nd) or (i,j) in seen or not np.isfinite(v) or v==0:raise ValueError('boundary deltaH duplicate/index/nonfinite/zero')
                seen.add((i,j));nnz+=1
                if nnz>2000000:raise ValueError('boundary deltaH NNZ cap')
                product=v*arm.coeff[j];reconstructed[i]+=product;operation_scale[i]+=abs(product)
        if nnz!=m['delta_H_exported_nonzero_nnz']:raise ValueError('boundary deltaH count mismatch')
        diff=float(np.linalg.norm(reconstructed-actual,np.inf));scale=float(np.linalg.norm(operation_scale,np.inf))
        relative=diff/scale if scale>0 else (0. if diff==0 else float('inf'))
        if not np.isfinite(relative) or relative>1e-11:raise ValueError('boundary COO action reconstruction disagreement')
        np.add.at(scatter,arm.dofmap,actual)
        checks.append(dict(owner=hex(owner),delta_H_nnz=nnz,COO_action_absolute_Linf_difference_N=diff,
            COO_action_difference_over_absolute_operation_scale=relative,actual_X_and_Node_matched=True))
    inputs.append(path);global_action=vector_csv(path,len(u));required_close(scatter,global_action,'boundary single scatter',atol=1e-12,rtol=1e-12)
    return global_action,dict(schema=meta['schema'],COO_delta_action_checks=checks,
        single_scatter_L2_difference_N=float(np.linalg.norm(scatter-global_action)),
        support_reaction_sign='reaction=-aBC',no_pointwise_traction_interpretation=True,
        actual_X_and_Node_and_CP_matched=True,full_delta_retained_and_interface_excluded=True)

def verify_boundary_file_seal(directory,run,inputs):
    p=directory/'boundary_action_binding.json';inputs.append(p);seal=read_json(p)
    if seal.get('schema')!='oe_boundary_action_file_binding_v1' or seal.get('binding_only_not_solver_acceptance') is not True:raise ValueError('boundary file seal schema')
    if set(seal.get('owner_handles',[]))!=set(OWNERS):raise ValueError('boundary seal owner set')
    if seal['global_solution_sha256']!=sha(directory/'global_solution.csv') or seal['external_force_sha256']!=sha(directory/'pre_boundary_force.csv'):raise ValueError('boundary seal actual X/F mismatch')
    required_files={'boundary_action_metadata.json','global_solution.csv','pre_boundary_force.csv','boundary_action_global.csv'}
    for owner in OWNERS:
        required_files.update({f'boundary_delta_H_{owner}.csv',f'boundary_delta_F_{owner}.csv',f'boundary_action_local_{owner}.csv',f'patch_external_{owner}.csv',f'load_stage_geometry_{owner}.json'})
        required_files.update(f'bulk_measure_{stage}_{owner}.json' for stage in ['raw_bulk_before_support','bulk_after_support','pre_boundary_H_possible_support'])
    if not required_files.issubset(seal['audit_files']):raise ValueError('boundary file seal omits required observed artifacts')
    for name,info in seal['audit_files'].items():
        if Path(name).name!=name or Path(name).is_absolute():raise ValueError('boundary seal unsafe basename')
        path=directory/name
        if path.stat().st_size!=info['bytes'] or sha(path)!=info['sha256']:raise ValueError('boundary sealed artifact changed '+name)
        inputs.append(path)
    required={(run/'source_runtime_manifest.json').resolve(),(run/'process_result.json').resolve()};matched=set()
    for info in seal['actual_run_manifest_bindings']:
        path=Path(info['path'])
        if path.stat().st_size!=info['bytes'] or sha(path)!=info['sha256']:raise ValueError('sealed run manifest changed')
        inputs.append(path)
        if path.resolve() in required:matched.add(path.resolve())
    if matched!=required:raise ValueError('seal must bind the actual run source manifest and natural-exit process result')
    return dict(schema=seal['schema'],bound_actual_solution_and_force=True,
        audited_file_count=len(seal['audit_files']),actual_source_and_process_manifest_bound=True,
        identity_seal_is_not_solver_acceptance=True)

def clean(x):
    if isinstance(x,np.ndarray):return x.tolist()
    if isinstance(x,(np.floating,np.integer)):return x.item()
    if isinstance(x,dict):return {k:clean(v) for k,v in x.items()}
    if isinstance(x,(tuple,list)):return [clean(v) for v in x]
    return x

def main():
    p=argparse.ArgumentParser();p.add_argument('--run-dir',type=Path,required=True);p.add_argument('--load-dir',type=Path,required=True)
    p.add_argument('--out-dir',type=Path,required=True);p.add_argument('--gauss',type=int,default=8)
    p.add_argument('--moment-origin-mm',type=float,nargs=3,default=[0.,0.,0.]);p.add_argument('--observed-boundary-action',type=Path)
    args=p.parse_args()
    if args.out_dir.exists():raise ValueError('output directory must be new; no overwrite')
    arms,F,u,positions,patchforces,betas,ell,cluster,inputs,scattererr=load_actual(args.run_dir,args.load_dir)
    origin=np.asarray(args.moment_origin_mm,float);finite(origin,'moment origin')
    out=integrate_cluster(arms,betas,ell,args.gauss,origin)
    second=integrate_cluster(arms,betas,ell,min(16,args.gauss+2),origin)
    bulk=integrate_bulk_action(arms);bulk_action=bulk.pop('global_action')
    action=out.pop('numerical_canonical_cluster_action_global');secondaction=second.pop('numerical_canonical_cluster_action_global')
    ef,em=resultants(F,positions,origin);external_work=float(F@u)
    data=dict(schema='oe-actual-threepatch-postprocess-v1',status='POSTPROCESSED_OBSERVED_FIELDS_NOT_SCIENTIFIC_ACCEPTANCE',
        units=dict(length='mm',force='N',stress_modulus='N/mm^2',rotation='rad',work='N mm'),moment_origin_mm=origin.tolist(),
        actual_global_dofs=len(u),owner_packet_sha256=PACKET_SHA,
        actual_owner_handles=[hex(a.handle) for a in arms],actual_materials=[dict(owner=hex(a.handle),E=a.E,nu=a.nu,t_mm=a.thickness) for a in arms],
        actual_Native_status=cluster['status'],structural_accuracy_accepted=False,endpoint_general_loaded_response='OPEN',
        external_load_ledger=dict(policy='pre_boundary_force used once; patch forces are a scatter crosscheck, not additional loads',
            patch_to_global_vector_difference_norm_N=scattererr,total_force_N=ef.tolist(),total_moment_N_mm=em.tolist(),
            external_generalized_work_N_mm=external_work,point_source_intent_not_inferred_from_equivalent_control_forces=True),
        bulk=bulk,cluster=out,quadrature_crosscheck=dict(orders=[args.gauss,min(16,args.gauss+2)],
            canonical_action_relative_difference=float(np.linalg.norm(action-secondaction)/max(np.linalg.norm(secondaction),1e-300)),
            quadratic_work_difference_N_mm=out['reconstructed_cluster_quadratic_work_N_mm']-second['reconstructed_cluster_quadratic_work_N_mm'],
            displacement_RMS_differences_mm=[a['displacement_RMS_mm']-b['displacement_RMS_mm'] for a,b in zip(out['jumps'],second['jumps'])]),
        recovered_clamp_balance=None,numerical_total_balance=None,loaded_full_RHS_residual=None)
    clamp=confirmed_clamp(args.run_dir/'boundary_domain_probe.jsonl',inputs)
    if clamp:
        rf,rm=recovered_clamp_resultant(arms[0],args.gauss,origin)
        data['recovered_clamp_balance']=dict(boundary_evidence=clamp,method='recovered physical full Green traction/moment on confirmed clamp; not observed weak-boundary reaction',
            recovered_support_force_N=rf.tolist(),recovered_support_moment_N_mm=rm.tolist(),
            external_plus_recovered_support_force_N=(ef+rf).tolist(),external_plus_recovered_support_moment_N_mm=(em+rm).tolist(),
            accepted_as_numerical_global_balance=False,endpoint_and_free_edge_corner_source_issue_unresolved=True)
    if args.observed_boundary_action:
        if args.observed_boundary_action.parent.resolve()!=args.load_dir.resolve():raise ValueError('boundary action must belong to the same fresh load/solution directory')
        seal=verify_boundary_file_seal(args.load_dir,args.run_dir,inputs)
        runtime_source=read_json(args.run_dir/'source_runtime_manifest.json')
        if not any(Path(x['path']).name=='OEWeakBoundaryActionAudit.h' for x in runtime_source.get('diagnostic_and_candidate_headers',[])):raise ValueError('boundary-action source identity absent from runtime manifest')
        b,binding=observed_boundary_action(args.observed_boundary_action,arms,u,inputs);binding['file_identity_seal']=seal
        bf,bm=resultants(b,positions,origin)
        force_scale=float(np.linalg.norm(ef)+np.linalg.norm(bf));moment_scale=float(np.linalg.norm(em)+np.linalg.norm(bm))
        data['numerical_total_balance']=dict(required_input_semantics='actual assembled weak-boundary internal action K_BC*U - F_BC; not negative external load or residual-derived reaction',
            support_reaction_sign='reaction=-boundary_internal_minus_rhs',total_force_N=(ef-bf).tolist(),total_moment_N_mm=(em-bm).tolist(),
            force_balance_relative_to_sum_of_resultant_norms=float(np.linalg.norm(ef-bf)/force_scale) if force_scale>0 else None,
            moment_balance_relative_to_sum_of_resultant_norms=float(np.linalg.norm(em-bm)/moment_scale) if moment_scale>0 else None,
            actual_boundary_internal_minus_rhs_work_N_mm=float(b@u),observed_action_binding=binding)
        residual=bulk_action+action+b-F
        norm2=float(np.linalg.norm(residual));norminf=float(np.linalg.norm(residual,np.inf));rhsnorm=float(np.linalg.norm(F))
        sum_norms=sum(np.linalg.norm(v) for v in [bulk_action,action,b,F])
        data['loaded_full_RHS_residual']=dict(equation='independent_GL4_bulk_action + independent_canonical_cluster_action + observed_boundary_internal_minus_rhs - actual_pre_boundary_force',
            absolute_L2_N=norm2,absolute_Linf_N=norminf,relative_to_external_L2=norm2/rhsnorm if rhsnorm>0 else None,
            normalized_by_sum_of_action_L2_norms=float(norm2/sum_norms) if sum_norms>0 else None,
            work_residual_N_mm=float(u@residual),external_force_not_constructed_from_KU=True,
            independent_material_quadratic_work_N_mm=float(u@bulk_action),independent_interface_quadratic_work_N_mm=float(u@action),
            observed_boundary_internal_minus_rhs_work_N_mm=float(u@b),actual_external_work_N_mm=external_work)
    data['input_manifest']=[dict(path=str(p.resolve()),sha256=sha(p)) for p in dict.fromkeys(inputs)]
    args.out_dir.mkdir(parents=True)
    (args.out_dir/'postprocess.json').write_text(json.dumps(clean(data),indent=2,allow_nan=False),encoding='utf-8')
    with (args.out_dir/'independent_canonical_interface_action.csv').open('w',newline='',encoding='utf-8') as f:
        w=csv.writer(f);w.writerow(['global_dof_zero_based','value']);w.writerows(enumerate(action))
    with (args.out_dir/'independent_GL4_bulk_action.csv').open('w',newline='',encoding='utf-8') as f:
        w=csv.writer(f);w.writerow(['global_dof_zero_based','value']);w.writerows(enumerate(bulk_action))
    print(json.dumps(dict(status=data['status'],path=str(args.out_dir/'postprocess.json'),actual_global_dofs=len(u),
        numerical_total_balance_available=data['numerical_total_balance'] is not None),indent=2))

if __name__=='__main__':raise SystemExit('Use postprocess_point_complete_v7.py with mandatory explicit identities')
