from pathlib import Path
import argparse,csv,json,hashlib
import numpy as np
from prepare_physical_field_data import evaluate
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def run(a):
 assert not a.output.exists()
 state=np.load(a.state);g=json.loads(a.geometry.read_text());m,n=g['controls_u'],g['controls_v'];coeff=np.concatenate([state['cp'].reshape(m,n,3),state['U'].reshape(m,n,3)],axis=2)
 with a.samples.open(newline='',encoding='utf-8-sig')as f:rows=list(csv.DictReader(f))
 assert rows and {r['sample_kind']for r in rows}=={'vertex','center'};uv=np.array([[float(r[k])for k in ['u','v']]for r in rows]);values,partition=evaluate(uv,state['knots_u'],state['knots_v'],coeff)
 U=np.array([[float(r[k])for k in ['ux','uy','uz']]for r in rows]);X=np.array([[float(r[k])for k in ['x','y','z']]for r in rows]);mag=np.array([float(r['umag'])for r in rows]);assert np.isfinite(U).all()and np.isfinite(X).all()and np.isfinite(mag).all()
 error=np.linalg.norm(values[:,3:]-U,axis=1);gap=np.linalg.norm(values[:,:3]-X,axis=1);magnitude=np.abs(np.linalg.norm(U,axis=1)-mag);groups={}
 for kind in ['vertex','center']:
  idx=np.array([i for i,r in enumerate(rows)if r['sample_kind']==kind]);assert len(idx)>0;groups[kind]=dict(rows=len(idx),max_direct_state_U_error_mm=float(error[idx].max()),max_direct_surface_coordinate_error_mm=float(gap[idx].max()),max_reported_magnitude_error_mm=float(magnitude[idx].max()))
 assert max(error.max(),gap.max(),magnitude.max())<1e-8
 report=dict(status='PASS_ALL_EXPORTED_VERTICES_AND_CENTROIDS_TRUE_POINT_IDENTITY',rows=len(rows),excluded_rows=0,groups=groups,partition_of_unity_error=partition,state_sha256=sha(a.state),geometry_sha256=sha(a.geometry),samples_sha256=sha(a.samples),reader_sha256=sha(Path(__file__)))
 a.output.write_text(json.dumps(report,indent=2),encoding='utf-8');print(json.dumps(report))
if __name__=='__main__':raise SystemExit('Use read_single_patch_v7.py strict current identity')
