"""Default plan; one pinned0f8 Duffy case, no Native/API/FE or global matrix."""
import os,sys
sys.dont_write_bytecode=True
for key in ['OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS']:os.environ[key]='1'
from pathlib import Path
from fractions import Fraction as F
from math import comb,factorial,fsum,isfinite
from itertools import permutations
import argparse,csv,hashlib,importlib.util,json,re,time,traceback
HERE=Path(__file__).resolve().parent
BUDGET=F(1,10**13)
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb')as f:
  for data in iter(lambda:f.read(4<<20),b''):h.update(data)
 return h.hexdigest()
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def clean(x):
 if isinstance(x,F):return str(x)
 if isinstance(x,dict):return {str(k):clean(v)for k,v in x.items()}
 if isinstance(x,(list,tuple)):return [clean(v)for v in x]
 return x
def save(p,x):
 with p.open('x',encoding='utf-8')as f:json.dump(clean(x),f,indent=2,allow_nan=False);f.write('\n')
def load(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m
def rule36(path):
 text=Path(path).read_text(encoding='utf-8-sig');body=re.search(r'static\s+const\s+Point\s+rule\[36\]\s*=\s*\{(.*?)\}\s*;',text,re.S).group(1)
 rows=re.findall(r'\{([^{}]+)\}',body);assert len(rows)==36
 r=[tuple(float(x.strip())for x in row.split(','))for row in rows];assert all(len(x)==4 for x in r)
 return r
def kahan(state,x):
 y=x-state[1];t=state[0]+y;state[1]=(t-state[0])-y;state[0]=t
def normalized(p,bounds):
 u0,u1,v0,v1=bounds;return [((u-u0)/(u1-u0),(v-v0)/(v1-v0))for u,v in p]
def positive(poly,core):return list(reversed(poly))if core.signed_area(poly)<0 else poly
def raw_paths(g,bounds,geom,core):
 u0,u1,v0,v1=bounds;cell=[(u0,v0),(u1,v0),(u1,v1),(u0,v1)]
 outer=positive([tuple(map(core.q,p))for p in g['outer_loop']],core)if g['has_outer']else cell
 parts=[(1,geom.rectangle_clip(outer,bounds))]
 if g['hole_loops']:assert int(g['shell_handle'])==1214 and len(g['hole_loops'])==1
 for hole in g['hole_loops']:parts.append((-1,geom.rectangle_clip(positive([tuple(map(core.q,p))for p in hole],core),bounds)))
 return [(sign,positive(p,core))for sign,p in parts if len(p)>=3]
def path_moments(paths,bounds,core):
 area=(bounds[1]-bounds[0])*(bounds[3]-bounds[2]);values=[F(0)]*8
 for sign,p in paths:
  for i,value in enumerate(core.positive_moments(normalized(p,bounds))):values[i]+=sign*area*value
 return values
def clip_raw_to_triangle(g,tri,core):
 result=F(0)
 # Clipping a concave subject by a convex triangle retains its signed boundary.
 if g['has_outer']:outer=positive([tuple(map(core.q,p))for p in g['outer_loop']],core)
 else:outer=tri
 result+=abs(core.signed_area(core.clip_convex(outer,tri)))
 for hole in g['hole_loops']:result-=abs(core.signed_area(core.clip_convex(positive([tuple(map(core.q,p))for p in hole],core),tri)))
 return result
def interval_normalized(boxes,bounds):
 u0,u1,v0,v1=bounds;return [[((x[0]-u0)/(u1-u0),(x[1]-u0)/(u1-u0)),((y[0]-v0)/(v1-v0),(y[1]-v0)/(v1-v0))]for x,y in boxes]
def closed_rectangle_moment(bounds,a,b):
 x0,x1,y0,y1=bounds;return(x1**(a+1)-x0**(a+1))*(y1**(b+1)-y0**(b+1))/F((a+1)*(b+1))
def preregistered_tests(rule,core,geom):
 tests=[]
 shapes=[[(F(0),F(0)),(F(1),F(0)),(F(0),F(1))],[(F(1,7),F(2,9)),(F(2,3),F(1,5)),(F(3,4),F(8,9))]]
 first=None
 for shape in shapes:
  for order in permutations(range(3)):
   tri=[shape[i]for i in order];uv=[tuple(float(tri[0][axis])*r[0]+float(tri[1][axis])*r[1]+float(tri[2][axis])*r[2]for axis in range(2))for r in rule]
   fitted=core.decode_triangle(rule,uv);assert not fitted['coordinate_overconstraints_failed']
   for i in range(3):
    for axis in range(2):assert fitted['vertex_boxes'][i][axis][0]<=core.q(float(tri[i][axis]))<=fitted['vertex_boxes'][i][axis][1]
   area=abs(float(core.signed_area(tri)));weights=[area*r[3]for r in rule];check=core.validate_uv_weights(rule,weights,core.triangle_area_interval(fitted['vertex_boxes']));assert not check['failed_rows']
   tests.append({'positive_shape':len(tests),'vertex_order':order,'coordinate_and_weight_overconstraints':True})
   if first is None:first=(uv,weights)
 uv,weights=first
 try:core.decode_triangle(rule,uv[:-1])
 except AssertionError:tests.append({'negative':'missing_GP','rejected':True})
 else:raise AssertionError('Missing GP negative accepted')
 bad=list(uv);bad[7],bad[13]=bad[13],bad[7];assert core.decode_triangle(rule,bad)['coordinate_overconstraints_failed'];tests.append({'negative':'swapped_nonfit_rows7_13','rejected':True})
 bad=list(uv);bad[9]=(bad[9][0]+1e-6,bad[9][1]);assert core.decode_triangle(rule,bad)['coordinate_overconstraints_failed'];tests.append({'negative':'coordinate_outside_format_interval','rejected':True})
 decoded=core.decode_triangle(rule,uv);bad=list(weights);bad[7]*=1.001;assert core.validate_uv_weights(rule,bad,core.triangle_area_interval(decoded['vertex_boxes']))['failed_rows'];tests.append({'negative':'weight_Jacobian_mismatch','rejected':True})
 U=[(F(0),F(0)),(F(3),F(0)),(F(3),F(3)),(F(2),F(3)),(F(2),F(1)),(F(1),F(1)),(F(1),F(3)),(F(0),F(3))]
 clipped=geom.rectangle_clip(U,(F(0),F(3),F(2),F(3)))
 for a,b in core.PAIRS:
  exact=closed_rectangle_moment((F(0),F(1),F(2),F(3)),a,b)+closed_rectangle_moment((F(2),F(3),F(2),F(3)),a,b)
  assert core.polygon_moment(clipped,a,b)==exact
 tests.append({'positive':'disconnected_U_exact8moments_against_two_closed_rectangles','passed':True})
 return tests
def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--execute',action='store_true');ap.add_argument('--out',type=Path);ap.add_argument('--package-sha256');a=ap.parse_args()
 if not a.execute:print('PLAN_ONLY_SINGLE_DUFFY_ALL8160SPAN_8UV_NOT_EXECUTED');return 0
 assert a.out is not None and not a.out.exists()and a.out.resolve().parent==HERE
 assert sha(HERE/'SOURCE_MANIFEST.json')==a.package_sha256
 source_before={str(HERE/'SOURCE_MANIFEST.json'):a.package_sha256}
 for r in read(HERE/'SOURCE_MANIFEST.json')['files']:
  assert sha(r['path'])==r['sha256']and Path(r['path']).stat().st_size==r['bytes'];source_before[r['path']]=r['sha256']
 pins=read(HERE/'DATA_PINS.json');before={}
 for r in pins['inputs']:
  p=Path(r['path']);assert p.is_file()and not p.is_symlink()and p.stat().st_size==r['bytes']and sha(p)==r['sha256'];before[str(p)]=r['sha256']
 guard=load('resource_guard_only',pins['resource_guard']);resource,start_resource=guard.own_cpu1_memory_job();clock=time.perf_counter();a.out.mkdir()
 save(a.out/'STARTED.json',{'PID':os.getpid(),'resources':start_resource,'source_scope':'one case observedpartition versus independent rawdomain, no Native/API/solve'})
 try:
  core=load('exact_observed_8uv_core',HERE/'exact_observed_core.py');geom=load('frozen_exact_raw_clip_geometry',pins['geometry_helper']);beta=load('frozen_simplex_absolute_L1',pins['beta_helper']);rule=rule36(pins['rule36_header'])
  save(a.out/'PREREGISTERED_POSITIVE_NEGATIVE_TESTS.json',preregistered_tests(rule,core,geom))
  case=Path(pins['case']);receipt=read(case/'RAW_CASE_RECEIPT.json');process=read(case/'process_result.json')
  assert sha(case/'source_runtime_manifest.json')==pins['expected_runtime_manifest_sha256']and sha(case/'applied_source_binding_318.json')==pins['expected_source_binding_sha256']
  assert receipt['runtime_manifest_sha256']==pins['expected_runtime_manifest_sha256']and receipt['CRX_source_binding_sha256']==pins['expected_source_binding_sha256']and receipt['Duffy36_reference']is True and receipt['line_override']is None
  assert process['exit_code']==0 and process['natural_owned_child_exit']is True and process['all_processes_naturally_exited_claimed']is False
  for name in ['actual_bootstrap_module_hashes.json','actual_loaded_module_hashes.json']:
   module=read(case/name);assert module['pid']==process['pid']and module['status']=='PASS_ACTUAL_LOADED_MODULE_FILES_MATCH_MANIFEST'and module['errors']==[]
  done=read(case/'derived_work/linear_state/state_complete.json');assert done['stress_cached_GP']==118272 and done['stress_actual_GP_records']==236544 and done['stress_skipped_records']==0
  geos={int(p.stem.rsplit('_',1)[1]):read(p)for p in(case/'capture').glob('trim_geometry_*.json')};assert len(geos)==23
  cells={};bound_keys={}
  for owner,g in geos.items():
   for cell in g['cells']:
    key=(owner,int(cell['element']));bounds=tuple(map(core.q,cell['bounds']));cells[key]={'cell':cell,'bounds':bounds,'acc':[[0.,0.]for i in range(8)],'count':0,'group':[]};boundkey=(owner,tuple(map(float,cell['bounds'])));assert boundkey not in bound_keys;bound_keys[boundkey]=key
  assert len(cells)==8160
  native={}
  for path in(case/'derived_work/cut_moments').glob('*.jsonl'):
   for line in path.read_text(encoding='utf-8-sig').splitlines():
    r=json.loads(line);key=(int(r['shellH']),int(r['element']));assert key not in native and key in cells and tuple(map(core.q,r['bounds']))==cells[key]['bounds'];native[key]=r
  assert len(native)==606
  raw=case/'derived_work/linear_state/actual_stress_quadrature.csv';previous=-1;nonparam_weights=0
  pair_fields=['patch_handle','quadrature_index','index_u','index_v','u','v','w1','w2','weight','retained_domain','span_u0','span_u1','span_v0','span_v1']
  with raw.open(encoding='utf-8-sig',newline='')as stream:
   reader=csv.DictReader(stream);assert reader.fieldnames==pins['raw_header']
   for neg in reader:
    pos=next(reader);assert neg['surface']=='SNEG'and pos['surface']=='SPOS'and all(neg[k]==pos[k]for k in pair_fields)
    gid=int(neg['quadrature_index']);assert gid==previous+1;previous=gid
    owner=int(neg['patch_handle'],16);bounds=tuple(float(neg[k])for k in['span_u0','span_u1','span_v0','span_v1']);key=bound_keys[owner,bounds];state=cells[key];u,v,w1,w2=[float(neg[k])for k in['u','v','w1','w2']];assert all(isfinite(x)for x in[u,v,w1,w2]);w=w1*w2
    assert all(x==0. or abs(x)>=sys.float_info.min for x in[u,v,w1,w2,w]),'OPEN_SUBNORMAL_FORMAT_MODEL'
    if float(neg['weight'])!=w:nonparam_weights+=1  # Retain this observation, never substitute gp.weight.
    u0,u1,v0,v1=map(float,state['bounds']);s=(u-u0)/(u1-u0);t=(v-v0)/(v1-v0);sp=[1.];tp=[1.]
    for i in range(6):sp.append(sp[-1]*s);tp.append(tp[-1]*t)
    for i,(p,q_)in enumerate(core.PAIRS):kahan(state['acc'][i],w*sp[p]*tp[q_])
    state['count']+=1
    if key in native and native[key]['backend']=='triangle':
     assert w2==1.0;state['group'].append((u,v,w,gid))
  assert previous+1==done['stress_cached_GP']
  moment_file=(a.out/'ALL_8160_SPAN_8UV_MOMENTS.csv').open('x',encoding='utf-8',newline='');writer=None
  geometry_file=(a.out/'ALL_SPAN_GEOMETRY.jsonl').open('x',encoding='utf-8');triangle_file=(a.out/'OBSERVED_TRIANGLES.jsonl').open('x',encoding='utf-8')
  arithmetic_fail=[];encoding_open=[];raw_difference=[];overlap_certain=[];native_cross_fail=[];total_triangles=0
  for key,state in cells.items():
   owner,element=key;g=geos[owner];bounds=state['bounds'];cell_area=(bounds[1]-bounds[0])*(bounds[3]-bounds[2]);raw_ref=path_moments(raw_paths(g,bounds,geom,core),bounds,core);assert raw_ref[0]==geom.raw_material_area(g,bounds)
   observed=[F(0)]*8;scales=[F(0)]*8;intervals=[(F(0),F(0))for i in range(8)];triangles=[];triangle_set_bounds=[];tri_uncert=F(0);cell_open=[];cell_fail=[]
   n=native.get(key)
   if n is None:
    assert state['count']in[0,16]
    if state['count']==16:
     observed=[cell_area/F((p+1)*(q_+1))for p,q_ in core.PAIRS];scales=list(observed);intervals=[(v,v)for v in observed]
   elif n['backend']=='inactive':assert state['count']==n['points']==0
   else:
    assert n['backend']=='triangle'and n['actualTriangleRulePoints']==36 and n['actual_bulk_rectangular_gauss_order']==4 and n['points']==n['acceptedPoints']==state['count']and state['count']%36==0
    for offset in range(0,state['count'],36):
     group=state['group'][offset:offset+36];assert len(group)==36;fit=core.decode_triangle(rule,[(r[0],r[1])for r in group]);area_box=core.triangle_area_interval(fit['vertex_boxes']);sign=1 if group[0][2]>0 else -1;assert all(r[2]*sign>0 for r in group)
     weight_check=core.validate_uv_weights(rule,[abs(r[2])for r in group],area_box)
     if fit['coordinate_overconstraints_failed']or weight_check['failed_rows']:cell_fail.append({'triangle':offset//36,'coordinate_failures':fit['coordinate_overconstraints_failed'],'weight_failures':weight_check['failed_rows']})
     tri=positive(fit['vertices'],core);triangles.append((sign,tri));norm=normalized(tri,bounds);central=[cell_area*v for v in core.positive_moments(norm)]
     boxes=interval_normalized(fit['vertex_boxes'],bounds);mi=core.triangle_moment_intervals(boxes,area_box)
     if mi is None:cell_open.append({'triangle':offset//36,'reason':'area encoding interval containszero'})
     for i,(p,q_)in enumerate(core.PAIRS):
      observed[i]+=sign*central[i];_,l1=beta.exact_affine_moment_and_L1(tuple(norm),p,q_);scales[i]+=cell_area*l1
      if mi is not None:intervals[i]=core.interval_add(intervals[i],mi[i]if sign>0 else(-mi[i][1],-mi[i][0]))
     set_bound=core.triangle_set_encoding_bound(fit['vertices'],fit['vertex_boxes']);triangle_set_bounds.append(set_bound);tri_uncert+=set_bound
     inside=clip_raw_to_triangle(g,tri,core);outside=abs(core.signed_area(tri))-inside
     item={'owner':owner,'element':element,'triangle':offset//36,'GLOBAL_GP_ids':[r[3]for r in group],'measured_fit':fit,'area_interval':area_box,'weight_validation':weight_check,'sign':sign,'central_triangle_area':abs(core.signed_area(tri)),'independent_raw_inside_area':inside,'central_outside_raw_area':outside,'set_symmetric_difference_encoding_bound':set_bound,'geometry_encoding_scope':'Observed partition; not independent raw material truth'}
     triangle_file.write(json.dumps(clean(item),allow_nan=False)+'\n');total_triangles+=1
   overlaps=[]
   for i in range(len(triangles)):
    for j in range(i):
     intersection=core.clip_convex(triangles[i][1],triangles[j][1]);overlap=abs(core.signed_area(intersection))
     bound=triangle_set_bounds[i]+triangle_set_bounds[j]
     if overlap:overlaps.append({'triangle_i':i,'triangle_j':j,'central_overlap_area':overlap,'pairwise_encoding_area_uncertainty_bound':bound})
     if overlap>bound and not cell_open and not cell_fail:overlap_certain.append({'owner':owner,'element':element,'triangle_i':i,'triangle_j':j,'overlap':str(overlap),'uncertainty':str(bound)})
   if cell_fail:arithmetic_fail.append({'owner':owner,'element':element,'format_overconstraints':cell_fail})
   if cell_open:encoding_open.append({'owner':owner,'element':element,'items':cell_open})
   inside_sum=sum((sign*clip_raw_to_triangle(g,t,core)for sign,t in triangles),F(0))if triangles else(raw_ref[0]if n is None and state['count']==16 else F(0))
   geometry_file.write(json.dumps(clean({'owner':owner,'element':element,'count_per_face':state['count'],'Native_cut_record':n is not None,'raw_material_area':raw_ref[0],'measured_signed_area':observed[0],'raw_minus_measured_area':raw_ref[0]-observed[0],'central_raw_area_minus_triangle_inside_sum':raw_ref[0]-inside_sum,'central_signed_outside_raw_area':observed[0]-inside_sum,'pairwise_overlaps':overlaps,'encoding_area_uncertainty_bound':tri_uncert,'missing_area_is_not_certified_if_overlap_or_encoding_open':bool(overlaps or cell_open or cell_fail)}),allow_nan=False)+'\n')
   for i,(p,q_)in enumerate(core.PAIRS):
    cache=F.from_float(state['acc'][i][0]);scale=scales[i]if scales[i]>0 else cell_area/F((p+1)*(q_+1));tol=BUDGET*scale;lo,hi=intervals[i];radius=max(abs(observed[i]-lo),abs(hi-observed[i]));error=abs(cache-observed[i]);native_value=F.from_float(float(n['signedLocalMoments'][i]))if n is not None else None
    reliable=radius<=tol and not cell_open and not cell_fail
    classification='OPEN_ENCODING_RESOLUTION'if cell_open else('FAIL_ARITHMETIC_OUTSIDE_FORMAT_INTERVAL'if not lo-tol<=cache<=hi+tol else('PASS_ARITHMETIC_ON_MEASURED_PARTITION'if error<=tol and reliable else'OPEN_ENCODING_RESOLUTION'))
    if classification.startswith('FAIL'):arithmetic_fail.append({'owner':owner,'element':element,'a':p,'b':q_,'reason':classification})
    elif classification.startswith('OPEN'):encoding_open.append({'owner':owner,'element':element,'a':p,'b':q_,'reason':classification})
    if native_value is not None and abs(cache-native_value)>tol:native_cross_fail.append({'owner':owner,'element':element,'a':p,'b':q_,'cache_minus_native':str(cache-native_value),'budget':str(tol)})
    raw_error=cache-raw_ref[i]
    if abs(observed[i]-raw_ref[i])>tol:raw_difference.append({'owner':owner,'element':element,'a':p,'b':q_,'measured_minus_raw':str(observed[i]-raw_ref[i]),'budget':str(tol)})
    row={'owner':owner,'element':element,'a':p,'b':q_,'raw_cache_moment':str(cache),'Native_cut_moment':str(native_value)if native_value is not None else'NOT_EMITTED_FULL_OR_ZERO','independent_raw_reference':str(raw_ref[i]),'measured_partition_center':str(observed[i]),'measured_interval_lower':str(lo),'measured_interval_upper':str(hi),'natural_absolute_L1_scale':str(scale),'unchanged_1e13_absolute_budget':str(tol),'cache_minus_measured_center':str(cache-observed[i]),'measured_minus_raw_geometry':str(observed[i]-raw_ref[i]),'cache_minus_raw_total':str(raw_error),'encoding_uncertainty':str(radius),'arithmetic_status':classification,'count_per_face':state['count']}
    if writer is None:writer=csv.DictWriter(moment_file,fieldnames=list(row));writer.writeheader()
    writer.writerow(row)
  moment_file.close();geometry_file.close();triangle_file.close()
  assert not any(sha(path)!=value for path,value in before.items())and not any(sha(path)!=value for path,value in source_before.items())
  status='FAIL_QUADRATURE_FORMAT_OR_PARTITION'if arithmetic_fail or native_cross_fail or overlap_certain else('OPEN_ENCODING_OR_RAW_GEOMETRY_REPRESENTATION'if encoding_open or raw_difference else'ALL_SPAN_8UV_CHECKS_PASS_ONLY')
  result={'status':status,'scope':'measured execution partition versus independently registered raw geometry; no FEM/PDE/continuum qualification','cells':len(cells),'Native_cut_records':len(native),'GLOBAL_cached_GP':previous+1,'physical_face_records':2*(previous+1),'observed_triangles':total_triangles,'gp_weight_not_equal_param_product_observations':nonparam_weights,'arithmetic_or_format_failures':arithmetic_fail,'Native606_cross_failures':native_cross_fail,'certain_overlap_failures':overlap_certain,'encoding_OPEN_records':encoding_open,'raw_representation_differences_above_same_arithmetic_budget':raw_difference,'original_budget':str(BUDGET),'Native_moments_not_used_for_fit':True,'no_threshold_region_face_or_group_selection_from_results':True,'source_input_before_after_unchanged':True,'oldarchive_current_source_quantization_not_assumed_truth':True,'resources_before':start_resource,'resources_after':resource(),'wall_seconds':time.perf_counter()-clock,'outputs':[{'name':p.name,'bytes':p.stat().st_size,'sha256':sha(p)}for p in a.out.iterdir()if p.is_file()]}
  save(a.out/'RESULT.json',result);print(json.dumps({'status':status,'result':str(a.out/'RESULT.json'),'sha256':sha(a.out/'RESULT.json')}));return 1 if status.startswith('FAIL')else 0
 except Exception as e:
  save(a.out/'FAILED_PRESERVED.json',{'status':'FAIL_OR_OPEN_SINGLE_CASE_AUDIT_NO_RETRY','error':repr(e),'traceback':traceback.format_exc(),'resources':resource(),'wall_seconds':time.perf_counter()-clock});raise
if __name__=='__main__':raise SystemExit(main())
