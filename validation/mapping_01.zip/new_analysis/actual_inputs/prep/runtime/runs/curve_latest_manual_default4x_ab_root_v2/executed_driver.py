"""One Root-selected fresh Core case. No build, queue, retry, next case or cleanup."""
from pathlib import Path
from datetime import datetime
import argparse
import csv
import importlib.util
import json
import os
import re
import shutil
import subprocess
import sys
import time
import uuid
import psutil
from owned_core_times import process_times
sys.dont_write_bytecode = True
from runtime_family_contract import *
import native_completed_producer_facts as completed

SCOPE = 'HULL_316CANONICAL_2OVERLAY_ONE_MANUAL_AB4X_V1_SOURCE_TIMES'
OLD_CASE = PREP / 'runtime/runs/final90f_hull_mode4_4x_v1'
CORE = Path(r'C:\Program Files\Autodesk\AutoCAD 2025\accoreconsole.exe')
PROFILE_SHA = '517b70c1b4f12550ff1c95c44c690cd4c4a7ac23ff2d3043ccf74d2db7b54a9d'
RECIPE_SHA = '4cca12132982a8fe7a53de55a4852426c77d0fcca1bf33ee5f223ba0a9074ee9'
POINT = PREP / 'mechanics/actual_hull4x_endpoint988_recovered_v1'
POINT_PLAN = POINT / 'native_point_source_v1/point_topology.tsv'
REQUEST = PREP / 'mechanics/candidate/endpoint_vertex988_source_v1/requests/endpoint_requests.tsv'
P4_PROTOCOL = 'f94cdddef84bf494edf28adcafbd88b9848a415ce211a4a1c3a1bb8d75bde3fa'
BYTE_FIELDS = ['structural_solution.csv','control_point_solution.csv','actual_KKT_solution.csv',
    'structural_rhs.csv','actual_KKT_rhs.csv','actual_constraints.csv','actual_master_constraints.csv',
    'actual_master_results.csv','patch_stored_H_energy.csv','actual_stress_quadrature.csv',
    'actual_stress_quadrature_targets.csv','structural_K.csv','actual_KKT.csv']


def module(name, path, expected):
    need(sha(path) == expected, 'pinned original helper source')
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec); spec.loader.exec_module(result)
    return result


def identity(path):
    return {'sha256':sha(path),'bytes':path.stat().st_size,'mtime_ns':path.stat().st_mtime_ns}


def reporting(source_root, case, phase, core_create_ns=None, core_exit_ns=None):
    rows=[];directory=source_root/'trim_diagnostics'
    if directory.is_dir():
        target=case/('source_diagnostics_'+phase);target.mkdir()
        for source in sorted(directory.iterdir()):
            if not source.is_file():continue
            before=identity(source);copy=target/source.name;shutil.copyfile(source,copy)
            after=identity(source);copied=identity(copy)
            unchanged=before==after;equal=before['sha256']==copied['sha256'] and before['bytes']==copied['bytes']
            row={'source':str(source),'copy':copy.relative_to(case).as_posix(),
                'source_identity_before':before,'source_identity_after':after,'copy_identity':copied,
                'source_unchanged_during_copy':unchanged,'source_copy_bytes_equal':equal}
            rows.append(row)
            need(unchanged and equal,'actual producer source changed during copy or copied bytes differ')
    save(case/('normal_reporting_'+phase+'.json'),{'files':rows,'role':'producer source identity and separate copied identity; copy mtime is not freshness evidence'})
    if phase=='after':
        need(core_create_ns is not None and core_exit_ns is not None and core_create_ns<=core_exit_ns,'exact retained owned Core lifetime required')
        required={'trim_experiment_summary.csv','trim_summary.csv','trim_cell_diagnostics.csv'}
        chosen={Path(row['source']).name:row for row in rows if Path(row['source']).name in required}
        need(set(chosen)==required,'all three required normal reporting sources')
        for name,row in chosen.items():
            need(core_create_ns<=row['source_identity_before']['mtime_ns']<=core_exit_ns
                 and row['source_identity_before']==row['source_identity_after'],
                 'actual reporting producer source mtime outside true Core lifetime: '+name)
    return rows


def byte_ab(case):
    baseline_case = PREP/'runtime/runs/newruntime_original4x_ab_root_v1'
    need(sha(baseline_case/'source_runtime_manifest.json')=='57a19b20741824cba5ddb76012f2393057e86b347a730cee30a07599808b3f42','actual0f8baseline family')
    baseline = baseline_case/'derived_work/linear_state'; current = case/'derived_work/linear_state'
    rows=[]
    for name in BYTE_FIELDS:
        a,b=baseline/name,current/name
        rows.append({'relative_field':'derived_work/linear_state/'+name,'old_sha256':sha(a),'new_sha256':sha(b),
                     'old_bytes':a.stat().st_size,'new_bytes':b.stat().st_size,'bytes_equal':a.stat().st_size==b.stat().st_size and sha(a)==sha(b)})
    for old in sorted((baseline_case/'capture').glob('trim_geometry_*.json')):
        new=case/'capture'/old.name
        rows.append({'relative_field':'capture/'+old.name,'old_sha256':sha(old),'new_sha256':sha(new),'old_bytes':old.stat().st_size,'new_bytes':new.stat().st_size,'bytes_equal':sha(old)==sha(new)})
    old=baseline_case/'point/actual_point_matrices.csv';new=case/'point/actual_point_matrices.csv'
    rows.append({'relative_field':'point/actual_point_matrices.csv','old_sha256':sha(old),'new_sha256':sha(new),'old_bytes':old.stat().st_size,'new_bytes':new.stat().st_size,'bytes_equal':sha(old)==sha(new)})
    save(case/'DEFAULT_NUMERICAL_BYTE_COMPARISON.json',{'status':'NUMERICAL_BYTE_COMPARISON_RECORDED_ONLY',
        'fields':rows,'PID_path_time_resource_metadata_separate_not_compared_as_numbers':True,
        'FEM_accuracy_or_scientific_acceptance':False,'scientific_acceptance':False,'all_bytes_equal':all(r['bytes_equal']for r in rows),
        'differences_preserved_and_independent_numeric_readers_and_Root_adjudication_required':True})


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--kind',choices=['ab4x'])
    ap.add_argument('--label');ap.add_argument('--runtime-manifest',type=Path);ap.add_argument('--runtime-manifest-sha256')
    ap.add_argument('--line4',action='store_true');ap.add_argument('--duffy36',action='store_true')
    ap.add_argument('--window',type=Path);ap.add_argument('--window-sha256');ap.add_argument('--execute',action='store_true')
    a=ap.parse_args()
    if not a.execute:
        print('SOURCE_ONLY: no Core/build/seal or case queue started.');return 0
    need(a.kind and a.label and re.fullmatch('[a-z][a-z0-9_]{0,79}',a.label),'one fresh case kind/label')
    need((a.kind=='control4x' and (a.line4 or a.duffy36)) or (a.kind!='control4x' and not a.line4 and not a.duffy36),'controlled flags only in explicit4x control')
    need(a.runtime_manifest and a.runtime_manifest_sha256,'actual postlink runtime manifest')
    manifest,stage=verify_runtime(a.runtime_manifest,a.runtime_manifest_sha256)
    source,_,source_root=source_family()
    need(a.window and a.window_sha256 and sha(a.window)==a.window_sha256,'Root actual new Native window')
    w=read(a.window)
    expected={'scope':SCOPE,'kind':a.kind,'label':a.label,'driver_sha256':sha(Path(__file__)),
        'runtime_manifest_sha256':a.runtime_manifest_sha256,'source_binding_sha256':SOURCE_SHA,
        'profile_sha256':PROFILE_SHA,'line_override':4 if a.line4 else None,'duffy36':a.duffy36,
        'configured_CPU':1,'owner_memory_declaration_bytes':64<<30,'startup_RAM_commit_bytes':128<<30}
    need(all(w.get(k)==v for k,v in expected.items()) and w.get('execution_selected') is True
         and w.get('budget_values_accepted') is True and w.get('old_scope_authority_used') is False,'one new Root Native authority')
    if a.kind!='ab4x':
        prerequisite=completed.bounded_path(w['same_runtime_4x_byte_AB_receipt_relative_to_prep'])
        need(sha(prerequisite)==w['same_runtime_4x_byte_AB_receipt_sha256'],'actual same-runtime default4x AB prerequisite')
        ab=read(prerequisite)
        need(ab['status']=='ORIGINAL4X_DEFAULT_NUMERICAL_BYTE_AB_PASS_ONLY'
             and ab['runtime_manifest_sha256']==a.runtime_manifest_sha256,'default4x flagoff AB must precede newcase/override')
    profile=OLD_CASE/'executed_profile.json';recipe=OLD_CASE/'profile_recipe_receipt.json'
    need(sha(profile)==PROFILE_SHA and sha(recipe)==RECIPE_SHA,'full exact517b mode4/profile historical recipe')
    q=read(recipe);p=read(profile)
    need(p['hash']=='7311d61340e0fb12' and p['TrimQuadratureMode']==4 and p['enableGeoNonlinear'] is False,'same full linear positiveClip mode4')
    for name,h in [('SolveConfig.h','d708115f29ad02b38ef850733fa1fa2e6cd6a7e7aefd9f7673db99047fcecfef'),
                   ('NonlinearAnalysisProfile.h','4076a1e59b50ee3ce3802196aff9875133b673196c3208c4eb55868e3eaae340')]:
        need(sha(source_root/'IGAforCAD'/name)==h,'unchanged exact profile default/Capture header family')
    need(sha(POINT_PLAN)=='0e522fa185ef9b906136ad0d2673219fe7cc7115ca7e0a983dabda4fd3c8ad82'
         and sha(REQUEST)=='3d84a280fe73632397f6d2a6621022dcb491ed3cb11b49da6014d4eb18aeb88f'
         and sha(POINT/'independent_native_point_report.json')=='6a84d1e1a73b31ccb4613d00d18c00e247ba43644f70455020d68bfb1615c417',
         'unchanged finite988point/73relation topology qualification, not new-state acceptance')
    if a.kind in ('ab4x','control4x'):
        model=OLD_CASE/'input_model.dwg';model_sha='e61b385ef49818614a8a460c1ba759b9808af1d999ea84ab183fa5737a984a6d'
        command='IgaExportOEActualHullLinearStateV1Local';event='before_actual_hull_linear_state';cp=10947;dof=32841
        marker='[IGA][OEActualHullLinearStateV1] state_complete=1 actual_point=1 globalK=1 KKT=1 solve=1 independent_acceptance=0.'
        cert=None;major=2<<30;p4process=16<<30
    else:
        info=source['uniform8x'] if a.kind=='uniform8x' else source['opening3_local16x']
        model=PREP/info['DWG_source_relative_to_prep'];model_sha=info['DWG_sha256']
        cert=PREP/info.get('physical_certificate_relative_to_prep',info.get('certificate_source_relative_to_prep'))
        cert_sha=info.get('physical_certificate_sha256',info.get('certificate_sha256'));need(sha(cert)==cert_sha,'exact admitted physical certificate')
        command='IgaExportOEAdmittedHullMeshStateV2Local';event='before_admitted_hull_mesh_state_v2';cp=info['CP'];dof=info['structural_DOF']
        marker='[IGA][OEAdmittedHullMeshStateV2] state_complete=1 actual_point=1 globalK=1 KKT=1 solve=1 independent_acceptance=0.'
        major=info['major_bytes'];p4process=info['P4process_bytes']
    original=identity(model);need(original['sha256']==model_sha,'immutable exact selected model')
    need(w['input_DWG_sha256']==model_sha and w['expected_CP']==cp and w['expected_structural_DOF']==dof
         and w['P4_major_bytes']==major and w['P4_process_bytes']==p4process,'case-only prospective scope')
    case=PREP/'runtime/runs'/a.label;work=STAGING/a.label
    need(not case.exists() and not work.exists(),'fresh case/work, no retry/overwrite')
    strict=module('Native_original_license_only_strictscan',PREP/'独立复核与发布准备_20261109/strong_flux_diagnosis_v1/fine_operator_capture_preparation_v1/fine_capture_guard_v2.py','41ba90596796a1ad185a8e1cb10ef73aa04fa3c67dca5d4ba0690fb875582dc5')
    sys.path.insert(0,str(PREP/'runtime/engineering_refinement2x_prepare_v1'))
    sampler=module('Native_original_Core_sampler',PREP/'runtime/preparation/combined_weighted_endpoint_execution_v1/run_component_once.py','ed0b58743ab277df0068dd54af8ff2c94551c0ed41c3a4ce9d9793a3fbcf6f95')
    contract=module('Native_original_actual_module_contract',PREP/'runtime/preparation/interior_fixture_module_identity_v1/module_identity_contract.py','81751e343247b51d3bc52cf0d1f6fd2da8fbe3f444a39948ff56daef19682774')
    memory=sampler.startup_memory();need(min(memory.values())>=128<<30 and shutil.disk_usage(STAGING).free>=128<<30,'whole64/start128 original policy')
    before=completed.resource_scan(strict,w);need(not before['blocked'],'RESOURCE_SLOT_BLOCKED')
    lock=PREP/'runtime/engineering_heavy_attempt.lock';payload=None;lock_owned=False;owns=False
    try:
        payload=json.dumps({'owner':SCOPE,'label':a.label,'launcher':os.getpid(),'nonce':uuid.uuid4().hex}).encode()
        with lock.open('xb')as stream:stream.write(payload)
        lock_owned=True;immediate=completed.resource_scan(strict,w);need(not immediate['blocked'],'RESOURCE_SLOT_BECAME_BUSY')
        case.mkdir();work.mkdir();owns=True
        for name in ['capture','module_identity','p4','point']:(case/name).mkdir()
        for name in ['linear_state','profile_before_import']:(work/name).mkdir()
        shutil.copyfile(model,case/'input_model.dwg');shutil.copyfile(model,work/'model.dwg')
        shutil.copyfile(a.runtime_manifest,case/'source_runtime_manifest.json');shutil.copyfile(SOURCE_BINDING,case/'applied_physical_source_binding_316_plus_2.json');shutil.copyfile(PARENT_INDEX,case/'parent90f_source_index1212.json')
        shutil.copyfile(a.window,case/'root_selected_window.json');shutil.copyfile(Path(__file__),case/'executed_driver.py')
        reporting(REPORT_SOURCE_ROOT,case,'before')
        flags={'IGA_SKIP_USER_COM_REGISTRATION':'1','IGA_SOLVER_STRICT_REPRODUCIBILITY':'1','IGA_ASSEMBLY_THREADS':'1','IGA_SOLVER_THREADS':'1','IGA_PARDISO_THREADS':'1',
            'IGA_OE_MODULE_IDENTITY_DIRECTORY':str(case/'module_identity'),'IGA_OE_EXPECTED_CRX_PATH':str(stage/'IGAforCAD.crx'),'IGA_OE_EXPECTED_DBX_PATH':str(stage/'JYH_IGAEntity.dbx'),
            'IGA_OE_GEOMETRY_DIRECTORY':str(case/'capture'),'IGA_OE_COUPLE_GEOMETRY_DIRECTORY':str(case/'capture'),'IGA_DIAGNOSTIC_LIFT_MPC_TRACE_SAMPLES':'1',
            'IGA_OE_P4_CAPTURE_V1':'1','IGA_OE_P4_CAPTURE_DIRECTORY':str(case/'p4'),'IGA_OE_P4_PROTOCOL_SHA256':P4_PROTOCOL,
            'IGA_OE_REAL_CAD_LINE_WORK_V1':'1','IGA_OE_CHECKED_SPECTRAL_STATUS_V1':'1','IGA_OE_REQUIRE_VALIDATED_MAPPING':'1','IGA_OE_BOUNDARY_PROBE_JSONL':str(case/'bulk_domain.jsonl'),
            'IGA_OE_ACTUAL_POINT_COMPONENT_V1':'1','IGA_OE_ACTUAL_POINT_PLAN_TSV':str(POINT_PLAN),'IGA_OE_ACTUAL_POINT_DIRECTORY':str(case/'point'),'IGA_OE_ENDPOINT_REQUEST_TSV':str(REQUEST),
            'IGA_OE_ACTUAL_HULL_STATE_V1':'1','IGA_OE_PARENT_POINT_QUALIFICATION':str(POINT/'independent_native_point_report.json'),'IGA_OE_ACTUAL_HULL_STATE_DIRECTORY':str(work/'linear_state')}
        if cert:
            flags.update(IGA_OE_ADMITTED_HULL_MESH_STATE_V2='1',IGA_OE_HULL_MESH_LEVEL='8x' if a.kind=='uniform8x' else 'opening3_16x',IGA_OE_HULL_MESH_INPUT_DWG=str(work/'model.dwg'),IGA_OE_HULL_MESH_INPUT_CERTIFICATE=str(cert))
        if a.line4:flags['IGA_DIAGNOSTIC_COUPLE_LINE_GAUSS_N']='4'
        if a.duffy36:
            (work/'cut_moments').mkdir();flags['IGA_OE_TRI_REFERENCE_DUFFY_GL6']='1';flags['IGA_OE_CUT_MOMENT_AUDIT_DIRECTORY']=str(work/'cut_moments')
        need('IGA_OE_EXTERNAL_LOAD_AUDIT_DIRECTORY'not in flags and 'IGA_OE_ENDPOINT_PASSIVE_V1'not in flags,'no old observer/endpoint side route')
        for source_file,name,h in [(OLD_CASE/'executed_capture_original_profile.lsp','capture_original_profile.lsp','a54720635512109739cb19fe09bbe75a9daf72eab5d0f2783530210b635b5104'),
                                  (OLD_CASE/'executed_engineering_profile_guard.lsp','engineering_profile_guard.lsp','20ed38add03937c2343cd0f77ded77d6c069db052592f1f6bb150cedcf184664')]:
            need(sha(source_file)==h,'unchanged profile preimport helper');shutil.copyfile(source_file,work/name);shutil.copyfile(source_file,case/('executed_'+name))
        baseline=Path(q['outputs']['baseline']['path']);need(sha(baseline)==q['outputs']['baseline']['sha256'],'historical source-default baseline bytes')
        for src,name in [(baseline,'source_default_baseline.json'),(profile,'analysis_profile.json')]:shutil.copyfile(src,work/name)
        shutil.copyfile(profile,case/'executed_profile.json');shutil.copyfile(recipe,case/'profile_recipe_receipt.json');flags['IGA_ANALYSIS_PROFILE_JSON']=str(work/'analysis_profile.json')
        save(case/'source_default_recipe_inheritance.json',{'status':'EXISTING_RECIPE_INHERITED_BY_IDENTICAL_DEFAULT_HEADERS_ONLY','original_recipe_sha256':RECIPE_SHA,'current_CRX_source_binding_sha256':SOURCE_SHA,
            'reused_DBX_parent_source_sha256':PARENT_SHA,'runtime_manifest_sha256':a.runtime_manifest_sha256,'runtime_profile_export_or_original_DWG_clone_claimed':False})
        hashgate='(and (setq oe_selected_profile (dictsearch (namedobjdict) "IGA_NONLINEAR_ANALYSIS_PROFILE")) (= (cdr (nth 2 (vl-remove-if-not (function (lambda (item) (member (car item) (quote (90 1))))) oe_selected_profile))) "7311d61340e0fb12"))'
        body=f'(if (oe-engineering-preimport-allowed "{(work/"profile_before_import").as_posix()}" "{(work/"source_default_baseline.json").as_posix()}" "{q["outputs"]["baseline"]["profile_hash"]}") (progn (command "IgaImportAnalysisProfileHeadless") (if {hashgate} (progn (oe-engineering-gate-status "{(work/"profile_before_import").as_posix()}" "IMPORT_HASH_MATCHED_NUMERIC_COMMAND_SELECTED" T T T) (command "{command}")) (oe-engineering-gate-status "{(work/"profile_before_import").as_posix()}" "IMPORT_HASH_REJECTED_NO_NUMERIC_COMMAND" T T nil))))'
        script='\n'.join([f'(arxload "{(stage/name).as_posix()}")'for name in ['JYH_IGAEntity.dbx','IGAforCAD.crx']]+['IgaExportOELoadedModuleIdentity',
            f'(if (= (getenv "IGA_OE_MODULE_GATE_OK") "1") (progn (load "{(work/"capture_original_profile.lsp").as_posix()}") (load "{(work/"engineering_profile_guard.lsp").as_posix()}") {body}) (princ "MODULE_GATE_REJECTED_NO_WORK"))','_.QUIT','_Y',''])
        (work/'run.scr').write_text(script,encoding='ascii');shutil.copyfile(work/'run.scr',case/'executed.scr')
        env={k:v for k,v in os.environ.items()if not k.upper().startswith('IGA_')};env.update(flags);env.update(OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',OMP_DYNAMIC='FALSE',MKL_DYNAMIC='FALSE',PATH=str(stage)+';'+env.get('PATH',''))
        cmd=[str(CORE),'/i',str(work/'model.dwg'),'/s',str(work/'run.scr'),'/l','en-US']
        save(case/'launch_plan.json',{'scope':SCOPE,'kind':a.kind,'command':cmd,'runtime_manifest_sha256':a.runtime_manifest_sha256,'CRX_source_binding_sha256':SOURCE_SHA,'CRX_source_layout':'316canonical0f8+2overlay','Curves_diagnostics_root':str(DIAGNOSTIC_ROOT),'reused_DBX_parent_source_sha256':PARENT_SHA,
            'Root_window_sha256':a.window_sha256,'explicit_IGA_environment':flags,'inherited_IGA_flags_cleared':True,'whole_owner_bytes':64<<30,'startup_RAM_commit_bytes':128<<30,
            'P4_major_bytes':major,'P4_process_bytes':p4process,'line_override':4 if a.line4 else None,'Duffy36_explicit_reference_integration':a.duffy36,'preflight':before,'immediate':immediate,'no_next_action_or_Native_queue':True})
        samples=[];clock=time.perf_counter()
        with(case/'stdout.raw.log').open('wb')as out,(case/'stderr.raw.log').open('wb')as err:
            child=subprocess.Popen(cmd,cwd=work,env=env,stdout=out,stderr=err,creationflags=subprocess.CREATE_NO_WINDOW)
            proc=psutil.Process(child.pid)
            with proc.oneshot():actual={'pid':proc.pid,'create_time_epoch':proc.create_time(),'exe':proc.exe(),'parent_pid':proc.ppid(),'name':proc.name()}
            need(actual['parent_pid']==os.getpid() and Path(actual['exe']).resolve()==CORE.resolve(),'actual owned Core identity')
            owned_start_times=process_times(child,child.pid,False)
            save(case/'process_started.json',{'pid':child.pid,'started':datetime.now().astimezone().isoformat(),'actual_Core_identity':actual,
                **owned_start_times,'automatic_retry':False})
            while child.poll()is None:samples.append(sampler.sample(child));time.sleep(.25)
            code=child.wait();samples.append(sampler.sample(child))
            owned_exit_times=process_times(child,child.pid,True)
            need(owned_exit_times['actual_Core_create_time_unix_ns']==owned_start_times['actual_Core_create_time_unix_ns'],
                 'same retained owned Core handle creation identity before and after wait')
        save(case/'process_result.json',{'pid':child.pid,'exit_code':code,'natural_owned_child_exit':True,
            'all_processes_naturally_exited_claimed':False,'wall_seconds':time.perf_counter()-clock,'assembly_or_solver_selected':True,
            **owned_exit_times})
        good=[r for r in samples if r['available']];need(good,'owned Core memory observations')
        peak=max(max(r[k]for k in ['PrivateUsage','PeakPagefileUsage','PeakWorkingSetSize'])for r in good)
        save(case/'owned_resource_observations.json',{'samples':samples,'observed_peak_bytes':peak,'owner_memory_declaration_bytes':64<<30,'OS_hard_limit_installed':False})
        for name in ['stdout','stderr']:
            text,encoding=contract.decode_raw_log((case/(name+'.raw.log')).read_bytes());(case/(name+'.log')).write_text(text,encoding='utf-8')
        need(code==0 and peak<=64<<30,'owned Core exit/resource gate')
        for name in ['bootstrap',event]:
            result=contract.inspect_modules(case,manifest,stage,name,child.pid);save(case/('actual_bootstrap_module_hashes.json'if name=='bootstrap'else'actual_loaded_module_hashes.json'),result);need(not result['errors'],'actual newCRX/oldDBX loaded paths and SHA')
        stdout=(case/'stdout.log').read_text(encoding='utf-8');stderr=(case/'stderr.log').read_text(encoding='utf-8')
        need(stdout.count(marker)==1 and '[ERR]'not in stdout+stderr,'strict Native completion, no masked failure')
        need(read(case/'p4/complete.json')['ordinary_batch_returned']is True and read(case/'p4/complete.json')['fatal_latch']is False
             and read(case/'p4/complete.json')['registry_entries']==read(case/'p4/complete.json')['visited_entries']==73
             and read(case/'point/point_complete.json')['actual_Native_point_assembly_complete']is True,'whole73relation and actual point component gates')
        need(read(work/'linear_state/state_complete.json')['actual_Hull_linear_state_complete']is True,'actual separate state data complete, not scientific acceptance')
        save(case/'original_input_before_after.json',{'before':original,'after':identity(model),'exact_sha_and_mtime_unchanged':original==identity(model)})
        need(identity(model)==original and sha(work/'model.dwg')==sha(case/'input_model.dwg')==model_sha,'source/input/work immutable with QUIT_Y')
        derived=case/'derived_work';derived.mkdir();shutil.copytree(work/'linear_state',derived/'linear_state')
        for name in ['profile_before_import','cut_moments']:
            if(work/name).exists():shutil.copytree(work/name,derived/name)
        reporting(REPORT_SOURCE_ROOT,case,'after',owned_exit_times['actual_Core_create_time_unix_ns'],owned_exit_times['actual_Core_exit_time_unix_ns']);verify_runtime(a.runtime_manifest,a.runtime_manifest_sha256)
        if a.kind=='ab4x':
            byte_ab(case);ab=read(case/'DEFAULT_NUMERICAL_BYTE_COMPARISON.json');ab['runtime_manifest_sha256']=a.runtime_manifest_sha256;save(case/'DEFAULT_NUMERICAL_BYTE_COMPARISON.json',ab)
        save(case/'RAW_CASE_RECEIPT.json',{'status':'ACTUAL_DEFAULT4X_RAW_STATE_AND_DIFFERENCES_CAPTURED_PENDING_INDEPENDENT_READERS',
            'kind':a.kind,'runtime_manifest_sha256':a.runtime_manifest_sha256,'CRX_source_binding_sha256':SOURCE_SHA,'CRX_source_layout':'316canonical0f8+2overlay','Curves_diagnostics_root':str(DIAGNOSTIC_ROOT),'reused_DBX_parent_source_sha256':PARENT_SHA,
            'case_CP':cp,'structural_DOF':dof,'line_override':4 if a.line4 else None,'Duffy36_reference':a.duffy36,
            'PDE_stability_FEM_accuracy_or57case_scientific_qualification':False,'all_processes_natural_exit_claimed':False,'background_newchildren_not_automatically_exempted':True})
        rows=[{'path':p.relative_to(case).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p)}for p in sorted(case.rglob('*'))if p.is_file()]
        save(case/'capture_artifact_manifest.json',{'files':rows,'scope':'one raw Native case; reader qualifications separate; no source data overwritten'})
        print('One Root-selected Core case data captured; independent reader/controlled-moment checks remain separate.');return 0
    except Exception as error:
        target=case/'failure_preserved.json'if owns else HERE/('PREFLIGHT_REJECTED_'+a.label+'.json')
        save(target,{'status':'FAILED_OR_INCOMPLETE_NEW_RUNTIME_CASE_NOT_ACCEPTED','error':repr(error),'automatic_retry_or_cleanup':False});raise
    finally:
        if lock_owned:
            need(lock.read_bytes()==payload,'owned heavy lock identity');lock.unlink()


if __name__=='__main__':raise SystemExit(main())
