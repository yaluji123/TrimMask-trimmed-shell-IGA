"""Small exact local bicubic/polynomial oracle; no global matrix assembly.

Fractions appear at input/scale/moment boundaries; polynomial arithmetic uses
integer coefficients with a shared denominator to avoid repeated cancellation.
"""
from dataclasses import dataclass
from fractions import Fraction as F
import math

def Q(x):return F.from_float(x) if isinstance(x,float) else F(x)
def lcm(values):
    value=1
    for x in values:value=math.lcm(value,int(x))
    return value

@dataclass
class Poly:
    c:dict
    den:int=1
    def __post_init__(self):
        if self.den<=0:raise ValueError('positive polynomial denominator required')
        self.c={tuple(k):int(v) for k,v in self.c.items() if v}
    @classmethod
    def fractions(cls,c):
        c={k:Q(v) for k,v in c.items() if v};den=lcm(v.denominator for v in c.values())
        return cls({k:v.numerator*(den//v.denominator) for k,v in c.items()},den)
    def __add__(self,other):
        den=math.lcm(self.den,other.den);a=den//self.den;b=den//other.den;out={k:v*a for k,v in self.c.items()}
        for k,v in other.c.items():out[k]=out.get(k,0)+v*b
        return Poly(out,den)
    def __sub__(self,other):return self+other.scale(-1)
    def scale(self,q):
        q=Q(q);return Poly({k:v*q.numerator for k,v in self.c.items()},self.den*q.denominator)
    def __mul__(self,other):
        out={}
        for (a,b),u in self.c.items():
            for (c,d),v in other.c.items():k=(a+c,b+d);out[k]=out.get(k,0)+u*v
        return Poly(out,self.den*other.den)
    def derivative(self,axis):
        out={}
        for k,v in self.c.items():
            if k[axis]:
                j=list(k);j[axis]-=1;out[tuple(j)]=k[axis]*v
        return Poly(out,self.den)
    def l1_bound(self):return F(sum(abs(v) for v in self.c.values()),self.den)
    def evaluate(self,x,y):return sum(F(v,self.den)*Q(x)**a*Q(y)**b for (a,b),v in self.c.items())
    def maximum_degrees(self):return (max((a for a,b in self.c),default=0),max((b for a,b in self.c),default=0),max((a+b for a,b in self.c),default=0))

@dataclass
class BasisRestriction:
    span:int
    lo:F
    hi:F
    indices:list
    coefficients:list # [active basis][power 0..p], common integer denominator
    denominator:int
    @property
    def width(self):return self.hi-self.lo

def restrict_basis(knots,p,span):
    """Exact Cox-de Boor polynomial on one open span, x=lo+width*s."""
    U=[Q(x) for x in knots];n=len(U)-p-1
    if not(p<=span<n and U[span+1]>U[span]):raise ValueError('invalid positive knot span')
    lo=U[span];h=U[span+1]-lo;prev={span:[F(1)]}
    for degree in range(1,p+1):
        cur={}
        for i in range(span-degree,span+1):
            values=[F(0)]*(degree+1);left=U[i+degree]-U[i];right=U[i+degree+1]-U[i+1]
            for poly,A,B in [(prev.get(i,[]),(lo-U[i])/left if left else F(0),h/left if left else F(0)),
                             (prev.get(i+1,[]),(U[i+degree+1]-lo)/right if right else F(0),-h/right if right else F(0))]:
                for k,v in enumerate(poly):values[k]+=A*v;values[k+1]+=B*v
            cur[i]=values
        prev=cur
    indices=list(range(span-p,span+1));den=lcm(v.denominator for i in indices for v in prev[i])
    values=[[v.numerator*(den//v.denominator) for v in prev[i]] for i in indices]
    if [sum(row[k] for row in values) for k in range(p+1)]!=[den]+[0]*p:raise RuntimeError('basis restriction lost exact partition')
    return BasisRestriction(span,lo,U[span+1],indices,values,den)

def all_restrictions(knots,p):
    return [restrict_basis(knots,p,i) for i in range(p,len(knots)-p-1) if knots[i+1]>knots[i]]

def shared_binary_controls(fields):
    """Interpret each actual float as exact input; keep one power-of-two den."""
    converted=[[[Q(x) for x in row] for row in field] for field in fields]
    den=max((x.denominator for f in converted for row in f for x in row),default=1)
    if den&(den-1):raise ValueError('actual float controls should have binary denominators')
    return [[[(x.numerator*(den//x.denominator)) for x in row] for row in f] for f in converted],den

def restrict_field(bu,bv,controls,controls_v,component,control_denominator):
    c={}
    for ii,i in enumerate(bu.indices):
        for jj,j in enumerate(bv.indices):
            value=controls[i*controls_v+j][component]
            if not value:continue
            for a,u in enumerate(bu.coefficients[ii]):
                if not u:continue
                for b,v in enumerate(bv.coefficients[jj]):
                    if v:c[a,b]=c.get((a,b),0)+value*u*v
    return Poly(c,control_denominator*bu.denominator*bv.denominator)

def physical_gradients(U,V,dx,dy):
    return (U.derivative(0).scale(1/Q(dx)),U.derivative(1).scale(1/Q(dy)),
            V.derivative(0).scale(1/Q(dx)),V.derivative(1).scale(1/Q(dy)))

def membrane_half_density(U,V,dx,dy,E,nu,t):
    ux,uy,vx,vy=physical_gradients(U,V,dx,dy);nu=Q(nu);factor=Q(E)*Q(t)/(2*(1-nu*nu));gamma=uy+vx
    density=ux*ux+vy*vy+(ux*vy).scale(2*nu)+(gamma*gamma).scale((1-nu)/2)
    return density.scale(factor),(ux,uy,vx,vy)

def bending_half_density(W,dx,dy,E,nu,t):
    """Nominal-affine controls only; no actual curved-mapping Hessian claim."""
    dx=Q(dx);dy=Q(dy);nu=Q(nu);D=Q(E)*Q(t)**3/(12*(1-nu*nu))
    xx=W.derivative(0).derivative(0).scale(1/dx**2);yy=W.derivative(1).derivative(1).scale(1/dy**2)
    xy=W.derivative(0).derivative(1).scale(1/(dx*dy))
    return (xx*xx+yy*yy+(xx*yy).scale(2*nu)+(xy*xy).scale(2*(1-nu))).scale(D/2)

def displacement_squared(U,V,W=None):
    value=U*U+V*V
    return value if W is None else value+W*W

@dataclass
class MomentVector:
    order:list
    numerators:list
    denominator:int
    lookup:dict
    @classmethod
    def fractions(cls,moments):
        order=sorted(moments);den=lcm(Q(moments[k]).denominator for k in order)
        nums=[Q(moments[k]).numerator*(den//Q(moments[k]).denominator) for k in order]
        return cls(order,nums,den,dict(zip(order,nums)))
    def integrate(self,poly):
        if any(k not in self.lookup for k in poly.c):raise ValueError('moment set does not cover polynomial; L2 can require (6,6)')
        numerator=sum(v*self.lookup[k] for k,v in poly.c.items())
        return F(numerator,poly.den*self.denominator)

def jacobian_perturbation_certificate(cp,ku,kv,Lx,Ly):
    """Positive-basis exact first-derivative control hull; flat membrane only."""
    ku=[Q(x) for x in ku];kv=[Q(x) for x in kv];m=len(ku)-4;n=len(kv)-4;Lx=Q(Lx);Ly=Q(Ly)
    C=[[Q(x) for x in row] for row in cp];origin=C[0]
    gu=[sum(ku[i+1:i+4])/3 for i in range(m)];gv=[sum(kv[j+1:j+4])/3 for j in range(n)]
    residual=[[[C[i*n+j][0]-origin[0]-Lx*gu[i],C[i*n+j][1]-origin[1]-Ly*gv[j]] for j in range(n)] for i in range(m)]
    bound=[[F(0),F(0)],[F(0),F(0)]]
    for i in range(m-1):
        denominator=ku[i+4]-ku[i+1]
        if denominator:
            for j in range(n):
                for r in range(2):bound[r][0]=max(bound[r][0],abs(3*(residual[i+1][j][r]-residual[i][j][r])/denominator))
    for j in range(n-1):
        denominator=kv[j+4]-kv[j+1]
        if denominator:
            for i in range(m):
                for r in range(2):bound[r][1]=max(bound[r][1],abs(3*(residual[i][j+1][r]-residual[i][j][r])/denominator))
    # Entrywise l1 >= spectral norm of deltaJ*J0^-1, no floating sqrt required.
    e=sum(bound[r][c]/([Lx,Ly][c]) for r in range(2) for c in range(2))
    if not 0<=e<1:raise ValueError('nominal affine map not certified perturbatively invertible')
    return dict(delta_J_component_bounds=bound,inverse_relative_bound=e/(1-e),det_relative_bound=2*e+e*e,spectral_upper_bound=e)

def membrane_geometry_energy_bound(gradients,nominal_energy,uv_area,Lx,Ly,E,nu,t,certificate):
    """Absolute bound on true flat membrane energy versus nominal affine.
    Input coefficients and registered UV polygon are fixed exact data here.
    """
    ux,uy,vx,vy=gradients;gamma=uy+vx
    G=sum(p.l1_bound() for p in gradients);eps=ux.l1_bound()+vy.l1_bound()+gamma.l1_bound()
    r=certificate['inverse_relative_bound'];d=certificate['det_relative_bound'];delta=G*r
    cmax=Q(E)*Q(t)/(1-abs(Q(nu)))
    density_bound=cmax*(eps*delta+delta*delta/2)
    return Q(Lx)*Q(Ly)*Q(uv_area)*(1+d)*density_bound+d*Q(nominal_energy)
