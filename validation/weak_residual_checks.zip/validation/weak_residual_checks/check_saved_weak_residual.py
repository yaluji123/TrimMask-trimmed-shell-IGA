"""Check saved complete finite-space residuals; no factorization or solve."""
from pathlib import Path
import argparse,json,math,struct
import numpy as np
from scipy import sparse

HERE=Path(__file__).resolve().parent

def need(ok, message):
    if not ok:raise ValueError(message)

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--data-root',type=Path,default=HERE.parents[1])
    root=parser.parse_args().data_root.resolve()
    records=json.loads((HERE/'recorded_four_levels.json').read_text())['levels'];results=[]
    for row in records:
        packet=root/row['packet'];n=row['free_dimension']
        with np.load(packet/'complete_physical_space_raw.npz',allow_pickle=False) as raw:
            r=raw['full_physical_residual_coordinates'].copy();U=raw['actual_U'].copy();F=raw['actual_external_F'].copy();bulk=raw['direct_independent_bulk_action'].copy();delta_r=raw['COO_vs_direct_bulk_physical_residual_difference'].copy()
            coarse_x=raw['Riesz_coordinates'].copy() if row['level']==1 else None
        G=sparse.load_npz(packet/'independent_G.npz');Z=sparse.load_npz(packet/'Z.npz')
        need(G.shape==(n,n) and Z.shape==(len(U),n) and r.shape==(n,), 'complete space dimensions')
        input_error=float(np.linalg.norm(Z.T@(bulk-F)-r)/(1+np.linalg.norm(r)))
        need(input_error<1e-12,'saved physical residual equation')
        energy=float(U@bulk)
        need(abs(energy-row['normalization_material_quadratic_work_Nmm'])/(1+abs(energy))<1e-12,'material-work normalization')
        if row['level']==1:x=coarse_x
        else:
            raw=(HERE/row['saved_solutions']).read_bytes();magic,count=struct.unpack('<8sI',raw[:12])
            need(magic==b'RZSOL001'and count==n and len(raw)==12+16*n,'original binary solution shape')
            saved=np.frombuffer(raw,dtype='<f8',offset=12).reshape(2,n);x=saved[0]
            delta_backward=float(np.linalg.norm(G@saved[1]-delta_r)/(np.linalg.norm(G.data)*np.linalg.norm(saved[1])+np.linalg.norm(delta_r)))
            delta_q=float(delta_r@saved[1]);need(delta_q>=0 and delta_backward<1e-12,'saved perturbation Riesz equation')
            delta_norm=math.sqrt(delta_q)
            need(abs(delta_norm-row['COO_direct_action_perturbation_dual_sqrt_Nmm'])/(1+abs(delta_norm))<1e-12,'reported perturbation dual arithmetic')
        need(x.shape==(n,)and np.isfinite(x).all(),'finite full saved Riesz coefficients')
        backward=float(np.linalg.norm(G@x-r)/(np.linalg.norm(G.data)*np.linalg.norm(x)+np.linalg.norm(r)))
        need(backward<1e-12,'saved Riesz equation')
        q=float(r@x);need(q>=0,'nonnegative saved quadratic')
        dual=math.sqrt(q);relative=math.sqrt(q/energy)
        need(abs(dual-row['full_finite_physical_dual_sqrt_Nmm'])/(1+abs(dual))<1e-12,'reported dual arithmetic')
        need(abs(relative-row['energy_normalized_full_finite_physical_dual'])/(1+abs(relative))<1e-12,'reported normalized dual arithmetic')
        results.append(dict(level=row['level'],free_dimension=n,normalized_full_finite_dual=relative,saved_equation_backward_error=backward,physical_residual_input_error=input_error,recorded_packet_status=row['recorded_packet_status'],recorded_final_status=row['recorded_final_status']))
    need([r['free_dimension']for r in results]==[621,1845,3717,6237],'four original complete spaces')
    print(json.dumps(dict(status='SAVED_FOUR_LEVEL_RIESZ_EQUATIONS_AND_ARITHMETIC_CHECKED',levels=results,linear_solve_or_factorization_executed=False),indent=2))

if __name__=='__main__':main()
