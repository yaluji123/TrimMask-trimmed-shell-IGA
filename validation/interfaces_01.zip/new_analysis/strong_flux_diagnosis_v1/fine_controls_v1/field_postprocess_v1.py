import traceback
from boot_v1 import start
resources = start()
import numpy as np
from scipy import sparse
from common_v1 import *

OUT = HERE/"physical_fields_v1"; OUT.mkdir(exist_ok=False)
result = {"status": "PHYSICAL_FIELDS_NOT_COMPLETED", "resources": resources, "states": []}
try:
    audit = read(HERE/"fine_rowaudit_v1/results.json")
    assert audit["status"] == "INDEPENDENT_COMPLETE_PHYSICAL_ROW_MATRIX_MATCHED"
    lam = audit["lambda_BC"]
    matrices = {name: sparse.load_npz(bind(HERE/"fine_rowaudit_v1"/(name+".npz")))
                for name in ("Kline", "PBC", "KBC_consistency")}
    packet = PREP/"all_h4_complete_physical_sparse_packet_v2"
    Z = sparse.load_npz(bind(packet/"Z.npz"))
    G = sparse.load_npz(bind(packet/"independent_G.npz"))
    gdiag = G.diagonal(); del G
    reference = read(PREP/"final16_Gamma_and_allgraph_duals_v2/final16_graph_h_and_finite_reference.json")
    refE = reference["seven_level_STRI3_reference"]["rows"][-1]["ALLSE_Nmm"]
    refU = np.array(reference["actual_FEM_peak_U_vector_mm"])
    source_flux = read(PREP/"cluster_gl4_all_h4_flux_v1.json")
    riesz_packets = {}
    for alpha in (105., 210., 420.):
        folder = HERE/f"alpha{int(alpha)}_mmd_v2"
        state_meta = read(folder/"results.json")
        assert state_meta["status"] == "QUALIFIED_UNSHIFTED_ACTUAL_SPARSE_STATE"
        data = np.load(bind(folder/"state.npz")); U, F = data["U"], data["F"]
        run, cluster, arms, betas, _, bulk_matrix = load(4, U)
        n = len(U); actualBC_local = matrix(run/"input_audit/boundary_delta_H_7867.csv", len(arms[0].dofmap), 200000)
        BC = scatter(actualBC_local, arms[0].dofmap, n)+(alpha-210.)*lam*matrices["PBC"]
        natural = matrix(run/"input_audit/triple_point_natural_b.csv", n, 4096)
        essential_a = matrix(run/"input_audit/triple_point_essential_a.csv", n, 4096)
        essential_far = matrix(run/"input_audit/triple_point_essential_far.csv", n, 4096)
        bulk = core.integrate_bulk_action(arms)
        bulk_action = bulk.pop("global_action"); energy = bulk["material_quadratic_work_N_mm"]
        assert energy > 0
        actions = {"line": matrices["Kline"]@U, "natural_b": natural@U,
                   "essential_a": essential_a@U, "essential_far": essential_far@U,
                   "BC_total": BC@U, "BC_consistency": matrices["KBC_consistency"]@U,
                   "BC_penalty": alpha*lam*(matrices["PBC"]@U)}
        actions["BC_reconstruction_roundoff"] = actions["BC_total"]-actions["BC_consistency"]-actions["BC_penalty"]
        r = Z.T@(bulk_action-F)
        work = {name: Z.T@v for name, v in actions.items()}
        closure = r+work["line"]+work["natural_b"]+work["essential_a"]+work["essential_far"]+work["BC_total"]
        normalized_closure = np.max(abs(closure)/np.sqrt(gdiag*energy))
        np.savez_compressed(OUT/f"alpha{int(alpha)}_complete_weak_ledger.npz", physical_r=r,
                            normalization=np.sqrt(gdiag*energy), closure=closure, **work)
        riesz_packets[f"r{int(alpha)}"] = r
        riesz_packets[f"energy{int(alpha)}"] = np.array(energy)
        events = [__import__('json').loads(x) for x in bind(run/"boundary_domain_probe.jsonl").read_text(encoding="utf-8-sig").splitlines()]
        purpose = None; points = []
        for e in events:
            if e["event"] == "probe_purpose": purpose = e["purpose"]
            elif e["event"] == "point_probe" and purpose == "carrier_integration": points.append(e)
        bu2 = bt2 = length = physical_bc_work = 0.; maxu = maxt = 0.
        boundary_rows = []
        for e in points:
            op = arms[0].operators(*e["uv"], mu=-arms[0].t, ell=1.)
            u, theta, T, m = [op[name]@arms[0].coeff for name in ("U", "theta", "T", "m")]
            w = e["physical_line_weight"]; length += w; bu2 += w*(u@u); bt2 += w*(theta@theta)
            maxu = max(maxu, norm(u)); maxt = max(maxt, norm(theta)); physical_bc_work += w*(T@u+m@theta)
            boundary_rows.append({"uv": e["uv"], "weight_ds_mm": w, "U_mm": u, "theta_rad": theta,
                                  "physical_T_N_per_mm": T, "physical_m_N": m})
        save(OUT/f"alpha{int(alpha)}_boundary_all96.json", {"rows": boundary_rows})
        cluster_metrics = []
        flux_rows = []
        numeric_sum_max = 0.
        for source_q in source_flux["quadrature_results"]:
            order = source_q["order"]
            core_metrics = core.integrate_cluster(arms, betas, 1., gauss=order)
            core_metrics.pop("numerical_canonical_cluster_action_global")
            cluster_metrics.append(core_metrics)
            qrows = []
            for point in source_q["all_GP"]:
                ops = [a.operators(point["u"], 0., ell=1.) for a in arms]
                z = [op["N"]@a.coeff for op, a in zip(ops, arms)]
                p = [-op["V"]@a.coeff for op, a in zip(ops, arms)]
                mean = sum(p)/3
                pnum = [pi-mean for pi in p]
                for (i, j), beta in betas.items():
                    jump = beta*(z[i]-z[j]); pnum[i] -= jump; pnum[j] += jump
                numeric_sum_max = max(numeric_sum_max, norm(sum(pnum)))
                qrows.append({"u": point["u"], "x_mm": point["x_mm"], "weight_ds_mm": point["weight_ds_mm"],
                    "owner_raw_g_N_per_mm": [op["effective_force"]@a.coeff for op, a in zip(ops, arms)],
                    "owner_raw_m_N": [op["m"]@a.coeff for op, a in zip(ops, arms)],
                    "owner_physical_scaled_p": p, "owner_scaled_trace_z": z,
                    "owner_numerical_flux_pnum": pnum, "sum_numerical_flux_algebraic_only": sum(pnum)})
            flux_rows.append({"order": order, "all_original_GP": qrows})
        save(OUT/f"alpha{int(alpha)}_all_original_raw_and_numeric_flux.json", {
            "quadratures": flux_rows, "physical_raw_not_mean_subtracted_or_relabelled": True,
            "pnum_sum_is_constructed_identity_not_accuracy": True})
        cuts = core.unique_cuts(arms); nodes, weights = np.polynomial.legendre.leggauss(8)
        intervals = {"whole": (0., 100.), "first1": (0., 1.), "first2p5": (0., 2.5),
                     "first5": (0., 5.), "first10": (0., 10.), "inner10to90": (10., 90.),
                     "last10": (90., 100.), "first_span": (0., 100.*cuts[1])}
        spatial = {}
        for name, (start, end) in intervals.items():
            f2 = fd = m2 = md = mint = 0.; fint = np.zeros(3)
            for left, right in zip(cuts[:-1], cuts[1:]):
                lo, hi = max(start, 100*left), min(end, 100*right)
                if hi <= lo: continue
                for x, weight in zip(nodes, weights):
                    xx = (lo+hi)*.5+(hi-lo)*x*.5; ds = (hi-lo)*weight*.5
                    ops = [a.operators(xx/100., 0., ell=1.) for a in arms]
                    gs = [op["effective_force"]@a.coeff for op, a in zip(ops, arms)]
                    ms = [float(a.t@(op["m"]@a.coeff)) for op, a in zip(ops, arms)]
                    g, mt = sum(gs), sum(ms)
                    f2 += ds*(g@g); fd += ds*sum(v@v for v in gs); m2 += ds*mt**2; md += ds*sum(v*v for v in ms)
                    fint += ds*g; mint += ds*mt
            spatial[name] = {"range_mm": [start, end], "force_abs_L2_N_per_sqrt_mm": np.sqrt(f2),
                "moment_abs_L2_N_sqrt_mm": np.sqrt(m2), "force_relative_L2": np.sqrt(f2/fd),
                "moment_relative_L2": np.sqrt(m2/md), "signed_force_integral_N": fint,
                "signed_moment_integral_Nmm": mint}
        peak = arms[2].operators(1., 1.)["U"]@arms[2].coeff
        positions = np.zeros((n//3, 3))
        for a in arms: positions[a.dofmap[::3]//3] = a.cp
        reaction = -(actions["BC_total"]+actions["essential_a"]+actions["essential_far"])
        rf, rm = core.resultants(reaction, positions, np.zeros(3)); ef, em = core.resultants(F, positions, np.zeros(3))
        row = {"alphaB": alpha, "material_energy_Nmm": .5*energy, "finite_reference_energy_Nmm": refE,
            "material_energy_signed_relative_to_finite_STRI3": .5*energy/refE-1.,
            "fixed_PATCH2_U_vector_mm": peak, "finite_reference_U_vector_mm": refU,
            "fixed_vector_relative_difference": norm(peak-refU)/norm(refU),
            "boundary_U_RMS_mm": np.sqrt(bu2/length), "boundary_theta_RMS_rad": np.sqrt(bt2/length),
            "boundary_GP_max_U_mm": maxu, "boundary_GP_max_theta_rad": maxt,
            "boundary_physical_full_work_Nmm": physical_bc_work,
            "action_quadratic_work_Nmm": {name: float(U@v) for name, v in actions.items()},
            "max_normalized_complete_weak_ledger_closure": normalized_closure,
            "independent_full_action_residual_L2_N": norm(bulk_action-F+actions["line"]+actions["natural_b"]+actions["essential_a"]+actions["essential_far"]+actions["BC_total"]),
            "independent_bulk_matrix_vs_direct_action_L2_N": norm(bulk_matrix@U-bulk_action),
            "cluster_quadratures": cluster_metrics, "spatial": spatial,
            "numeric_flux_sum_scaled_max_algebraic_only": numeric_sum_max,
            "force_global_balance_relative": norm(rf+ef)/(norm(rf)+norm(ef)),
            "moment_global_balance_relative": norm(rm+em)/(norm(rm)+norm(em)),
            "all_6237_finite_tests_retained": len(r) == 6237,
            "original_strong_metrics_not_declared_passing": True}
        save(OUT/f"alpha{int(alpha)}_results.json", row); result["states"].append(row)
        print("PHYSICAL_FIELDS_COMPLETED_ALPHA "+str(int(alpha)), flush=True)
    np.savez_compressed(OUT/"Riesz_rhs_and_normalization.npz", **riesz_packets)
    result["status"] = "ALL_FIXED_CONTROLS_PHYSICAL_FIELDS_COMPLETED_RIESZ_SEPARATE"
except Exception as e:
    result.update(failure=repr(e), traceback=traceback.format_exc())
finally:
    verify_inputs(); result.update(input_sha256=PINS, observed_memory=memory())
    save(OUT/"results.json", result)
if result["status"] != "ALL_FIXED_CONTROLS_PHYSICAL_FIELDS_COMPLETED_RIESZ_SEPARATE": raise SystemExit(2)
