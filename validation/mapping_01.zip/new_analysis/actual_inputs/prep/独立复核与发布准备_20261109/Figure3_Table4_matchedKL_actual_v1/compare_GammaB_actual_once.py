"""One actual same-world GammaB coarse/fine vector comparison; no new accuracy gate."""
from pathlib import Path
import sys, json, hashlib, math, csv, traceback
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
binding=read(HERE/'ACTUAL_GAMMAB_INPUT_BINDING.json')
guard=binding['resource_guard'];assert sha(guard['path'])==guard['sha256']
sys.path.insert(0,str(Path(guard['path']).parent))
from resource_guard import install
resources=install()
assert resources['OS_memory_job_installed']and resources['CPU_affinity_cores']==1 and resources['memory_limit_bytes']==536870912
try:
 for key in ['coarse','fine','coarse_process']:
  assert sha(binding[key]['path'])==binding[key]['sha256']
 coarse=read(binding['coarse']['path']);fine=read(binding['fine']['path'])
 for key,d in [('coarse',coarse),('fine',fine)]:
  assert d['node']==binding[key]['node'] and d['xyz_mm']==[100.,0.,0.] and d['actual_field_precision']=='DOUBLE_PRECISION'
  assert d['matched_family']=='KLphysicalclampnode1UR3free' and d['only_BC_delta']==[1,6] and d['components']==['U1','U2','U3'] and all(math.isfinite(x)for x in d['U_mm'])
 c=coarse['U_mm'];f=fine['U_mm'];delta=[x-y for x,y in zip(c,f)]
 norm=lambda x:math.sqrt(sum(y*y for y in x))
 rows=[{'component':name,'coarse_mm':x,'fine_mm':y,'delta_coarse_minus_fine_mm':z,'absolute_delta_mm':abs(z),'fraction_abs_change_over_abs_fine':abs(z)/abs(y)if y!=0 else None,'relative_change_status':'DEFINED'if y!=0 else 'N/A_ZERO_FINE_COMPONENT'}for name,x,y,z in zip(['U1','U2','U3'],c,f,delta)]
 report={'status':'ACTUAL_GAMMAB_LOCAL_REFERENCE_SELF_CHANGE_MEASURED_NO_ACCEPTANCE_GATE','same_world_point_mm':[100.,0.,0.],'coarse_h_mm':.25,'fine_h_mm':.125,'components':rows,'coarse_vector_mm':c,'fine_vector_mm':f,'delta_coarse_minus_fine_mm':delta,'absolute_vector_delta_L2_mm':norm(delta),'fine_vector_L2_mm':norm(f),'fraction_vector_change_over_fine_L2':norm(delta)/norm(f)if norm(f)!=0 else None,'new_local0p1percent_or_component_acceptance_gate_applied':False,'original0p1percent_response_criteria_scope':['global_maximum_U_magnitude','ALLSE','ALLIE'],'denominator_max1_or_mean_subtraction_used':False,'inputs':binding,'resources':resources,'no_new_state_solve_API_FE_Core_or_other_figure':True}
 with(HERE/'ACTUAL_GAMMAB_SAME_WORLD_SELF_CHANGE.json').open('x',encoding='utf-8')as out:json.dump(report,out,indent=2,allow_nan=False);out.write('\n')
 with(HERE/'ACTUAL_GAMMAB_COMPONENTS.csv').open('x',encoding='utf-8',newline='')as out:
  writer=csv.DictWriter(out,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
 print(json.dumps({'status':report['status'],'vector_fraction':report['fraction_vector_change_over_fine_L2'],'component_fractions':[r['fraction_abs_change_over_abs_fine']for r in rows],'resources':resources}),flush=True)
except Exception as error:
 with(HERE/'FAILED_GAMMAB_ONCE.json').open('x',encoding='utf-8')as out:json.dump({'status':'FAIL_STOP_NO_NEXT_STAGE','error':repr(error),'traceback':traceback.format_exc()},out,indent=2)
 raise
