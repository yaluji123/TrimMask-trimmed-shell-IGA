"""Check saved Green inputs and work ledgers; no integration or state solve."""
from pathlib import Path
import argparse,json,collections
import numpy as np
HERE=Path(__file__).resolve().parent

def need(ok,message):
    if not ok:raise ValueError(message)

def label(row):return tuple(row.get(k)for k in ['phase','owner','fixture','level','state','rule'])

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--data-root',type=Path,default=HERE.parents[1]);root=p.parse_args().data_root.resolve()
    inputs=[]
    for row in json.loads((HERE/'input_map.json').read_text())['levels']:
        cluster=json.loads((HERE/row['cluster']).read_text());ndof=cluster['actual_global_dofs']
        with np.load(root/row['weak_packet']/'complete_physical_space_raw.npz',allow_pickle=False)as z:weak=z['actual_U'].copy()
        with np.load(HERE/row['states'],allow_pickle=False)as z:conf=z['Uconf'];delta=z['deltaU']
        need(weak.shape==conf.shape==delta.shape==(ndof,),'complete global coefficient vectors')
        gap=float(np.linalg.norm(weak-delta-conf)/(1+np.linalg.norm(conf)));need(gap<1e-12,'saved weak/delta/conforming identity')
        dofs=[]
        for arm in cluster['arms']:
            owner=int(arm['handle'],16) if isinstance(arm['handle'],str) else arm['handle']
            g=json.loads((HERE/row['geometries'][str(owner)]).read_text());m,n=g['controls_u'],g['controls_v']
            ids=np.asarray(arm['global_dofmap'],dtype=int).ravel();need(len(ids)==3*m*n,'complete owner global DOF map');dofs.extend(ids.tolist())
            need(np.asarray(g['control_global_Vg']).size==3*m*n and np.asarray(g['weights']).size==m*n,'complete control net and rational weights')
            need(len(g['knots_u'])==m+g['degree_u']+1 and len(g['knots_v'])==n+g['degree_v']+1,'exact knot vector dimensions')
            need(g['E']==arm['E_observed']and g['nu']==arm['nu_observed']and g['constant_t']==arm['thickness_observed'],'actual material/thickness identity')
        need(len(dofs)==ndof and set(dofs)==set(range(ndof)),'all and only actual structural coefficients mapped')
        inputs.append(dict(level=row['level'],global_dofs=ndof,weak_minus_delta_relative_gap=gap,owners=len(cluster['arms'])))
    directory=root/'new_analysis/commonlift_B4rho_Green_root_actual_v2'
    records=json.loads((directory/'DIRECT_GREEN_ALL_COMPONENTS.json').read_text());indexed={label(r):r for r in records if r['phase']!='ordinarySUM'}
    sums=collections.defaultdict(lambda:collections.defaultdict(float));counts={};point_error=0.
    for filename,kind in [('ALL_CELL_EDGE_H_CORNER_INCIDENCES.jsonl','corner'),('ALL_EXPLICIT_INTERNAL_KNOT_FACETS.jsonl','facet'),('ALL_OUTER_BOUNDARY_CONSTITUTIVE_TRACES_GL4.jsonl','boundary')]:
        count=0
        with(directory/filename).open()as stream:
            for line in stream:
                r=json.loads(line);key=label(r);count+=1
                if kind=='corner':
                    value=float(r['sign']*np.asarray(r['H_N'])@np.asarray(r['virtual_u_mm']));point_error=max(point_error,abs(value-r['H_work_Nmm'])/(1+abs(value)));sums[key]['corners']+=r['H_work_Nmm']
                elif kind=='facet':sums[key]['internal_explicit']+=r['work']
                else:
                    T,m,g,u,theta,tau=[np.asarray(r[k])for k in ['physical_T_N_per_mm','physical_m_N','physical_g_N_per_mm','virtual_u_mm','virtual_theta_rad','tau']]
                    for value,stored in [(float(T@u+m@theta),r['full_power_density_N']),(float(g@u+(m@tau)*(theta@tau)),r['reduced_power_density_N'])]:point_error=max(point_error,abs(value-stored)/(1+abs(value)))
                    sums[key][r['edge_role']]+=r['ds_weight_mm']*r['full_power_density_N']
        counts[filename]=count
    need(list(counts.values())==[53568,12600,6336]and len(records)==98,'complete saved ledger counts')
    operation_error=max(abs(value-indexed[key][name])/max(1.,indexed[key]['operation'])for key,parts in sums.items()for name,value in parts.items())
    closure=max(abs(r['material']-(r['body_membrane']+r['body_bending'])-(r['Gamma']+r['other_outer']+r['internal_explicit'])-r['Green_defect'])/(1+abs(r['operation']))for r in records)
    need(point_error<1e-12 and operation_error<1e-10 and closure<1e-12,'saved work arithmetic under original operation-scaled Green QA budget')
    print(json.dumps(dict(status='SAVED_GREEN_INPUTS_AND_LEDGERS_CHECKED',inputs=inputs,raw_ledger_counts=counts,point_power_max_normalized_difference=point_error,grouped_work_max_operation_normalized_difference=operation_error,closure_arithmetic_max_operation_normalized_difference=closure,volume_or_facet_integration_executed=False,state_solve_executed=False),indent=2))

if __name__=='__main__':main()
