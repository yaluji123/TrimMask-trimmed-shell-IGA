"""Strict final-batch metadata selection only; no geometry/length/coverage math.

Raw accepted batches are observations, not final support. Native ABI has Panel
CSV emission + point_batch_end, NOT a panel_finalized JSON event. All raw rows
and stage/batch/UID records remain in the identity ledger.
"""
from collections import defaultdict
import re

class FinalBatchOpen(ValueError):pass
def need(ok,message):
    if not ok:raise FinalBatchOpen(message)
def integer(value,name):
    need(type(value)in(int,str)and re.fullmatch(r'[0-9]+',str(value))is not None,'literal nonnegative integer '+name)
    return int(value)
def key3(row):return tuple(integer(row[k],k)for k in['entry','attempt','batch'])
def key4(row):return key3(row)+(integer(row['uid'],'uid'),)
def one(rows,message):
    need(len(rows)==1,message);return rows[0]

def select_final_batches(relations,points,gps,panels,statuses,events,complete):
    """Return selected immutable row references and a FULL raw metadata ledger.

    Uniqueness is proven from final gp, never max(batch), last status, ordinal
    alone or GP-only geometric coverage. Any unresolved entry remains OPEN.
    """
    ids=[integer(rel['registry_index'],'registry_index')for rel in relations]
    need(len(ids)==len(set(ids))and len(ids)==complete['registry_entries']==complete['visited_entries'],'complete explicit registry')
    need(len(points)==complete['attempt_GP_count']and len(gps)==complete['final_GP_count'],'unchanged all accepted/final denominators')
    P=defaultdict(list);G=defaultdict(list);N=defaultdict(list);S=defaultdict(list);E=defaultdict(list)
    point_keys=set();gp_keys=set();global_uid=set();panel_keys=set()
    for row in points:
        k=key4(row);need(k not in point_keys and k[3]>0 and k[3]not in global_uid,'all raw accepted UID identities unique')
        point_keys.add(k);global_uid.add(k[3]);P[k[:3]].append(row)
    for row in gps:
        k=key4(row);need(k not in gp_keys and k in point_keys,'each actual final GP has one accepted raw point, no missing/duplicate UID')
        gp_keys.add(k);G[k[:3]].append(row)
    for row in panels:
        k=key3(row)+(integer(row['panel'],'panel'),);need(k not in panel_keys,'unique producer panel identity')
        panel_keys.add(k);N[k[:3]].append(row)
    for row in statuses:S[integer(row['entry'],'entry')].append(row)
    for line,event in enumerate(events,1):E[integer(event['entry'],'event entry')].append((line,event))
    need(set(k[0]for k in point_keys|gp_keys)<=set(ids)and set(k[0]for k in N)<=set(ids)and set(S)<=set(ids),'no unregistered source identities')
    # This evidence records all accepted-not-final points, regardless of whether
    # their batch/attempt later succeeded, failed or was superseded.
    not_final=[row for row in points if key4(row)not in gp_keys]
    ledger=dict(status='OPEN_FINAL_BATCH_SELECTION_NOT_ACCEPTED',selection_policy='unique actual final GP batch + full UID equality + source Panel/batch/entry finalization evidence',
      named_panel_finalized_JSON_event_claimed=False,
      producer_panel_binding='Panel CSV emitted at each builder panel end; same-key unique point_batch_begin/end seals accepted count; entry terminal must match',
      all_raw_accepted_point_rows=points,all_raw_final_GP_rows=gps,all_raw_producer_panel_rows=panels,
      all_raw_status_rows=statuses,all_raw_events=[dict(source_line_one_based=i,event=e)for i,e in enumerate(events,1)],
      accepted_attempt_rows=len(points),final_GP_rows=len(gps),accepted_not_final_rows=not_final,
      accepted_not_final_UID_keys=[list(key4(row))for row in not_final],accepted_not_final_count=len(not_final),
      accepted_not_final_is_not_inferred_mapping_rejected=True,no_raw_rows_deleted_or_rewritten=True,
      geometry_or_eligible_interval_coverage_computed=False,entries=[],open_entries=[])
    selected_points=[];selected_panels=[];success={};matched_finalized={}
    for entry in ids:
        batch_rows=[]
        for k in sorted(k for k in P if k[0]==entry):
            event_rows=[dict(source_line_one_based=line,event=event)for line,event in E[entry]if key3(event)==k]
            batch_rows.append(dict(entry=entry,attempt=k[1],batch=k[2],accepted_UIDs=[key4(row)[3]for row in P[k]],
              final_UIDs=[key4(row)[3]for row in G.get(k,[])],producer_panels=N.get(k,[]),stage_events=event_rows))
        info=dict(entry=entry,all_batches=batch_rows,all_status_rows=S[entry],selected_final_batch=None,selection_status='OPEN')
        try:
            st=one([r for r in S[entry]if r['stage']=='entry_return'and r['returned']=='true'],'unique successful entry_return')
            attempt=integer(st['attempt'],'winning attempt');need(st['route']in('matched','unmatched'),'supported explicit final route')
            need(st['mapping_rejected']=='false'and st['opaque_final_gp']=='false'and st['empty_true']=='false'and st['rolled_back']=='false','successful final nonempty/nonopaque/nonrollback entry')
            final_batches=[k for k,actual_rows in G.items()if k[0]==entry and actual_rows]
            chosen=one(final_batches,'actual final GP must identify one unique full batch; mixed batches OPEN')
            need(chosen[1]==attempt and chosen[2]>0,'final GP belongs to winning actual attempt/positive batch')
            pp=P.get(chosen,[]);gg=G.get(chosen,[]);pn=N.get(chosen,[])
            need(pp and gg and pn,'full final batch points/GP/panels all observed')
            need({key4(r)for r in pp}=={key4(r)for r in gg},'whole chosen batch UID set equals final GP; partial batch/panel ambiguity OPEN')
            need([integer(r['accepted_ordinal'],'accepted ordinal')for r in pp]==list(range(len(pp))),'unchanged selected batch accepted-ordinal order')
            need([integer(r['panel'],'panel')for r in pn]==list(range(len(pn))),'complete producer panel order/identity, no guessed subset')
            need(sum(integer(r['accepted_points'],'panel accepted')for r in pn)==len(pp),'all selected producer panel accepted counts consume final batch')
            begin=one([(line,e)for line,e in E[entry]if e['kind']=='point_batch_begin'and key3(e)==chosen],'unique selected point_batch_begin')
            end=one([(line,e)for line,e in E[entry]if e['kind']=='point_batch_end'and key3(e)==chosen],'unique selected point_batch_end')
            need(begin[0]<end[0]and integer(end[1]['accepted'],'batch accepted')==len(pp)and integer(end[1]['tested'],'batch tested')>=len(pp),'actual batch-end count/finalization; not GP-only support')
            ab=one([(line,e)for line,e in E[entry]if e['kind']=='attempt_begin'and integer(e['attempt'],'attempt')==attempt],'unique winning attempt_begin')
            ae=one([(line,e)for line,e in E[entry]if e['kind']=='attempt_end'and integer(e['attempt'],'attempt')==attempt],'unique winning attempt_end')
            terminal=one([(line,e)for line,e in E[entry]if e['kind']=='entry_outcome'],'unique producer entry_outcome')
            need(ab[0]<begin[0]<end[0]<ae[0]<terminal[0]and ab[1]['route']==st['route']and ae[1]['returned']is True,
              'winning attempt route/lifecycle matches selected final batch')
            need(terminal[1]['status']=='ASSEMBLED_NONEMPTY'and key3(terminal[1])==chosen,'producer terminal batch/attempt agrees with final GP; otherwise OPEN')
            if st['route']=='matched':
                for gp in gg:
                    k=key4(gp);ev=one([(line,e)for line,e in E[entry]if e['kind']=='matched_weight_finalized'and key4(e)==k],'unique actual matched_weight_finalized for each final UID')
                    need(begin[0]<ev[0]<terminal[0],'matched weight finalized in selected producer lifecycle')
                    matched_finalized[k]=ev[1]
            selected_points.extend(pp);selected_panels.extend(pn);success[entry]=st
            info.update(selected_final_batch=dict(entry=entry,attempt=attempt,batch=chosen[2],final_UIDs=[key4(r)[3]for r in gg],
              point_batch_begin_line=begin[0],point_batch_end_line=end[0],entry_outcome_line=terminal[0],
              producer_panel_keys=[list(key3(r)) + [integer(r['panel'],'panel')]for r in pn],
              panel_count=len(pn),accepted_points=len(pp),final_GP=len(gg)),selection_status='UNIQUE_FULL_FINAL_BATCH_BOUND')
        except (FinalBatchOpen,KeyError,ValueError,TypeError)as error:
            info['open_reason']=str(error);ledger['open_entries'].append(dict(entry=entry,reason=str(error)))
        ledger['entries'].append(info)
    if not ledger['open_entries']:
        need(len(success)==len(ids)and len(selected_points)==len(gps),'every requested relation and actual final GP selected exactly once')
        ledger['status']='UNIQUE_FINAL_BATCH_UID_PANEL_INPUTS_BOUND_ONLY_NOT_COVERAGE'
    return dict(points=selected_points,gps=gps,panels=selected_panels,success=success,finalized=matched_finalized,ledger=ledger)
