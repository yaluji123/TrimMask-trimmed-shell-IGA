from pathlib import Path
import csv
import hashlib
import importlib.util
import json
import sys
import numpy as np
from scipy import sparse

HERE = Path(__file__).resolve().parent
S = HERE.parent
ROOT = S.parents[1]
PREP = ROOT/"runtime/preparation/triple_point_completion_20261107_v7b"
CAPTURE = S/"fine_operator_capture_preparation_v1/capture_attempt_v1"
PINS = {}


def sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024*1024), b""):
            h.update(block)
    return h.hexdigest()


def bind(path):
    PINS[str(path)] = sha(path)
    return Path(path)


def read(path):
    return json.loads(bind(path).read_text(encoding="utf-8-sig"))


def clean(x):
    if isinstance(x, dict): return {str(k): clean(v) for k, v in x.items()}
    if isinstance(x, (tuple, list)): return [clean(v) for v in x]
    if isinstance(x, np.ndarray): return x.tolist()
    if isinstance(x, np.generic): return x.item()
    return x


def save(path, value):
    Path(path).write_text(json.dumps(clean(value), indent=2, allow_nan=False)+"\n", encoding="utf-8")


def norm(x):
    return float(np.linalg.norm(x.data if sparse.issparse(x) else x))


def verify_inputs():
    for path, digest in PINS.items():
        assert sha(path) == digest, "input drift "+path


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, bind(path))
    value = importlib.util.module_from_spec(spec); sys.modules[name] = value
    spec.loader.exec_module(value)
    return value


core = module("cluster_physical_core", PREP/"independent_readers_v7/cluster_physical_core.py")


def matrix(path, n, cap):
    ri = np.empty(cap, dtype=np.int32); ci = ri.copy(); data = np.empty(cap); count = 0
    with bind(path).open(encoding="utf-8-sig", newline="") as stream:
        rows = csv.reader(stream); next(rows)
        for row in rows:
            assert count < cap
            i, j, v = int(row[0]), int(row[1]), float(row[2])
            assert 0 <= i < n and 0 <= j < n and np.isfinite(v) and v != 0.
            ri[count], ci[count], data[count] = i, j, v; count += 1
    result = sparse.coo_matrix((data[:count], (ri[:count], ci[:count])), shape=(n, n)).tocsr()
    assert result.nnz == count
    return result


def vector(path, n):
    result = np.empty(n); count = 0
    with bind(path).open(encoding="utf-8-sig", newline="") as stream:
        rows = csv.reader(stream); next(rows)
        for row in rows:
            assert count < n and int(row[0]) == count
            result[count] = float(row[-1]); count += 1
    assert count == n and np.isfinite(result).all()
    return result


def load(level, U=None):
    run = ROOT/"runtime/runs/final90f_cluster_gl4_all_h1_v1" if level == 1 else CAPTURE
    cluster = read(run/"triple_cluster.json")
    n = 729 if level == 1 else 6561
    assert cluster["actual_global_dofs"] == n and cluster["actual_form"] == "Sym"
    if U is None: U = np.zeros(n)
    arms = []
    for item in sorted(cluster["arms"], key=lambda x: int(x["handle"], 16)):
        owner = int(item["handle"], 16)
        path = run/f"input_audit/load_stage_geometry_{owner}.json"
        if level == 4:
            assert sha(path) == sha(ROOT/f"runtime/runs/final90f_cluster_gl4_all_h4_v1/input_audit/{path.name}")
        g = read(path); mapping = np.array(item["global_dofmap"], dtype=int)
        arms.append(core.Arm(owner, np.array(g["knots_u"]), np.array(g["knots_v"]), 3, 3,
            np.array(g["control_global_Vg"]), np.array(g["weights"]), g["E"], g["nu"], g["constant_t"], mapping, U[mapping]))
    selected = sorted((int(r["handle"], 16), tuple(core.OWNERS.index(int(x, 16)) for x in r["owners"]))
                      for r in cluster["relations"] if r["selected_penalty"])
    betas = {pair: float(beta) for (_, pair), beta in zip(selected, cluster["selected_beta"])}
    packet = PREP/("all_h1_complete_physical_weak_dual_v2" if level == 1 else "all_h4_complete_physical_sparse_packet_v2")
    bulk = sparse.load_npz(bind(packet/"independent_Kb.npz"))
    return run, cluster, arms, betas, packet, bulk


def global_rows(local, mapping, n):
    rr, cc = np.nonzero(local)
    return sparse.coo_matrix((local[rr, cc], (rr, mapping[cc])), shape=(6, n)).tocsr()


def scatter(local, mapping, n):
    x = local.tocoo()
    return sparse.coo_matrix((x.data, (mapping[x.row], mapping[x.col])), shape=(n, n)).tocsr()


def memory():
    import psutil
    return psutil.Process().memory_info()._asdict()
