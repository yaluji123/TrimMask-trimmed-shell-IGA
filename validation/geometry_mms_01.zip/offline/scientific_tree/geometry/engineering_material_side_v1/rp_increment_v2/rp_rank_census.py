"""Independent local RP sample census; never assembles/solves an MPC or K.
Count/rank refers to observed local trace evaluation, not whole-model rigidity.
"""
from pathlib import Path
from fractions import Fraction as F
import argparse,hashlib,json,math,sys
sys.dont_write_bytecode=True
import numpy as np
HERE=Path(__file__).resolve().parent
def q(x):
    if isinstance(x,bool)or not math.isfinite(float(x)):raise ValueError('invalid scalar')
    return F(str(x))
def basis(knots,p,n,t):
    K=list(map(q,knots));x=q(t)
    if len(K)!=n+p+1 or K!=sorted(K)or not(K[p]<=x<=K[n]):raise ValueError('basis domain/shape')
    B=[F(int(K[i]<=x<K[i+1]))for i in range(len(K)-1)]
    if x==K[n]:B=[F(int(i==n-1))for i in range(len(K)-1)]
    for d in range(1,p+1):
        B=[((x-K[i])*B[i]/(K[i+d]-K[i])if K[i+d]!=K[i]else F(0))+((K[i+d+1]-x)*B[i+1]/(K[i+d+1]-K[i+1])if K[i+d+1]!=K[i+1]else F(0))for i in range(len(K)-d-1)]
    return B[:n]
def value_basis(g,uv):
    m=int(g['controls_u']);n=int(g['controls_v']);U=basis(g['knots_u'],g['degree_u'],m,uv[0]);V=basis(g['knots_v'],g['degree_v'],n,uv[1]);W=list(map(q,g['weights']))
    a=[U[i]*V[j]*W[i*n+j]for i in range(m)for j in range(n)];den=sum(a)
    if den==0:raise ValueError('zero rational denominator')
    return[a/den for a in a]
def edge_candidates(g,uv,tolerant=False):
    u,v=map(q,uv);U=list(map(q,g['knots_u']));V=list(map(q,g['knots_v']));p=g['degree_u'];r=g['degree_v'];m=g['controls_u'];n=g['controls_v'];u0,u1=U[p],U[m];v0,v1=V[r],V[n]
    tu=F('1e-10')*max(F(1),u1-u0)if tolerant else F(0);tv=F('1e-10')*max(F(1),v1-v0)if tolerant else F(0)
    return {e for e,d,tol in [(1,abs(v-v0),tv),(2,abs(u-u1),tu),(3,abs(v-v1),tv),(4,abs(u-u0),tu)]if d<=tol}
def singulars(A):
    if not A:return {'numeric_rank_relative1e_12':0,'singular_values':[]}
    sv=np.linalg.svd(np.array(A,dtype=float),compute_uv=False);return{'numeric_rank_relative1e_12':int(np.sum(sv>sv[0]*1e-12))if len(sv)and sv[0]>0 else 0,'singular_values':sv.tolist()}
def census(capture):
    rp=capture/'rp_collected_samples.json';data=json.loads(rp.read_text(encoding='utf-8-sig'))
    if not data.get('capture_complete')or data.get('original_sampling_unchanged')is not True or data.get('trace_augmentation_flag_present')is not False:raise ValueError('RP sample contract incomplete/changed')
    geos={int(g['shell_handle']):g for p in capture.glob('trim_geometry_*.json')for g in[json.loads(p.read_text(encoding='utf-8-sig'))]};reports=[];seen=0;basis_max=0.
    for group in data['groups']:
        if group['sample_count']!=len(group['samples']):raise ValueError('group sample count mismatch')
        owners={}
        for s in group['samples']:owners.setdefault(int(s['owner_shell_handle']),[]).append(s)
        for owner,samples in sorted(owners.items()):
            g=geos[owner];m=g['controls_u'];n=g['controls_v'];exact={1,2,3,4};near=set(exact);rows=[]
            for s in samples:
                exact&=edge_candidates(g,s['uv']);near&=edge_candidates(g,s['uv'],True);B=value_basis(g,s['uv']);rows.append(B);local=s.get('local_basis',{});seen+=1
                if local.get('status')=='native_value_basis_APIs_no_global_numbering':
                    entries=local['basis'];native={int(v['local_cp']):float(v['value'])for v in entries}
                    if len(native)!=len(entries)or any(not 0<=cp<m*n for cp in native):raise ValueError('bad native basis local CP')
                    delta=max(abs(float(B[i])-native.get(i,0.))for i in range(m*n));basis_max=max(basis_max,delta)
                    if delta>1e-12:raise ValueError('independent basis differs from Native snapshot')
                    if len(local.get('translation_rows',[]))!=3:raise ValueError('missing local translation rows')
                    for c,row in enumerate(local['translation_rows']):
                        if row['component_zero_based']!=c or len(row['coefficients'])!=len(entries):raise ValueError('symbolic row shape')
                        for v in row['coefficients']:
                            cp=int(v['local_cp'])
                            if v['local_symbolic_dof']!=3*cp+c or float(v['value'])!=native[cp]:raise ValueError('symbolic CP row mismatch')
            report={'group_id':group['group_id'],'owner_shell_handle':owner,'sample_rows':len(samples),'unique_uv_count':len({tuple(map(q,s['uv']))for s in samples}),'common_exact_carrier_edges':sorted(exact),'common_near_carrier_edges_tolerance1e_10':sorted(near),'sampling_rule_modified':False,'global_joint_or_RP_mechanical_equivalence_accepted':False}
            candidates=exact if len(exact)==1 else(near if len(near)==1 else set())
            if candidates:
                edge=next(iter(candidates));CP=([i*n+(0 if edge==1 else n-1)for i in range(m)]if edge in(1,3)else[(m-1 if edge==2 else 0)*n+j for j in range(n)])
                A=[[float(row[cp])for cp in CP]for row in rows];bound=min(len(samples),len(CP));report.update(edge=edge,trace_control_count=len(CP),trace_local_cp_indices=CP,exact_sample_count_rank_upper_bound=bound,trace_nullity_lower_bound_from_row_count=max(0,len(CP)-len(samples)),exact_boundary_trace_subspace_observed=len(exact)==1,numeric_trace_projection=singulars(A),interpretation=('exact boundary trace sampled at fewer independent locations than trace CP: local evaluation cannot constrain the whole trace'if len(exact)==1 and len(samples)<len(CP)else'count/rank report only; no full-trace or whole-model conclusion'))
            else:report.update(status='NO_UNIQUE_COMMON_CARRIER_EDGE_UNSUPPORTED_FOR_TRACE_RANK',exact_sample_count_rank_upper_bound=min(len(samples),m*n))
            reports.append(report)
    if seen!=data['actual_sample_count']:raise ValueError('total sample count mismatch')
    return{'schema':'oe-local-rp-rank-census-v2','scope':'actual local sample/value trace only; no global constraint assembly or engineering acceptance','RP_file_sha256':hashlib.sha256(rp.read_bytes()).hexdigest(),'actual_samples_observed':seen,'independent_Native_value_basis_max_abs_difference':basis_max,'reports':reports,'global_RP_rank_or_rigidity_claimed':False,'RPsampling_modified':False}
def selftest():
    K=[0]*4+[i/40 for i in range(1,40)]+[1]*4;n=43;p=3
    samples=[0,.25,.5,.75,1];A=[list(map(float,basis(K,p,n,t)))for t in samples]
    assert singulars(A)['numeric_rank_relative1e_12']==5 and len(samples)<n
    assert all(sum(basis(K,p,n,t))==1 for t in samples)
    greville=[float(sum(map(q,K[i+1:i+4]))/3)for i in range(n)]
    full=singulars([list(map(float,basis(K,p,n,t)))for t in greville]);assert full['numeric_rank_relative1e_12']==43
    return{'status':'PASS_SYNTHETIC_RANK_COMPONENT_ONLY','frozen_Native_hull_RP_observed':False,'five_rows_43_trace_columns_numeric_rank':5,'sample_count_nullity_lower_bound':38,'Greville43_synthetic_rank':43,'RPsampling_changed_or_new_option_adopted':False}
def main():
    a=argparse.ArgumentParser(description=__doc__);a.add_argument('--capture',type=Path);a.add_argument('--out',type=Path,required=True);a.add_argument('--selftest',action='store_true');args=a.parse_args();assert not args.out.exists(),'output collision'
    result=selftest()if args.selftest else census(args.capture);args.out.parent.mkdir(parents=True,exist_ok=True);args.out.write_text(json.dumps(result,indent=2),encoding='utf-8');print(json.dumps({'status':result.get('status','ACTUAL_LOCAL_CENSUS_ONLY'),'output':str(args.out)}))
if __name__=='__main__':main()
