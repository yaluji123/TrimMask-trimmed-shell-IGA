"""Independent, exactly integrated quadratic plane-stress triangles."""
from pathlib import Path
import json,argparse,hashlib,time
import numpy as np
from scipy.sparse import coo_matrix
from scipy.sparse.linalg import spsolve
import independent_triangle_cst as linear
HERE=Path(__file__).resolve().parent;ROOT=linear.ROOT
HELPER_SHA='5cfd200a0002bd025bbf534010bd5081e7d9fddc9bce7fbd91896884ea3345ad'
assert hashlib.sha256((HERE/'independent_triangle_cst.py').read_bytes()).hexdigest()==HELPER_SHA
GAUSS=np.array([[2/3,1/6,1/6],[1/6,2/3,1/6],[1/6,1/6,2/3]])
def mesh(N,vertices):
 x,t,pairs,offset=linear.mesh(N,vertices,1);base=len(x);edges=np.sort(np.concatenate([t[:,[0,1]],t[:,[1,2]],t[:,[2,0]]]),axis=1);unique,inverse=np.unique(edges,axis=0,return_inverse=True)
 conn=np.column_stack([t,base+inverse[:len(t)],base+inverse[len(t):2*len(t)],base+inverse[2*len(t):]])
 x=np.vstack([x,x[unique].mean(1)]);uv=np.vstack([pairs/N,(pairs[unique]/N).mean(1)]);lookup={tuple(e):base+i for i,e in enumerate(unique)}
 left=[int(z)for z in offset];right=[int(offset[j]+N-j)for j in range(N+1)];bottom=list(range(N+1))
 boundary=[]
 for line in [bottom,right,list(reversed(left))]:
  for a,b in zip(line[:-1],line[1:]):boundary.append((a,b,lookup[tuple(sorted([a,b]))]))
 loaded=[(a,b,lookup[tuple(sorted([a,b]))])for a,b in zip(left[:-1],left[1:])]
 return x,conn,uv,boundary,loaded
def basis(L):return np.r_[L*(2*L-1),4*L[0]*L[1],4*L[1]*L[2],4*L[2]*L[0]]
def geometry(x,conn):
 p=x[conn[:,:3]];a2=np.cross(p[:,1]-p[:,0],p[:,2]-p[:,0]);assert np.all(a2>0)
 b=np.column_stack([p[:,1,1]-p[:,2,1],p[:,2,1]-p[:,0,1],p[:,0,1]-p[:,1,1]])/a2[:,None];c=np.column_stack([p[:,2,0]-p[:,1,0],p[:,0,0]-p[:,2,0],p[:,1,0]-p[:,0,0]])/a2[:,None]
 return a2/2,np.stack([b,c],axis=2)
def assemble(x,conn,E=206000.,nu=.3,t=7.):
 area,grad=geometry(x,conn);D=E/(1-nu*nu)*np.array([[1,nu,0],[nu,1,0],[0,0,(1-nu)/2]]);ke=np.zeros((len(conn),12,12))
 for L in GAUSS:
  derivative=np.concatenate([(4*L-1)[None,:,None]*grad,np.stack([4*(L[0]*grad[:,1]+L[1]*grad[:,0]),4*(L[1]*grad[:,2]+L[2]*grad[:,1]),4*(L[2]*grad[:,0]+L[0]*grad[:,2])],axis=1)],axis=1)
  B=np.zeros((len(conn),3,12));B[:,0,::2]=derivative[:,:,0];B[:,1,1::2]=derivative[:,:,1];B[:,2,::2]=derivative[:,:,1];B[:,2,1::2]=derivative[:,:,0]
  ke+=np.einsum('eji,jk,ekl,e->eil',B,D,B,area*t/3,optimize=True)
 dof=(2*conn[:,:,None]+np.arange(2)).reshape(-1,12);r=np.repeat(dof,12,axis=1).ravel();c=np.tile(dof,(1,12)).ravel();return coo_matrix((ke.ravel(),(r,c)),shape=(2*len(x),2*len(x))).tocsr(),area
def self_check():
 v=np.array([[0.,0.],[2.,0.],[.4,1.2]]);x,conn,uv,boundary,_=mesh(4,v);K,area=assemble(x,conn);assert abs(area.sum()-1.2)<1e-14
 for u in [np.tile([1.,0.],len(x)),np.tile([0.,1.],len(x)),np.column_stack([-x[:,1],x[:,0]]).ravel()]:assert np.linalg.norm(K@u)/(np.linalg.norm(K.data)*np.linalg.norm(u))<1e-14
 epsilon=1e-4;E=206000.;nu=.3;t=7.;L0=2.;C=E/(1-nu**2);uExact=np.column_stack([epsilon*x[:,0]**2/L0,np.zeros(len(x))]).ravel();F=np.zeros(2*len(x));body=np.array([-C*2*epsilon/L0*t,0.])
 for L in GAUSS:
  local=area[:,None,None]/3*basis(L)[None,:,None]*body[None,None,:];np.add.at(F.reshape(-1,2),conn.ravel(),local.reshape(-1,2))
 z,w=np.polynomial.legendre.leggauss(3)
 for a,b,mid in boundary:
  tangent=x[b]-x[a];length=np.linalg.norm(tangent);normal=np.array([tangent[1],-tangent[0]])/length
  for q,weight in zip(z,w):
   s=(q+1)/2;point=x[a]+s*tangent;sig=C*2*epsilon*point[0]/L0*np.diag([1.,nu]);traction=t*sig@normal;N=np.array([(1-s)*(1-2*s),s*(2*s-1),4*s*(1-s)])
   for node,n in zip([a,b,mid],N):F[2*node:2*node+2]+=length*.5*weight*n*traction
 fixed=np.repeat(uv[:,1]==0,2);u=uExact.copy();free=~fixed;u[free]=spsolve(K[free][:,free],F[free]-K[free][:,fixed]@u[fixed]);error=float(np.linalg.norm(u-uExact)/np.linalg.norm(uExact));assert error<1e-11
 return dict(rigid_modes_and_exact_area_pass=True,quadratic_continuous_body_and_traction_MMS_relative_error=error,F_not_formed_as_K_times_exact=True)
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--subdivisions',type=int,choices=[16,32,64,128,256,512,1024]);ap.add_argument('--output',type=Path);ap.add_argument('--self-check-only',action='store_true');a=ap.parse_args();control=self_check()
 if a.self_check_only:print(json.dumps(dict(status='PASS_P2_INDEPENDENT_QUADRATIC_MMS_AND_RIGID_CONTROLS',**control)));return
 assert a.subdivisions and a.output and not a.output.exists();a.output.mkdir();start=time.perf_counter();source=ROOT/'runtime/runs/triangle_final1211_as_stored_v1/capture/trim_geometry_806.json';g=json.loads(source.read_text());cp=np.array(g['control_global_Vg']).reshape(13,13,3);origin=cp[0,0,:2];J=np.column_stack([cp[-1,0,:2]-origin,cp[0,-1,:2]-origin]);vertices=np.array(g['outer_loop'])[[1,2,0]]@J.T
 loadSource=ROOT/'runtime/runs/triangle_final1x_stored_v2/input_audit/load_0_read_entity.json';ld=json.loads(loadSource.read_text());assert ld['owner_shell_handle']==806 and ld['stored_force_payload'][2:]==[0,0,0,0];traction=np.array(ld['stored_force_payload'][:2])*7.
 x,conn,uv,boundary,loaded=mesh(a.subdivisions,vertices);K,areas=assemble(x,conn);F=np.zeros(2*len(x))
 for aa,bb,mm in loaded:
  length=np.linalg.norm(x[bb]-x[aa]);F[2*aa:2*aa+2]+=length/6*traction;F[2*bb:2*bb+2]+=length/6*traction;F[2*mm:2*mm+2]+=length*2/3*traction
 fixed=np.repeat(uv[:,1]==0,2);free=~fixed;u=np.zeros(2*len(x));u[free]=spsolve(K[free][:,free],F[free]);residual=K@u-F;reaction=residual[fixed].reshape(-1,2).sum(0);force=F.reshape(-1,2).sum(0);balance=float(np.linalg.norm(force+reaction)/np.linalg.norm(force));res=float(np.linalg.norm(residual[free])/np.linalg.norm(F));energy=float(.5*u@(K@u));work=float(.5*u@F)
 moment=float(np.sum(x[:,0]*F[1::2]-x[:,1]*F[0::2]));rfull=residual.reshape(-1,2);reactionMoment=float(np.sum(x[fixed[::2],0]*rfull[fixed[::2],1]-x[fixed[::2],1]*rfull[fixed[::2],0]));mb=abs(moment+reactionMoment)/abs(moment)
 assert max(res,balance,mb,abs(energy-work)/abs(work))<1e-8;mag=np.linalg.norm(u.reshape(-1,2),axis=1);peak=int(mag.argmax())
 result=dict(status='PASS_INDEPENDENT_P2_LINEAR_MEMBRANE_LEVEL_ONLY_NOT_CONVERGENCE',subdivisions=a.subdivisions,nodes=len(x),triangles=len(conn),dofs=len(u),element='quadratic Lagrange 6-node triangle; shape-regular uniform family; 3-point exact degree2 stiffness integration',E=206000.,nu=.3,t=7.,traction_N_per_mm=traction.tolist(),area_mm2=float(areas.sum()),peak_U_mm=float(mag[peak]),peak_vector_mm=u.reshape(-1,2)[peak].tolist(),peak_location_mm=(x[peak]+origin).tolist(),material_energy_Nmm=energy,half_external_work_Nmm=work,free_residual_relative=res,force_balance_relative=balance,moment_balance_relative=mb,external_force_N=force.tolist(),reaction_N=reaction.tolist(),control=control,geometry_source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),load_source_sha256=hashlib.sha256(loadSource.read_bytes()).hexdigest(),source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),helper_source_sha256=HELPER_SHA,planar_KL_in_plane_membrane_subproblem_only=True,wall_seconds=time.perf_counter()-start,convergence_not_established_by_one_level=True)
 np.savez_compressed(a.output/'mesh_and_state.npz',points=x,origin=origin,triangles=conn,U=u.reshape(-1,2),F=F.reshape(-1,2),vertices=vertices);(a.output/'results.json').write_text(json.dumps(result,indent=2),encoding='utf-8');print(json.dumps(result))
if __name__=='__main__':main()
