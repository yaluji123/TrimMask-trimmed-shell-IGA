"""Original matched-edge extraction and saved line arithmetic."""
import math

def edge_curve(g,edge):
    m,n=g['controls_u'],g['controls_v'];v=g['control_global_Vg'];P=[v[i:i+3]for i in range(0,len(v),3)]
    if edge in (1,3):ids=[i*n+(0 if edge==1 else n-1)for i in range(m)];p=g['degree_u'];K=g['knots_u']
    elif edge in(2,4):ids=[(m-1 if edge==2 else 0)*n+j for j in range(n)];p=g['degree_v'];K=g['knots_v']
    else:raise ValueError('actual matched edge not1..4')
    return dict(degree=p,knots=K,control_global_xyz=[P[i]for i in ids],weights=[1]*len(ids),rational=False,extraction_complete=True)


def replay_line_errors(aa, bb, tt, ds, curve):
    denominator = math.sqrt(sum((float((curve.P[-1][j] - curve.P[0][j]) * (bb - aa) / (curve.hi - curve.lo)) ** 2 for j in range(3))))
    old_errors = []
    for k in range(8):
        value = math.fsum((float(ds[i]) / denominator * ((float(tt[i]) - float(aa)) / (float(bb) - float(aa))) ** k for i in range(4)))
        old_errors.append(abs(value - 1 / (k + 1)) / (1 / (k + 1)))
    return old_errors
