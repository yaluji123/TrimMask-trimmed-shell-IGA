"""Reconstruct the captured 729-DOF baseline before any alpha sensitivity solve."""
from pathlib import Path
import csv
import hashlib
import importlib.util
import json
import sys
import traceback
sys.dont_write_bytecode = True
from resource_guard import install, actual_budget

D = Path(__file__).resolve().parents[1]
ROOT = D.parents[1]
PREP = ROOT/"runtime/preparation/triple_point_completion_20261107_v7b"
RUN = ROOT/"runtime/runs/final90f_cluster_gl4_all_h1_v1"
OUT = D/"baseline_210_v1"
OUT.mkdir(exist_ok=False)
resources = install()
resources["preflight"] = actual_budget(729, 59921)
(OUT/"resource_preflight.json").write_text(json.dumps(resources, indent=2)+"\n")
import numpy as np
from scipy import sparse, linalg
from scipy.sparse.linalg import splu

inputs = {}


def bind(path):
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    inputs[str(path)] = digest
    return path


def read(path):
    return json.loads(bind(path).read_text(encoding="utf-8-sig"))


def matrix_csv(path, n):
    rr, cc, vv, seen = [], [], [], set()
    with bind(path).open(encoding="utf-8-sig") as stream:
        for row in csv.reader(stream):
            if row[0].startswith(("global_", "local_")):
                continue
            i, j, v = int(row[0]), int(row[1]), float(row[2])
            assert 0 <= i < n and 0 <= j < n and np.isfinite(v) and (i, j) not in seen
            seen.add((i, j))
            rr.append(i); cc.append(j); vv.append(v)
    return sparse.coo_matrix((vv, (rr, cc)), shape=(n, n)).tocsr()


def vector_csv(path, n):
    with bind(path).open(encoding="utf-8-sig") as stream:
        rows = list(csv.reader(stream))[1:]
    assert len(rows) == n and [int(r[0]) for r in rows] == list(range(n))
    return np.array([float(r[-1]) for r in rows])


def norm(a):
    return float(np.linalg.norm(a.data)) if sparse.issparse(a) else float(np.linalg.norm(a))


def scatter(local, mapping, n=729):
    local = sparse.coo_matrix(local)
    return sparse.coo_matrix((local.data, (mapping[local.row], mapping[local.col])),
                             shape=(n, n)).tocsr()


def rows_global(local, mapping):
    row, col = np.nonzero(local)
    return sparse.coo_matrix((local[row, col], (row, mapping[col])), shape=(6, 729)).tocsr()


result = {"status": "BASELINE_NOT_QUALIFIED", "resources": resources,
          "actual_N_V_rows_exported": False,
          "row_reconstruction": "Frozen physical formulas at actual Native carrier-integration points; no fitted scalar or matrix correction."}
try:
    protocol = read(D/"CONTROL_PROTOCOL.json")
    freeze = read(D/"EXISTING_DATA_FREEZE.json")
    for entry in freeze["upstream_scientific_sources"]:
        assert hashlib.sha256(Path(entry["path"]).read_bytes()).hexdigest() == entry["sha256"]
    source = bind(PREP/"independent_readers_v7/cluster_physical_core.py")
    spec = importlib.util.spec_from_file_location("frozen_physical_core", source)
    core = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = core
    spec.loader.exec_module(core)
    cluster = read(RUN/"triple_cluster.json")
    assert cluster["actual_global_dofs"] == 729 and cluster["actual_form"] == "Sym"
    scope = read(RUN/"input_audit/patch_order_operator_scope.json")
    assert scope["matrix_is_actual_solver_argument"] and scope["no_symmetrization_shift_or_regularization_by_exporter"]
    actual_K = matrix_csv(RUN/"input_audit/patch_order_global_K.csv", 729)
    actual_F = vector_csv(RUN/"input_audit/patch_order_global_F.csv", 729)
    actual_U = vector_csv(RUN/"input_audit/global_solution.csv", 729)
    external = vector_csv(RUN/"input_audit/pre_boundary_force.csv", 729)
    assert np.array_equal(actual_F, external), "Actual F differs from unchanged external physical load"
    qualifier = read(PREP/"cluster_gl4_all_h1_actual_K_qualification_v1/actual_coarse_point_qualification.json")
    assert qualifier["actual_run"] == str(RUN)
    coefficient_budget = qualifier["actual_Native_vs_independent_solve"]["coefficient_budget"]
    backward_budget = qualifier["actual_Native_vs_independent_solve"]["backward_budget"]
    assert coefficient_budget == protocol["baseline_gates"]["actual_Native_vs_independent_U_relative"]
    assert backward_budget == protocol["baseline_gates"]["normwise_backward_error"]
    bulk = sparse.load_npz(bind(PREP/"all_h1_complete_physical_weak_dual_v2/independent_Kb.npz"))
    arms = []
    for entry in sorted(cluster["arms"], key=lambda x: int(x["handle"], 16)):
        owner = int(entry["handle"], 16)
        geo = read(RUN/f"input_audit/load_stage_geometry_{owner}.json")
        mapping = np.array(entry["global_dofmap"], dtype=int)
        arms.append(core.Arm(owner, np.array(geo["knots_u"]), np.array(geo["knots_v"]),
                             geo["degree_u"], geo["degree_v"], np.array(geo["control_global_Vg"]),
                             np.array(geo["weights"]), geo["E"], geo["nu"], geo["constant_t"],
                             mapping, actual_U[mapping]))
    assert [a.handle for a in arms] == list(core.OWNERS)
    events = [json.loads(line) for line in bind(RUN/"boundary_domain_probe.jsonl").read_text(encoding="utf-8-sig").splitlines()]
    snapshots = [e for e in events if e["event"] == "apply_snapshot"]
    assert len(snapshots) == 1
    boundary = snapshots[0]
    assert boundary["surface"] == arms[0].handle and boundary["gauss"] == 4
    assert boundary["active_components"] == [True]*6 and boundary["prescribed_global"] == [0]*6
    purpose = None
    points = []
    for e in events:
        if e["event"] == "probe_purpose":
            purpose = e["purpose"]
        elif e["event"] == "point_probe" and purpose == "carrier_integration":
            assert e["surface"] == arms[0].handle and e["uv"][0] == 0.
            assert e["physical_line_weight"] > 0
            points.append(e)
    assert len(points) == 24
    A = np.zeros((243, 243)); C = A.copy(); P = A.copy()
    observations = []
    for e in points:
        u, v = e["uv"]
        op = arms[0].operators(u, v, mu=-arms[0].t, ell=1.)
        N = np.vstack([op["U"], op["theta"]])
        V = np.vstack([op["T"], op["m"]])
        w = e["physical_line_weight"]
        A += w*(V.T@V)
        C += w*(V.T@N)
        P += w*(N.T@N)
        observations.append({"u": u, "v": v, "weight_ds_mm": w,
                             "N": N, "V": V})
    assert abs(sum(p["weight_ds_mm"] for p in observations)-60.) < 1e-10
    active = np.flatnonzero(np.any(A != 0., axis=0) | np.any(A != 0., axis=1)
                            | np.any(P != 0., axis=0) | np.any(P != 0., axis=1))
    raw_k = bulk[arms[0].dofmap, :][:, arms[0].dofmap][active, :][:, active].toarray()
    raw_a = A[np.ix_(active, active)]
    tolerance = 100*np.finfo(float).eps*len(active)
    assert norm(raw_k-raw_k.T) <= tolerance*norm(raw_k)
    assert norm(raw_a-raw_a.T) <= tolerance*norm(raw_a)
    kval, ku = linalg.eigh((raw_k+raw_k.T)*.5)
    aval = linalg.eigvalsh((raw_a+raw_a.T)*.5)
    ktol = tolerance*max(abs(kval))
    atol = tolerance*max(abs(aval))
    assert kval[0] >= -ktol and aval[0] >= -atol
    zero = kval <= ktol
    if np.any(zero):
        assert norm(raw_a@ku[:, zero])/norm(raw_a) <= tolerance
    assert not np.all(zero)
    T = ku[:, ~zero]/np.sqrt(kval[~zero])
    pencil = T.T@raw_a@T
    lam = float(linalg.eigvalsh((pencil+pencil.T)*.5)[-1])
    assert lam > 0 and np.isfinite(lam)
    consistency_local = -C-C.T
    bc_local = consistency_local+210.*lam*P
    actual_bc_local = matrix_csv(RUN/"input_audit/boundary_delta_H_7867.csv", 243)
    bc_relative = norm(sparse.csr_matrix(bc_local)-actual_bc_local)/norm(actual_bc_local)
    result.update(boundary_lambda_reconstructed_without_fit=lam, boundary_active_columns=active.tolist(),
                  boundary_matrix_relative_Frobenius=bc_relative,
                  boundary_trace_points=len(points), boundary_length_mm=sum(p["weight_ds_mm"] for p in observations))
    # Retain a failed decomposition before the gate; never fit lambda from this difference.
    np.savez_compressed(OUT/"boundary_reconstruction.npz", A=A, C=C, P=P, lambda_principal=lam,
                        reconstructed_BC=bc_local, actual_BC=actual_bc_local.toarray(),
                        N=np.stack([p["N"] for p in observations]), V=np.stack([p["V"] for p in observations]),
                        uv=np.array([[p["u"], p["v"]] for p in observations]),
                        weight_ds=np.array([p["weight_ds_mm"] for p in observations]))
    assert bc_relative <= 1e-10, "Reconstructed boundary C/P/pencil does not match actual BC delta"
    for owner in core.OWNERS:
        assert np.array_equal(vector_csv(RUN/f"input_audit/boundary_delta_F_{owner}.csv", 243), np.zeros(243))
    selected = sorted((int(r["handle"], 16), tuple(core.OWNERS.index(int(x, 16)) for x in r["owners"]))
                      for r in cluster["relations"] if r["selected_penalty"])
    betas = {pair: float(beta) for (_, pair), beta in zip(selected, cluster["selected_beta"])}
    line = sparse.csr_matrix((729, 729))
    nodes, weights = np.polynomial.legendre.leggauss(4)
    cuts = core.unique_cuts(arms)
    for a, b in zip(cuts[:-1], cuts[1:]):
        for x, w in zip(nodes, weights):
            u = (a+b)*.5+(b-a)*x*.5
            ds = 100.*(b-a)*w*.5
            op = [arm.operators(u, 0., ell=1.) for arm in arms]
            Ns = [rows_global(o["N"], arm.dofmap) for o, arm in zip(op, arms)]
            Vs = [rows_global(o["V"], arm.dofmap) for o, arm in zip(op, arms)]
            for i in range(3):
                for j in range(3):
                    block = Ns[i].T@Vs[j]*(ds*((1. if i == j else 0.)-1/3))
                    line += block+block.T
            for (i, j), beta in betas.items():
                jump = Ns[i]-Ns[j]
                line += ds*beta*(jump.T@jump)
    natural = matrix_csv(RUN/"input_audit/triple_point_natural_b.csv", 729)
    essential_a = matrix_csv(RUN/"input_audit/triple_point_essential_a.csv", 729)
    essential_far = matrix_csv(RUN/"input_audit/triple_point_essential_far.csv", 729)
    bc = scatter(bc_local, arms[0].dofmap)
    reconstructed = bulk+line+natural+essential_a+essential_far+bc
    matrix_relative = norm(reconstructed-actual_K)/norm(actual_K)
    result["full_K_relative_Frobenius"] = matrix_relative
    assert matrix_relative <= 1e-10, "Full independently reconstructed K does not match actual K"
    factor = splu(reconstructed.tocsc())
    state = factor.solve(actual_F)
    coefficient_relative = norm(state-actual_U)/norm(actual_U)
    backward = norm(reconstructed@state-actual_F)/(norm(reconstructed)*norm(state)+norm(actual_F))
    result.update(coefficient_relative_to_actual_U=coefficient_relative,
                  original_coefficient_budget=coefficient_budget, normwise_backward_error=backward,
                  original_backward_budget=backward_budget, actual_F_exact_unchanged=True)
    assert coefficient_relative <= coefficient_budget and backward <= backward_budget
    for name, matrix in {"actual_K": actual_K, "reconstructed_K": reconstructed,
                         "Kbulk": bulk, "Kline": line, "Knatural_b": natural,
                         "Kessential_a": essential_a, "Kessential_far": essential_far,
                         "KBC_consistency": scatter(consistency_local, arms[0].dofmap),
                         "KBC_P": scatter(P, arms[0].dofmap)}.items():
        sparse.save_npz(OUT/(name+".npz"), matrix)
    np.savez_compressed(OUT/"state_and_scalar.npz", actual_F=actual_F, actual_U=actual_U,
                        reconstructed_U=state, lambda_BC=lam)
    result["status"] = "QUALIFIED_RECONSTRUCTED_BASELINE_WITHIN_ORIGINAL_GATES"
    result["controls_may_proceed_only_with_this_source_and_output_hashes"] = True
except Exception as error:
    result["failure"] = str(error)
    result["traceback"] = traceback.format_exc()
finally:
    result["input_sha256"] = inputs
    result["source_sha256"] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    result["control_protocol_sha256"] = hashlib.sha256((D/"CONTROL_PROTOCOL.json").read_bytes()).hexdigest()
    for path, digest in inputs.items():
        assert hashlib.sha256(Path(path).read_bytes()).hexdigest() == digest
    (OUT/"results.json").write_text(json.dumps(result, indent=2)+"\n", encoding="utf-8")
    print(json.dumps({key: value for key, value in result.items() if key not in ("input_sha256", "traceback", "boundary_active_columns")}, indent=2))
if result["status"] != "QUALIFIED_RECONSTRUCTED_BASELINE_WITHIN_ORIGINAL_GATES":
    raise SystemExit(2)
