from pathlib import Path
import sys
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(S/"sources"))
from resource_guard import install
sys.path.insert(0, str(S/"fine_offline_control_preparation_v1"))
from fine_sparse_budget_v1 import state_factor_budget, riesz_factor_budget


def start(riesz=False):
    resources = install()
    if not resources["OS_memory_job_installed"]:
        raise RuntimeError("Actual 512MiB process Job required")
    resources["preflight"] = riesz_factor_budget(584782) if riesz else state_factor_budget(630793)
    return resources
