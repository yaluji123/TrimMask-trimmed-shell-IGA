import numpy as np
def estimate(values):
 a,b,c=map(float,values[-3:]);d0=b-a;d1=c-b
 if d0*d1<=0 or not d1:return dict(monotone=False,estimated_relative_error=None)
 p=float(np.log2(abs(d0/d1)));estimate=abs(d1)/(2**p-1)/abs(c)if p>0 else None
 return dict(monotone=True,observed_order=p,extrapolated_limit=c+d1/(2**p-1)if p>0 else None,estimated_relative_error=estimate,safety_multiplier=1.25,estimated_relative_with_safety=1.25*estimate if estimate is not None else None,not_rigorous_error_bound=True)
