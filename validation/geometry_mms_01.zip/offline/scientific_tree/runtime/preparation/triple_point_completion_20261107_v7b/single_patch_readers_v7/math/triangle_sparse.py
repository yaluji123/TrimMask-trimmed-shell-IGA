from pathlib import Path
import json,csv,sys,hashlib
import numpy as np
from scipy.sparse import csr_matrix,coo_matrix,diags
from scipy.sparse.linalg import norm,spsolve,eigsh
ROOT=Path(r'D:\BaiduSyncdisk\CODEX\投稿\二次修稿\准备工作');HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'mechanics'))
import run_mechanics_checks as core
from sparse_spd_extremes import extremes
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def matrix(p,n):
 a=np.loadtxt(p,delimiter=',',skiprows=1,ndmin=2);return coo_matrix((a[:,2],(a[:,0].astype(int),a[:,1].astype(int))),shape=(n,n)).tocsr()
def packed(rows,n):
 a=np.asarray(rows);return coo_matrix((a[:,2],(a[:,0].astype(int),a[:,1].astype(int))),shape=(6,n)).tocsr()if len(a)else csr_matrix((6,n))
def rel(a,b):return float(norm(a-b)/max(norm(b),np.finfo(float).tiny))
def run(case,out):
 assert not out.exists();out.mkdir(parents=True)
 g=read(case/'capture/trim_geometry_806.json');m,n=g['controls_u'],g['controls_v'];nd=3*m*n;cp=np.array(g['control_global_Vg']).reshape(m,n,3)
 J=np.column_stack([cp[-1,0]-cp[0,0],cp[0,-1]-cp[0,0]]);B=np.linalg.inv(J[:2]);normal=np.cross(J[:,0],J[:,1]);normal/=np.linalg.norm(normal);assert np.linalg.norm(normal-[0,0,1])<1e-12
 events=[json.loads(line)for line in(case/'boundary_domain_probe.jsonl').read_text().splitlines()];parts=[r for r in events if r['event']=='registered_trace_partition'];points=[r for r in events if r['event']=='registered_trace_point'];pencils=[r for r in events if r['event']=='registered_trace_pencil'];assert len(parts)==len(pencils)==1 and points
 ku=np.array(g['knots_u']);kv=np.array(g['knots_v'])
 def rows(u,v,nx,ny):
  from math import comb
  bu=core.basis(u,ku);bv=core.basis(v,kv)
  def d(x,y):
   a=np.zeros(m*n)
   for i in range(x+1):
    for j in range(y+1):a+=comb(x,i)*comb(y,j)*B[0,0]**i*B[1,0]**(x-i)*B[0,1]**j*B[1,1]**(y-j)*np.outer(bu[i+j],bv[x+y-i-j]).ravel()
   return a
  dd={(x,y):d(x,y)for x,y in[(0,0),(1,0),(0,1),(2,0),(1,1),(0,2),(3,0),(2,1),(1,2),(0,3)]}
  return map(csr_matrix,core.operators(dd,nx,ny,206000.,7.,.3,False))
 A=csr_matrix((nd,nd));C=A.copy();P=A.copy();Ai=A.copy();Ci=A.copy();Pi=A.copy();errN=errV=0.;pointdata=[]
 for r in points:
  N=packed(r['getter_N'],nd);V=packed(r['getter_V'],nd);w=r['weight_ds'];sign=r['outward_sign'];assert r['ell']==1.
  a,b=next((np.array(x['a']),np.array(x['b']))for x in parts[0]['intervals']if x['active']and x['a'][0]<r['u']<x['b'][0]);tangent=J@(b-a);tangent/=np.linalg.norm(tangent);left=np.cross(normal,tangent);Ni,Vi=rows(r['u'],r['v'],*left[:2]);errN=max(errN,rel(N,Ni));errV=max(errV,rel(V,Vi))
  Ns=N[:5];Vs=diags([sign]*3+[-sign]*2)@V[:5];Nis=Ni[:5];Vis=diags([sign]*3+[-sign]*2)@Vi[:5]
  A+=w*(Vs.T@Vs);C+=w*(Vs.T@Ns);P+=w*(Ns.T@Ns);Ai+=w*(Vis.T@Vis);Ci+=w*(Vis.T@Nis);Pi+=w*(Nis.T@Nis);pointdata.append((N,w))
 raw=matrix(case/'input_audit/raw_bulk_H_806.csv',nd);supported=matrix(case/'input_audit/supported_bulk_H_806.csv',nd);bc=matrix(case/'input_audit/boundary_delta_H_806.csv',nd);pencil=pencils[0];beta=pencil['alpha']*pencil['lambda_principal_metric'];bce=rel(-C-C.T+beta*P,bc);K=supported+bc
 with(case/'input_audit/boundary_action_local_806.csv').open(encoding='utf-8-sig',newline='')as f:local=list(csv.DictReader(f))
 assert len(local)==nd;u=np.zeros(nd);action=u.copy();F=u.copy()
 for r in local:i=3*int(r['local_cp'])+int(r['component']);u[i]=float(r['u_local_mm']);action[i]=float(r['aBC_N'])
 with(case/'input_audit/patch_external_806.csv').open(encoding='utf-8-sig',newline='')as f:
  for r in csv.DictReader(f):F[3*int(r['local_cp'])+int(r['component'])]=float(r['actual_patch_F_N'])
 assert np.all(K.diagonal()>0);D=diags(1/np.sqrt(K.diagonal()));S=D@K@D;sym=rel(S,S.T);S=(S+S.T)*.5
 low,vec,high,SPDchecks=extremes(S);eigres=float(np.linalg.norm(S@vec[:,0]-low[0]*vec[:,0]));u2=spsolve(K,F)
 cpflat=cp.reshape(-1,3);force=F.reshape(-1,3).sum(0);reaction=-action.reshape(-1,3).sum(0);moment=np.cross(cpflat,F.reshape(-1,3)).sum(0);reactionMoment=-np.cross(cpflat,action.reshape(-1,3)).sum(0)
 forceError=float(np.linalg.norm(force+reaction)/np.linalg.norm(force));momentError=float(np.linalg.norm(moment+reactionMoment)/np.linalg.norm(moment));res=float(np.linalg.norm(K@u-F)/np.linalg.norm(F));ue=float(np.linalg.norm(u-u2)/np.linalg.norm(u2))
 with(case/'derived_work/displacement_samples.csv').open(encoding='utf-8-sig',newline='')as f:samples=list(csv.DictReader(f))
 peak=max(samples,key=lambda r:float(r['umag']));measure=sum(w for _,w in pointdata);boundary=np.sqrt(sum(w*(N@u)**2 for N,w in pointdata)/measure)
 energy=float(.5*u@(raw@u));halfwork=float(.5*u@F)
 result=dict(status='PASS_TRIANGLE_H_FAMILY_NATIVE_AND_INDEPENDENT_OPERATOR_ONLY',case=str(case),dofs=nd,controls=[m,n],points=len(points),gauss_order=parts[0]['gauss_order'],maximum_actual_curve_gap_mm=pencil['maximum_original_curve_gap_mm'],max_getter_relative_error=dict(N=errN,V=errV),integrated_independent_relative_errors=dict(A=rel(A,Ai),C=rel(C,Ci),P=rel(P,Pi)),actual_BC_delta_operator_error=bce,actual_raw_and_supported_bulk_both_captured=True,system_residual=res,independent_solve_relative=ue,equilibrated_min_eigenvalue=float(low[0]),equilibrated_condition2=float(high[0]/low[0]),scaled_eigenpair_residual=eigres,scaled_symmetry_relative=sym,material_energy_Nmm=energy,half_external_work_Nmm=halfwork,material_energy_minus_work_relative=abs(energy-halfwork)/abs(halfwork),external_force_N=force.tolist(),reaction_N=reaction.tolist(),force_balance_relative=forceError,moment_balance_relative=momentError,boundary_component_RMS=boundary.tolist(),peak_displacement_mm=float(peak['umag']),peak_location_mm=[float(peak[k])for k in ('x','y','z')],peak_vector_mm=[float(peak[k])for k in ('ux','uy','uz')],FEM_or_mesh_accuracy_accepted=False,reader_source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
 result['SPD_factor_checks']=SPDchecks;result['SPD_method_qualification_sha256']='09f4ddec39d4498cd497a04509f2da7aab424b304db6fa5397d30e32b0522fe4'
 assert max(errN,errV)<1e-8 and max(result['integrated_independent_relative_errors'].values())<1e-8 and bce<1e-10
 assert res<1e-8 and ue<1e-6 and low[0]>1e-8 and eigres<1e-8 and sym<1e-10 and max(forceError,momentError)<1e-5
 (out/'results.json').write_text(json.dumps(result,indent=2),encoding='utf-8');np.savez_compressed(out/'state.npz',U=u,F=F,cp=cpflat,J=J,knots_u=ku,knots_v=kv)
 print(json.dumps(result))
if __name__=='__main__':raise SystemExit('Use read_single_patch_v7.py strict current identity')
