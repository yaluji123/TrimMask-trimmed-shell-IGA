"""Same immutable exact oracle, all nine completed profiles; frozen gates.
Only an aggregation adapter changes. No Host/compiler/solver or method adoption.
"""
from pathlib import Path
from fractions import Fraction as F
import os,sys,ast,json,csv,hashlib,math,re,time
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1';os.environ['MKL_NUM_THREADS']='1'
if hasattr(sys,'set_int_max_str_digits'):sys.set_int_max_str_digits(0)
HERE=Path('runtime/preparation/final_paper_cases_20261107_v1/current_public98_oracle');PREP=Path('投稿/二次修稿/准备工作');ORACLE=PREP/'mechanics/candidate/public98_energy_oracle_v1'
sys.path.insert(0,str(ORACLE))
import numpy as np
from exact_cell_polynomial import *
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
frozen=json.loads((ORACLE/'FIRST_ORACLE_FROZEN.json').read_text())
for name,info in frozen['files'].items():
    if sha(ORACLE/name)!=info['sha256']:raise RuntimeError('first oracle immutable file mismatch: '+name)
PROTOCOL=HERE/'clean_timing_comparison_protocol_predata_v2.json'
if sha(PROTOCOL)!='78504c401985bb4953328081c2c71a1ee4f495d19f567d767e1753d644086250':raise RuntimeError('pre-data gates changed')
protocol=json.loads(PROTOCOL.read_text());OUT=HERE/'actual_results'

GEOM_SHA='19fbf71b05130aedc741d5117f2cab829bfd09f2ec7be185ba099a1089d89b5b'
# Reuse only the two pure reader/report definitions from the frozen runner.
# Importing its top level would attempt a second actual run/output overwrite.
tree=ast.parse((ORACLE/'run_actual_oracle.py').read_text());functions=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in ('load_case','exact_report')]
if len(functions)!=2:raise RuntimeError('frozen reader definition contract')
# Only the producer's declared natural-exit metadata key changes; all math is frozen.
class NaturalOwnedExitABI(ast.NodeTransformer):
    def visit_Constant(self,node):
        if node.value=='natural_exit':return ast.copy_location(ast.Constant(value='natural_owned_child_exit'),node)
        return node
functions=[NaturalOwnedExitABI().visit(n) if n.name=='load_case' else n for n in functions]
exec(compile(ast.fix_missing_locations(ast.Module(body=functions,type_ignores=[])),str(ORACLE/'run_actual_oracle.py')+'[pure_defs_current_ABI]','exec'),globals())

def vector(path,n):
    with path.open(encoding='utf-8-sig',newline='') as f:
        reader=csv.DictReader(f)
        if reader.fieldnames!=['global_dof_zero_based','value']:raise RuntimeError('force vector schema')
        rows=list(reader)
    if len(rows)!=n:raise RuntimeError('force dimension')
    out=np.zeros(n);seen=set()
    for row in rows:
        i=int(row['global_dof_zero_based']);v=float(row['value'])
        if i in seen or not 0<=i<n or not np.isfinite(v):raise RuntimeError('force entry')
        seen.add(i);out[i]=v
    return out
def boundary_descriptor(run):
    values=[]
    for line in (run/'boundary_domain_probe.jsonl').open(encoding='utf-8-sig'):
        x=json.loads(line)
        if x.get('event')=='apply_snapshot':
            keys=['surface','declared_owner','declared_edge','api_edge','gauss','E','nu','thickness','prescribed_global','active_components','carrier','surface_L3_global_to_local']
            values.append({k:x[k] for k in keys})
    metadata=json.loads((run/'input_audit/boundary_action_metadata.json').read_text())
    return dict(physical_boundary_snapshots=values,methods=[dict(owner=x['shell_handle'],method=x['boundary_method_enum']) for x in metadata['patches']])

def run(index,OUT,context):
 from single_patch_context_v7 import METHODS
 NAMES=[]
 for method in METHODS:
  entry=index['public_profiles'][method];case=context.case(entry,'quadrature',method,False);NAMES.append(case.name)
 started=time.perf_counter();cases=[load_case(name) for name in NAMES];ref=cases[0];g=ref['g'];n=len(ref['globalU'])
 for case in cases:
     if sha(case['run']/'source_runtime_manifest.json')!='50999199bb7bf6770b7446beae7c5e2600294276d6ba858ab7a616f873bf5a84' or case['runtime']['actual_source_binding_sha256']!='90f72156bd9f1430e25177e91b6a69b89c4434f81934dfdee19b20eef2a96566' or case['runtime']['actual_source_count']!=1212:raise RuntimeError('final complete-pair identity')
 referenceF=vector(ref['run']/'input_audit/pre_boundary_force.csv',n);referenceFlocal=referenceF[ref['mapping']]
 bcReference=boundary_descriptor(ref['run']);identity=[]
 for case in cases:
     geometry_same=all(case['g'][k]==g[k] for k in ['knots_u','knots_v','weights','control_global_Vg','E','nu','constant_t','isVarThk'])
     samebinary=case['runtime']['runtime'][0]['sha256']==ref['runtime']['runtime'][0]['sha256']
     if not geometry_same or not samebinary:raise RuntimeError('different actual geometry/material or binary')
     forcepath=case['run']/'input_audit/pre_boundary_force.csv';fv=vector(forcepath,n);case['inputs'].append(forcepath)
     forceDifference=float(np.linalg.norm(fv[case['mapping']]-referenceFlocal)/np.linalg.norm(referenceFlocal))
     bc=boundary_descriptor(case['run']);bcsame=bc==bcReference
     case['inputs'] += [case['run']/'boundary_domain_probe.jsonl',case['run']/'input_audit/boundary_action_metadata.json']
     identity.append(dict(case=case['name'],same_binary=samebinary,same_geometry_material=geometry_same,
         actual_Node_map_same=np.array_equal(case['mapping'],ref['mapping']),direct_physical_key_force_relative_L2_difference=forceDifference,
         external_force_gate=forceDifference<=protocol['identity_gates']['actual_pure_external_F_relative_L2_tolerance'],
         same_observed_boundary_descriptor_and_method=bcsame,Native_support_mask_observed=False,
         actual_uz_exactly_zero=True,identity_gate=forceDifference<=protocol['identity_gates']['actual_pure_external_F_relative_L2_tolerance'] and bcsame))
 CACHE=PREP/'geometry/native98/energy_moments_tensor49_v1/cell_local_tensor49_moments.json'
 if sha(CACHE)!='5881337f23e501816d2b9458cde757924801297b245ad8145ca4ec6abb71fc94':raise RuntimeError('49moment cache drift')
 cache=json.loads(CACHE.read_text());powers=[tuple(x) for x in cache['powers']]
 if powers!=[(a,b) for a in range(7) for b in range(7)] or len(cache['cells'])!=1296:raise RuntimeError('49moment coverage')
 ku=g['knots_u'];kv=g['knots_v'];umap={(b.lo,b.hi):b for b in all_restrictions(ku,3)};vmap={(b.lo,b.hi):b for b in all_restrictions(kv,3)}
 controls,den=shared_binary_controls([c['localU'][:,:2].tolist() for c in cases])
 Lx=F(2000);Ly=F(800);J=Lx*Ly;E=Q(g['E']);nu=Q(g['nu']);t=Q(g['constant_t'])
 certificate=jacobian_perturbation_certificate(ref['cp'].tolist(),ku,kv,Lx,Ly);d=certificate['det_relative_bound']
 totals=[dict(E=F(0),S=F(0),B=F(0),dE=F(0),dS=F(0),dB=F(0)) for _ in cases]
 uvArea=F(0);rows=[]
 for step,cell in enumerate(sorted(cache['cells'],key=lambda x:x['element'])):
     b=list(map(F,cell['bounds_exact']));bu=umap[tuple(b[:2])];bv=vmap[tuple(b[2:])];area=F(cell['retainedUVArea_exact']);uvArea+=area
     if bu.width*bv.width!=F(cell['cellUVArea_exact']):raise RuntimeError('actual cell mismatch')
     if area==0:
         for case in cases:rows.append(dict(case=case['name'],element=cell['element'],reference_class='out',half_energy_N_mm=0.,difference_half_energy_N_mm=0.,difference_field_norm_squared_mm4=0.,geometry_difference_energy_bound_N_mm=0.))
         continue
     if cell['reference_class']=='in':moments={p:F(cell['cellUVArea_exact'])/((p[0]+1)*(p[1]+1)) for p in powers}
     elif cell['reference_class']=='cut':moments=dict(zip(powers,map(F,cell['moments_uv_weighted_exact'])))
     else:raise RuntimeError('bad nonempty class')
     M=MomentVector.fractions(moments)
     if moments[0,0]!=area:raise RuntimeError('M00 mismatch')
     referenceField=[restrict_field(bu,bv,controls[0],39,c,den) for c in (0,1)]
     for i,(case,control) in enumerate(zip(cases,controls)):
         field=referenceField if i==0 else [restrict_field(bu,bv,control,39,c,den) for c in (0,1)]
         delta=[field[c]-referenceField[c] for c in (0,1)];values=[]
         for U,V in [field,delta]:
             density,grad=membrane_half_density(U,V,Lx*bu.width,Ly*bv.width,E,nu,t);normpoly=displacement_squared(U,V)
             if density.maximum_degrees()[2]>10 or normpoly.maximum_degrees()[2]>12:raise RuntimeError('degree coverage')
             energy=J*M.integrate(density);norm2=J*M.integrate(normpoly)
             if energy<0 or norm2<0:raise RuntimeError('negative exact integral; no abs/clamp recovery')
             bound=membrane_geometry_energy_bound(grad,energy,area,Lx,Ly,E,nu,t,certificate);values.append((energy,norm2,bound))
         for keys,vals in [(('E','S','B'),values[0]),(('dE','dS','dB'),values[1])]:
             for key,val in zip(keys,vals):totals[i][key]+=val
         rows.append(dict(case=case['name'],element=cell['element'],reference_class=cell['reference_class'],half_energy_N_mm=float(values[0][0]),
             difference_half_energy_N_mm=float(values[1][0]),difference_field_norm_squared_mm4=float(values[1][1]),geometry_difference_energy_bound_N_mm=float(values[1][2])))
     if step%128==0:print(json.dumps(dict(event='nine_profile_oracle_progress',cells_completed=step+1,total=1296,elapsed_seconds=round(time.perf_counter()-started,2))),flush=True)
 E0=totals[0]['E'];S0=totals[0]['S'];B0=totals[0]['B'];A=J*uvArea
 if E0<=B0 or S0<=0:raise RuntimeError('reference normalization not certified positive')
 tolDisp=F(str(protocol['physical_accuracy_gates']['retained_displacement_relative_L2_upper_bound']))
 tolEnergy=F(str(protocol['physical_accuracy_gates']['material_energy_seminorm_relative_difference_upper_bound']))
 tolGap=F(str(protocol['physical_accuracy_gates']['independent_physical_half_energy_relative_gap_upper_bound']))
 summary=[]
 for i,(case,z,idgate) in enumerate(zip(cases,totals,identity)):
     disp2upper=z['dS']*(1+d)/(S0*(1-d));energy2upper=(z['dE']+z['dB'])/(E0-B0)
     gapupper=(abs(z['E']-E0)+z['B']+B0)/(E0-B0)
     gates=dict(retained_displacement_L2_upper=disp2upper<=tolDisp*tolDisp,energy_seminorm_upper=energy2upper<=tolEnergy*tolEnergy,
         independent_material_half_energy_gap_upper=gapupper<=tolGap,identity=idgate['identity_gate'])
     fieldDifference=case['localU']-ref['localU'];native=case['energies']['after_support_bulk_half_quadratic']
     summary.append(dict(case=case['name'],raw_control_coefficient_relative_L2=float(np.linalg.norm(fieldDifference)/np.linalg.norm(ref['localU'])),
         retained_physical_displacement_relative_L2=math.sqrt(float(z['dS']/S0)),retained_RMS_difference_mm=math.sqrt(float(z['dS']/A)),
         energy_seminorm_relative=math.sqrt(float(z['dE']/E0)),energy_seminorm_difference_sqrt_N_mm=math.sqrt(float(2*z['dE'])),
         independent_material_half_energy_N_mm=float(z['E']),difference_half_energy_N_mm=float(z['dE']),
         geometry_material_energy_abs_bound_N_mm=float(z['B']),geometry_difference_energy_abs_bound_N_mm=float(z['dB']),
         independent_material_half_energy_relative_gap=float((z['E']-E0)/E0),
         displacement_relative_L2_upper=math.sqrt(float(disp2upper)),energy_seminorm_relative_upper=math.sqrt(float(energy2upper)),
         independent_material_half_energy_gap_upper=float(gapupper),
         observed_Native_after_support_half_energy_N_mm=native,observed_Native_after_support_minus_oracle_relative=float(Q(native)/z['E']-1),
         identity_observations=idgate,eligibility_gates=gates,accuracy_eligible_for_coststudy_only=all(gates.values()),
         final_paper_or_production_method_adopted=False))
 # Historical exact regression is retained on its original inputs, not relabelled as this runtime.
 historical=PREP/'mechanics/candidate/public98_energy_oracle_v1/aggregate_v2/actual_results/all_profiles_oracle.json'
 if sha(historical)!='716180b7e2bd7458f6f28c6704063df59be9db954176f873a4e2011cd3d41d28':raise RuntimeError('historical exact regression evidence drift')
 oldresult=json.loads(historical.read_text());assert oldresult['first_Ear7_exact_energy_and_direct_difference_regression_identical']
 first=json.loads((ORACLE/'actual_results_v1/oracle_results.json').read_text())
 historical_comparison=[]
 for i,name in [(0,'duffy'),(1,'ear7')]:
     oldvalue=F(first['fields'][name]['nominal_affine_material_half_energy_N_mm']['exact'])
     historical_comparison.append(dict(current_case=cases[i]['name'],same_exact_energy=totals[i]['E']==oldvalue,current_minus_historical_exact=str(totals[i]['E']-oldvalue),current_source_not_relabelled_as_historical=True))
 byName={x['case']:x for x in summary};masked=None
 for name in [NAMES[6],NAMES[7],NAMES[8]]:
     if byName[name]['accuracy_eligible_for_coststudy_only']:masked=name;break
 fixed=NAMES[2];automatic=NAMES[3]
 threeEligible=masked is not None and byName[fixed]['accuracy_eligible_for_coststudy_only'] and byName[automatic]['accuracy_eligible_for_coststudy_only']
 result=dict(schema='oe-public98-nine-profile-exact-physical-oracle-v2',status='COMPLETED_SAME_ORACLE_ALL9_PREDECLARED_COSTSTUDY_GATES',
     fixed_reference=ref['name'],protocol_path=str(PROTOCOL),protocol_sha256=sha(PROTOCOL),
     historical_exact_regression_retained_on_original_inputs=True,current_to_historical_exact_energy_comparison=historical_comparison,independent_geometry_cache_sha256=sha(CACHE),
     raw_22_9_percent_coefficient_history_preserved=True,physical_metrics_not_true_continuum_error=True,actual_membrane_uz_exact0_in_all9=True,
     geometry_model_bound_retained=True,actual_binary=ref['runtime']['runtime'][0],actual_profile_count=9,profiles=summary,
     coststudy_selection=dict(masked_first_passing=masked,positive_fitted_fixed_profile=fixed,automatic_positive_fitted_profile=automatic,
         three_families_accuracy_eligible=threeEligible,final_paper_or_production_adoption=False,
         if_not_all_eligible='No equal-accuracy three-method timing claim; no tolerance lowering or unplanned masking density increase'),
     general_method_stability_or_reference_mesh_accuracy_accepted=False,Host_compiler_solver_started=False,
     elapsed_seconds=time.perf_counter()-started)
 sources=[PROTOCOL,HERE/'predata_protocol_identity_record.json',CACHE,ORACLE/'FIRST_ORACLE_FROZEN.json',ORACLE/'exact_cell_polynomial.py',ORACLE/'run_actual_oracle.py',Path(__file__)]+[p for c in cases for p in c['inputs']]
 for path in sources:context.bind(path)
 result.update(source_binding_sha256=context.identity.source_sha,runtime_manifest_sha256=context.identity.runtime_sha)
 result['input_manifest']=context.finish()
 OUT.mkdir()
 (OUT/'all_profiles_oracle.json').write_text(json.dumps(result,indent=2,allow_nan=False),encoding='utf-8')
 exact={case['name']:{k:str(v) for k,v in z.items()} for case,z in zip(cases,totals)}
 (OUT/'exact_totals.json').write_text(json.dumps(exact,indent=2),encoding='utf-8')
 with (OUT/'all_profiles_metrics.csv').open('w',newline='',encoding='utf-8-sig') as f:
     keys=['case','raw_control_coefficient_relative_L2','retained_physical_displacement_relative_L2','retained_RMS_difference_mm','energy_seminorm_relative',
         'independent_material_half_energy_N_mm','difference_half_energy_N_mm','geometry_material_energy_abs_bound_N_mm','geometry_difference_energy_abs_bound_N_mm',
         'independent_material_half_energy_relative_gap','displacement_relative_L2_upper','energy_seminorm_relative_upper','independent_material_half_energy_gap_upper','accuracy_eligible_for_coststudy_only']
     w=csv.DictWriter(f,fieldnames=keys);w.writeheader();w.writerows({k:r[k] for k in keys} for r in summary)
 with (OUT/'per_cell_profile_comparison.csv').open('w',newline='',encoding='utf-8-sig') as f:
     w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
 print(json.dumps(dict(status=result['status'],elapsed_seconds=result['elapsed_seconds'],selection=result['coststudy_selection'],
     metrics=[{k:r[k] for k in ['case','retained_physical_displacement_relative_L2','energy_seminorm_relative','independent_material_half_energy_relative_gap','accuracy_eligible_for_coststudy_only']} for r in summary]),indent=2),flush=True)
