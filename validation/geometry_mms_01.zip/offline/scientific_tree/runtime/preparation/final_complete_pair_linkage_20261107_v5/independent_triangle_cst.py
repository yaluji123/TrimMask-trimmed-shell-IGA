"""Independent linear plane-stress reference for this planar, in-plane loaded triangle."""
from pathlib import Path
import argparse,json,hashlib,time
import numpy as np
from scipy.sparse import coo_matrix
from scipy.sparse.linalg import spsolve
ROOT=Path(r'D:\BaiduSyncdisk\CODEX\投稿\二次修稿\准备工作');HERE=Path(__file__).resolve().parent
def mesh(N,vertices,grading=1):
 offsets=np.array([j*(N+1)-j*(j-1)//2 for j in range(N+1)],dtype=np.int64)
 pairs=np.array([(i,j)for j in range(N+1)for i in range(N+1-j)],dtype=float)
 bary=np.column_stack([1-pairs.sum(1)/N,pairs[:,0]/N,pairs[:,1]/N]);bary=bary**grading;bary/=bary.sum(1)[:,None]
 x=bary@vertices;tri=[]
 for j in range(N):
  for i in range(N-j):
   tri.append([offsets[j]+i,offsets[j]+i+1,offsets[j+1]+i])
   if i<N-j-1:tri.append([offsets[j]+i+1,offsets[j+1]+i+1,offsets[j+1]+i])
 return x,np.asarray(tri,dtype=np.int32),pairs,offsets
def assemble(x,tri,E,nu,t):
 p=x[tri];area2=(p[:,1,0]-p[:,0,0])*(p[:,2,1]-p[:,0,1])-(p[:,2,0]-p[:,0,0])*(p[:,1,1]-p[:,0,1]);assert np.all(area2>0)
 b=np.column_stack([p[:,1,1]-p[:,2,1],p[:,2,1]-p[:,0,1],p[:,0,1]-p[:,1,1]])/area2[:,None]
 c=np.column_stack([p[:,2,0]-p[:,1,0],p[:,0,0]-p[:,2,0],p[:,1,0]-p[:,0,0]])/area2[:,None]
 B=np.zeros((len(tri),3,6));B[:,0,0::2]=b;B[:,1,1::2]=c;B[:,2,0::2]=c;B[:,2,1::2]=b
 D=E/(1-nu*nu)*np.array([[1,nu,0],[nu,1,0],[0,0,(1-nu)/2]])
 ke=np.einsum('eji,jk,ekl,e->eil',B,D,B,.5*area2*t,optimize=True)
 dofs=(2*tri[:,:,None]+np.arange(2)).reshape(-1,6);r=np.repeat(dofs,6,axis=1).ravel();col=np.tile(dofs,(1,6)).ravel()
 K=coo_matrix((ke.ravel(),(r,col)),shape=(2*len(x),2*len(x))).tocsr();return K,float(area2.sum()/2)
def edge_load(F,x,ids,traction):
 for a,b in zip(ids[:-1],ids[1:]):
  f=np.linalg.norm(x[b]-x[a])*.5*np.asarray(traction);F[2*a:2*a+2]+=f;F[2*b:2*b+2]+=f
def self_check():
 vertices=np.array([[0.,0.],[2.,0.],[.4,1.2]]);x,tri,pairs,offset=mesh(4,vertices);E=206000.;nu=.3;t=7.;K,area=assemble(x,tri,E,nu,t);assert abs(area-1.2)<1e-14
 for rigid in [np.tile([1.,0.],len(x)),np.tile([0.,1.],len(x)),np.column_stack([-x[:,1],x[:,0]]).ravel()]:assert np.linalg.norm(K@rigid)/(np.linalg.norm(K.data)*np.linalg.norm(rigid))<1e-14
 epsilon=1e-4;exact=np.column_stack([epsilon*x[:,0],-nu*epsilon*x[:,1]]).ravel();F=np.zeros(2*len(x));stress=np.array([[E*epsilon,0],[0,0]])
 for ids in [list(range(5)),[int(offset[j]+4-j)for j in range(5)],[int(offset[j])for j in range(4,-1,-1)]]:
  tangent=x[ids[-1]]-x[ids[0]];n=np.array([tangent[1],-tangent[0]])/np.linalg.norm(tangent);edge_load(F,x,ids,t*(stress@n))
 fixed=np.repeat(pairs[:,1]==0,2);u=exact.copy();free=~fixed;u[free]=spsolve(K[free][:,free],F[free]-K[free][:,fixed]@u[fixed]);error=np.linalg.norm(u-exact)/np.linalg.norm(exact);assert error<1e-11
 energy=.5*exact@(K@exact);expected=.5*E*t*epsilon**2*area;assert abs(energy-expected)/expected<1e-12
 return dict(affine_independent_traction_patch_error=float(error),rigid_modes_pass=True,constant_strain_energy_relative=float(abs(energy-expected)/expected),area=area)
def graded_self_check():
 vertices=np.array([[0.,0.],[2.,0.],[.4,1.2]]);x,tri,pairs,offset=mesh(8,vertices,3);K,area=assemble(x,tri,206000.,.3,7.);assert abs(area-1.2)<1e-14
 exact=np.column_stack([1e-4*x[:,0],-.3e-4*x[:,1]]).ravel();energy=.5*exact@(K@exact);expected=.5*206000.*7e-8*area
 assert abs(energy-expected)/expected<1e-12
 for rigid in [np.tile([1.,0.],len(x)),np.tile([0.,1.],len(x)),np.column_stack([-x[:,1],x[:,0]]).ravel()]:assert np.linalg.norm(K@rigid)/(np.linalg.norm(K.data)*np.linalg.norm(rigid))<1e-14
 return dict(power=3,orientation_area_and_rigid_controls_pass=True,constant_strain_energy_relative=float(abs(energy-expected)/expected))
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--subdivisions',type=int,choices=[16,32,64,128,256,512,1024]);ap.add_argument('--output',type=Path);ap.add_argument('--grading-power',type=int,choices=[1,3],default=3);ap.add_argument('--self-check-only',action='store_true');a=ap.parse_args();check=self_check();check['graded_mesh']=graded_self_check()
 if a.self_check_only:print(json.dumps(dict(status='PASS_INDEPENDENT_CST_IMPLEMENTATION_CONTROLS_ONLY',**check)));return
 assert a.subdivisions and a.output and not a.output.exists();a.output.mkdir();start=time.perf_counter()
 source=ROOT/'runtime/runs/triangle_final1211_as_stored_v1/capture/trim_geometry_806.json';g=json.loads(source.read_text());cp=np.array(g['control_global_Vg']).reshape(13,13,3);origin=cp[0,0,:2];J=np.column_stack([cp[-1,0,:2]-origin,cp[0,-1,:2]-origin]);outer=np.asarray(g['outer_loop']);assert outer.shape==(3,2)
 # The captured registered triangle is [apex,left-bottom,right-bottom].
 loadSource=ROOT/'runtime/runs/triangle_final1x_stored_v2/input_audit/load_0_read_entity.json';load=json.loads(loadSource.read_text());assert load['owner_shell_handle']==806 and load['stored_force_payload'][2:]==[0,0,0,0]
 traction=np.asarray(load['stored_force_payload'][:2])*7.;assert traction[0]>0 and traction[1]==0
 vertices=outer[[1,2,0]]@J.T;x,tri,pairs,offsets=mesh(a.subdivisions,vertices,a.grading_power);K,area=assemble(x,tri,206000.,.3,7.);F=np.zeros(2*len(x));edge_load(F,x,[int(i)for i in offsets],traction)
 fixed=np.repeat(pairs[:,1]==0,2);free=~fixed;u=np.zeros(2*len(x));u[free]=spsolve(K[free][:,free],F[free]);residual=K@u-F;reaction=residual[fixed].reshape(-1,2).sum(0);force=F.reshape(-1,2).sum(0);res=float(np.linalg.norm(residual[free])/np.linalg.norm(F));balance=float(np.linalg.norm(reaction+force)/np.linalg.norm(force));energy=float(.5*u@(K@u));work=float(.5*u@F)
 assert res<1e-8 and balance<1e-8 and abs(energy-work)/abs(work)<1e-8
 umag=np.linalg.norm(u.reshape(-1,2),axis=1);peak=int(umag.argmax());moment=float(np.sum(x[:,0]*F[1::2]-x[:,1]*F[0::2]));rfull=residual.reshape(-1,2);reactionMoment=float(np.sum(x[fixed[::2],0]*rfull[fixed[::2],1]-x[fixed[::2],1]*rfull[fixed[::2],0]));momentbalance=abs(moment+reactionMoment)/abs(moment);assert momentbalance<1e-8
 result=dict(status='PASS_INDEPENDENT_CST_LINEAR_MEMBRANE_LEVEL_ONLY_NOT_CONVERGENCE',subdivisions=a.subdivisions,nodes=len(x),triangles=len(tri),dofs=len(u),planar_KL_in_plane_membrane_subproblem_only=True,E=206000.,nu=.3,t=7.,traction_N_per_mm=[300.,0.],area_mm2=area,geometry_source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),solver='SciPy SuperLU sparse direct; CST exactly integrated',self_check=check,peak_U_mm=float(umag[peak]),peak_location_mm=(x[peak]+origin).tolist(),peak_vector_mm=u.reshape(-1,2)[peak].tolist(),material_energy_Nmm=energy,half_external_work_Nmm=work,free_residual_relative=res,force_balance_relative=balance,moment_balance_relative=momentbalance,external_force_N=force.tolist(),reaction_N=reaction.tolist(),wall_seconds=time.perf_counter()-start,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),convergence_not_established_by_one_level=True)
 result.update(grading_power=a.grading_power,grading_rule='normalize all three barycentric coordinates raised to a fixed power; straight domain edges preserved',traction_N_per_mm=traction.tolist(),load_source_sha256=hashlib.sha256(loadSource.read_bytes()).hexdigest(),nominal300_not_substituted_for_actual_stored_payload=True)
 np.savez_compressed(a.output/'mesh_and_state.npz',points=x,origin=origin,triangles=tri,U=u.reshape(-1,2),F=F.reshape(-1,2),vertices=vertices)
 (a.output/'results.json').write_text(json.dumps(result,indent=2),encoding='utf-8');print(json.dumps(result))
if __name__=='__main__':main()
