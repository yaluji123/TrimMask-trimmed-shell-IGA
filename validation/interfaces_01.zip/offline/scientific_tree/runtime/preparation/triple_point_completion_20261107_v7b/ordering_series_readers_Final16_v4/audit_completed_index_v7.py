"""Metadata-only incomplete-input audit/export; never a job queue or numeric acceptance."""
from pathlib import Path
import argparse,json,re
from series_context_v7 import require,read,SOURCE,RUNTIME

def missing_entry(entry,q,flux):
    missing=[]
    if entry.get('complete')is not True:missing.append('complete')
    for key in ['run_dir','packet_dir']:
        if not isinstance(entry.get(key),str)or not entry[key]:missing.append(key)
    for key in ['postprocess']+(['flux_report']if flux else[]):
        value=entry.get(key)
        if not isinstance(value,dict)or not isinstance(value.get('path'),str)or not value['path']or re.fullmatch('[0-9a-f]{64}',str(value.get('sha256')))is None:missing.append(key+'.path/sha256')
    if entry.get('boundary_gauss')!=q:missing.append('boundary_gauss')
    return missing

def entries(index):
    result={}
    for entry in index['cases']:result[f"q4/{entry['omit']}/{entry['refine_factor']}"]=(entry,4,True)
    for entry in index['q5_controls']:result[f"q5/{entry['omit']}/1"]=(entry,5,False)
    result['order/cyclic']=(index['ordering_alternate'],4,False)
    return result

def audit(index):
    require(index['schema']=='oe-current90f-completed-threepatch-series-index-v7'and index['source_binding_sha256']==SOURCE and index['runtime_manifest_sha256']==RUNTIME,'current input-index identity')
    require(len(index['cases'])==16 and {(e['omit'],e['refine_factor'])for e in index['cases']}=={(o,h)for o in ['all','1ec2','1ec5','1ec8']for h in range(1,5)},'exact16 key grid')
    require(len(index['q5_controls'])==2 and {e['omit']for e in index['q5_controls']}=={'all','1ec8'},'exact two control keys')
    require(set(index['coarse_B_qualifications'])=={'all','1ec8'}and set(index['historical_source_default_linkage_reports'])=={'baseline','bc-isolation'},'both bounded coarse qualifications and both historical linkage references')
    missing={key:missing_entry(entry,q,flux)for key,(entry,q,flux)in entries(index).items()}
    for group in ['coarse_B_qualifications','historical_source_default_linkage_reports']:
        for key,value in index[group].items():
            if not isinstance(value.get('path'),str)or not value['path']or re.fullmatch('[0-9a-f]{64}',str(value.get('sha256')))is None:missing[group+'/'+key]=['path/sha256']
    value=index['ordering_report']
    if not isinstance(value.get('path'),str)or not value['path']or re.fullmatch('[0-9a-f]{64}',str(value.get('sha256')))is None:missing['ordering_report']=['path/sha256']
    for entry in index['q5_controls']:
        value=entry['control_report']
        if not isinstance(value.get('path'),str)or not value['path']or re.fullmatch('[0-9a-f]{64}',str(value.get('sha256')))is None:missing['GL4_GL5_report/'+entry['omit']]=['path/sha256']
    missing={key:fields for key,fields in missing.items()if fields}
    return dict(status='INDEX_METADATA_INCOMPLETE_NOT_NUMERIC_ACCEPTANCE'if missing else'INDEX_METADATA_COMPLETE_NOT_NUMERIC_ACCEPTANCE',missing=missing,Native_or_solver_or_jobs_started=False,files_or_results_qualified_by_this_audit=False)

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--case-index',type=Path,required=True);ap.add_argument('--output',type=Path)
    ap.add_argument('--export-key');ap.add_argument('--entry-output',type=Path);args=ap.parse_args();index=read(args.case_index);result=audit(index)
    if args.export_key is not None:
        require(args.entry_output is not None and not args.entry_output.exists(),'fresh single-entry output required')
        table=entries(index);require(args.export_key in table,'explicit one completed entry key')
        entry,q,flux=table[args.export_key];require(not missing_entry(entry,q,flux),'selected entry metadata not complete')
        args.entry_output.write_text(json.dumps(entry,indent=2)+'\n',encoding='utf-8')
    if args.output is not None:
        require(not args.output.exists(),'fresh metadata audit output');args.output.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,indent=2));return 0

if __name__=='__main__':raise SystemExit(main())
