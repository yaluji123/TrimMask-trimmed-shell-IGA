"""Independent endpoint local-trace/physical-moment reader. No state solve.

The native outputs must exist. --self-test exercises reference math only, never
manufactures a Native capture. Raw shear, endpoint role choice and point C/P are
not qualified by this reader.
"""
from pathlib import Path
from collections import Counter,defaultdict
import argparse,csv,hashlib,json,math
import numpy as np
from scipy.interpolate import BSpline
HERE=Path(__file__).resolve().parent;PACKET=HERE.parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def need(b,s):
 if not b:raise ValueError(s)
def load(p,cap=8*1024*1024):
 need(p.is_file()and p.stat().st_size<=cap,'bounded JSON '+str(p));return json.loads(p.read_text(encoding='utf-8-sig'))
def readrows(p,delimiter=',',cap=64*1024*1024):
 need(p.is_file()and p.stat().st_size<=cap,'bounded CSV '+str(p))
 with p.open(newline='',encoding='utf-8-sig')as f:return list(csv.DictReader(f,delimiter=delimiter))
def rel(a,b):return float(np.linalg.norm(a-b)/max(1.,np.linalg.norm(b)))
def ring(g,q):
 lo=(g['knots_u'][g['degree_u']],g['knots_v'][g['degree_v']]);hi=(g['knots_u'][g['controls_u']],g['knots_v'][g['controls_v']]);kind=int(q['kind'])
 p=[lo,(hi[0],lo[1]),hi,(lo[0],hi[1])]if kind==0 else(g['outer_loop']if kind==1 else g['hole_loops'][int(q['ring'])]);p=np.asarray(p,float)
 if len(p)>1 and np.array_equal(p[0],p[-1]):p=p[:-1]
 need(len(p)>=3,'registered primitive ring');return p

def registered_closure(g,uv):
    if not g['trim_registered']:return True
    def state(poly):
        p=np.asarray(poly,float)
        if len(p)>1 and np.array_equal(p[0],p[-1]):p=p[:-1]
        eps=1e-9*(float(np.max(np.ptp(p,axis=0)))+1.);on=False;inside=False
        for a,b in zip(p,np.roll(p,-1,axis=0)):
            d=b-a;t=float(np.clip(np.dot(uv-a,d)/np.dot(d,d),0,1));on|=np.linalg.norm(uv-a-t*d)<=eps
            if (a[1]>uv[1])!=(b[1]>uv[1]):
                x=a[0]+(uv[1]-a[1])*(b[0]-a[0])/(b[1]-a[1])
                if uv[0]<x:inside=not inside
        return on,inside
    if g['has_outer']:
        on,inside=state(g['outer_loop'])
        if not(on or inside):return False
    for p in g['hole_loops']:
        on,inside=state(p)
        if inside and not on:return False
    return True

def independent_point(g,uv):
    u=BSpline(g['knots_u'],np.eye(g['controls_u']),g['degree_u'],axis=0)(uv[0]);v=BSpline(g['knots_v'],np.eye(g['controls_v']),g['degree_v'],axis=0)(uv[1]);return np.outer(u,v).ravel()@np.asarray(g['control_global_Vg']).reshape(-1,3)

def kinematics(g,u,v,L3):
 m,n=g['controls_u'],g['controls_v'];pu,pv=g['degree_u'],g['degree_v'];need(all(x==1 for x in g['weights']),'unit-weight initial scope');B=[BSpline(g['knots_u'],np.eye(m),pu,axis=0)(u,nu=d)for d in range(3)];C=[BSpline(g['knots_v'],np.eye(n),pv,axis=0)(v,nu=d)for d in range(3)];b=lambda i,j:np.outer(B[i],C[j]).ravel();N=b(0,0);d=np.stack([b(1,0),b(0,1)],axis=1);dd=np.empty((m*n,2,2));dd[:,0,0]=b(2,0);dd[:,0,1]=dd[:,1,0]=b(1,1);dd[:,1,1]=b(0,2);X=np.asarray(g['control_global_Vg']).reshape(-1,3);J=X.T@d;xl=X@L3[:2].T;Jxy=xl.T@d;need(np.isfinite(Jxy).all()and np.linalg.det(Jxy)!=0,'reference Jacobian');inv=np.linalg.inv(Jxy);grad=d@inv;geoH=np.einsum('ia,ijk->ajk',xl,dd);adjust=dd-np.einsum('ia,ajk->ijk',grad,geoH);H=np.einsum('aj,ijk,kb->iab',inv.T,adjust,inv);normal=L3[2];gradworld=grad@L3[:2];NN=np.zeros((6,3*m*n))
 for cp in range(m*n):
  NN[:3,3*cp:3*cp+3]=np.eye(3)*N[cp]
  NN[3:,3*cp:3*cp+3]=np.outer(np.cross(gradworld[cp],normal),normal)
 return N,NN,J,H,normal

def moment(H,normal,L3,mu,E,nu,t):
 D=E*t**3/(12*(1-nu**2));Mxx=D*(H[:,0,0]+nu*H[:,1,1]);Myy=D*(H[:,1,1]+nu*H[:,0,0]);Mxy=D*(1-nu)*H[:,0,1];q=L3@mu;traction=np.stack([Mxx*q[0]+Mxy*q[1],Mxy*q[0]+Myy*q[1],np.zeros(len(H))],axis=1)@L3;mv=np.cross(traction,normal);out=np.zeros((3,3*len(H)))
 for cp in range(len(H)):out[:,3*cp:3*cp+3]=np.outer(mv[cp],normal)
 return out

_COEFFICIENT_CACHE={}
def polynomial_coefficients(g):
    key=(g['shell_handle']if 'shell_handle'in g else 0,tuple(g['knots_u']),tuple(g['knots_v']))
    if key in _COEFFICIENT_CACHE:return _COEFFICIENT_CACHE[key]
    answer=[]
    for axis in ['u','v']:
        n=g['controls_'+axis];degree=g['degree_'+axis];K=np.asarray(g['knots_'+axis]);need(n<=64,'bounded coefficient map64');nodes=np.array([np.mean(K[i+1:i+degree+1])for i in range(n)]);lo,hi=K[degree],K[n];B=BSpline(K,np.eye(n),degree,axis=0)(nodes);coef=np.linalg.solve(B,np.stack([((nodes-lo)/(hi-lo))**k for k in range(4)],axis=1));check=np.linspace(lo,hi,17);err=np.max(np.abs(BSpline(K,coef,degree,axis=0)(check)-np.stack([((check-lo)/(hi-lo))**k for k in range(4)],axis=1)));need(err<1e-11,'off-collocation polynomial reproduction');answer.append(coef)
    _COEFFICIENT_CACHE[key]=answer;return answer

def polynomial_probe_actions(g,uv,L3,metadata,actual):
    # Coefficients are bounded collocation SOLUTIONS, not Greville samples.
    cu,cv=polynomial_coefficients(g);m,n=g['controls_u'],g['controls_v'];X=np.asarray(g['control_global_Vg']).reshape(-1,3);normal=L3[2];lo=np.array([g['knots_u'][g['degree_u']],g['knots_v'][g['degree_v']]]);span=np.array([g['knots_u'][m],g['knots_v'][n]])-lo;xi,eta=(uv-lo)/span;source=np.asarray(metadata['source_getter_conormal']);te=np.asarray(metadata['tangent']);mu=np.asarray(metadata['outward_conormal_candidate']);E,nu,t=metadata['E'],metadata['nu'],metadata['t'];D=E*t**3/(12*(1-nu*nu));Dm=E*t/(1-nu*nu);J=np.asarray(metadata['J_columns']).T;inv=np.linalg.inv(L3[:2]@J)
    Bu=[BSpline(g['knots_u'],np.eye(m),g['degree_u'],axis=0)(uv[0],nu=k)for k in range(3)];Bv=[BSpline(g['knots_v'],np.eye(n),g['degree_v'],axis=0)(uv[1],nu=k)for k in range(3)];dd=np.empty((m*n,2,2));dd[:,0,0]=np.outer(Bu[2],Bv[0]).ravel();dd[:,0,1]=dd[:,1,0]=np.outer(Bu[1],Bv[1]).ravel();dd[:,1,1]=np.outer(Bu[0],Bv[2]).ravel();geoH=np.einsum('ia,ijk->ajk',X@L3[:2].T,dd)
    def direct(poly):
        def deriv(a,b):
            z=0.
            for(i,j),c in poly.items():
                if i>=a and j>=b:z+=c*math.factorial(i)/math.factorial(i-a)*math.factorial(j)/math.factorial(j-b)*xi**(i-a)*eta**(j-b)/span[0]**a/span[1]**b
            return z
        value=deriv(0,0);grad=np.array([deriv(1,0),deriv(0,1)])@inv;HP=np.array([[deriv(2,0),deriv(1,1)],[deriv(1,1),deriv(0,2)]]);HC=inv.T@(HP-grad[0]*geoH[0]-grad[1]*geoH[1])@inv;return value,grad,HC
    def vector_moment(H,conormal):
        MM=D*np.array([[H[0,0]+nu*H[1,1],(1-nu)*H[0,1]],[(1-nu)*H[0,1],H[1,1]+nu*H[0,0]]]);local=MM@(L3@conormal)[:2];return np.cross(L3.T@np.array([*local,0.]),normal)
    results=[]
    def check(name,coef,expectN,expectRawMoment,expectedM=None,expectedForce=None):
        for suffix in ['sparse','compact']:
            NN=actual('N_'+suffix);VV=actual('V_'+suffix);got=NN@coef;em=float(np.linalg.norm(VV[3:]@coef-expectRawMoment));nm=max(1.,np.linalg.norm(VV[3:])*np.linalg.norm(coef),np.linalg.norm(expectRawMoment));en=float(np.linalg.norm(got-expectN));nn=max(1.,np.linalg.norm(NN)*np.linalg.norm(coef),np.linalg.norm(expectN));need(en/nn<1e-9 and em/nm<1e-9,'independent polynomial point action '+name)
            er=0.
            if expectedM is not None:
                gotM=actual('M_'+suffix,3)@coef;er=float(np.linalg.norm(gotM-expectedM));need(er/max(1.,np.linalg.norm(actual('M_'+suffix,3))*np.linalg.norm(coef),np.linalg.norm(expectedM))<1e-9,'independent physical moment action '+name)
                R=np.cross(expectedM,te)
                for ending,sign,enabled in [('plus',1.,metadata['half_before_epsilon_plus1']),('minus',-1.,metadata['half_after_epsilon_minus1'])]:
                    if enabled:need(np.linalg.norm(actual('R_'+suffix+'_'+ending,3)@coef-sign*R)/max(1.,np.linalg.norm(actual('R_'+suffix+'_'+ending,3))*np.linalg.norm(coef),np.linalg.norm(R))<1e-9,'independent signed endpoint point action '+name)
            ef=0.
            if expectedForce is not None:ef=float(np.linalg.norm(VV[:3]@coef-expectedForce));need(ef/max(1.,np.linalg.norm(VV[:3])*np.linalg.norm(coef),np.linalg.norm(expectedForce))<1e-9,'independent membrane force '+name)
            results.append(dict(name=name,channel=suffix,value_absolute_error=en,moment_absolute_error=em,moment_normwise_error=em/nm,physical_moment_absolute_error=er,membrane_force_absolute_error=ef))
    zero=np.zeros(3);point=np.asarray(metadata['actual_xyz'])
    for axis in range(3):
        e=np.eye(3)[axis];check('rigid_translation_'+str(axis),np.tile(e,m*n),np.r_[e,zero],zero)
        co=np.cross(np.tile(e,(m*n,1)),X).ravel();check('rigid_rotation_'+str(axis),co,np.r_[np.cross(e,point),e-normal*np.dot(e,normal)],zero)
    probes=[('membrane_x',{(1,0):1.},L3[0]),('membrane_y',{(0,1):1.},L3[1]),('bend_xx',{(2,0):1.},normal),('bend_yy',{(0,2):1.},normal),('constant_twist',{(1,1):1.},normal),('variable_twist',{(2,1):1.},normal),('normal_cubic',{(3,0):1.},normal)]
    for name,poly,direction in probes:
        coeff=sum((c*np.outer(cu[:,i],cv[:,j]).ravel()for(i,j),c in poly.items()),np.zeros(m*n));co=(coeff[:,None]*direction).ravel();value,grad,H=direct(poly);w=float(np.dot(direction,normal));expectedN=np.r_[value*direction,np.cross(w*(grad@L3[:2]),normal)];raw=-w*vector_moment(H,source);physical=w*vector_moment(H,mu)if metadata['boundary_candidate']and abs(abs(metadata['conormal_dot'])-1.)<=1e-10 else None;force=None
        if name.startswith('membrane'):
            local=L3@direction;exx,eyy=grad[0]*local[0],grad[1]*local[1];gxy=grad[1]*local[0]+grad[0]*local[1];NN=Dm*np.array([[exx+nu*eyy,(1-nu)*gxy/2],[(1-nu)*gxy/2,eyy+nu*exx]]);f=NN@(L3@source)[:2];force=L3.T@np.array([*f,0.])
        check(name,co,expectedN,raw,physical,force)
    return dict(probes=13,actual_channel_checks=len(results),max_absolute_moment=max(q['moment_absolute_error']for q in results),max_normwise_moment=max(q['moment_normwise_error']for q in results),max_absolute_value=max(q['value_absolute_error']for q in results),raw_shear_or_Q_qualified=False)

class ScalarRows:
    def __init__(self,path):
        need(path.is_file()and path.stat().st_size<=512*1024*1024,'bounded streamed scalar file');self.file=path.open(newline='',encoding='ascii');self.reader=iter(csv.DictReader(self.file));self.pending=next(self.reader,None);self.sequence=0
    def for_uid(self,uid):
        out=defaultdict(dict);counts=Counter();need(self.pending is None or int(self.pending['uid'])>=uid,'grouped actual UID order')
        while self.pending is not None and int(self.pending['uid'])==uid:
            q=self.pending;self.sequence+=1;need(int(q['sequence'])==self.sequence and self.sequence<=4000000,'actual scalar sequence');r,c=int(q['row']),int(q['local_col']);v=float(q['value']);ch=q['channel'];need(0<=r<6 and 0<=c<40000 and np.isfinite(v),'finite scalar identity');need(ch in ['N_sparse','V_sparse','N_compact','V_compact','M_sparse','M_compact','R_sparse_plus','R_sparse_minus','R_compact_plus','R_compact_minus'],'actual channel');A=out[ch];A[r,c]=A.get((r,c),0.)+v;counts[ch]+=1;self.pending=next(self.reader,None)
        return out,counts
    def finish(self,count):
        need(self.pending is None and self.sequence==count,'complete actual scalar census');self.file.close()

def vertex_plan_contract(plan,contract):
 need(len(plan)==988 and [int(q['uid'])for q in plan]==list(range(1,989)),'finite988 UID contract')
 p=PACKET/'requests/APPENDED_VERTEX_METADATA_CONTRACT.json';need(sha(p)==contract['append_vertex_metadata_sha256'],'frozen30vertex metadata')
 v=load(p);raw=(PACKET/'requests/endpoint_requests.tsv').read_bytes()
 need(sha(Path(v['base958']['path']))==v['base958']['sha256']and hashlib.sha256(raw[:v['base958']['bytes']]).hexdigest()==v['base958']['sha256'],'original958 exact bytes prefix')
 need(sha(Path(v['source30table']['path']))==v['source30table']['sha256']and len(v['records'])==30,'sealed30source identity')
 mapping={}
 for q,w in zip(plan[958:],v['records']):
  need(q==w['row_tokens']and int(q['uid'])==w['new_uid']and int(q['kind'])>=0,'exact appended primitive/raw/vertex/gamma tokens')
  need(w['new_physical_corner_inferred']is False and w['flags_semantics']=='raw projection observations, not final physical incidence','no physical-incidence upgrade')
  mapping[int(q['uid'])]=w
 need(len(mapping)==30,'unique30literalvertices')
 return mapping

def vertex_actual_metadata(q,z,vertices):
 if int(q['uid'])not in vertices:return
 v=vertices[int(q['uid'])]
 need(z['status']=='ROWS_CAPTURED_LOCAL_CP3_ROLE_NOT_CERTIFIED'and z['boundary_candidate']is True,'all30literalvertices need actual local traces')
 need(z['selected_uv']==[float(v['row_tokens'][k])for k in ['su','sv']],'actual selected literal vertex exact')

def vertex_unsigned_R0(q,z,A,te,vertices):
 if int(q['uid'])not in vertices:return
 need(z['half_before_epsilon_plus1']or z['half_after_epsilon_minus1'],'raw projection channel observes unsignedR0')
 for suffix in ['sparse','compact']:
  R0=np.cross(A('M_'+suffix,3).T,te).T
  if z['half_before_epsilon_plus1']:need(rel(A('R_'+suffix+'_plus',3),R0)<1e-9,'actual unsignedM-cross-ownte plus channel')
  if z['half_after_epsilon_minus1']:need(rel(-A('R_'+suffix+'_minus',3),R0)<1e-9,'actual unsignedM-cross-ownte minus channel')
 # This checks producer channels only; raw fraction flags are not physical rays.

def audit(case,manifest,manifest_sha):
 need(sha(manifest)==manifest_sha==sha(case/'source_runtime_manifest.json'),'pinned actual new runtime manifest');bm=load(manifest);module=load(case/'actual_loaded_module_hashes.json');events=module.get('events',[module]);ev=next((x for x in events if x.get('event')=='before_endpoint_passive'),None);need(ev is not None and not ev['errors']and ev['status']=='PASS_ACTUAL_LOADED_MODULE_FILES_MATCH_MANIFEST','actual endpoint module event')
 expected={q['name']:q for q in bm['runtime']}
 for kind,name in [('crx','IGAforCAD.crx'),('dbx','JYH_IGAEntity.dbx')]:
  q=ev['verified_manifest_runtime'][kind];need(q['same_path']and q['actual_sha256']==expected[name]['sha256']and sha(Path(q['actual_path']))==q['actual_sha256'],'actual loaded file hash')
 process=load(case/'process_result.json');need(process['exit_code']==0 and process['natural_owned_child_exit'],'owned process natural terminal');need(load(case/'owned_process_resource_observations.json')['within_declared_observed_memory'],'owned observed resource gate');logs=load(case/'log_decode_receipt.json');need(all(q['strict_decode']for q in logs.values()),'strict actual log decoding');need('[ERR]'not in(case/'stdout.log').read_text(encoding='utf-8') and (case/'stderr.log').stat().st_size==0,'actual error-free scoped logs');identity=load(case/'original_input_before_after.json');need(identity['exact_sha_and_mtime_unchanged']and identity['before']['sha256']=='e61b385ef49818614a8a460c1ba759b9808af1d999ea84ab183fa5737a984a6d','original input');capture=case/'capture';capture=capture if capture.is_dir()else case
 contract=load(PACKET/'requests/REQUEST_CONTRACT.json');planfile=PACKET/'requests/endpoint_requests.tsv';need(sha(planfile)==contract['file_sha256'],'frozen request plan');plan=readrows(planfile,'\t');need(len(plan)==contract['rows']==988,'988 base958-plus30 literalvertex requests');footer=load(capture/'endpoint_complete.json');need(footer['request_SHA256']==sha(planfile)and footer['records']==footer['requested']==988 and all(footer[k]is False for k in ['numbering_called','bulk','interface','point_C_P','solve','physical_acceptance']),'footer scope/count')
 meta=[]
 with(capture/'endpoint_metadata.jsonl').open(encoding='utf-8-sig')as f:
  for line in f:need(len(line)<8192,'bounded metadata line');meta.append(json.loads(line))
 need(len(meta)==988 and [q['uid']for q in meta]==list(range(1,989)),'all real request records exactly once');scanner=ScalarRows(capture/'endpoint_rows.csv');geos={};accepted_sides=set();maxN=maxRawM=maxPhysicalM=maxPointR=maxJ=0.;accepted=0;rejected=Counter();probe_count=0;probe_max_abs=0.;probe_max_norm=0.
 vertices=vertex_plan_contract(plan,contract)
 for q,z in zip(plan,meta):
  local_rows,counts=scanner.for_uid(z['uid']);matrix_cache={}
  for k in ['uid','entry','couple','end','side','owner','kind','ring','edge']:need(int(q[k])==z[k],'request exact key '+k)
  vertex_actual_metadata(q,z,vertices)
  values=[float(q[k])for k in contract['columns'][9:]];need(z['request_values']==values and z['given_gamma_raw_tokens']==[q[k]for k in ['gu1','gu2','gt1','gt2']] and z['actual_current_line_gamma_observed']is False,'all original doubles and frozen-gamma provenance');owner=z['owner'];geo=capture/f'trim_geometry_{owner}.json'
  if owner not in geos:geos[owner]=load(geo)
  g=geos[owner];cols=3*g['controls_u']*g['controls_v'];need(cols==z['local_cols'],'actual localCP layout');uv=np.asarray(z['selected_uv']);need(np.array_equal(uv,np.asarray([float(q['su']),float(q['sv'])])),'explicit limit unchanged');lo=np.array([g['knots_u'][g['degree_u']],g['knots_v'][g['degree_v']]]);hi=np.array([g['knots_u'][g['controls_u']],g['knots_v'][g['controls_v']]]);outside=bool(np.any(uv<lo)or np.any(uv>hi))
  if z['kind']!=-1:
   p=ring(g,q);a,b=p[z['edge']],p[(z['edge']+1)%len(p)];need(np.array_equal(a,z['primitive_a'])and np.array_equal(b,z['primitive_b'])and np.array_equal(a,np.array([float(q['au']),float(q['av'])]))and np.array_equal(b,np.array([float(q['bu']),float(q['bv'])])),'live primitive data identity');raw=np.array([float(q['ru']),float(q['rv'])]);frac=float(np.clip(np.dot(raw-a,b-a)/np.dot(b-a,b-a),0,1));need(np.linalg.norm(uv-(a+frac*(b-a)))<=64*np.finfo(float).eps*(1+max(np.linalg.norm(a),np.linalg.norm(b))),'explicit association arithmetic');need(z['half_before_epsilon_plus1']==(z['fraction']>0)and z['half_after_epsilon_minus1']==(z['fraction']<1),'signed halfedges kept')
  if z['status']!='ROWS_CAPTURED_LOCAL_CP3_ROLE_NOT_CERTIFIED':
   need(not local_rows,'rejection has no invented getter rows');need(z['status']in ['SELECTED_OUTSIDE_PARAMETER_DOMAIN_NO_SNAP','SELECTED_NOT_REGISTERED_CLOSURE','ACTUAL_ASSOCIATION_RESIDUAL_REJECTED'],'specific rejection');
   if z['status']=='SELECTED_OUTSIDE_PARAMETER_DOMAIN_NO_SNAP':need(outside,'outside rejection requires actual outside selected UV')
   elif z['status']=='SELECTED_NOT_REGISTERED_CLOSURE':need(not outside and not registered_closure(g,uv),'closure rejection independently justified')
   else:need(not outside and registered_closure(g,uv)and np.linalg.norm(independent_point(g,uv)-np.array([float(q[k])for k in ['x','y','z']]))>float(q['tau']),'mapping residual rejection independently justified')
   rejected[z['status']]+=1;continue
  need(not outside and registered_closure(g,uv)and z['residual_mm']<=float(q['tau']),'actual tolerance/domain/closure');accepted+=1;accepted_sides.add((z['entry'],z['end'],z['side']));L3=np.array(z['L3_rows']);need(np.linalg.norm(L3@L3.T-np.eye(3))<=1e-10,'actual frame orthonormal');N,NN,J,H,normal=kinematics(g,*uv,L3);need(abs(N.sum()-1)<1e-12,'independent partition unity');Jactual=np.array(z['J_columns']).T;maxJ=max(maxJ,rel(Jactual,J));X=np.asarray(g['control_global_Vg']).reshape(-1,3);need(np.linalg.norm(N@X-np.array(z['actual_xyz']))<=max(float(q['tau']),1e-12),'independent physical point')
  def A(channel,nrow=6):
   if(channel,nrow)not in matrix_cache:
    out=np.zeros((nrow,cols))
    for(r,c),v in local_rows.get(channel,{}).items():need(r<nrow and c<cols,'actual row/CP bound');out[r,c]+=v
    matrix_cache[channel,nrow]=out
   return matrix_cache[channel,nrow]
  need(np.linalg.norm(L3[2]@J)<=1e-10*max(1.,np.linalg.norm(J)),'actual frame normal is surface normal')
  if z['boundary_candidate']:need(abs(abs(z['conormal_dot'])-1.)<=1e-10,'finite boundary candidate requires resolved conormal for physical R capture')
  source=np.array(z['source_getter_conormal']);te=np.array(z['tangent']);need(np.linalg.norm(source-np.cross(normal,te))<=1e-10,'actual getter source conormal');Msource=moment(H,normal,L3,source,z['E'],z['nu'],z['t'])
  for suffix in ['sparse','compact']:
   need(counts['N_'+suffix]>0 and counts['V_'+suffix]>0,'actual N/V channels required');maxN=max(maxN,rel(A('N_'+suffix),NN));maxRawM=max(maxRawM,rel(A('V_'+suffix)[3:],-Msource))
  probes=polynomial_probe_actions(g,uv,L3,z,A);probe_count+=probes['actual_channel_checks'];probe_max_abs=max(probe_max_abs,probes['max_absolute_moment']);probe_max_norm=max(probe_max_norm,probes['max_normwise_moment'])
  if z['boundary_candidate'] and abs(abs(z['conormal_dot'])-1)<=1e-10:
   area=sum(p[i,0]*p[(i+1)%len(p),1]-p[i,1]*p[(i+1)%len(p),0]for i in range(len(p)));left=(1 if area>0 else-1)*(-1 if z['kind']==2 else 1);pnormal=np.cross(J[:,0],J[:,1]);pnormal/=np.linalg.norm(pnormal);tref=J@(b-a);tref/=np.linalg.norm(tref);mu=-left*np.cross(pnormal,tref);need(np.linalg.norm(mu-z['outward_conormal_candidate'])<=1e-10 and np.linalg.norm(tref-te)<=1e-10 and abs(float(np.dot(source,mu))-z['conormal_dot'])<=1e-10,'independent material-side conormal');Mexpected=moment(H,normal,L3,mu,z['E'],z['nu'],z['t']);Rexpected=np.cross(Mexpected.T,te).T
   for suffix in ['sparse','compact']:
    maxPhysicalM=max(maxPhysicalM,rel(A('M_'+suffix,3),Mexpected))
    if z['half_before_epsilon_plus1']:maxPointR=max(maxPointR,rel(A('R_'+suffix+'_plus',3),Rexpected))
    if z['half_after_epsilon_minus1']:maxPointR=max(maxPointR,rel(A('R_'+suffix+'_minus',3),-Rexpected))
  vertex_unsigned_R0(q,z,A,te,vertices)
 scanner.finish(footer['scalar_rows'])
 need(accepted==footer['accepted_rows_requests'] and len(accepted_sides)==292,'actual accepted trace for every finite owner-side');need(maxN<1e-9 and maxRawM<1e-9 and maxPhysicalM<1e-9 and maxPointR<1e-9 and maxJ<1e-10,'independent physical N/M/R gates')
 bridgepath=PACKET.parent/'real_cad_endpoint_passive_source_v1/EXISTING_GLOBAL_MPC_REUSE_BRIDGE.json';need(sha(bridgepath)=='b3da527fc662c4d7d2b765dd0ff664e4da54a4579531206b8ecaa1792c8bfa7d','sealed old C/RHS source bridge');bridge=load(bridgepath);oldC=next(q for q in bridge['bindings']if Path(q['path']).name=='global_mpc_audit.json');need(sha(Path(oldC['path']))==oldC['sha256'],'actual old C/RHS bytes');oldRP=next(q for q in bridge['bindings']if Path(q['path']).name=='rp_collected_samples.json');need(sha(capture/'rp_collected_samples.json')==oldRP['sha256'],'new actual RP local basis/sampling matches reusable C contract')
 for owner,g in geos.items():
  old=next(q for q in bridge['bindings']if Path(q['path']).name==f'trim_geometry_{owner}.json');need(sha(capture/f'trim_geometry_{owner}.json')==old['sha256'],'new actual geometry matches reusable numbered C input')
 inventory=load(capture/'endpoint_entity_inventory.json');cnt=inventory['counts'];records=inventory['entities'];need(sum(cnt.values())==inventory['all_model_entities_read']and cnt['Couple']==73,'complete same traversal census');need(Counter(q['kind']for q in records)==Counter({k:v for k,v in cnt.items()if k!='other'and v}),'all relevant actual entities recorded');rp=load(capture/'rp_descriptor_entities.json');rpKinds={'referencePointLoad','referencePointBoundary','referencePointAction','referenceCouplingPoint','referenceCoupling','liftPointLoad'};need({q['handle']for q in records if q['kind']in rpKinds}=={q['entity_handle']for q in rp['entities']},'RP source identities actual same epoch');need({q['handle']for q in records if q['kind']=='Couple'}=={int(q['couple'])for q in plan},'complete actual73relation entity IDs')
 for q in records:
  if q['kind']not in rpKinds|{'Couple'}:need(len(q['values'])==6 and all(np.isfinite(q['values']))and q['owner']in geos,'complete ordinary entity payload')
 return dict(status='PASS_BOUNDED_ACTUAL_ENDPOINT_LOCAL_N_M_R_CAPTURE_ONLY',requests=988,append_literal_vertex_requests=30,raw_projection_flags_physical_incidence_accepted=False,accepted=accepted,rejections=dict(rejected),owner_sides_with_actual_N=292,max_N=maxN,max_raw_moment=maxRawM,max_physical_moment=maxPhysicalM,max_signed_point_R=maxPointR,max_J=maxJ,inventory_counts=cnt,polynomial_action_channel_checks=probe_count,polynomial_max_absolute_moment_error=probe_max_abs,polynomial_max_normwise_moment_error=probe_max_norm,actual_gamma_from_new_line_producer=False,existing_C_RHS_not_recomputed=True,reused_actual_C_RHS_SHA256=oldC['sha256'],point_C_P_adoption=False,mechanical_role_reference_RP_zero_waiver_or_engineering_accepted=False,raw_shear_reconstructed=False,scope='Same frozen Hull geometry, constant isotropic flat unit-weight KL3; actual local rows and candidate incidence R only; no point weakform/state.')

def self_test():
 g=dict(controls_u=4,controls_v=4,degree_u=3,degree_v=3,knots_u=[0]*4+[1]*4,knots_v=[0]*4+[1]*4,weights=[1]*16,control_global_Vg=[v for i in range(4)for j in range(4)for v in [20*i/3,10*j/3,0.]])
 N,NN,J,H,n=kinematics(g,.37,.61,np.eye(3));X=np.asarray(g['control_global_Vg']).reshape(-1,3);need(abs(N.sum()-1)<1e-14 and np.max(np.abs(H.sum(axis=0)))<1e-14,'reference partition');need(np.max(np.abs(np.einsum('i,ijk->jk',X[:,0],H)))<1e-13,'affine field zero curvature');M=moment(H,n,np.eye(3),np.array([0.,1.,0.]),206000.,.3,2.5);need(np.linalg.norm(M@NN.T[:,0])<1e-10,'rigid translation zero moment');te=np.array([1.,0.,0.]);mu=np.array([0.,1.,0.]);M=moment(H,n,np.eye(3),mu,206000.,.3,2.5);VR=np.zeros_like(NN);VR[3:]=-M;Bu=BSpline(g['knots_u'],np.eye(4),3,axis=0)(.37,nu=1);Bv=BSpline(g['knots_v'],np.eye(4),3,axis=0)(.61,nu=1);B0u=BSpline(g['knots_u'],np.eye(4),3,axis=0)(.37);B0v=BSpline(g['knots_v'],np.eye(4),3,axis=0)(.61);grad=np.stack([np.outer(Bu,B0v).ravel()/20,np.outer(B0u,Bv).ravel()/10],axis=1);Dm=206000.*2.5/(1-.3**2)
 for cp in range(16):
  for j in range(2):
   e=np.eye(2)[j];exx,eyy=grad[cp,0]*e[0],grad[cp,1]*e[1];gxy=grad[cp,1]*e[0]+grad[cp,0]*e[1];stress=Dm*np.array([[exx+.3*eyy,.7*gxy/2],[.7*gxy/2,eyy+.3*exx]]);VR[:2,3*cp+j]=stress@mu[:2]
 R=np.cross(M.T,te).T;operators={ch:A for suffix in ['sparse','compact']for ch,A in [('N_'+suffix,NN),('V_'+suffix,VR),('M_'+suffix,M),('R_'+suffix+'_plus',R),('R_'+suffix+'_minus',-R)]};metadata=dict(source_getter_conormal=mu.tolist(),tangent=te.tolist(),outward_conormal_candidate=mu.tolist(),E=206000.,nu=.3,t=2.5,J_columns=J.T.tolist(),actual_xyz=(N@X).tolist(),boundary_candidate=True,conormal_dot=1.,half_before_epsilon_plus1=True,half_after_epsilon_minus1=True)
 action=lambda channel,nrow=6:operators[channel];probes=polynomial_probe_actions(g,np.array([.37,.61]),np.eye(3),metadata,action);negative=[]
 for name,channel in [('moment_sign','V_sparse'),('point_sign','R_compact_plus'),('value_scale','N_sparse'),('membrane_force','V_compact')]:
  mutated={k:v.copy()for k,v in operators.items()}
  if name=='moment_sign':mutated[channel][3:]*=-1
  elif name=='point_sign':mutated[channel]*=-1
  elif name=='value_scale':mutated[channel][:3]*=1.1
  else:mutated[channel][:3]*=1.1
  try:polynomial_probe_actions(g,np.array([.37,.61]),np.eye(3),metadata,lambda c,nrow=6:mutated[c])
  except ValueError:negative.append(name)
 need(len(negative)==4,'physical reference negative controls')
 plan=PACKET/'requests/endpoint_requests.tsv';contract=load(PACKET/'requests/REQUEST_CONTRACT.json');need(sha(plan)==contract['file_sha256'],'real plan hash');need(len(readrows(plan,'\t'))==988,'real finite plan');return dict(status='PASS_PYTHON_REFERENCE_AND_PLAN_ONLY_NOT_NATIVE',Native_capture_synthesized=False,tests=['partition','affine_zero_curvature','rigid_zero_moment','frozen988_base958_plus30_vertex_plan'],polynomial_reference_actions=probes,reference_wrong_primitive_controls=negative)
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('case',nargs='?',type=Path);ap.add_argument('--manifest',type=Path);ap.add_argument('--manifest-sha');ap.add_argument('--self-test',action='store_true');ap.add_argument('--out',type=Path);a=ap.parse_args();need(a.self_test!=bool(a.case),'choose actual immutable capture or reference only');r=self_test()if a.self_test else audit(a.case,a.manifest,a.manifest_sha);r['reader_SHA256']=sha(Path(__file__))
 if a.out:need(not a.out.exists(),'fresh independent output');a.out.write_text(json.dumps(r,indent=2),encoding='utf-8')
 print(json.dumps(r))
