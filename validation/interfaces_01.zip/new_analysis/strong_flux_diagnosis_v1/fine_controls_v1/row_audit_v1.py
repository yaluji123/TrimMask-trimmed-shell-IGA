from pathlib import Path
import sys
import traceback
from boot_v1 import start
resources = start()
import numpy as np
from scipy import sparse
from scipy.sparse.linalg import eigsh, splu, LinearOperator
from common_v1 import *

level = int(sys.argv[1]); assert level in (1, 4)
OUT = HERE/("coarse_rowaudit_v1" if level == 1 else "fine_rowaudit_v1")
OUT.mkdir(exist_ok=False)
result = {"status": "ROW_AUDIT_NOT_QUALIFIED", "level": level, "resources": resources}
try:
    if level == 4:
        assert read(HERE/"coarse_rowaudit_v1/results.json")["status"] == "INDEPENDENT_COMPLETE_PHYSICAL_ROW_MATRIX_MATCHED"
    run, cluster, arms, betas, packet, bulk = load(level)
    n = cluster["actual_global_dofs"]; local_n = len(arms[0].dofmap)
    actual = matrix(run/"input_audit/patch_order_global_K.csv", n, 200000 if level == 1 else 700000)
    F = vector(run/"input_audit/patch_order_global_F.csv", n)
    events = [__import__('json').loads(line) for line in bind(run/"boundary_domain_probe.jsonl").read_text(encoding="utf-8-sig").splitlines()]
    snapshots = [e for e in events if e["event"] == "apply_snapshot"]
    assert len(snapshots) == 1 and snapshots[0]["prescribed_global"] == [0]*6 and snapshots[0]["active_components"] == [True]*6
    purpose = None; points = []
    for e in events:
        if e["event"] == "probe_purpose": purpose = e["purpose"]
        elif e["event"] == "point_probe" and purpose == "carrier_integration": points.append(e)
    assert len(points) == 24*level
    A = sparse.csr_matrix((local_n, local_n)); C = A.copy(); P = A.copy()
    for e in points:
        assert e["uv"][0] == 0. and e["physical_line_weight"] > 0
        op = arms[0].operators(*e["uv"], mu=-arms[0].t, ell=1.)
        N = sparse.csr_matrix(np.vstack([op["U"], op["theta"]]))
        V = sparse.csr_matrix(np.vstack([op["T"], op["m"]]))
        w = e["physical_line_weight"]
        A += w*(V.T@V); C += w*(V.T@N); P += w*(N.T@N)
    active = np.unique(np.concatenate([A.nonzero()[0], A.nonzero()[1], P.nonzero()[0], P.nonzero()[1]]))
    assert 0 < len(active) <= 256
    metric = bulk[arms[0].dofmap, :][:, arms[0].dofmap][active, :][:, active].tocsc()
    aa = A[active, :][:, active].tocsc()
    tol = 100*np.finfo(float).eps*len(active)
    assert norm(metric-metric.T) <= tol*norm(metric) and norm(aa-aa.T) <= tol*norm(aa)
    v0 = np.ones(len(active)); v0 /= norm(v0)
    lo = float(eigsh(metric, k=1, which="SA", tol=1e-12, maxiter=4000, v0=v0, return_eigenvectors=False)[0])
    hi = float(eigsh(metric, k=1, which="LA", tol=1e-12, maxiter=4000, v0=v0, return_eigenvectors=False)[0])
    assert lo > tol*hi, "Sparse SPD principal path cannot handle a filtered null metric"
    mf = splu(metric)
    inv = LinearOperator(metric.shape, matvec=mf.solve, rmatvec=lambda x: mf.solve(x, trans="T"))
    values, vectors = eigsh(aa, M=metric, Minv=inv, k=1, which="LA", tol=1e-12, maxiter=4000, v0=v0)
    lam = float(values[0]); psi = vectors[:, 0]
    pencil_residual = norm(aa@psi-lam*(metric@psi))/(norm(aa@psi)+lam*norm(metric@psi))
    assert lam > 0 and pencil_residual <= 1e-10
    BCcons = -C-C.T; BC = BCcons+210.*lam*P
    actualBC = matrix(run/"input_audit/boundary_delta_H_7867.csv", local_n, 200000)
    BCgap = norm(BC-actualBC)/norm(actualBC)
    assert BCgap <= 1e-10
    line = sparse.csr_matrix((n, n)); consistency = line.copy(); penalty = line.copy()
    nodes, weights = np.polynomial.legendre.leggauss(4); cuts = core.unique_cuts(arms); gp = 0
    for a, b in zip(cuts[:-1], cuts[1:]):
        for x, w in zip(nodes, weights):
            u = (a+b)*.5+(b-a)*x*.5; ds = 100.*(b-a)*w*.5; gp += 1
            op = [arm.operators(u, 0., ell=1.) for arm in arms]
            Ns = [global_rows(o["N"], arm.dofmap, n) for o, arm in zip(op, arms)]
            Vs = [global_rows(o["V"], arm.dofmap, n) for o, arm in zip(op, arms)]
            for i in range(3):
                for j in range(3):
                    block = ds*((1. if i == j else 0.)-1/3)*(Ns[i].T@Vs[j])
                    consistency += block+block.T
            for (i, j), beta in betas.items():
                jump = Ns[i]-Ns[j]; penalty += ds*beta*(jump.T@jump)
    assert gp == cluster["samples"] == 24*level
    line = consistency+penalty
    sys.path.insert(0, str(PREP/"independent_readers_v7"))
    points_module = module("point_physical_sparse_v7", PREP/"independent_readers_v7/point_physical_sparse_v7.py")
    expected, point_plan = points_module.point_matrices(arms, 1., n)
    point_names = [("natural_joint_b", "triple_point_natural_b.csv"), ("essential_joint_a", "triple_point_essential_a.csv"),
                   ("essential_PATCH0_far_corner", "triple_point_essential_far.csv")]
    checks = []
    for key, filename in point_names:
        observed = matrix(run/"input_audit"/filename, n, 4096)
        gap = norm(expected[key]-observed)/norm(observed)
        assert gap <= 1e-10
        checks.append({"group": key, "relative_Frobenius": gap})
    reconstructed = bulk+line+scatter(BC, arms[0].dofmap, n)+sum((expected[k] for k, _ in point_names), sparse.csr_matrix((n, n)))
    gap = norm(reconstructed-actual)/norm(actual)
    assert gap <= 1e-10
    for name, value in {"Kbulk": bulk, "Kconsistency9": consistency, "Kpenalty": penalty, "Kline": line,
        "KBC_consistency": scatter(BCcons, arms[0].dofmap, n), "PBC": scatter(P, arms[0].dofmap, n),
        "Knatural_b": expected["natural_joint_b"], "Kessential_a": expected["essential_joint_a"],
        "Kessential_far": expected["essential_PATCH0_far_corner"], "Kreconstructed": reconstructed}.items():
        sparse.save_npz(OUT/(name+".npz"), value)
    result.update(status="INDEPENDENT_COMPLETE_PHYSICAL_ROW_MATRIX_MATCHED", n=n, lambda_BC=lam,
        boundary_active_columns=len(active), boundary_sparse_pencil_relative_residual=pencil_residual,
        boundary_metric_numeric_min_eigenvalue=lo, BC_relative_Frobenius=BCgap,
        full_actual_K_relative_Frobenius=gap, independent_point_checks=checks,
        all_nine_ordered_consistency_blocks=True, actual_BC_GP_count=len(points), joint_source_rule_GP_count=gp,
        joint_GP_scope="reproduced frozen GL4 rule on actual exported knots, not a claimed row capture",
        independent_material_bulk_reused_with_identical_geometry=True,
        Kactual_not_used_to_derive_any_reconstructed_component=True,
        recorded_betas=betas, dense_global_or_local2187_matrix_allocated=False)
except Exception as e:
    result.update(failure=repr(e), traceback=traceback.format_exc())
finally:
    verify_inputs(); result.update(observed_memory=memory(), input_sha256=PINS, resources=resources)
    save(OUT/"results.json", result); print(__import__('json').dumps(clean({k:v for k,v in result.items() if k not in ("input_sha256","traceback","recorded_betas")}), indent=2))
if result["status"] != "INDEPENDENT_COMPLETE_PHYSICAL_ROW_MATRIX_MATCHED": raise SystemExit(2)
