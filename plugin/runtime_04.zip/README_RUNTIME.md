# AutoCAD2025 CoreConsole runtime

Use the complete case command, profile and physical flags in PAPER_REPRODUCTION_CASES.json. Extract the five native models with the repository prepare_data.py. See docs/runtime.md in the repository for setup. Keep all runtime modules together. The licensed CAD host is required. Component notices accompany their modules.

Version2.0.0-oe-r1-rc4 uses the recorded numerical implementation with updated distribution metadata. The release modules load in AutoCAD2025 CoreConsole with SECURELOAD=1. Published numerical data retain their original recorded runtime families.
