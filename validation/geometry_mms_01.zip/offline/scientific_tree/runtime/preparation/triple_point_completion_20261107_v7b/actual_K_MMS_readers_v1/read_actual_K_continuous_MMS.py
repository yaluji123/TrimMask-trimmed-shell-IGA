"""One actual 729-DOF K, independent continuous MMS; source-only proposal.

Root-only offline execution after review. No Native/compiler/process observer,
ordinary-load solve, new K assembly, delta addition or fine-grid dense path.
"""
from pathlib import Path
import argparse,hashlib,importlib,json,os,sys
for key in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS']:os.environ[key]='1'
SOURCE='90f72156bd9f1430e25177e91b6a69b89c4434f81934dfdee19b20eef2a96566'
RUNTIME='50999199bb7bf6770b7446beae7c5e2600294276d6ba858ab7a616f873bf5a84'
PINS={'point_identity_v7.py':'efa3916a57bdfcbeadeb3809c5855f118caa0de26f0d973231be9c4fdff62b2d',
 'line_reader_v7.py':'69a8e5a0a1b9fea82bf1f9e7342ac51dd07c06e2b695196bb2037b7314bf80ff',
 'qualify_actual_coarse_point_K_v7.py':'d7f5069026c0c514923fac207c9214ac68b2f22fc529215ab601bde9f215534a',
 'cluster_physical_core.py':'e52b2ff82da8f02b4ef77d4676fb0388444ca036319f0b048108b2365e2c54ff',
 'point_physical_sparse_v7.py':'61ce66702c17c751110a8a2bfe18d57474637a1b13d62852b437ba4f77139c19'}

def need(ok,message):
    if not ok:raise ValueError(message)

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def read(path):return json.loads(Path(path).read_text(encoding='utf-8-sig'))

def coarse_budget(n):
    need(n==729,'actual complete K export is qualified only for729 DOF; no inferred fine K')
    estimate=40*n*n*8+8*n*8
    need(estimate<=536870912,'preserved512MiB major-buffer estimate')
    return estimate

def arguments():
    ap=argparse.ArgumentParser(description=__doc__)
    for name in ['prep','source-root','source-binding','runtime-manifest','reader-dir','run-dir','load-dir',
                 'qualification-report','protocol','out-dir']:
        ap.add_argument('--'+name,type=Path,required=True)
    for name in ['source-binding-sha256','runtime-manifest-sha256','qualification-report-sha256','protocol-sha256']:
        ap.add_argument('--'+name,required=True)
    return ap.parse_args()

def main(a=None):
    a=arguments()if a is None else a
    for name in ['prep','source_root','source_binding','runtime_manifest','reader_dir','run_dir','load_dir','qualification_report','protocol','out_dir']:
        need(getattr(a,name).is_absolute(),'all receipts and CLI paths must be absolute: '+name)
    need(a.source_binding_sha256==SOURCE and a.runtime_manifest_sha256==RUNTIME,'exact current90f/509991')
    need(not a.out_dir.exists(),'fresh one-case output; no retry/overwrite')
    directory=a.reader_dir.resolve()
    for name,h in PINS.items():need(sha(directory/name)==h,'preserved qualified reader source '+name)
    need(sha(a.protocol)==a.protocol_sha256,'Root-qualified frozen protocol')
    protocol=read(a.protocol)
    need(protocol['status']=='SOURCE_ONLY_NOT_EXECUTED'and protocol['source_binding_sha256']==SOURCE and
      protocol['runtime_manifest_sha256']==RUNTIME and protocol['actual_dofs']==729 and
      protocol['relative_MMS_budget']==1e-7 and protocol['quadrature']==[6,8]and
      protocol['major_buffer_budget_bytes']==536870912,'fixed original budgets; no tuned gates')
    own=Path(__file__).resolve().parent;family_source=own/'continuous_mms_families.py'
    need(sha(family_source)==protocol['continuous_family_source_sha256'],'frozen continuous density/RHS source')
    sys.path.insert(0,str(directory))
    identity_module=importlib.import_module('point_identity_v7')
    need(Path(identity_module.__file__).resolve()==directory/'point_identity_v7.py','exact strict identity import')
    identity=identity_module.Identity(a);identity.fresh_output(a.out_dir,[a.run_dir,a.load_dir])
    for name,h in PINS.items():identity.bind(directory/name,h)
    identity.bind(a.protocol,a.protocol_sha256);identity.bind(family_source,protocol['continuous_family_source_sha256'])
    identity.bind(own/'frozen_before/run_continuum_endpoint_controls.py',protocol['original_continuous_source_sha256'])
    identity.bind(own/'frozen_before/qualify_actual_coarse_point_K_v7.py',PINS['qualify_actual_coarse_point_K_v7.py'])
    reader=importlib.import_module('line_reader_v7');coarse=importlib.import_module('qualify_actual_coarse_point_K_v7')
    point=importlib.import_module('point_physical_sparse_v7')
    import continuous_mms_families as family
    need(Path(family.__file__).resolve()==family_source,'exact proposed continuous family import')
    import numpy as np
    run=a.run_dir.resolve();packet=a.load_dir.resolve()
    qualification=read(identity.bind(a.qualification_report,a.qualification_report_sha256))
    need(qualification['status']=='QUALIFIED_ACTUAL_COARSE_POINT_OPERATOR_AND_PHYSICAL_B_MMS_ONLY'and
      qualification['source_binding_sha256']==SOURCE and qualification['runtime_manifest_sha256']==RUNTIME and
      Path(qualification['actual_run']).resolve()==run and qualification['actual_global_dofs']==729 and
      qualification['full_actual_K_numeric_SPD']['passed']is True,'same real qualified729 Native K; not build-only identity')
    for item in qualification['input_manifest']:identity.bind(item['path'],item['sha256'])
    arms,Fordinary,Uordinary,positions,_,betas,ell,cluster,inputs,_=reader.load_actual(run,packet,identity)
    major=coarse_budget(len(Uordinary));reader.verify_boundary_file_seal(packet,run,inputs)
    need(reader.confirmed_clamp(run/'boundary_domain_probe.jsonl',inputs)is not None,'actual original full homogeneous clamp')
    K,Factual=coarse.actual_solver_packet(run,packet,len(Uordinary),identity)
    need(np.array_equal(Factual,Fordinary),'actual ordinary F unchanged; distinct MMS F never replaces it')
    actual,physical,_,point_report=point.qualify_points(run,packet,arms,ell,Uordinary,positions,cluster,identity)
    need(list(family.FAMILIES)==protocol['families'],'fixed complete family list')
    results=[];arrays={};budget=protocol['relative_MMS_budget']
    for index,kind in enumerate(family.FAMILIES):
        F6,fs6,ledger6=family.physical_rhs(arms,kind,6,ell)
        F8,fs,ledger=family.physical_rhs(arms,kind,8,ell)
        exact,representation=family.exact_coefficients(arms,fs)
        residual=K@exact-F8;scale=float(np.linalg.norm(F8))
        relative=float(np.linalg.norm(residual)/scale);quad=float(np.linalg.norm(F6-F8)/scale)
        checks=dict(actual_K_full_broken_MMS=relative<=budget,GL6_GL8_physical_rhs=quad<=budget)
        negative_rows=[]
        controls=[]
        if kind=='homogeneous_clamp_axial_membrane_linear':controls.append('flip_natural_force')
        if kind=='homogeneous_clamp_free_corners_balanced_normal_moments':controls.append('flip_natural_moment')
        if kind=='homogeneous_clamp_nonzero_b_corner_load':controls.append('omit_natural_b_corner')
        for name in controls:
            bad,_,bad_ledger=family.physical_rhs(arms,kind,8,ell,negative=name)
            defect=K@exact-bad;gap=float(np.linalg.norm(bad-F8)/scale);bad_relative=float(np.linalg.norm(defect)/scale)
            sensitive=gap>2*budget;rejected=bad_relative>budget
            checks['negative_'+name]=sensitive and rejected
            negative_rows.append(dict(control=name,physical_rhs_difference_relative=gap,
              independently_sensitive_at_existing_budget=sensitive,actual_K_residual_relative=bad_relative,
              rejected_at_existing_budget=rejected,insensitive_is_inconclusive_not_pass=not sensitive))
            arrays[f'f{index}_{name}_rhs']=bad;arrays[f'f{index}_{name}_residual']=defect
        if kind=='homogeneous_clamp_nonzero_b_corner_load':
            # Existing negative: replace only actual natural matrix by wrong total.
            wrong=point.tidy(K-actual['natural_joint_b']+physical['wrong_b_using_total'])
            defect=wrong@exact-F8;gap=float(np.linalg.norm((wrong-K)@exact)/scale)
            bad_relative=float(np.linalg.norm(defect)/scale);sensitive=gap>2*budget;rejected=bad_relative>budget
            checks['negative_wrong_total_corner']=sensitive and rejected
            negative_rows.append(dict(control='wrong_total_replacement_already_has_Gamma',
              actual_matrix_action_difference_relative=gap,independently_sensitive_at_existing_budget=sensitive,
              actual_K_residual_relative=bad_relative,rejected_at_existing_budget=rejected,
              insensitive_is_inconclusive_not_pass=not sensitive))
            arrays[f'f{index}_wrong_total_residual']=defect
        arrays[f'f{index}_exact_coefficients']=exact;arrays[f'f{index}_F6']=F6;arrays[f'f{index}_F8']=F8
        arrays[f'f{index}_actual_K_residual']=residual
        results.append(dict(family=kind,checks=checks,actual_K_MMS_absolute_L2_N=float(np.linalg.norm(residual)),
          actual_K_MMS_relative_L2=relative,GL6_GL8_rhs_relative_L2=quad,normalization='norm of independent physical F8',
          representation=representation,closed_continuous_formulas=[f['formula']for f in fs],
          physical_load_ledger=ledger,negative_controls=negative_rows))
    passed=all(all(row['checks'].values())for row in results)
    for path in inputs:identity.bind(path)
    identity.bind(Path(__file__));identity.verify_unchanged()
    result=dict(status='QUALIFIED_ACTUAL_COARSE_K_FIXED_CONTINUOUS_MMS_ONLY'if passed else'FAILED_ACTUAL_COARSE_K_CONTINUOUS_MMS_OR_CONTROL',
      source_binding_sha256=SOURCE,runtime_manifest_sha256=RUNTIME,actual_run=str(run),actual_load_packet=str(packet),
      actual_global_dofs=len(Uordinary),qualification_report=str(a.qualification_report.resolve()),
      original_relative_MMS_budget=budget,major_buffer_estimate_bytes=major,major_buffer_budget_bytes=536870912,
      actual_K_includes_existing_three_point_groups=True,positive_MMS_adds_no_matrix_delta=True,
      actual_ordinary_F_or_U_modified=False,RHS_generated_from_K_times_exact=False,point_qualification=point_report,
      family_results=results,raw_archive='actual_K_MMS_raw_vectors.npz',
      ordinary_solution_physical_accuracy_accepted=False,full_h_graph_reference_or_PDE_acceptance=False,
      raw_strong_FAIL_preserved=True,full_physical_Riesz_norm_computed=False,scientific_revision_ready=False,
      no_Native_compiler_process_observer_or_ordinary_solver=True,input_manifest=identity.manifest())
    a.out_dir.mkdir(parents=True,exist_ok=False)
    np.savez_compressed(a.out_dir/'actual_K_MMS_raw_vectors.npz',**arrays)
    (a.out_dir/'results.json').write_text(json.dumps(identity_module.clean(result),indent=2,allow_nan=False)+'\n',encoding='utf-8')
    print(json.dumps(dict(status=result['status'],output=str(a.out_dir/'results.json'))))
    return 0 if passed else 1

if __name__=='__main__':raise SystemExit(main())
