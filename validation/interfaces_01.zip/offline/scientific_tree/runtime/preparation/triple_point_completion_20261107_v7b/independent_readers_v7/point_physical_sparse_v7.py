"""Sparse physical point operators from frozen m/U rows; never allocate global n*n."""
from pathlib import Path
import csv,json,math
import numpy as np
from scipy import sparse
from cluster_physical_core import cross
from point_identity_v7 import require,required,read,sha

POINT_CAP=4096;EXPORT_CAP=1048576;MATRIX_BUDGET=1e-10;MAJOR_BUDGET=512*1024**2
GROUPS=[('natural_joint_b','triple_point_natural_b.csv','free_interface'),
        ('essential_joint_a','triple_point_essential_a.csv','essential_boundary'),
        ('essential_PATCH0_far_corner','triple_point_essential_far.csv','essential_boundary')]

def zero(n):return sparse.csr_matrix((n,n),dtype=float)

def row_global(local,arm,n):
    local=np.asarray(local,float);require(local.shape==(3,len(arm.dofmap))and np.isfinite(local).all(),'physical point row schema')
    rows,columns=np.nonzero(local)
    return sparse.coo_matrix((local[rows,columns],(rows,arm.dofmap[columns])),shape=(3,n)).tocsr()

def tidy(matrix):
    matrix=matrix.tocsr();matrix.sum_duplicates();matrix.eliminate_zeros();matrix.sort_indices()
    require(np.isfinite(matrix.data).all(),'point matrix nonfinite')
    return matrix

def norm(matrix):return float(np.linalg.norm(matrix.data))

def point_matrices(arms,ell,n):
    """Exactly the frozen independent cross(tau)@physical moment incidence formula."""
    require(1<=n<=7000 and len(arms)==3 and ell>0,'point fixture dimensions')
    # Only O(n) physical row arrays plus <=4096 sparse point coefficients, never n^2.
    preflight=64*3*n*8+16*POINT_CAP*24
    require(preflight<=MAJOR_BUDGET,'point major-buffer budget')
    def N(arm,u,v):return row_global(arm.operators(u,v,ell=ell)['U'],arm,n)
    def R(arm,u,v,mu,tau,epsilon):
        return row_global(-epsilon*cross(tau)@arm.operators(u,v,mu=mu,ell=ell)['m'],arm,n)
    bN=[N(a,1.,0.)for a in arms];meanB=sum(bN,sparse.csr_matrix((3,n)))/3
    bG=[R(a,1.,0.,a.t,a.e2,-1)for a in arms]
    bGamma=[R(a,1.,0.,-a.e2,a.t,1)for a in arms]
    Cb=sum(((Ni-meanB).T@Gi for Ni,Gi in zip(bN,bG)),zero(n))
    Cwrong=sum(((Ni-meanB).T@(Gi+Ji)for Ni,Gi,Ji in zip(bN,bG,bGamma)),zero(n))
    aN=[N(a,0.,0.)for a in arms];meanA=sum(aN,sparse.csr_matrix((3,n)))/3
    aGamma=[R(a,0.,0.,-a.e2,a.t,-1)for a in arms]
    aG=[R(a,0.,0.,-a.t,-a.e2,1)for a in arms]
    Ca=meanA.T@sum(aGamma,sparse.csr_matrix((3,n)))+sum((aN[i].T@aG[i]for i in (1,2)),zero(n))
    farN=N(arms[0],0.,1.);farG=R(arms[0],0.,1.,arms[0].e2,-arms[0].t,1);Cf=farN.T@farG
    matrices=dict(natural_joint_b=tidy(-(Cb+Cb.T)),essential_joint_a=tidy(-(Ca+Ca.T)),
                  essential_PATCH0_far_corner=tidy(-(Cf+Cf.T)),wrong_b_using_total=tidy(-(Cwrong+Cwrong.T)))
    require(sum(matrices[name].nnz for name,_,_ in GROUPS)<=POINT_CAP,'independent point stencil4096 cap')
    return matrices,dict(major_buffer_preflight_bytes=preflight,global_dense_square_allocated=False,physical_formula='-epsilon cross(tau) @ physical moment, then full Sym; no F=KU')

def read_coo(path,n,cap=POINT_CAP):
    values=[];rows=[];columns=[];seen=set()
    with Path(path).open(encoding='utf-8-sig',newline='')as f:
        reader=csv.DictReader(f)
        fields=['global_row_zero_based','global_col_zero_based','value_N_per_mm']
        require(reader.fieldnames==fields,'point COO schema')
        for row in reader:
            i,j,v=int(row[fields[0]]),int(row[fields[1]]),float(row[fields[2]])
            require(0<=i<n and 0<=j<n and (i,j)not in seen and math.isfinite(v)and v!=0.,'point COO duplicate/index/value')
            seen.add((i,j));require(len(seen)<=cap,'actual point COO capacity')
            rows.append(i);columns.append(j);values.append(v)
    return sparse.coo_matrix((values,(rows,columns)),shape=(n,n)).tocsr()

def rigid_modes(positions):
    n=3*len(positions);modes=np.zeros((n,6))
    for i,x in enumerate(positions):
        modes[3*i:3*i+3,:3]=np.eye(3)
        for r in range(3):modes[3*i:3*i+3,3+r]=np.cross(np.eye(3)[r],x)
    return modes

def qualify_points(run,packet,arms,ell,state,positions,cluster,identity):
    n=len(state);run=Path(run);packet=Path(packet)
    meta_path=identity.bind(run/'input_audit/triple_point_delta_metadata.json');meta=read(meta_path)
    required_equal={'schema':'oe-triple-endpoint-delta-matrices-v1','global_dofs':n,'actual_form':'Sym',
      'owner_packet_sha256':'bdc28e39b1cbfec38b24f2e9978e4300f6cef0656aa557ba4b12ca2830ba63ab',
      'coefficient_order':'actual_global_DOF_zero_based','value_units':'N/mm',
      'boundary_call_contract_observed':True,'observed_boundary_entity':'1EBE','observed_owner':'1EBB','declared_edge':4,
      'curve_call_observation_is_application_success':False,'all_surface_RP_and_other_BC_types_observed':False,
      'caller_globalList_commit_observed_by_this_header':False,'same_sparse_values_in_returned_triplets':True,
      'export_phase':'after_header_numeric_qualification_before_successful_return',
      'assembly_channel':'same returned TripList appended by Apply_coupling',
      'full_system_diagnostic_includes_all_point_groups':True,'internal_rigid_and_old_line_MMS_include_natural_b_only':True,
      'external_RHS_modified':False,'new_point_DOF':False,'positive_point_penalty':False,'small_values_pruned':False,
      'exact_zeros_omitted':True,'maximum_total_point_nnz':POINT_CAP,'maximum_export_bytes':EXPORT_CAP,
      'solver_or_scientific_acceptance':False}
    for key,value in required_equal.items():
        observed=required(meta,key)
        require((observed is value)if isinstance(value,bool)else observed==value,'point metadata field '+key)
    epoch=required(meta,'boundary_observation_epoch');require(type(epoch)is int and epoch>0,'point epoch required')
    require(type(required(meta,'observed_BC_gauss'))is int and meta['observed_BC_gauss']>0,'observed BC quadrature count required')
    observed=required(cluster,'endpoint_point_completion')
    for key in ['essential_curve_call_contract_observed','rows_valid','matrices_built','matrices_exported']:require(required(observed,key)is True,'actual Native point qualification '+key)
    require(required(observed,'same_solve_epoch')==epoch and required(observed,'observed_BC_gauss')==required(meta,'observed_BC_gauss'),'point/cluster epoch or gauss mismatch')
    events=[x for x in map(json.loads,identity.bind(run/'boundary_domain_probe.jsonl').read_text(encoding='utf-8-sig').splitlines())if x.get('event')=='apply_snapshot']
    require(len(events)==1,'single actual curve BC invocation')
    bc=events[0]
    for key,value in {'epoch':epoch,'surface':7867,'boundary_entity':7870,'declared_owner':7867,'declared_edge':4,'gauss':meta['observed_BC_gauss']}.items():require(required(bc,key)==value,'actual BC call field '+key)
    values=required(bc,'prescribed_global')
    require(required(bc,'active_components')==[True]*6 and len(values)==6 and all(type(v)in(int,float)and math.isfinite(v)and v==0. for v in values),'strict actual homogeneous six-payload clamp')
    require(required(bc,'api_edge')in(0,4),'actual curve BC API edge')
    curve=required(bc,'curve');cp=np.asarray(required(curve,'control_global'),float).reshape(-1,3)
    knots=np.asarray(required(curve,'knots'),float);m=required(curve,'m');p=required(curve,'degree')
    require(1<=p<m<=4096 and len(cp)==m and len(knots)==m+p+1 and np.isfinite(cp).all()and np.isfinite(knots).all(),'complete curve schema')
    lo,hi=knots[p],knots[m]
    require(hi>lo and np.all(knots[1:]>=knots[:-1])and np.all(knots[:p+1]==lo)and np.all(knots[m:]==hi),'clamped full curve knots')
    for knot in sorted(set(knots[p+1:m])):require(lo<knot<hi and np.count_nonzero(knots==knot)<=p,'continuous interior curve knots')
    A=arms[0].origin;B=A+arms[0].dv
    require((np.linalg.norm(cp[0]-A)<=1e-8 and np.linalg.norm(cp[-1]-B)<=1e-8)or(np.linalg.norm(cp[-1]-A)<=1e-8 and np.linalg.norm(cp[0]-B)<=1e-8),'complete PATCH0 x0 curve endpoints')
    line=cp[-1]-cp[0];length2=float(line@line);require(length2>0,'nondegenerate observed curve')
    parameter=(cp-cp[0])@line/length2
    require(np.max(np.linalg.norm(cp-cp[0]-parameter[:,None]*line,axis=1))<=1e-8 and np.min(parameter)>=-1e-12 and np.max(parameter)<=1+1e-12 and np.min(np.diff(parameter))>=-64*np.finfo(float).eps,'monotone complete straight CV net; legacy straight flag not authority')
    expected,preflight=point_matrices(arms,ell,n);actual={};checks=[]
    entries=required(meta,'groups');require(len(entries)==3,'exactly three point groups')
    by_file={required(x,'file'):x for x in entries};require(set(by_file)=={f for _,f,_ in GROUPS},'point group filenames')
    count=0;total_bytes=meta_path.stat().st_size
    # The copied sealed packet must contain untouched actual COO and metadata too.
    identity.bind(packet/meta_path.name,sha(meta_path))
    seal=read(identity.bind(packet/'boundary_action_binding.json'))
    for name,filename,role in GROUPS:
        row=by_file[filename];require(required(row,'role')==role,'point role')
        path=identity.bind(run/'input_audit'/filename);identity.bind(packet/filename,sha(path))
        require(filename in required(seal,'audit_files')and required(seal['audit_files'][filename],'sha256')==sha(path),'actual point COO absent from packet seal')
        matrix=read_coo(path,n);count+=matrix.nnz;total_bytes+=path.stat().st_size
        require(count<=POINT_CAP and total_bytes<=EXPORT_CAP,'cumulative point stencil/export capacity')
        require(matrix.nnz==required(row,'nnz'),'point exported nnz')
        difference=tidy(matrix-expected[name]);scale=max(norm(expected[name]),np.finfo(float).tiny)
        relative=norm(difference)/scale;require(relative<=MATRIX_BUDGET,'actual point matrix disagrees with independent physical incidence '+name)
        symmetry=norm(tidy(matrix-matrix.T))/max(norm(matrix),np.finfo(float).tiny)
        require(symmetry<=MATRIX_BUDGET,'point matrix symmetry')
        actual[name]=matrix;checks.append(dict(group=name,role=role,actual_nnz=matrix.nnz,physical_nnz=expected[name].nnz,
            matrix_relative_Frobenius_difference=relative,matrix_symmetry_relative=symmetry,
            actual_action_difference_L2_N=float(np.linalg.norm((matrix-expected[name])@state))))
    require(count<=POINT_CAP and total_bytes<=EXPORT_CAP,'actual total point stencil/export budget')
    require('triple_point_delta_metadata.json'in seal['audit_files']and seal['audit_files']['triple_point_delta_metadata.json']['sha256']==sha(meta_path),'actual point metadata absent from packet seal')
    require(list(required(observed,'nnz_by_role'))==[actual[k].nnz for k,_,_ in GROUPS],'cluster point nnz list')
    rigid=rigid_modes(positions);natural=actual['natural_joint_b'];den=max(norm(natural)*np.linalg.norm(rigid),np.finfo(float).tiny)
    rigid_defect=float(np.linalg.norm(natural@rigid)/den);require(rigid_defect<=MATRIX_BUDGET,'actual natural point rigid-null failure')
    actions={key:matrix@state for key,matrix in actual.items()}
    return actual,expected,actions,dict(status='ACTUAL_POINT_COO_MATCHED_BOUNDED_PHYSICAL_INCIDENCES',groups=checks,
      total_actual_nnz=count,actual_serialized_bytes=total_bytes,natural_only_rigid_relative=rigid_defect,
      internal_natural_only=True,essential_groups_are_boundary_reactions=True,actual_U_used=True,
      scope='operator/identity qualification, not physical response accuracy',**preflight)
