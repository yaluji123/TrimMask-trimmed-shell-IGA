"""Mandatory explicit v7 identities; read-only provenance, never numerical acceptance."""
from pathlib import Path
import hashlib,json,re

V7_SOURCE='90f72156bd9f1430e25177e91b6a69b89c4434f81934dfdee19b20eef2a96566'
CORE_SHA='e52b2ff82da8f02b4ef77d4676fb0388444ca036319f0b048108b2365e2c54ff'
HEADERS={'IGAforCAD/OETripleClusterNativeV1.h':'e89b3d7cd82f30acf0be06c881063c52f34a4f49f879723b5da5e488b8b39bb1',
         'IGAforCAD/OEBoundaryDomainDebugV2.h':'1130b74c0ab24ae218d7805cd0a85f1e28a9bbd8876b3b00459a4ae6742a19e7'}

def require(ok,message):
    if not ok:raise ValueError(message)

def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb')as f:
        for data in iter(lambda:f.read(1<<20),b''):h.update(data)
    return h.hexdigest()

def digest(value):
    require(isinstance(value,str)and re.fullmatch('[0-9a-f]{64}',value)is not None,'explicit nonempty SHA256 required')
    return value

def required(obj,key):
    require(isinstance(obj,dict)and key in obj and obj[key]is not None,'missing mandatory field '+key)
    return obj[key]

def read(path):return json.loads(Path(path).read_text(encoding='utf-8-sig'))

def clean(x):
    import numpy as np
    if isinstance(x,np.generic):return x.item()
    if isinstance(x,np.ndarray):return x.tolist()
    if isinstance(x,dict):return {str(k):clean(v)for k,v in x.items()}
    if isinstance(x,(list,tuple)):return [clean(v)for v in x]
    return x

def identity_arguments(parser):
    parser.add_argument('--prep',type=Path,required=True)
    parser.add_argument('--source-root',type=Path,required=True)
    parser.add_argument('--source-binding',type=Path,required=True)
    parser.add_argument('--source-binding-sha256',required=True)
    parser.add_argument('--runtime-manifest',type=Path,required=True)
    parser.add_argument('--runtime-manifest-sha256',required=True)

class Identity:
    def __init__(self,args):
        self.prep=args.prep.resolve();self.root=args.source_root.resolve();self.inputs={};self.allowed_runtime={}
        self.source_sha=digest(args.source_binding_sha256);self.runtime_sha=digest(args.runtime_manifest_sha256)
        require(self.source_sha==V7_SOURCE,'this successor requires the exact qualified v7 source; no 55f relabelling')
        require(self.root==self.prep/'candidate_source_point_complete_v7','explicit isolated source root required')
        self.binding=read(self.bind(args.source_binding,self.source_sha))
        require(Path(required(self.binding,'source_root')).resolve()==self.root,'binding/source-root mismatch')
        members=required(self.binding,'actual_source')
        require(required(self.binding,'actual_source_count')==1212 and len(members)==1212,'complete1212 source binding required')
        seen=set();self.source_members={}
        for item in members:
            rel=Path(required(item,'path'));require(not rel.is_absolute()and '..'not in rel.parts and str(rel)not in seen,'invalid source member')
            seen.add(str(rel));path=self.bind(self.root/rel,digest(required(item,'sha256')))
            self.source_members[rel.as_posix()]=item['sha256']
            require(path.stat().st_size==required(item,'bytes'),'source member byte count')
        for rel,h in HEADERS.items():self.bind(self.root/rel,h)
        self.runtime=read(self.bind(args.runtime_manifest,self.runtime_sha))
        self.verify_manifest(self.runtime)
        self.qualify_runtime_paths(self.runtime)
        self.bind(Path(__file__).with_name('cluster_physical_core.py'),CORE_SHA)
        import cluster_physical_core
        require(Path(cluster_physical_core.__file__).resolve()==Path(__file__).with_name('cluster_physical_core.py').resolve(),'physical core import path must be this preserved copy')
        for name in ['point_identity_v7.py','line_reader_v7.py','point_physical_sparse_v7.py','postprocess_point_complete_v7.py','physical_mms_frozen.py']:
            self.bind(Path(__file__).with_name(name))

    def bind(self,path,expected=None):
        raw=Path(path);require(not raw.is_symlink(),'symlink input rejected')
        path=raw.resolve();require(path.is_file(),'missing input: '+str(path))
        require(path.is_relative_to(self.prep)or path in self.allowed_runtime,'unqualified external input rejected before reading')
        h=sha(path)
        if not path.is_relative_to(self.prep):
            require(path in self.allowed_runtime,'outside PREP and not an explicit qualified runtime member: '+str(path))
            expected_runtime,expected_bytes=self.allowed_runtime[path]
            require(path.parent==self.runtime_stage and raw.parent.resolve()==self.runtime_stage and path.stat().st_size==expected_bytes and h==expected_runtime,'qualified external runtime path/hash/bytes drift')
        if expected is not None:require(h==digest(expected),'input SHA mismatch: '+str(path))
        require(path not in self.inputs or self.inputs[path]==h,'input changed during read')
        self.inputs[path]=h;return path


    def qualify_runtime_paths(self,m):
        # Called only after explicit manifest SHA and verify_manifest() qualification.
        stage=Path(required(m,'new_ASCII_stage'))
        require(stage.is_absolute()and str(stage).isascii()and not stage.is_symlink()and not stage.is_junction(),'explicit qualified ASCII runtime stage')
        self.runtime_stage=stage.resolve();allowed={}
        names=[required(row,'name')for row in required(m,'runtime')]
        require(len(names)==8 and set(names)=={'IGAforCAD.crx','JYH_IGAEntity.dbx','mkl_core.2.dll','libiomp5md.dll','mkl_intel_thread.2.dll','mkl_def.2.dll','mkl_avx2.2.dll','mkl_avx512.2.dll'},'qualified exact8 runtime whitelist')
        for row in m['runtime']:
            path=stage/row['name'];resolved=path.resolve()
            require(path.is_file()and not path.is_symlink()and not path.is_junction()and resolved.parent==self.runtime_stage,'qualified runtime member path')
            h=digest(required(row,'sha256'));size=required(row,'bytes')
            require(path.stat().st_size==size and sha(path)==h,'qualified runtime member actual hash/bytes')
            allowed[resolved]=(h,size)
            require(resolved not in self.inputs or self.inputs[resolved]==h,'qualified runtime changed during initialization');self.inputs[resolved]=h
        self.allowed_runtime=allowed

    def verify_manifest(self,m):
        require(Path(required(m,'source_root')).resolve()==self.root,'runtime manifest must name new isolated source root')
        require(required(m,'actual_source_binding_sha256')==self.source_sha and required(m,'actual_source_count')==1212,'runtime/source identity mismatch')
        entries=required(m,'runtime');names={}
        for item in entries:
            name=required(item,'name');require(name not in names,'duplicate runtime name');names[name]=item
            digest(required(item,'sha256'));require(required(item,'bytes')>0,'runtime bytes required')
        require(set(names)=={'IGAforCAD.crx','JYH_IGAEntity.dbx','mkl_core.2.dll','libiomp5md.dll','mkl_intel_thread.2.dll','mkl_def.2.dll','mkl_avx2.2.dll','mkl_avx512.2.dll'},'exact complete eight-runtime set required')
        headers=required(m,'diagnostic_and_candidate_headers');by_path={x['path'].replace('\\','/'):x for x in headers}
        require(len(by_path)==len(headers),'duplicate diagnostic header identity')
        for rel,h in HEADERS.items():require(rel in by_path and required(by_path[rel],'sha256')==h,'runtime manifest missing actual applied header '+rel)
        for rel in ['IGAforCAD/OEPassiveLineLoadAudit.h','IGAforCAD/OEWeakBoundaryActionAudit.h','IGAforCAD/OEActualPatchOrderAudit.h']:
            require(rel in by_path and required(by_path[rel],'sha256')==self.source_members[rel],'runtime manifest missing bound actual action/export header '+rel)

    def verify_run(self,run,manifest,inputs):
        run=Path(run).resolve();self.bind(run/'source_runtime_manifest.json',self.runtime_sha)
        self.bind(run/'applied_source_binding.json',self.source_sha);self.verify_manifest(manifest)
        process=read(self.bind(run/'process_result.json'))
        require(required(process,'exit_code')==0 and required(process,'natural_owned_child_exit')is True and required(process,'all_processes_naturally_exited_claimed')is False,'closed owned child required')
        module=read(self.bind(run/'actual_bootstrap_module_hashes.json'))
        require(required(module,'status')=='PASS_ACTUAL_LOADED_MODULE_FILES_MATCH_MANIFEST'and required(module,'errors')==[],'actual module qualification required')
        require(required(module,'event')=='bootstrap'and required(module,'pid')==required(process,'pid'),'actual bootstrap event/owned process PID mismatch')
        require(required(module,'actual_file_paths_hashed_not_requested_paths')is True and required(module,'staged_files_relabelled_as_loaded_without_observation')is False,'actual loaded file semantics')
        actual=required(module,'verified_manifest_runtime');runtime={x['name']:x for x in manifest['runtime']}
        for role,name in [('crx','IGAforCAD.crx'),('dbx','JYH_IGAEntity.dbx')]:
            entry=required(actual,role)
            require(required(entry,'actual_sha256')==required(runtime[name],'sha256')and required(entry,'expected_sha256')==runtime[name]['sha256'],'loaded/runtime hash mismatch')
            require(required(entry,'actual_bytes')==runtime[name]['bytes']and required(entry,'same_path')is True,'loaded runtime path/bytes mismatch')
            loaded=Path(required(entry,'actual_path'));expected=Path(required(entry,'expected_path'))
            require(loaded.is_absolute()and expected.is_absolute()and loaded.resolve()==expected.resolve()and loaded.is_file()and not loaded.is_symlink(),'actual observed loaded module path')
            observed_sha=sha(loaded);require(observed_sha==runtime[name]['sha256']and loaded.stat().st_size==runtime[name]['bytes'],'actual loaded module file hash/bytes mismatch')
            resolved=loaded.resolve();require(resolved not in self.inputs or self.inputs[resolved]==observed_sha,'loaded runtime changed during read');self.inputs[resolved]=observed_sha
        for name in ['executed_profile.json','profile_recipe_receipt.json','original_input_before_after.json','launch_plan.json']:
            self.bind(run/name)
        original=read(run/'original_input_before_after.json')
        require(required(original,'exact_sha_and_mtime_unchanged')is True,'original input changed')
        for p in self.inputs:
            if p not in inputs:inputs.append(p)

    def verify_unchanged(self):
        for path,h in self.inputs.items():require(sha(path)==h,'input mutated: '+str(path))

    def fresh_output(self,path,protected=()):
        output=Path(path).resolve()
        require(not output.exists()and output.is_relative_to(self.prep),'fresh output under PREP required')
        for root in [self.root,*map(lambda p:Path(p).resolve(),protected)]:
            require(not output.is_relative_to(root),'output may not be inside source or actual input packet/run')

    def manifest(self):return [dict(path=str(p),sha256=h)for p,h in sorted(self.inputs.items())]
