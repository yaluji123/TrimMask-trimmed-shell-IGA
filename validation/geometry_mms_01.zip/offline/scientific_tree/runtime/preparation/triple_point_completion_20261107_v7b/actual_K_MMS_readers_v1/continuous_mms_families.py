"""Continuous polynomial/PDE loads. No K, ordinary U or recovered flux input.

Original fields(): exact frozen 239012... source excerpt; only material input
uses current verified arms. One separately declared axial-linear membrane field
has zero radial displacement to retain the actual homogeneous clamp.
"""
from pathlib import Path
import numpy as np
import sympy as sp
from cluster_physical_core import greville,basis_derivatives
X,Y=sp.symbols('x y',real=True);L=sp.Integer(100);S=X/L
MU=[(-1.,0.),(1.,0.),(0.,-1.),(0.,1.)]
ENDS=[((0.,1.),(0.,0.)),((1.,0.),(1.,1.)),((0.,0.),(1.,0.)),((1.,1.),(0.,1.))]
FAMILIES=('homogeneous_clamp_axial_membrane_linear',
 'homogeneous_clamp_free_corners_balanced_normal_moments',
 'homogeneous_clamp_free_corners_nontrivial_theta_membrane_balance',
 'homogeneous_clamp_nonzero_b_corner_load')
def require(ok,message):
    if not ok:raise ValueError(message)

def fields(kind,arm,i,arms):
    nu=sp.Rational(str(arm.nu));E=sp.Rational(str(arm.E));t=sp.Rational(str(arm.thickness));D=E*t**3/(12*(1-nu**2))
    D0=sp.Rational(210000)*8**3/(12*(1-sp.Rational(3,10)**2));amp=sp.Rational(1,1000)
    q=[sp.Integer(1),sp.Integer(-1),sp.sqrt(2)][i];r=[1,-1,0][i]
    radial_extra=sp.Integer(0)
    if kind=='homogeneous_clamp_axial_membrane_linear':
        theta=sp.Integer(0);A=sp.Integer(0);B=sp.Integer(0)
        h=sp.Rational(1,100)*S;translation=np.zeros(3);omega=np.zeros(3)
    elif kind=='nonzero_both_ends_manufactured_clamp':
        theta=amp*(sp.Rational(1,3)+S);A=sp.Integer(0);B=sp.Integer(0);h=sp.Integer(0)
        translation=np.array([.01,-.02,.03]);omega=np.array([1e-4,-2e-4,3e-4])
    elif kind=='homogeneous_clamp_nonzero_b_corner_load':
        theta=amp*S**2;A=sp.Rational(r,1)/D*S**2
        B=q*D0*(2-nu)*sp.diff(theta,X,2)/D
        h=sp.Rational(1,100)*S**2;translation=np.zeros(3);omega=np.zeros(3)
    elif kind=='homogeneous_clamp_free_corners_balanced_normal_moments':
        theta=sp.Integer(0);A=sp.Rational(r,1)/D*S**2*(3-2*S);B=sp.Integer(0)
        h=sp.Rational(1,100)*S**2;translation=np.zeros(3);omega=np.zeros(3)
    elif kind=='homogeneous_clamp_free_corners_nontrivial_theta_membrane_balance':
        theta=amp*S**2*(3-2*S);A=sp.Integer(0);B=(2-nu)*sp.diff(theta,X,2)
        material=[]
        for observed_arm in arms:
            ee=sp.Rational(str(observed_arm.E));nn=sp.Rational(str(observed_arm.nu));tt=sp.Rational(str(observed_arm.thickness))
            material.append((ee*tt/(1-nn**2),ee*tt**3/(12*(1-nn**2)),nn))
        normals=[sp.Matrix([0,0,1]),sp.Matrix([0,-1,0]),sp.Matrix([0,-1/sp.sqrt(2),-1/sp.sqrt(2)])]
        target=sum((dd*(2-nn)*normal for (_,dd,nn),normal in zip(material,normals)),sp.zeros(3,1))
        # beta0=0 preserves the actual homogeneous PATCH0 clamp. The other two
        # coefficients follow from exact transverse joint force conservation.
        beta2=-sp.sqrt(2)*target[1]/material[2][0]
        beta1=(target[2]-material[2][0]*beta2/sp.sqrt(2))/material[1][0]
        radial_extra=[sp.Integer(0),beta1,beta2][i]*sp.diff(theta,X,2)
        h=sp.Rational(1,100)*S**2;translation=np.zeros(3);omega=np.zeros(3)
    else:raise ValueError(kind)
    w=Y*theta-(2-nu)*Y**3*sp.diff(theta,X,2)/6+A*Y**2/2+B*Y**3/6
    ut=h;uy=sp.Integer(0) if kind=='homogeneous_clamp_axial_membrane_linear' else -nu*Y*sp.diff(h,X)+Y*radial_extra
    ex=sp.diff(ut,X);ey=sp.diff(uy,Y);gam=sp.diff(ut,Y)+sp.diff(uy,X)
    factor=E*t/(1-nu**2);N=sp.Matrix([[factor*(ex+nu*ey),factor*(1-nu)*gam/2],[factor*(1-nu)*gam/2,factor*(ey+nu*ex)]])
    H=sp.hessian(w,(X,Y));CH=D*((1-nu)*H+nu*sp.trace(H)*sp.eye(2));M=-CH
    Q=sp.Matrix([-sp.diff(CH[0,0],X)-sp.diff(CH[0,1],Y),-sp.diff(CH[1,0],X)-sp.diff(CH[1,1],Y)])
    f=sp.Matrix([-sp.diff(N[0,0],X)-sp.diff(N[0,1],Y),-sp.diff(N[1,0],X)-sp.diff(N[1,1],Y),
        D*(sp.diff(w,X,4)+2*sp.diff(w,X,2,Y,2)+sp.diff(w,Y,4))])
    scalar_expr=[ut,uy,w,sp.diff(w,X),sp.diff(w,Y),theta,sp.diff(theta,X),sp.diff(ut,X),sp.diff(uy,X)]
    funcs=[sp.lambdify((X,Y),z,'numpy') for z in [sp.Matrix(scalar_expr),N,CH,M,Q,f,M.diff(X),M.diff(Y)]]
    assert all(sp.degree(z,X)<=3 and sp.degree(z,Y)<=3 for z in [ut,uy,w])
    def eval(x,y,mu):
        vals,Nv,CHv,Mv,Qv,fv,Mx,My=[np.asarray(fn(x,y),float) for fn in funcs]
        vals=vals.ravel();mx,my=mu;mu=np.array([mx,my]);tau=np.array([-my,mx])
        pos=arm.origin+arm.t*x+arm.e2*y
        U=arm.t*vals[0]+arm.e2*vals[1]+arm.normal*vals[2]+translation+np.cross(omega,pos)
        theta_vector=arm.t*vals[4]-arm.e2*vals[3]+omega-arm.normal*(arm.normal@omega)
        # ut_x/uy_x are evaluated independently from the continuous polynomials.
        ux=vals[7];uyx=vals[8]
        Us=arm.t*ux+arm.e2*uyx+arm.normal*vals[3]+np.cross(omega,arm.t)
        phi=arm.t*(arm.t@theta_vector)+np.cross(arm.t,Us)
        T=arm.t*(Nv@mu)[0]+arm.e2*(Nv@mu)[1]+arm.normal*(Qv.ravel()@mu)
        moment=np.cross(arm.normal,arm.t*(Mv@mu)[0]+arm.e2*(Mv@mu)[1])
        dM=tau[0]*Mx+tau[1]*My;mnt=float(mu@Mv@tau);mnn=float(mu@Mv@mu)
        Fred=arm.t*(Nv@mu)[0]+arm.e2*(Nv@mu)[1]+arm.normal*(Qv.ravel()@mu+mu@dM@tau)
        fn=arm.t*fv[0,0]+arm.e2*fv[1,0]+arm.normal*fv[2,0]
        Hvec=np.cross(moment,arm.t)
        # derivative along physical common tangent, constant co-normal at joint
        ms=np.cross(arm.normal,arm.t*(Mx@mu)[0]+arm.e2*(Mx@mu)[1])
        eff=T-np.cross(ms,arm.t)
        return dict(U=U,theta=theta_vector,phi=phi,N=Nv,CH=CHv,M=Mv,T=T,m=moment,mnt=mnt,mnn=mnn,
            reduced_force=Fred,reduced_moment=(arm.t*tau[0]+arm.e2*tau[1])*mnn,body=fn,H=Hvec,effective_force=eff,
            theta_t=vals[5]+arm.t@omega,theta_t_prime=vals[6])
    return dict(eval=eval,formula=dict(w_mm=str(sp.expand(w)),u_t_mm=str(ut),u_radial_mm=str(uy),theta_t_addition_rad=str(theta),
        body_components_N_per_mm2=[str(sp.expand(z)) for z in f],D_N_mm=str(D)),funcs=funcs,
        translation=translation,omega=omega,homogeneous_clamp=kind!='nonzero_both_ends_manufactured_clamp',
        symbolic=dict(ut=ut,uy=uy,w=w,N=N,M=M,Q=Q,body=f))

def gauss(cuts,order):
    z,w=np.polynomial.legendre.leggauss(order)
    return [(float((a+b)/2+(b-a)*x/2),float((b-a)*y/2))
      for a,b in zip(cuts[:-1],cuts[1:])if b>a for x,y in zip(z,w)]

def global_row(arm,local,total):
    result=np.zeros((local.shape[0],total));result[:,arm.dofmap]=local;return result

def family_contract(arms,kind):
    require(kind in FAMILIES and len(arms)==3,'one fixed homogeneous-clamp family')
    for a,thickness in zip(arms,(8.,7.,6.)):
        require(a.E==210000. and a.nu==.3 and a.thickness==thickness and abs(a.length-100.)<=1e-8,
          'existing frozen family actual material/length scope, including its fixed D0')
    fs=[fields(kind,a,i,arms)for i,a in enumerate(arms)]
    # Exact analytic owner frames, independently checked against each actual arm.
    e2=[sp.Matrix([0,1,0]),sp.Matrix([0,0,1]),sp.Matrix([0,-1/sp.sqrt(2),1/sp.sqrt(2)])]
    normals=[sp.Matrix([0,0,1]),sp.Matrix([0,-1,0]),sp.Matrix([0,-1/sp.sqrt(2),-1/sp.sqrt(2)])]
    tangent=sp.Matrix([1,0,0]);g=sp.zeros(3,1);mu=sp.Integer(0);point=sp.zeros(3,1)
    for a,f,r,n in zip(arms,fs,e2,normals):
        require(np.linalg.norm(a.t-np.array(tangent,float).ravel())<=1e-12 and
          np.linalg.norm(a.e2-np.array(r,float).ravel())<=1e-12 and
          np.linalg.norm(a.normal-np.array(n,float).ravel())<=1e-12,'same exact analytic/actual frame')
        q=f['symbolic'];N=q['N'];M=q['M'];Q=q['Q']
        g+=(-N[0,1]*tangent-N[1,1]*r+(-Q[1]-sp.diff(M[0,1],X))*n).subs(Y,0)
        mu+=M[1,1].subs(Y,0)
        point+=2*M[0,1].subs({X:L,Y:0})*n
        # Whole actual clamp, not the over-restrictive first-two-all-component rows.
        if a is arms[0]:
            for value in [q['ut'],q['uy'],q['w'],sp.diff(q['w'],X)]:
                require(sp.simplify(value.subs(X,0))==0,'analytic full homogeneous PATCH0 clamp')
    g=g.applyfunc(sp.simplify);mu=sp.simplify(mu);point=point.applyfunc(sp.simplify)
    if kind!='homogeneous_clamp_axial_membrane_linear':
        require(g==sp.zeros(3,1)and mu==0,'old family has exact zero distributed joint load; no residual load invented')
    if 'free_corners'in kind:require(point==sp.zeros(3,1),'old free-corner family has exact zero total natural point load')
    return fs,dict(distributed_joint_force=[str(z)for z in g],common_axis_line_moment=str(mu),
      total_natural_b_point=[str(z)for z in point],homogeneous_full_PATCH0_clamp=True,
      ordinary_paper_load_claimed=False,actual_geometry_material_used=True)

def physical_rhs(arms,kind,order,ell,negative=None):
    """PDE/body + reduced natural Green + total shared natural corner. Never K*c.

    Independent test basis is used only to integrate closed physical densities.
    Essential a/far have zero prescribed value, hence no independent point source.
    """
    require(order in(6,8)and ell>0,'frozen GL6/8 and positive trace length')
    require(negative in(None,'flip_natural_force','flip_natural_moment','omit_natural_b_corner'),'declared negative only')
    fs,contract=family_contract(arms,kind);n=max(int(a.dofmap.max())for a in arms)+1
    body=np.zeros(n);outer=np.zeros(n);far=np.zeros(n);joint=np.zeros(n);point=np.zeros(n)
    joint_corners={0:[np.zeros(3)for _ in arms],1:[np.zeros(3)for _ in arms]}
    own={0:[],1:[]};far_ledger=[];force_sign=-1 if negative=='flip_natural_force'else 1
    moment_sign=-1 if negative=='flip_natural_moment'else 1
    for i,(a,f)in enumerate(zip(arms,fs)):
        for u,wu in gauss(sorted(set(a.ku)),order):
            for v,wv in gauss(sorted(set(a.kv)),order):
                z=f['eval'](a.length*u,a.width*v,(0.,-1.));o=a.operators(u,v,ell=ell)
                np.add.at(body,a.dofmap,np.linalg.norm(np.cross(a.du,a.dv))*wu*wv*o['U'].T@z['body'])
        corners={}
        for edge,mu in enumerate(MU):
            mu_world=a.t*mu[0]+a.e2*mu[1];variable=a.kv if edge<2 else a.ku
            length=a.width if edge<2 else a.length
            if edge!=2 and not(i==0 and edge==0):
                for s,weight in gauss(sorted(set(variable)),order):
                    u,v=(float(edge),s)if edge<2 else(s,float(edge==3))
                    z=f['eval'](a.length*u,a.width*v,mu);o=a.operators(u,v,mu=mu_world,ell=ell)
                    local=length*weight*(force_sign*o['U'].T@z['reduced_force']+moment_sign*o['theta'].T@z['reduced_moment'])
                    np.add.at(outer,a.dofmap,local)
            for uv,sign in zip(ENDS[edge],(1.,-1.)):
                z=f['eval'](a.length*uv[0],a.width*uv[1],mu);corner=sign*z['mnt']*a.normal
                if edge==2:own[int(uv[0])].append(corner);continue
                if i==0 and edge==0:continue
                corners[uv]=corners.get(uv,np.zeros(3))+corner
        for uv,value in corners.items():
            if uv[1]==0.:joint_corners[int(uv[0])][i]+=value;continue
            essential=i==0 and uv[0]==0.
            far_ledger.append(dict(owner=hex(a.handle),uv=list(uv),force_N=value.tolist(),essential=essential))
            if not essential:np.add.at(far,a.dofmap,a.operators(*uv,ell=ell)['U'].T@value)
    # Explicit analytic Gamma load, rather than a fitted p_hat. The old three
    # families were required above to have exactly zero g and common moment.
    cuts=sorted({float(x)for a in arms for x in a.ku})
    for u,weight in gauss(cuts,order):
        density=[f['eval'](a.length*u,0.,(0.,-1.))for a,f in zip(arms,fs)]
        g=sum(z['effective_force']for z in density);mt=sum(a.t@z['m']for a,z in zip(arms,density))
        if kind!='homogeneous_clamp_axial_membrane_linear':g=np.zeros(3);mt=0.
        for a in arms:
            o=a.operators(u,0.,ell=ell)
            local=a.length*weight/3*(force_sign*o['U'].T@g+moment_sign*(a.t@o['theta']).T*mt)
            np.add.at(joint,a.dofmap,local)
    total_b=sum(own[1])+sum(joint_corners[1])
    if negative!='omit_natural_b_corner':
        for a in arms:np.add.at(point,a.dofmap,a.operators(1.,0.,ell=ell)['U'].T@total_b/3)
    result=body+outer+far+joint+point
    require(np.isfinite(result).all()and np.linalg.norm(result)>0,'finite nonzero independent physical RHS')
    ledger=dict(analytic_contract=contract,body_rhs=body,outer_reduced_natural_rhs=outer,
      far_natural_point_rhs=far,joint_distributed_mean_rhs=joint,natural_b_mean_point_rhs=point,
      total_natural_b_point_N=total_b.tolist(),Gamma_own_b_corner_N=sum(own[1]).tolist(),
      adjacent_outer_b_corner_N=[v.tolist()for v in joint_corners[1]],far_corners=far_ledger,
      shared_essential_a_external_point_source=False,essential_far_external_point_source=False,
      RHS_accepts_K_or_ordinary_U=False,negative=negative,quadrature_order=order)
    return result,fs,ledger

def exact_coefficients(arms,fs):
    """Basis interpolation of the fixed degree<=3 continuous field; never K solve."""
    n=max(int(a.dofmap.max())for a in arms)+1;exact=np.zeros(n);seen=set();proof=[]
    for a,f in zip(arms,fs):
        gu=greville(a.ku,3,a.m);gv=greville(a.kv,3,a.n)
        Bu=np.array([basis_derivatives(a.ku,3,x)[0]for x in gu]);Bv=np.array([basis_derivatives(a.kv,3,y)[0]for y in gv])
        values=np.array([[f['eval'](a.length*u,a.width*v,(0.,-1.))['U']for v in gv]for u in gu])
        coefficients=np.zeros_like(values)
        for c in range(3):coefficients[:,:,c]=np.linalg.solve(Bu,np.linalg.solve(Bv,values[:,:,c].T).T)
        reconstruction=np.einsum('ij,jkc,lk->ilc',Bu,coefficients,Bv)
        error=float(np.linalg.norm(reconstruction-values)/max(np.linalg.norm(values),1e-30))
        require(error<=1e-10,'unchanged cubic interpolation representation budget')
        for index,value in zip(a.dofmap,coefficients.ravel()):
            require(index not in seen or abs(exact[index]-value)<=1e-10*max(abs(value),1.),'shared Node exact field compatibility')
            seen.add(int(index));exact[index]=value
        proof.append(dict(owner=hex(a.handle),interpolation_relative_error=error,degree_each_coordinate_at_most_three=True))
    require(len(seen)==n and np.isfinite(exact).all(),'all actual coefficients represented')
    return exact,proof
