"""Evaluate the complete final spline state at every independent reference node."""
from pathlib import Path
import argparse,csv,json,hashlib
import numpy as np
from scipy.interpolate import BSpline
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def evaluate(uv,ku,kv,coefficients):
 m,n,_=coefficients.shape;result=np.empty((len(uv),coefficients.shape[-1]));partition=0.
 for begin in range(0,len(uv),32768):
  p=uv[begin:begin+32768];bu=BSpline.design_matrix(p[:,0],ku,3,extrapolate=False);bv=BSpline.design_matrix(p[:,1],kv,3,extrapolate=False)
  assert np.all(np.diff(bu.indptr)==4)and np.all(np.diff(bv.indptr)==4)
  iu=bu.indices.reshape(-1,4);iv=bv.indices.reshape(-1,4);weight=bu.data.reshape(-1,4,1)*bv.data.reshape(-1,1,4);partition=max(partition,float(np.max(np.abs(weight.sum((1,2))-1))))
  result[begin:begin+len(p)]=np.einsum('pij,pijc->pc',weight,coefficients[iu[:,:,None],iv[:,None,:]],optimize=True)
 assert partition<1e-12
 return result,partition
def run(a):
 nr=read(a.native_results);fr=read(a.reference_results);conv=read(a.reference_convergence)
 assert nr['status']=='PASS_TRIANGLE_H_FAMILY_NATIVE_AND_INDEPENDENT_OPERATOR_ONLY'and conv['status']=='PASS_INDEPENDENT_P2_MEMBRANE_REFERENCE_0P1PERCENT_CRITERION'
 assert fr['source_sha256']=='85e40ee9819d50d6d3bb7a8499a4dc219a97a10a8b1cbaf31b5aa5f1cd59810e'
 assert not a.output.exists();a.output.mkdir();g=read(a.native_geometry);state=np.load(a.native_state);ref=np.load(a.reference_state);m,n=g['controls_u'],g['controls_v']
 cp=state['cp'].reshape(m,n,3);coeff=np.concatenate([cp,state['U'].reshape(m,n,3)],axis=2);ku=state['knots_u'];kv=state['knots_v'];J=state['J'];origin=ref['origin'];world=np.column_stack([ref['points']+origin,np.zeros(len(ref['points']))]);uv=(world[:,:2]-cp[0,0,:2])@np.linalg.inv(J[:2]).T
 # Only roundoff outside the proven carrier is projected; every physical point is preserved.
 originalUV=uv.copy();assert uv.min()>=-512*np.finfo(float).eps and uv.max()<=1+512*np.finfo(float).eps
 uv=np.clip(uv,0,1);roundoffClips=int(np.count_nonzero(np.any(uv!=originalUV,axis=1)));values,partition=evaluate(uv,ku,kv,coeff);gap=np.linalg.norm(values[:,:3]-world,axis=1);tolerance=max(1e-8,max(np.linalg.norm(J[:,0]),np.linalg.norm(J[:,1]))*1e-10);assert np.max(gap)<=tolerance
 iga=values[:,3:];fem=np.column_stack([ref['U'],np.zeros(len(ref['U']))]);assert np.isfinite(iga).all()and np.isfinite(fem).all()
 # Direct state evaluation is checked against all actual producer displacement samples.
 with a.native_samples.open(encoding='utf-8-sig',newline='')as f:export=list(csv.DictReader(f))
 exportUV=np.array([[float(r['u']),float(r['v'])]for r in export]);exportU=np.array([[float(r[k])for k in ['ux','uy','uz']]for r in export]);computed,_=evaluate(exportUV,ku,kv,coeff);exportError=np.linalg.norm(computed[:,3:]-exportU,axis=1);assert np.max(exportError)<1e-8
 # Evaluate the true retained apex, independently of any rounded display vertex.
 apexUV=np.asarray(g['outer_loop'][0],dtype=float).reshape(1,2);apex,_=evaluate(apexUV,ku,kv,coeff);apexRef=np.array(fr['peak_location_mm']+[0.]);assert np.linalg.norm(apex[0,:3]-apexRef)<=tolerance
 conn=ref['triangles'];assert conn.shape[1]==6
 display=np.concatenate([conn[:,[0,3,5]],conn[:,[3,1,4]],conn[:,[5,4,2]],conn[:,[3,4,5]]]);assert len(display)==4*len(conn)
 np.savez_compressed(a.output/'physical_fields.npz',points=ref['points'],world=world,triangles=display,P2_connectivity=conn,IGA_U=iga,FEM_U=fem,uv=uv,origin=origin)
 peakIGA=float(np.linalg.norm(apex[0,3:]));peakFEM=fr['peak_U_mm'];richardson=conv['Richardson_estimates']['peak_U_mm']['extrapolated_limit'];difference=np.linalg.norm(iga-fem,axis=1)
 result=dict(status='PASS_ALL_REFERENCE_NODES_SAME_PHYSICAL_TRIANGLE_FIELD_DATA',points=len(world),P2_elements=len(conn),display_triangles=len(display),excluded_nodes=0,excluded_elements=0,carrier_roundoff_projection_count=roundoffClips,max_physical_registration_gap_mm=float(np.max(gap)),original_physical_registration_tolerance_mm=tolerance,partition_of_unity_error=partition,actual_export_sample_count=len(export),all_actual_export_samples_max_U_difference_mm=float(np.max(exportError)),true_apex_IGA_U_mm=peakIGA,reference_fine_peak_U_mm=peakFEM,reference_Richardson_estimated_peak_U_mm=richardson,relative_apex_gap_to_fine_reference=abs(peakIGA-peakFEM)/peakFEM,relative_apex_gap_to_extrapolated_estimate=abs(peakIGA-richardson)/richardson,max_nodal_vector_difference_mm=float(difference.max()),material_energy_IGA_Nmm=nr['material_energy_Nmm'],material_energy_reference_Nmm=fr['material_energy_Nmm'],material_energy_relative_difference=abs(nr['material_energy_Nmm']-fr['material_energy_Nmm'])/fr['material_energy_Nmm'],all_requested_observations_used=True,not_a_stress_or_transverse_bending_certificate=True,reference_estimate_not_rigorous_continuum_bound=True,producer_sha256=sha(Path(__file__)),field_data_sha256=sha(a.output/'physical_fields.npz'))
 imax=int(np.linalg.norm(iga,axis=1).argmax());result.update(maximum_IGA_U_on_all_reference_nodes_mm=float(np.linalg.norm(iga[imax])),maximum_IGA_node_world_mm=world[imax].tolist(),unweighted_reference_node_vector_relative_difference=float(np.linalg.norm(iga-fem)/np.linalg.norm(fem)),unweighted_node_metric_not_continuous_L2=True)
 (a.output/'physical_field_summary.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
 sources={key:dict(path=str(getattr(a,key)),sha256=sha(getattr(a,key)))for key in ['native_state','native_geometry','native_samples','native_results','reference_state','reference_results','reference_convergence']};(a.output/'internal_input_manifest.json').write_text(json.dumps(sources,indent=2),encoding='utf-8');print(json.dumps(result))
if __name__=='__main__':raise SystemExit('Use read_single_patch_v7.py strict current identity')
