"""Bounded actual729 default/cyclic readback; no Native/compiler/job launcher."""
from pathlib import Path
import argparse,csv,hashlib,json,os
for key in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS']:os.environ[key]='1'
import numpy as np
from series_context_v7 import Context,common_arguments,require,read as read_json,sha as digest,clean,SOURCE,RUNTIME
OWNERS=(0x1ebb,0x1ebc,0x1ebd)

def relnorm(a,b):
    a=np.asarray(a);b=np.asarray(b);den=max(float(np.linalg.norm(a)),float(np.linalg.norm(b)))
    return float(np.linalg.norm(a-b))/den if den else 0.

def finite(a):
    a=np.asarray(a,float);require(np.all(np.isfinite(a)),'nonfinite observation');return a

def coo(path,n,fields,cap=200000):
    a=np.zeros((n,n));seen=set()
    with path.open(encoding='utf-8-sig',newline='') as f:
        reader=csv.DictReader(f);require(reader.fieldnames==fields,'COO schema '+str(path))
        for row in reader:
            i=int(row[fields[0]]);j=int(row[fields[1]]);v=float(row[fields[2]])
            require(0<=i<n and 0<=j<n and (i,j) not in seen and np.isfinite(v) and v!=0.,'COO index/duplicate/nonfinite/zero')
            seen.add((i,j));require(len(seen)<=cap,'COO entry cap');a[i,j]=v
    return a

def build_signature(manifest):
    runtime={x['name']:(x['sha256'],x['bytes']) for x in manifest['runtime']}
    require({'IGAforCAD.crx','JYH_IGAEntity.dbx'}<=set(runtime),'runtime identity missing')
    headers={x['path']:x['sha256'] for x in manifest['diagnostic_and_candidate_headers']}
    require({'OEActualPatchOrderAudit.h','OEWeakBoundaryActionAudit.h','OEConstantStrainBilinearProbe.h'}<={Path(k).name for k in headers},'new actual audit headers not bound')
    return {'runtime':runtime,'changed_source':{x['path']:x['after_sha256'] for x in manifest['changed_source_files']},'headers':headers,'build_log_sha256':manifest['build_log_sha256']}

def observed_map(audit,arms,mode,inputs):
    p=audit/'patch_numbering_order.json';inputs.append(p);meta=read_json(p)
    require(meta.get('schema')=='oe_actual_patch_numbering_order_v1' and meta['mode']==mode,'actual order mode/schema')
    require(meta['global_dofs']==729 and meta['global_nodes']==243,'coarse exact dimensions')
    for flag in ['empty_registry_before_first_registration_verified','actual_Node_and_registry_SN_verified','after_strong_translation_numbering_unchanged']:
        require(meta.get(flag) is True,'missing actual numbering witness '+flag)
    require(meta.get('relation_enumeration_modified') is False,'unexpected relation enumeration change')
    expected=list(OWNERS) if mode=='default_ascending' else [OWNERS[-1],*OWNERS[:-1]]
    require(meta['default_sorted_handles']==list(OWNERS) and meta['actual_numbering_traversal']==expected,'actual traversal witness')
    p=audit/'patch_numbering_observed.csv';inputs.append(p)
    with p.open(encoding='utf-8-sig',newline='') as f:
        reader=csv.DictReader(f);require(reader.fieldnames==['shell_handle','numbering_owner_ordinal','local_cp','Node_one_based','global_dof_x_zero_based','cp_x','cp_y','cp_z'],'observed Node CSV schema');rows=list(reader)
    require(len(rows)==243,'all actual control points required')
    byowner={a.handle:a for a in arms};mapping={};seen=set()
    for row in rows:
        h=int(row['shell_handle']);cp=int(row['local_cp']);node=int(row['Node_one_based']);g=int(row['global_dof_x_zero_based']);ordinal=int(row['numbering_owner_ordinal'])
        require(h in byowner and 0<=cp<81 and 0<=ordinal<3 and expected[ordinal]==h,'Node owner/local/ordinal')
        require((h,cp) not in seen and g==3*(node-1),'duplicate or inconsistent actual Node');seen.add((h,cp));arm=byowner[h]
        require(arm.m*arm.n==81 and np.array_equal([float(row[k]) for k in ['cp_x','cp_y','cp_z']],arm.cp[cp]),'actual CP identity')
        for c in range(3):
            key=(h,cp,c);require(g+c==int(arm.dofmap[3*cp+c]),'Node map disagrees with actual cluster/force map');mapping[key]=g+c
    require(len(mapping)==729 and set(mapping.values())==set(range(729)),'mapping must cover each actual DOF once')
    return meta,mapping

def dense_diagnostics(K,F,X,Fexternal,tau_rep,tau_back,rhs_tol):
    # Direct floating calculations on the original exported solver argument.
    tau_rep=float(tau_rep);tau_back=float(tau_back);rhs_tol=float(rhs_tol)
    singular=np.linalg.svd(K,compute_uv=False);smax=float(singular[0]);smin=float(singular[-1])
    require(smin>0 and np.all(np.isfinite(singular)),'singular/nonfinite original matrix')
    inverse=np.linalg.solve(K,np.eye(len(X)));inverse_residual=K@inverse-np.eye(len(X))
    norm1=float(np.linalg.norm(K,1));invnorm1=float(np.linalg.norm(inverse,1));cond1=norm1*invnorm1
    residual=K@X-F;ri=float(np.linalg.norm(residual,np.inf));r2=float(np.linalg.norm(residual));x2=float(np.linalg.norm(X));f2=float(np.linalg.norm(F))
    eta2=r2/(smax*x2+f2) if smax*x2+f2 else 0.
    deninf=float(np.linalg.norm(K,np.inf))*float(np.linalg.norm(X,np.inf))+float(np.linalg.norm(F,np.inf));etainf=ri/deninf if deninf else 0.
    component_den=np.abs(K)@np.abs(X)+np.abs(F);component=np.divide(np.abs(residual),component_den,out=np.zeros_like(residual),where=component_den!=0)
    require(np.all((component_den!=0)|(residual==0)),'zero backward denominator with nonzero residual')
    ext2=float(np.linalg.norm(Fexternal));extinf=float(np.linalg.norm(Fexternal,np.inf));require(ext2>0 and extinf>0,'physical external N normalization undefined')
    symmetry=float(np.linalg.norm(K-K.T))/max(float(np.linalg.norm(K)),1e-300)
    # Diagnosis only; this symmetric part never replaces actual K/F or X.
    eig=np.linalg.eigvalsh((K+K.T)/2);lam_min=float(eig[0]);margin=tau_rep*smax
    result={'matrix_source':'original exported actual solver K; no replacement or repair','direct_dense_floating_condition1':cond1,'direct_dense_floating_condition2':smax/smin,'singular_max_N_per_mm':smax,'singular_min_N_per_mm':smin,'inverse_norm1':invnorm1,'inverse_residual_Linf':float(np.linalg.norm(inverse_residual,np.inf)),'inverse_normwise_backward':float(np.linalg.norm(inverse_residual,np.inf))/(float(np.linalg.norm(K,np.inf))*float(np.linalg.norm(inverse,np.inf))+1),'symmetry_relative_Frobenius':symmetry,'diagnostic_symmetric_part_min_eigenvalue':lam_min,'diagnostic_SPD_margin':margin,'interval_SPD_certificate':False,'residual_L2_N':r2,'residual_Linf_N':ri,'residual_L2_over_actual_external_force_L2':r2/ext2,'residual_Linf_over_actual_external_force_Linf':ri/extinf,'normwise_backward_2':eta2,'normwise_backward_inf':etainf,'maximum_normwise_backward':max(eta2,etainf),'maximum_componentwise_backward_report_only':float(np.max(component)),'physical_flux_accuracy_inferred':False,'gates':{'symmetry':symmetry<=tau_rep,'numeric_SPD_with_roundoff_margin':lam_min>margin,'normwise_backward':max(eta2,etainf)<=tau_back,'actual_RHS_N_normalized_numerical_closure':max(r2/ext2,ri/extinf)<=rhs_tol}}
    return result,residual

def compare_runs(a,b,protocol):
    n=729;eps=float(np.finfo(float).eps);tau=max(1e-12,64*n*eps);tau_cal=protocol['calibration_relative_tolerance']
    require(a['signature']==b['signature'],'different actual source/runtime/build')
    for field in ['source_sha256','refine_factor','stored_relation_form','explicit_actual_form','omit_penalty_relation','analysis_profile_sha256','profile_recipe_receipt_sha256','boundary_gauss_order','profile_role']:
        require(a['launch'][field]==b['launch'][field],'different input/launch '+field)
    for key in ['owner_packet_sha256','global_dofs','fixed_physical_omit_handle','ell','base_alpha']:
        require(a['meta'][key]==b['meta'][key],'different physical order settings '+key)
    require(a['geometry']==b['geometry'],'different full geometry/material/reference frame observations')
    keys=sorted(a['mapping']);require(keys==sorted(b['mapping']),'different physical basis key set')
    g0=np.array([a['mapping'][k] for k in keys]);g1=np.array([b['mapping'][k] for k in keys]);changed=int(np.count_nonzero(g0!=g1))
    require(changed==n,'ORDER_NOT_EXERCISED: all729 actual DOFs must change')
    K0=a['K'][np.ix_(g0,g0)];K1=b['K'][np.ix_(g1,g1)];F0=a['F'][g0];F1=b['F'][g1];X0=a['X'][g0];X1=b['X'][g1]
    dk=float(np.linalg.norm(K1-K0));df=float(np.linalg.norm(F1-F0));dx=float(np.linalg.norm(X1-X0));x0=float(np.linalg.norm(X0));require(x0>0,'zero solution bound undefined')
    bound=(df+dk*float(np.linalg.norm(X1))+float(np.linalg.norm(a['residual']))+float(np.linalg.norm(b['residual'])))/(a['diagnostics']['singular_min_N_per_mm']*x0)
    xtol=max(tau,8*bound);x_inconclusive=xtol>=protocol['X_bound_inconclusive_if_tolerance_greater_equal']
    calibration=[]
    def cal(name,x,y):
        v=relnorm(x,y);calibration.append({'quantity':name,'relative_difference':v,'gate':v<=tau_cal})
    for h in OWNERS:
        aa=next(v for v in a['cluster']['arms'] if int(v['handle'],16)==h);bb=next(v for v in b['cluster']['arms'] if int(v['handle'],16)==h)
        cal(f'lambda_owner_{h}',aa['lambda_practical_union_metric'],bb['lambda_practical_union_metric'])
    for field in ['rho','effective_alpha']:cal(field,a['cluster']['graph_calibration'][field],b['cluster']['graph_calibration'][field])
    selected=lambda c:{x['handle'] for x in c['relations'] if x['selected_penalty']}
    require(selected(a['cluster'])==selected(b['cluster']),'different selected physical graph')
    cal('selected_beta_canonical_relation_order',a['cluster']['selected_beta'],b['cluster']['selected_beta'])
    bc=[]
    for arm0,arm1 in zip(a['arms'],b['arms']):
        h=arm0.handle;require(h==arm1.handle,'owner order');H0,f0=a['boundary'][h];H1,f1=b['boundary'][h];u0=arm0.coeff;u1=arm1.coeff
        aa=a['action'][arm0.dofmap];ab=b['action'][arm1.dofmap];pred=H0@(u1-u0)+(H1-H0)@u1-(f1-f0);difference=(ab-aa)-pred
        scale=np.abs(H0)@np.abs(u1-u0)+np.abs(H1-H0)@np.abs(u1)+np.abs(f1-f0)+np.abs(aa)+np.abs(ab)
        den=float(np.linalg.norm(scale,np.inf));cov=float(np.linalg.norm(difference,np.inf))/den if den else 0.
        bc.append({'owner':hex(h),'deltaH_relative_Frobenius_difference':relnorm(H0,H1),'deltaF_relative_difference':relnorm(f0,f1),'aBC_actual_mapped_relative_difference':relnorm(aa,ab),'aBC_actual_max_absolute_difference_N':float(np.max(np.abs(ab-aa))),'aBC_X_operator_covariance_operation_scaled_error':cov,'gate':relnorm(H0,H1)<=tau and relnorm(f0,f1)<=tau and cov<=tau})
    mapped_external=relnorm(a['Fext'][g0],b['Fext'][g1]);krel=dk/max(float(np.linalg.norm(K0)),float(np.linalg.norm(K1)));frel=relnorm(F0,F1);xrel=dx/x0
    gates={'all729_observed_global_DOFs_changed':changed==n,'K_PKP_Frobenius':krel<=tau,'assembled_RHS_PF':frel<=tau,'pure_external_PF':mapped_external<=tau,'X_perturbation_bound':not x_inconclusive and xrel<=xtol,'same_practical_calibration':all(v['gate'] for v in calibration),'boundary_operator_and_action_covariance':all(v['gate'] for v in bc),'baseline_numeric_gates':all(a['diagnostics']['gates'].values()),'alternate_numeric_gates':all(b['diagnostics']['gates'].values())}
    return {'status':'PASS_CAPTURED_NUMERICAL_ORDER_CONTROLS_ONLY' if all(gates.values()) else ('NUMERICALLY_INCONCLUSIVE_ORDER_CONTROLS' if x_inconclusive else 'FAIL_CAPTURED_NUMERICAL_ORDER_CONTROLS'),'gates':gates,'actual_changed_DOFs':changed,'observed_permutation':[[int(h),int(cp),int(c),int(i),int(j)] for (h,cp,c),i,j in zip(keys,g0,g1)],'permutation_columns':['owner','local_cp','component','baseline_global_dof','alternate_global_dof'],'K_PKP_relative_Frobenius_error':krel,'assembled_RHS_PF_relative_error':frel,'pure_external_PF_relative_error':mapped_external,'X_mapped_relative_L2_error':xrel,'X_mapped_max_absolute_error_mm':float(np.max(np.abs(X1-X0))),'X_perturbation_bound':bound,'X_comparison_tolerance':xtol,'X_bound_inconclusive':x_inconclusive,'calibration_comparison':calibration,'boundary_comparison':bc,'repeatability_tolerance':tau,'baseline_diagnostics':a['diagnostics'],'alternate_diagnostics':b['diagnostics'],'condition_estimator_equality_required':False,'structural_accuracy_accepted':False,'independent_physical_flux_or_reference_convergence_inferred':False}

def current_launch_identity(run,plan,cluster,meta,manifest,inputs,mode,prep):
    """Bind current producer metadata to the original explicit comparison fields."""
    source=SOURCE;build=RUNTIME
    require(digest(run/'source_runtime_manifest.json')==build,'exact current complete-pair manifest')
    require(manifest['actual_source_binding_sha256']==source and manifest['actual_source_count']==1212,'exact current source binding/count')
    require(digest(run/'applied_source_binding.json')==source,'actual copied source binding')
    modules={x['name']:x['sha256'] for x in manifest['runtime']}
    require(modules['IGAforCAD.crx']=='d55a004bc4830d2ddadfad99b6e9ffd05511a5bf3f411c85a87179053a195f0b' and modules['JYH_IGAEntity.dbx']=='3cf634b56ee449a15a4176e9c0e413bc17d65d99a19df9bfb6c2fd113f6b943d','exact current CRX and DBX')
    window_path=run/'root_selected_window.json';original_path=run/'original_input_before_after.json';model_path=run/'input_model.dwg'
    intake_path=prep/'geometry/threepatch_identity/results/native_intake_inputs.json'
    inputs += [window_path,original_path,model_path,intake_path,run/'applied_source_binding.json']
    window=read_json(window_path);original=read_json(original_path);intake=read_json(intake_path)['inputs']['public_auto_three']
    require(window['status']=='ROOT_SELECTED_ONE_MANUAL_ACTION' and window['scope']=='OE_POINT_COMPLETE_90F_ONE_MANUAL_CASE_V7B','current one-case family window')
    require(window['action']=='cluster' and window['label']==run.name and window['runner_file']=='run_cluster_once.py','actual current cluster selection')
    require(window['source_binding_sha256']==source and window['runtime_manifest_sha256']==build,'window source/runtime identity')
    require(plan['kind']=='cluster' and plan['source_binding_sha256']==source and plan['manifest_sha256']==build and plan['window_sha256']==digest(window_path),'actual launch and selected-window identity')
    parameters=window['parameters']
    require(set(parameters)=={'omit','refine_factor','cyclic_order','analysis_profile_sha256','profile_recipe_receipt_sha256','boundary_gauss_order','profile_role'} and parameters['refine_factor']==1 and parameters['boundary_gauss_order']==4 and parameters['profile_role']=='boundary_q4','explicit final q4 source-default coarse graph parameters')
    profile_path=run/'executed_profile.json';recipe_path=run/'profile_recipe_receipt.json';trace_path=run/'boundary_domain_probe.jsonl';inputs += [profile_path,recipe_path,trace_path]
    require(digest(profile_path)==parameters['analysis_profile_sha256'] and digest(recipe_path)==parameters['profile_recipe_receipt_sha256'],'actual imported complete profile identity')
    profile=read_json(profile_path);clone=read_json(recipe_path)
    require(profile['ManualLineGaussN_BC'] is True and profile['LineGaussN_BC']==4 and profile['enableGeoNonlinear'] is False,'actual final q4 profile')
    require(clone['status']=='SOURCE_DEFAULT_FULL_PROFILE_RECIPE_ONLY_NOT_RUNTIME_EXPORT' and clone['baseline_origin']=='CPP_CAPTURE_OF_FROZEN_SOURCE_DEFAULTS' and clone['all_other_profile_values_preserved'] is True and clone['boundary_recipe_changes_only']==['ManualLineGaussN_BC','LineGaussN_BC'] and clone['source_binding_sha256']=='55f52d5e713ec074883a66712a0401b3d5ed7976ad5c12b6ef94da9429de7a03' and clone['runtime_manifest_sha256']=='fec1f383a568ae52e6a03e2828cd405e0b8f3ade941dd0afbabbd8a872b3d35a' and clone['actual_Native_configuration_exported'] is False and clone['original_DWG_profile_cloned'] is False,'explicit source-default recipe, no runtime/stored-profile clone claim')
    require(clone['outputs']['boundary_q4']['sha256']==digest(profile_path),'q4 source-default recipe included in producer receipt')
    snapshots=[json.loads(line)for line in trace_path.read_text(encoding='utf-8-sig').splitlines()if line.strip()];snapshots=[v for v in snapshots if v['event']=='apply_snapshot']
    require(len(snapshots)==1 and snapshots[0]['gauss']==4,'actual Native q4 boundary observed')
    require(parameters['omit'] in ('all','1ec2','1ec5','1ec8') and isinstance(parameters['cyclic_order'],bool),'explicit graph/order values')
    require(parameters['cyclic_order']==(mode=='cyclic') and meta['mode']==mode,'actual requested and observed numbering mode')
    omit=0 if parameters['omit']=='all' else int(parameters['omit'],16)
    require(int(cluster['omit_handle'],16)==omit==meta['fixed_physical_omit_handle'],'actual observed physical omitted relation')
    stored={r['stored_form'] for r in cluster['relations']}
    require(stored=={'Skew'} and cluster['actual_form']=='Sym' and cluster['stored_form_override_explicit'] is True,'stored Skew and explicit actual Sym observed')
    flags=plan['explicit_IGA_child_environment']
    require(flags['IGA_OE_TRIPLE_CLUSTER_V1']=='SYM' and flags['IGA_OE_TRIPLE_REFERENCE_LENGTH']=='1','explicit actual cluster flags')
    if mode=='cyclic':require(flags['IGA_OE_PATCH_NUMBERING_ORDER']=='cyclic','explicit cyclic numbering flag')
    else:require('IGA_OE_PATCH_NUMBERING_ORDER' not in flags,'default run must not carry an order override')
    require(original['exact_sha_and_mtime_unchanged'] is True and original['before']==original['after'],'immutable original input record')
    model_sha=original['before']['sha256']
    require(model_sha==intake['sha256']==digest(model_path),'exact original threepatch model identity')
    return dict(source_sha256=model_sha,refine_factor=parameters['refine_factor'],stored_relation_form='Skew',explicit_actual_form=cluster['actual_form'],omit_penalty_relation=parameters['omit'],analysis_profile_sha256=parameters['analysis_profile_sha256'],profile_recipe_receipt_sha256=parameters['profile_recipe_receipt_sha256'],boundary_gauss_order=parameters['boundary_gauss_order'],profile_role=parameters['profile_role'])

def load_run(context,entry,mode,protocol):
    value=context.load_case(entry,4,cyclic=mode=='cyclic',require_flux=False)
    run=value['run'];audit=value['packet'];arms=value['arms'];X=value['coefficients'];Fext=value['external'];cluster=value['cluster'];inputs=[]
    require(len(X)==729 and all(a.m*a.n==81 for a in arms),'coarse729 ONLY before any dense allocation')
    require(40*729*729*8+8*729*8<=512*1024**2,'original bounded major-buffer budget')
    meta,mapping=observed_map(audit,arms,mode,inputs);reader=context.reader
    scope=read_json(context.bind(audit/'patch_order_operator_scope.json'))
    require(scope['schema']=='oe_patch_order_actual_solver_input_v1'and scope['exported']is True and scope['rows']==729 and scope['matrix_is_actual_solver_argument']is True and scope['no_symmetrization_shift_or_regularization_by_exporter']is True and scope['assembly_includes_actual_BC_and_coupling']is True,'actual unmodified full solver K required')
    require(scope['stage']=='immediately_before_IGA_SolveSparseWithRigidBasis','original solver export stage')
    kp=context.bind(audit/'patch_order_global_K.csv');fp=context.bind(audit/'patch_order_global_F.csv')
    context.bind(run/'input_audit/patch_order_global_K.csv',digest(kp));context.bind(run/'input_audit/patch_order_global_F.csv',digest(fp))
    K=coo(kp,729,['global_row_zero_based','global_col_zero_based','value_N_per_mm']);F=reader.vector_csv(fp,729)
    geometry={};boundary={};B=np.zeros_like(K);BCrhs=np.zeros(729)
    for arm in arms:
        h=arm.handle;geometry[h]=read_json(context.bind(audit/f'load_stage_geometry_{h}.json'))
        H=coo(context.bind(audit/f'boundary_delta_H_{h}.csv'),243,['local_row_zero_based','local_col_zero_based','value_N_per_mm'],100000)
        with context.bind(audit/f'boundary_delta_F_{h}.csv').open(encoding='utf-8-sig',newline='')as stream:rows=list(csv.DictReader(stream))
        require(len(rows)==243 and {int(v['local_dof_zero_based'])for v in rows}==set(range(243)),'local BC RHS rows')
        f=np.zeros(243)
        for row in rows:f[int(row['local_dof_zero_based'])]=float(row['value_N'])
        boundary[h]=(H,finite(f));B[np.ix_(arm.dofmap,arm.dofmap)]+=H;np.add.at(BCrhs,arm.dofmap,f)
    essential=value['points']['essential_joint_a']+value['points']['essential_PATCH0_far_corner']
    completed_B=B+essential.toarray()
    completed_action=value['vectors']['boundary_internal_minus_rhs_completed.csv']
    eps=float(np.finfo(float).eps);tau=max(1e-12,64*729*eps);back=max(1e-14,128*729*eps)
    diag,residual=dense_diagnostics(K,F,X,Fext,tau,back,protocol['physical_N_RHS_relative_numerical_closure_tolerance'])
    diag['observed_boundary_packet_checks']=value['boundary_checks'];diag['file_identity_seal']=value['seal'];diag['completed_point_qualification']=value['point_qualification']
    manifest=read_json(context.bind(run/'source_runtime_manifest.json'));plan=read_json(context.bind(run/'launch_plan.json'))
    launch=current_launch_identity(run,plan,cluster,meta,manifest,inputs,mode,context.prep)
    for path in inputs:context.bind(path)
    require(cluster['FEM_target_used']is False,'FEM target not used for calibration')
    return dict(run=run,audit=audit,arms=arms,X=X,Fext=Fext,K=K,F=F,action=value['boundary_original_action'],boundary=boundary,geometry=geometry,
      cluster=cluster,meta=meta,mapping=mapping,signature=build_signature(manifest),launch=launch,diagnostics=diag,residual=residual,
      points=value['points'],completed_B=completed_B,completed_B_rhs=BCrhs,completed_B_action=completed_action,
      completed_internal_action=value['vectors']['independent_canonical_interface_action.csv'],postprocess=value['post'],inputs=inputs)

def completed_covariance(a,b,result,protocol):
    keys=sorted(a['mapping']);g0=np.asarray([a['mapping'][k]for k in keys]);g1=np.asarray([b['mapping'][k]for k in keys])
    tau=result['repeatability_tolerance'];u0=a['X'][g0];u1=b['X'][g1];rows=[]
    groups=[('natural_joint_b','free_interface'),('essential_joint_a','essential_boundary'),('essential_PATCH0_far_corner','essential_boundary')]
    for name,role in groups:
        M0=a['points'][name][g0,:][:,g0].toarray();M1=b['points'][name][g1,:][:,g1].toarray()
        action0=M0@u0;action1=M1@u1;pred=M0@(u1-u0)+(M1-M0)@u1;difference=action1-action0-pred
        scale=np.abs(M0)@np.abs(u1-u0)+np.abs(M1-M0)@np.abs(u1)+np.abs(action0)+np.abs(action1)
        denominator=float(np.linalg.norm(scale,np.inf));cov=float(np.linalg.norm(difference,np.inf))/denominator if denominator else 0.
        rows.append(dict(group=name,role=role,PKP_relative_Frobenius=relnorm(M0,M1),operation_scaled_action_covariance=cov,gate=bool(relnorm(M0,M1)<=tau and cov<=tau)))
    H0=a['completed_B'][np.ix_(g0,g0)];H1=b['completed_B'][np.ix_(g1,g1)];f0=a['completed_B_rhs'][g0];f1=b['completed_B_rhs'][g1]
    aa=a['completed_B_action'][g0];ab=b['completed_B_action'][g1]
    pred=H0@(u1-u0)+(H1-H0)@u1-(f1-f0);difference=ab-aa-pred
    scale=np.abs(H0)@np.abs(u1-u0)+np.abs(H1-H0)@np.abs(u1)+np.abs(f1-f0)+np.abs(aa)+np.abs(ab)
    denominator=float(np.linalg.norm(scale,np.inf));cov=float(np.linalg.norm(difference,np.inf))/denominator if denominator else 0.
    boundary=dict(completed_B_PKP_relative_Frobenius=relnorm(H0,H1),completed_B_rhs_PF_relative=relnorm(f0,f1),operation_scaled_actual_action_covariance=cov,
      role='original_BC+actual essential_a/far',reaction_from_actual_matrix_times_U_not_global_residual=True,
      gate=bool(relnorm(H0,H1)<=tau and relnorm(f0,f1)<=tau and cov<=tau))
    result['gates'].update(actual_three_point_group_covariance=all(row['gate']for row in rows),completed_boundary_covariance=boundary['gate'])
    result['point_group_comparison']=rows;result['completed_boundary_comparison']=boundary
    result['completed_weak_balance']=[a['postprocess']['numerical_total_balance'],b['postprocess']['numerical_total_balance']]
    result['completed_loaded_RHS']=[a['postprocess']['loaded_full_RHS_residual'],b['postprocess']['loaded_full_RHS_residual']]
    result['raw_strong_metrics_not_relabelled']=[a['postprocess']['cluster']['effective_force_sum_relative_L2'],b['postprocess']['cluster']['effective_force_sum_relative_L2']]
    result['status']='PASS_CAPTURED_NUMERICAL_ORDER_CONTROLS_ONLY'if all(result['gates'].values())else('NUMERICALLY_INCONCLUSIVE_ORDER_CONTROLS'if result['X_bound_inconclusive']else'FAIL_CAPTURED_NUMERICAL_ORDER_CONTROLS')
    return result

def main():
    ap=argparse.ArgumentParser(description=__doc__);common_arguments(ap)
    ap.add_argument('--baseline-entry',type=Path,required=True);ap.add_argument('--alternate-entry',type=Path,required=True)
    ap.add_argument('--coarse-qualification',type=Path,required=True);ap.add_argument('--coarse-qualification-sha256',required=True)
    ap.add_argument('--comparison-protocol',type=Path,required=True);ap.add_argument('--out-dir',type=Path,required=True);args=ap.parse_args()
    context=Context(args);require(not args.out_dir.exists(),'fresh ordering output')
    protocol=read_json(context.bind(args.comparison_protocol,'71abe866b266ac7b1d6448a915799480547df8ff8c6b96db8e48b02947e85e0f'))
    left=read_json(context.bind(args.baseline_entry));right=read_json(context.bind(args.alternate_entry))
    a=load_run(context,left,'default_ascending',protocol);b=load_run(context,right,'cyclic',protocol)
    context.identity.fresh_output(args.out_dir,[a['run'],b['run'],a['audit'],b['audit']])
    qualified=context.coarse_qualification(dict(path=str(args.coarse_qualification),sha256=args.coarse_qualification_sha256),a['run'])
    result=completed_covariance(a,b,compare_runs(a,b,protocol),protocol)
    result.update(source_binding_sha256=SOURCE,runtime_manifest_sha256=RUNTIME,baseline_actual_coarse_B_qualification=qualified,
      protocol=protocol,Host_compiler_or_external_solver_started=False,all_h_or_general_physical_accuracy_inferred=False)
    context.bind(Path(__file__));result['input_manifest']=context.finish()
    args.out_dir.mkdir(parents=True,exist_ok=False)
    with(args.out_dir/'actual_order_comparison.json').open('x',encoding='utf-8')as f:json.dump(clean(result),f,indent=2,allow_nan=False)
    print(json.dumps(dict(status=result['status'],path=str(args.out_dir/'actual_order_comparison.json'))));return 0 if result['status'].startswith('PASS_')else 2

if __name__=='__main__':raise SystemExit(main())

