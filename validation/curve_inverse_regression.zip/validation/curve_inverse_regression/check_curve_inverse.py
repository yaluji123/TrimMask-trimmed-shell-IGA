"""Check the frozen 303 same-curve scalar Newton emulations; read-only by default.

This is not a reconstruction of the unexported first failing Native sample.
The three numerical functions retain the original diagnostic mathematics.
Only the local curve and frozen parameter records are read. No solver is run.
"""
import bisect
from fractions import Fraction as F
import json
import math
from pathlib import Path

def deboor(knots,degree,values,t):
 n=len(values);span=n-1 if t==knots[n]else bisect.bisect_right(knots,t)-1
 assert degree<=span<n
 d=list(values[span-degree:span+1])
 for r in range(1,degree+1):
  for j in range(degree,r-1,-1):
   den=knots[span+1+j-r]-knots[span-degree+j];assert den>0
   a=(t-knots[span-degree+j])/den;d[j]=(1-a)*d[j-1]+a*d[j]
 return d[degree]

def derivative(knots,p,values,t):
 d=[p*(values[i+1]-values[i])/(knots[i+p+1]-knots[i+1])for i in range(len(values)-1)]
 return deboor(knots[1:-1],p-1,d,t)

def old_scalar_inverse(knots,p,values,target):
 lo,hi=knots[p],knots[len(values)];utol=1e-12*(abs(hi-lo)+1);prior=.5*(lo+hi)
 def step(t):
  slope=derivative(knots,p,values,t);assert math.isfinite(slope)and slope!=0
  candidate=t-(deboor(knots,p,values,t)-target)/slope
  if candidate<lo+utol:candidate=lo
  if candidate>hi-utol:candidate=hi
  return candidate
 candidate=step(prior);iterations=0
 while abs(prior-candidate)>1e-6 and iterations<50:
  prior=candidate;candidate=step(prior);iterations+=1
 return prior,candidate,iterations

def main():
    here = Path(__file__).resolve().parent
    geometry = json.loads((here / "curve.json").read_text(encoding="utf-8"))
    saved = json.loads((here / "records.json").read_text(encoding="utf-8"))
    curve = geometry["curve"]
    assert geometry["coordinate_units"] == "mm" and geometry["registry_index"] == 17
    assert curve["extraction_complete"] and curve["degree"] == 3 and not curve["rational"]
    assert all(w == 1 for w in curve["weights"])
    assert saved["same_curve_representation_exact"]
    assert saved["first_actual_failed_Native_map_sample"] is None
    assert saved["exact_Native_mapParams_reconstructed"] is False
    assert saved["no_physical_threshold_relaxation"] and saved["no_API_Native_FE_or_PDE_solve"]
    frac = lambda x: F.from_float(float(x))
    p = curve["degree"]
    K = list(map(frac, curve["knots"]))
    raw = curve["control_global_xyz"]
    assert len(raw) % 3 == 0
    P = [[frac(v) for v in raw[i:i+3]] for i in range(0, len(raw), 3)]
    assert len(K) == len(P) + p + 1 and len(curve["weights"]) == len(P)
    assert K == sorted(K) and K[p] < K[len(P)]
    assert all(math.isfinite(float(x)) for x in K + [x for point in P for x in point])
    axis = max(range(3), key=lambda j: abs(P[-1][j] - P[0][j]))
    kf = list(map(float, K))
    columns = [[v[j] for v in P] for j in range(3)]
    vf = list(map(float, columns[axis]))
    records = saved["records"]
    assert len(records) == 303
    parameters = [F(r["known_target_parameter_Fraction"]) for r in records]
    assert parameters == sorted(set(parameters))
    assert all(K[p] <= t <= K[len(P)] for t in parameters)
    old_failures = latest_failures = checked_values = 0
    max_old = max_latest = 0.0
    for index, (t, record) in enumerate(zip(parameters, records)):
        exact_point = [deboor(K, p, col, t) for col in columns]
        target_axis = deboor(kf, p, vf, float(t))
        old, new, iterations = old_scalar_inverse(kf, p, vf, target_axis)
        old_point = [deboor(kf, p, list(map(float, col)), old) for col in columns]
        new_point = [deboor(kf, p, list(map(float, col)), new) for col in columns]
        target = [deboor(kf, p, list(map(float, col)), float(t)) for col in columns]
        old_error = math.sqrt(sum((x-y)**2 for x, y in zip(old_point, target)))
        new_error = math.sqrt(sum((x-y)**2 for x, y in zip(new_point, target)))
        recomputed = {
            "known_target_parameter_Fraction": str(t),
            "identity_other_parameter_Fraction": str(t),
            "exact_identity_oracle_residual": 0,
            "exact_point_Fraction": [str(x) for x in exact_point],
            "scalar_projection_axis": axis,
            "emulated_return_prior": old,
            "emulated_last_candidate": new,
            "emulated_iterations": iterations,
            "emulated_old_physical_residual_mm": old_error,
            "emulated_last_candidate_residual_mm": new_error,
            "original_backsub_budget_mm": 1e-8,
            "old_emulation_exceeds_original_budget": old_error > 1e-8,
            "last_candidate_exceeds_original_budget": new_error > 1e-8,
        }
        assert record.keys() == recomputed.keys(), (index, "record fields differ")
        for key, value in recomputed.items():
            assert type(record[key]) is type(value) and record[key] == value, (index, key)
            checked_values += 1
        old_failures += old_error > 1e-8
        latest_failures += new_error > 1e-8
        max_old = max(max_old, old_error)
        max_latest = max(max_latest, new_error)
    assert old_failures == 12 and latest_failures == 0
    print(json.dumps({
        "status": "FROZEN_303_SCALAR_RECORDS_REPRODUCED_EXACTLY",
        "records_checked": len(records), "record_fields_checked": checked_values,
        "all_record_values_equal": True,
        "original_step_stop": 1e-6, "original_physical_budget_mm": 1e-8,
        "prior_return_exceeds_budget": old_failures,
        "latest_candidate_exceeds_budget": latest_failures,
        "maximum_prior_residual_mm": max_old,
        "maximum_latest_residual_mm": max_latest,
        "surface_affine_checks_preserved_not_recomputed": True,
        "scope": "Same-curve dominant-axis scalar Newton emulation; not the first failing Native sample.",
        "Native_FE_PDE_solve_or_compilation_run": False,
    }, indent=2))


if __name__ == "__main__":
    main()
