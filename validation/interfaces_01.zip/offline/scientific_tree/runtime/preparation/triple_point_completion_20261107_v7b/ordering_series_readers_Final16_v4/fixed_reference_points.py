"""Keep common Gamma endpoint and actual outer PATCH2 FEM peak physically distinct."""
import numpy as np

GAMMA_WORLD=[100.,0.,0.]
def need(ok,message):
    if not ok:raise ValueError(message)

def gamma_vector_from_readback(report,fem,parent,extractor_sha):
    need(report['read_only']is True and report['new_solver_executed_by_this_script']is False and report['source_hash_size_mtime_unchanged']is True,'actual immutable read-only FEM capture')
    need(report['fixed_world_readback_producer_sha256']==extractor_sha and report['mesh_level']=='0p0625mm','exact proposed fixed-point producer and qualified fine mesh')
    need(report['source_odb']==parent['ODB']and report['source_odb_sha256']==parent['ODB_sha256']and report['input_sha256']==parent['source_input_sha256'],'same existing qualified ODB/input SHA')
    need(report['nodes']==4596471 and report['elements']==9184000,'same original fine reference dimensions')
    for name,expected_sha in [('ODB',parent['ODB_sha256']),('INP',parent['source_input_sha256'])]:
        item=report['source_before_after'][name]
        need(item['before']==item['after']and item['before']['sha256']==expected_sha,'source SHA/size/mtime unchanged '+name)
    need(report['maximum_displacement_location_mm']==fem['latest_computed_peak_xyz_mm']and report['maximum_displacement_vector_mm']==fem['latest_computed_U_vector_at_peak_mm'],'true peak preserved, not replaced by Gamma endpoint')
    points=report['fixed_world_displacements'];matches=[p for p in points if p['point_name']=='common_Gamma_b']
    need(len(matches)==1,'one independently captured common Gamma endpoint')
    p=matches[0];need(p['requested_world_xyz_mm']==GAMMA_WORLD and p['position_tolerance_mm']==1e-8 and p['physical_residual_mm']<=1e-8,'fixed original physical location/tolerance')
    need(np.linalg.norm(np.asarray(p['actual_world_xyz_mm'])-GAMMA_WORLD)<=1e-8 and type(p['node_label'])is int and p['node_label']>0,'actual original shared node/world coordinate')
    vector=np.asarray(p['U_vector_mm'],float);need(vector.shape==(3,)and np.isfinite(vector).all()and np.linalg.norm(vector)>0,'actual finite nonzero Gamma reference U')
    return vector.tolist()

def actual_peak_traces(arms,peak_world):
    """All retained full-carrier owners at the actual FEM peak; never copy to other owners."""
    target=np.asarray(peak_world,float);traces=[];not_on_owner=[]
    for arm in arms:
        J=np.column_stack([arm.du,arm.dv]);uv=np.linalg.lstsq(J,target-arm.origin,rcond=None)[0]
        projection=arm.origin+J@uv
        if np.linalg.norm(projection-target)>1e-8:
            not_on_owner.append(dict(owner=hex(arm.handle),reason='fixed FEM peak not on this owner carrier',projection_gap_mm=float(np.linalg.norm(projection-target))));continue
        eps=512*np.finfo(float).eps
        if np.any(uv<-eps)or np.any(uv>1+eps):
            not_on_owner.append(dict(owner=hex(arm.handle),reason='fixed FEM peak outside this owner parameter domain'));continue
        original=uv.copy();uv=np.clip(uv,0.,1.)  # roundoff only; exact world tolerance checked again below
        op=arm.operators(float(uv[0]),float(uv[1]));gap=float(np.linalg.norm(op['X']-target));need(gap<=1e-8,'actual retained peak trace physical position')
        traces.append(dict(owner=hex(arm.handle),xyz_mm=op['X'].tolist(),uv=uv.tolist(),U_vector_mm=(op['U']@arm.coeff).tolist(),world_residual_mm=gap,roundoff_parameter_adjustment=bool(np.any(uv!=original))))
    need(len(traces)==1 and traces[0]['owner']=='0x1ebd','this original benchmark peak belongs only to retained PATCH2')
    return traces,not_on_owner
