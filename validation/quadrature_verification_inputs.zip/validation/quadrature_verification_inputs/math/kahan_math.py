"""Original cached quadrature-moment summation update."""

def kahan(state,x):
 y=x-state[1];t=state[0]+y;state[1]=(t-state[0])-y;state[0]=t
