"""Pinned current readers and explicit completed-case inputs; no Native/job launcher."""
from pathlib import Path
import argparse,hashlib,importlib,importlib.util,json,sys
import numpy as np

HERE=Path(__file__).resolve().parent
SOURCE='90f72156bd9f1430e25177e91b6a69b89c4434f81934dfdee19b20eef2a96566'
RUNTIME='50999199bb7bf6770b7446beae7c5e2600294276d6ba858ab7a616f873bf5a84'
DOFS={1:729,2:2025,3:3969,4:6561}
PROFILE_GUARD_SHA='45bfe7c480953421a096540c59edaad34fae0148654c42f1615ba7e18335346b'

def require(ok,message):
    if not ok:raise ValueError(message)
def read(path):return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def clean(value):
    if isinstance(value,np.generic):return value.item()
    if isinstance(value,np.ndarray):return value.tolist()
    if isinstance(value,dict):return {str(k):clean(v)for k,v in value.items()}
    if isinstance(value,(list,tuple)):return [clean(v)for v in value]
    return value

def common_arguments(parser):
    for name in ['prep','reader-dir','source-root','source-binding','runtime-manifest']:
        parser.add_argument('--'+name,type=Path,required=True)
    parser.add_argument('--source-binding-sha256',required=True);parser.add_argument('--runtime-manifest-sha256',required=True)
    parser.add_argument('--Gamma-reference-readback',dest='gamma_reference_readback',type=Path)
    parser.add_argument('--Gamma-reference-readback-sha256',dest='gamma_reference_readback_sha256')

class Context:
    def __init__(self,args):
        self.args=args;self.prep=args.prep.resolve();self.directory=args.reader_dir.resolve()
        require(args.source_binding_sha256==SOURCE and args.runtime_manifest_sha256==RUNTIME,'this successor is current90f/509991 only, never relabel old outputs')
        bindings=read(HERE/'READER_BINDINGS.json')
        require(self.directory.is_relative_to(self.prep),'current reader directory under PREP')
        for name,h in bindings.items():require(sha(self.directory/name)==h,'pinned current reader source '+name)
        sys.path.insert(0,str(self.directory))
        modules={name:importlib.import_module(name)for name in ['point_identity_v7','line_reader_v7','point_physical_sparse_v7','cluster_physical_core']}
        for name,module in modules.items():require(Path(module.__file__).resolve()==self.directory/(name+'.py'),'wrong reader/core module import '+name)
        self.identity=modules['point_identity_v7'].Identity(args);self.reader=modules['line_reader_v7'];self.points=modules['point_physical_sparse_v7'];self.core=modules['cluster_physical_core']
        for name,h in bindings.items():self.bind(self.directory/name,h)
        self.bind(HERE/'READER_BINDINGS.json');self.bind(Path(__file__))
        guard_path=self.prep/'runtime/preparation/triple_point_completion_20261107_v7b/cluster_case_tools_v1/paper_case_guard.py'
        self.bind(guard_path,PROFILE_GUARD_SHA)
        spec=importlib.util.spec_from_file_location('bounded_profile_inheritance_source_only',guard_path)
        self.profile_guard=importlib.util.module_from_spec(spec);spec.loader.exec_module(self.profile_guard)

    def bind(self,path,expected=None):
        # Delegation is essential: it retains the explicit qualified external8 runtime whitelist.
        return self.identity.bind(path,expected)

    def report(self,reference):
        require(isinstance(reference,dict)and reference.get('path')is not None and reference.get('sha256')is not None,'completed report path AND SHA required')
        return read(self.bind(reference['path'],reference['sha256']))

    def load_case(self,entry,q,cyclic=False,require_flux=True):
        require(entry['complete']is True,'case is not indexed complete')
        run=Path(entry['run_dir']).resolve();packet=Path(entry['packet_dir']).resolve()
        require(run.is_relative_to(self.prep/'runtime/runs'),'actual closed run location')
        self.profile_guard.case_identity(run,RUNTIME,'actual_bootstrap_module_hashes.json')
        arms,F,u,positions,forces,betas,ell,cluster,inputs,_=self.reader.load_actual(run,packet,self.identity)
        require(len(u)==DOFS[entry['refine_factor']]and ell==1 and cluster['alpha']==2.1,'original graph/h/ell/alpha scope')
        for path in inputs:self.bind(path)
        original=read(self.bind(run/'original_input_before_after.json'))
        require(original['exact_sha_and_mtime_unchanged']is True and original['before']==original['after'],'immutable original input record')
        self.bind(run/'input_model.dwg',original['before']['sha256'])
        intake=read(self.bind(self.prep/'geometry/threepatch_identity/results/native_intake_inputs.json'))['inputs']['public_auto_three']
        require(original['before']['sha256']==intake['sha256'],'exact original threepatch DWG across current cases')
        seal=self.reader.verify_boundary_file_seal(packet,run,inputs)
        for path in inputs:self.bind(path)
        window=read(self.bind(run/'root_selected_window.json'));parameters=window['parameters']
        role='boundary_q4'if q==4 else'boundary_q5'
        require(window['action']=='cluster'and parameters['omit']==entry['omit']and parameters['refine_factor']==entry['refine_factor']and parameters['cyclic_order']is cyclic and parameters['boundary_gauss_order']==q and parameters['profile_role']==role,'exact current profile/graph/h/order selection')
        profile=read(self.bind(run/'executed_profile.json',parameters['analysis_profile_sha256']))
        receipt_path=self.bind(run/'profile_recipe_receipt.json',parameters['profile_recipe_receipt_sha256']);receipt=read(receipt_path)
        inherited=read(self.bind(run/'source_default_recipe_inheritance.json'))
        require(inherited==self.profile_guard.profile_inheritance(receipt_path,RUNTIME),'literal historical recipe plus current unchanged-config inheritance')
        require(profile['ManualLineGaussN_BC']is True and profile['LineGaussN_BC']==q and profile['enableGeoNonlinear']is False and receipt['outputs'][role]['sha256']==sha(run/'executed_profile.json'),'actual entire q profile identity')
        events=[json.loads(line)for line in self.bind(run/'boundary_domain_probe.jsonl').read_text(encoding='utf-8-sig').splitlines()if line.strip()]
        snapshots=[e for e in events if e['event']=='apply_snapshot']
        require(len(snapshots)==1 and snapshots[0]['gauss']==q and snapshots[0]['prescribed_global']==[0]*6 and not any(e['event']=='registered_trace_partition'for e in events),'actual original normal-carrier homogeneous BC/q')
        actual,physical,point_actions,point_report=self.points.qualify_points(run,packet,arms,ell,u,positions,cluster,self.identity)
        post=self.report(entry['postprocess'])
        require(post['schema']=='oe-actual-threepatch-point-complete-postprocess-v7'and post['status']=='POSTPROCESSED_OBSERVED_FIELDS_NOT_SCIENTIFIC_ACCEPTANCE'and post['source_binding_sha256']==SOURCE and post['runtime_manifest_sha256']==RUNTIME and post['actual_global_dofs']==len(u),'current complete postprocess identity')
        require(post['actual_internal_matrix_role']=='line+natural_b'and post['actual_boundary_matrix_role']=='original_BC+essential_a+essential_far'and post['numerical_total_balance']is not None and post['loaded_full_RHS_residual']is not None,'completed internal/boundary weak ledger required')
        for item in post['input_manifest']:self.bind(item['path'],item['sha256'])
        paths={Path(row['path']).resolve()for row in post['input_manifest']}
        require({run/'source_runtime_manifest.json',run/'process_result.json',packet/'global_solution.csv',self.directory/'postprocess_point_complete_v7.py'}<=paths,'postprocess must bind exact run, packet and adopted current reader')
        require(post['quadrature_crosscheck']['orders']==[8,10],'original independent line GL8/10 crosscheck')
        output_hashes={r['file']:r['sha256']for r in post['output_vectors']};post_dir=Path(entry['postprocess']['path']).resolve().parent
        vectors={}
        for name in ['independent_canonical_line_action.csv','independent_canonical_interface_action.csv','independent_GL4_bulk_action.csv','actual_natural_point_action.csv','actual_essential_point_action.csv','boundary_internal_minus_rhs_completed.csv']:
            require(name in output_hashes,'bound output vector missing '+name)
            vectors[name]=self.reader.vector_csv(self.bind(post_dir/name,output_hashes[name]),len(u))
        b0,bchecks=self.reader.observed_boundary_action(packet/'boundary_action_global.csv',arms,u,inputs)
        for path in inputs:self.bind(path)
        natural=point_actions['natural_joint_b'];essential=point_actions['essential_joint_a']+point_actions['essential_PATCH0_far_corner']
        require(np.array_equal(vectors['actual_natural_point_action.csv'],natural)and np.array_equal(vectors['actual_essential_point_action.csv'],essential),'actual COO times same-case U point vectors')
        require(np.array_equal(vectors['independent_canonical_interface_action.csv'],vectors['independent_canonical_line_action.csv']+natural)and np.array_equal(vectors['boundary_internal_minus_rhs_completed.csv'],b0+essential),'completed roles, never residual-inferred reaction')
        flux=None
        if require_flux:
            flux=self.report(entry['flux_report']);require(flux['status']=='COMPLETED_DIAGNOSTIC_OBSERVATIONS_NOT_MECHANICAL_ACCURACY_ACCEPTANCE'and flux['source_binding_sha256']==SOURCE and flux['runtime_manifest_sha256']==RUNTIME and Path(flux['case']).resolve()==run,'complete current GP/endpoint/fixed8 report')
            require(flux['no_endpoints_GP_or_unselected_pairs_removed']is True and flux['raw_strong_flux_FAIL_not_relabelled']is True,'raw strong/point/pair ledger retained')
            span_count=len(self.core.unique_cuts(arms))-1
            require([r['order']for r in flux['quadrature_results']]==[8,10],'fixed flux integration orders')
            for row in flux['quadrature_results']:
                require(row['all_GP_count']==len(row['all_GP'])==span_count*row['order']and len(row['fixed_virtual_work'])==8 and len(row['all_signed_span_endpoint_incidences'])==2*span_count,'all GP,8 tests and both endpoint incidences')
                require(all(len(g['owners'])==3 and len(g['all_pairs'])==3 for g in row['all_GP']),'all three owners and pairs at every GP')
            for item in flux['input_manifest']:self.bind(item['path'],item['sha256'])
        return dict(run=run,packet=packet,arms=arms,external=F,coefficients=u,positions=positions,patch_forces=forces,betas=betas,ell=ell,cluster=cluster,post=post,
          vectors=vectors,points=actual,physical_points=physical,point_actions=point_actions,point_qualification=point_report,boundary_original_action=b0,boundary_checks=bchecks,seal=seal,window=window,receipt=receipt,inheritance=inherited,flux=flux)

    def coarse_qualification(self,reference,run):
        report=self.report(reference)
        require(report['status']=='QUALIFIED_ACTUAL_COARSE_POINT_OPERATOR_AND_PHYSICAL_B_MMS_ONLY'and report['source_binding_sha256']==SOURCE and report['runtime_manifest_sha256']==RUNTIME and Path(report['actual_run']).resolve()==Path(run).resolve()and report['actual_global_dofs']==729,'actual current coarse B qualification binding')
        require(report['physical_MMS']['positive_test_does_not_add_delta_to_actual_new_K']is True and report['full_actual_K_numeric_SPD']['passed']is True and report['actual_Native_vs_independent_solve']['inconclusive']is False and report['full_h_graph_reference_or_general_PDE_acceptance']is False,'bounded actual K/B/solve qualification scope')
        mms=report['physical_MMS'];matrix=report['actual_K_difference'];solution=report['actual_Native_vs_independent_solve']
        require(mms['old_Native_assembly_budget']==1e-7 and mms['old_K_B_relative_residual']>1e-7 and mms['new_ACTUAL_K_B_relative_residual']<=1e-7 and mms['wrong_total_replacement_B_relative_residual']>1e-7,'original actual physical B positive/negative budgets')
        require(matrix['budget']==1e-10 and matrix['relative_to_actual_K_Frobenius']<=1e-10 and matrix['actual_F_unchanged']is True and solution['coefficient_relative_difference']<=solution['coefficient_budget'],'serialized actual operator/F/solution qualification gates')
        for item in report['input_manifest']:self.bind(item['path'],item['sha256'])
        return report

    def Gamma_reference(self,fem):
        from fixed_reference_points import gamma_vector_from_readback
        require(self.args.gamma_reference_readback is not None and self.args.gamma_reference_readback_sha256 is not None,'actual common Gamma FEM vector readback path/SHA required for reference aggregation')
        path=self.bind(self.args.gamma_reference_readback,self.args.gamma_reference_readback_sha256);report=read(path)
        parent=read(self.bind(self.prep/'runtime/runs/stri3_0p0625mm_v1/solve_output_binding.json','c005db5407564c65407f1f04956e1f98a0b517b53cf8caff711886ff68d34c81'))
        producer=self.bind(Path(__file__).with_name('extract_stri3_gamma_point_readonly.py'),'997852222525916d9da7a4251d730f08fa7348eb16c71cdc66351d9a62742ba9')
        vector=gamma_vector_from_readback(report,fem,parent,sha(producer))
        self.bind(Path(__file__).with_name('fixed_reference_points.py'))
        return vector,dict(path=str(path),sha256=sha(path),producer_sha256=sha(producer),requested_world_xyz_mm=[100.,0.,0.],actual_fixed_world_point=report['fixed_world_displacements'],same_original_ODB_input_hash_size_mtime_preserved=True)

    def finish(self):self.identity.verify_unchanged();return self.identity.manifest()
