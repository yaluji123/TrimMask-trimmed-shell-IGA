# Saved spectral calibration data

Run `python check_saved_calibration.py` from any directory using Python 3.10 or newer. Only the Python standard library is required. The check verifies the 584 original input matrices against the recorded identities, applies the original filters to all 292 saved homogeneous eigenvalue arrays, and recomputes all 730 calibration comparisons in 146 groups. It does not repeat an eigendecomposition or launch a solver.

`pencils.jsonl` is the original saved public-LP64 result. `matrices/` contains the exact A/B inputs to that calculation. `calibration_parameters.jsonl` and `blocks.csv` retain the actual physical calibration parameters and assembled scalar outputs. `recorded_comparisons.json` retains the original successful comparisons and their tolerance. The two `cross_backend_*.json` files preserve the earlier open results, including all saved pencil and calibration records. They retain their original scientific status. `controls.json` preserves all seven recorded small controls.

`lp64_qz_method_reference.md` reproduces the numerical public-LP64 call and filter expressions. It is a method excerpt. The standalone reader checks saved arrays and arithmetic; it does not certify a continuous spectral bound, Native A/B byte identity, the backend used in an earlier CAD process, or PDE accuracy.
