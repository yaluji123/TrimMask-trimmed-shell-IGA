# Recorded public LP64 method

This is a source excerpt, not an executable replay program. The original
calculation used the public high-level LP64 LAPACKE interface with binary64
column-major input matrices. The archived homogeneous eigenvalue arrays are
checked by the standard-library reader without another decomposition.

The numerical call and original beta, imaginary-part and positive-ratio filter
are reproduced below. Array setup, memory checks and host setup are omitted.
`N` is the LP64 matrix dimension; `A` and `B` are mutable copies of the inputs;
`ar`, `ai` and `beta` hold the returned homogeneous eigenvalues.

```cpp
 r.info=LAPACKE_dggev(LAPACK_COL_MAJOR,'N','N',N,A.data(),N,B.data(),N,ar.data(),ai.data(),beta.data(),nullptr,N,nullptr,N);
 for(size_t i=0;i<n;++i){double a=r.ar[i],im=r.ai[i],b=r.beta[i];need(std::isfinite(a)&&std::isfinite(im)&&std::isfinite(b),"original nonfinite rejection");if(std::abs(b)<1e-8){++r.small;if(b==0){if(a==0&&im==0)++r.zerozero;else ++r.infinite;}continue;}if(std::abs(im)>1e-10){++r.complex;continue;}double x=a/b;need(std::isfinite(x),"original finite ratio");if(x>0){++r.positive;r.maximum=std::max(r.maximum,x);}else ++r.nonpositive;}
 r.filtered=r.positive>0&&r.maximum>0;
```

The original normalized scalar tolerance is 2e-12. A finite filtered value is
not a certified spectral upper bound. Both earlier open cross-backend results
and all seven recorded small controls are retained beside the successful data.
