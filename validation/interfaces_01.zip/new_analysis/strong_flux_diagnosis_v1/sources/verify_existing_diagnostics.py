"""Recheck the historical review readbacks without rewriting those artifacts."""
from pathlib import Path
import csv
import hashlib
import json
import sys
sys.dont_write_bytecode = True
from resource_guard import install, actual_budget

DIAG = Path(__file__).resolve().parents[1]
ROOT = DIAG.parents[1]
PREP = ROOT / "runtime/preparation/triple_point_completion_20261107_v7b"
resources = install()
resources["preflight"] = actual_budget(729, 59921)
import numpy as np
from numpy.polynomial import Polynomial
from scipy import sparse
from scipy.interpolate import BSpline


def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def vector(path, n):
    with path.open(encoding="utf-8-sig") as stream:
        rows = list(csv.DictReader(stream))
    fields = list(rows[0])
    assert len(rows) == n and [int(r[fields[0]]) for r in rows] == list(range(n))
    return np.array([float(r[fields[-1]]) for r in rows])


def close(actual, expected):
    assert np.allclose(actual, expected, atol=1e-10, rtol=1e-10), (actual, expected)


def transfer(old, new):
    obj = BSpline(old, np.eye(len(old)-4), 3, axis=0)
    for x in new[4:-4]:
        if (np.count_nonzero(np.isclose(obj.t, x, atol=1e-14, rtol=0))
                < np.count_nonzero(np.isclose(new, x, atol=1e-14, rtol=0))):
            obj = obj.insert_knot(float(x))
    assert len(obj.t) == len(new) and np.max(abs(obj.t-np.asarray(new))) < 1e-14
    return sparse.csr_matrix(obj.c[:len(new)-4])


inputs = {}


def bind(path):
    inputs[str(path)] = hashlib.sha256(path.read_bytes()).hexdigest()
    return path


spatial = read(DIAG / "existing/CLAIM_MATCH_NUMERICAL.json")
maximum_polynomial_error = 0.
for record in spatial["rows"]:
    path = bind(Path(record["input"]))
    assert inputs[str(path)] == record["input_sha256"]
    data = read(path)
    q = next(q for q in data["quadrature_results"] if q["order"] == 8)
    geom = read(bind(Path(record["case"])/"capture/trim_geometry_7867.json"))
    cuts = 100.*np.unique(geom["knots_u"])
    by_span = {}
    for row in q["all_GP"]:
        by_span.setdefault(row["span"], []).append(row)
    totals = {key: [0., 0., np.zeros(3), 0.]
              for key in record["intervals"]}
    for span, rows in by_span.items():
        a, b = cuts[span:span+2]
        x = np.array([r["x_mm"] for r in rows])
        g = np.array([sum(np.array(o["physical_effective_force_N_per_mm"])
                          for o in r["owners"]) for r in rows])
        m = np.array([sum(o["physical_moment_N"][0] for o in r["owners"])
                      for r in rows])
        pg = [Polynomial.fit(x, g[:, j], 3, domain=[a, b]) for j in range(3)]
        pm = Polynomial.fit(x, m, 3, domain=[a, b])
        error = max(max(np.max(abs(p(x)-g[:, j])) for j, p in enumerate(pg)),
                    np.max(abs(pm(x)-m)))
        maximum_polynomial_error = max(maximum_polynomial_error, float(error))
        assert error < 1e-9*max(np.max(abs(g)), np.max(abs(m)), 1.)
        for key, old in record["intervals"].items():
            lo, hi = old["range_mm"]
            aa, bb = max(a, lo), min(b, hi)
            if bb <= aa:
                continue
            for j, p in enumerate(pg):
                f, f2 = p.integ(), (p*p).integ()
                totals[key][0] += f2(bb)-f2(aa)
                totals[key][2][j] += f(bb)-f(aa)
            f, f2 = pm.integ(), (pm*pm).integ()
            totals[key][1] += f2(bb)-f2(aa)
            totals[key][3] += f(bb)-f(aa)
    for key, old in record["intervals"].items():
        g2, m2, gi, mi = totals[key]
        close(np.sqrt(max(0., g2)), old["force_L2_N_per_sqrt_mm"])
        close(np.sqrt(max(0., m2)), old["moment_L2_N_sqrt_mm"])
        close(gi, old["signed_force_integral_N"])
        close(mi, old["signed_moment_integral_Nmm"])

base_run = ROOT / "runtime/runs/final90f_cluster_gl4_all_h1_v1"
base = read(bind(base_run/"triple_cluster.json"))
base_arms = {a["handle"]: a for a in base["arms"]}
old_geom = read(bind(base_run/"capture/trim_geometry_7867.json"))
coarse = PREP / "all_h1_complete_physical_weak_dual_v2"
labels0 = read(bind(coarse/"free_coordinate_labels.json"))
chosen = [j for j, label in enumerate(labels0)
          if label[0] in ("common_U", "scaled_common_rho")]
Z0 = sparse.load_npz(bind(coarse/"Z.npz"))[:, chosen]
old_local = read(DIAG/"existing/CLAIM_MATCH_LOCAL_LEDGER.json")
old_fixed = read(DIAG/"existing/CLAIM_MATCH_FIXED_PHYSICAL_TESTS.json")
for h in range(1, 5):
    packet = PREP / ("all_h1_complete_physical_weak_dual_v2" if h == 1
                     else f"all_h{h}_complete_physical_sparse_packet_v2")
    post = PREP/f"cluster_gl4_all_h{h}_postprocess_v1"
    meta = read(bind(packet/"results.json"))
    n = meta["complete_finite_physical_space"]["global_dofs"]
    energy = meta["normalization_material_quadratic_work_Nmm"]
    Z = sparse.load_npz(bind(packet/"Z.npz"))
    G = sparse.load_npz(bind(packet/"independent_G.npz"))
    raw = np.load(bind(packet/"complete_physical_space_raw.npz"))
    labels = read(bind(packet/"free_coordinate_labels.json"))
    names = {"line": "independent_canonical_line_action.csv",
             "natural_b": "actual_natural_point_action.csv",
             "essential_a_far": "actual_essential_point_action.csv",
             "boundary_completed": "boundary_internal_minus_rhs_completed.csv"}
    actions = {key: vector(bind(post/name), n) for key, name in names.items()}
    coordinate_r = raw["full_physical_residual_coordinates"]
    scale = np.sqrt(G.diagonal()*energy)
    for item in old_local["results"][h-1]["all_common_trace_local_tests"]:
        j = item["free_column"]
        assert labels[j] == item["label"]
        close(coordinate_r[j]/scale[j], item["normalized_physical_defect"])
        for key, action in actions.items():
            close((Z[:, j].T@action).item()/scale[j], item["normalized_terms"][key])

    run = ROOT/f"runtime/runs/final90f_cluster_gl4_all_h{h}_v1"
    current = read(bind(run/"triple_cluster.json"))
    geo = read(bind(run/"capture/trim_geometry_7867.json"))
    T = sparse.kron(sparse.kron(transfer(old_geom["knots_u"], geo["knots_u"]),
                               transfer(old_geom["knots_v"], geo["knots_v"])),
                    sparse.eye(3), format="coo")
    rr, cc, vv = [], [], []
    for arm in current["arms"]:
        rr.extend(np.array(arm["global_dofmap"])[T.row])
        cc.extend(np.array(base_arms[arm["handle"]]["global_dofmap"])[T.col])
        vv.extend(T.data)
    P = sparse.coo_matrix((vv, (rr, cc)), shape=(n, 729)).tocsr()
    W = P@Z0
    C = sparse.load_npz(bind(packet/"C.npz"))
    assert np.max(abs((C@W).data), initial=0.) < 1e-10
    Kb = sparse.load_npz(bind(packet/"independent_Kb.npz"))
    test_energy = np.asarray(W.multiply(Kb@W).sum(axis=0)).ravel()
    if h == 1:
        coarse_test_energy = test_energy
    else:
        assert np.max(abs(test_energy-coarse_test_energy)/coarse_test_energy) < 1e-10
    fixed_r = W.T@(raw["direct_independent_bulk_action"]-raw["actual_external_F"])
    normalization = np.sqrt(test_energy*energy)
    for j, item in enumerate(old_fixed["results"][h-1]["all_tests"]):
        assert labels0[chosen[j]] == item["label"]
        close(fixed_r[j]/normalization[j], item["normalized_physical_defect"])
        for key, action in actions.items():
            close((W[:, j].T@action).item()/normalization[j], item["normalized_terms"][key])

all_graph = [r for r in spatial["rows"] if r["graph"] == "all"]
assert all_graph[-1]["intervals"]["whole"]["moment_L2_N_sqrt_mm"] > all_graph[0]["intervals"]["whole"]["moment_L2_N_sqrt_mm"]
for path, digest in inputs.items():
    assert hashlib.sha256(Path(path).read_bytes()).hexdigest() == digest
result = {"status": "REPRODUCED_16_SPATIAL_4_COMPLETE_LOCAL_AND_30_FIXED_TEST_READBACKS",
          "original_strong_moment_adverse_trend_reproduced": True,
          "verification_not_retroactive_historical_producer": True,
          "resources": resources, "maximum_polynomial_reconstruction_error": maximum_polynomial_error,
          "input_sha256": inputs, "source_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
(DIAG/"EXISTING_DATA_REPRODUCTION.json").write_text(json.dumps(result, indent=2)+"\n", encoding="utf-8")
print(json.dumps({key: value for key, value in result.items() if key != "input_sha256"}, indent=2))
