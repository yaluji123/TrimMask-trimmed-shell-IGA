"""Independent quadratic plane-stress FE on the exact registered polygonal plate.
No Native matrix/solution supplies this FE stiffness or force.
One explicit mesh-size level only; convergence is a separate readback.
"""
from pathlib import Path
import os
for key in ('OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS'):os.environ[key]='1'
import argparse,hashlib,json,sys,time
import numpy as np
from scipy.sparse.linalg import spsolve
HERE=Path(__file__).resolve().parent
PREP=HERE.parents[3]
sys.path.insert(0,str(HERE.parent/'public_plate_reference_dependencies_v1'))
sys.path.insert(0,str(HERE/'qualified_math'))
import triangle
import independent_triangle_p2 as p2

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def need(ok,message):
 if not ok:raise ValueError(message)
def signed_area(poly):
 a=np.asarray(poly);return .5*np.sum(a[:,0]*np.roll(a[:,1],-1)-np.roll(a[:,0],-1)*a[:,1])
def inside(point,poly):
 x,y=point;a=np.asarray(poly);b=np.roll(a,-1,axis=0)
 crossings=(a[:,1]>y)!=(b[:,1]>y)
 return bool(np.count_nonzero(crossings & (x<(b[:,0]-a[:,0])*(y-a[:,1])/np.where(crossings,b[:,1]-a[:,1],1)+a[:,0]))%2)
def points_inside(points,poly):
 a=np.asarray(poly);b=np.roll(a,-1,axis=0);counts=np.zeros(len(points),dtype=np.int32)
 for first,last in zip(a,b):
  cross=(first[1]>points[:,1])!=(last[1]>points[:,1])
  if last[1]!=first[1]:counts+=cross & (points[:,0]<(last[0]-first[0])*(points[:,1]-first[1])/(last[1]-first[1])+first[0])
 return counts%2==1
def hole_seed(poly):
 a=np.asarray(poly);b=np.roll(a,-1,axis=0);cross=a[:,0]*b[:,1]-b[:,0]*a[:,1]
 seed=((a+b)*cross[:,None]).sum(0)/(3*cross.sum())
 need(inside(seed,a),'polygon centroid must be strictly inside each declared hole')
 distances=[]
 for x,y in zip(a,b):
  d=y-x;v=seed-x;s=np.clip(v@d/(d@d),0,1);distances.append(np.linalg.norm(v-s*d))
 need(min(distances)>1e-8,'hole seed on/near actual segment')
 return seed
def make_mesh(loops,max_area):
 vertices=[];segments=[];markers=[];seeds=[]
 for i,poly in enumerate(loops):
  a=np.asarray(poly);need(len(a)>=3 and np.isfinite(a).all(),'finite original polygon')
  base=len(vertices);vertices.extend(a.tolist())
  segments.extend([(base+j,base+(j+1)%len(a))for j in range(len(a))])
  markers.extend([10,20,30,40]if i==0 else [100+i]*len(a))
  if i:seeds.append(hole_seed(a))
 inp=dict(vertices=np.asarray(vertices),segments=np.asarray(segments,dtype=np.int32),segment_markers=np.asarray(markers,dtype=np.int32),holes=np.asarray(seeds))
 out=triangle.triangulate(inp,'pq20a%.17geCn'%max_area)
 x=np.asarray(out['vertices']);t=np.asarray(out['triangles'],dtype=np.int64)
 area=np.cross(x[t[:,1]]-x[t[:,0]],x[t[:,2]]-x[t[:,0]])/2
 need((area>0).all()and area.max()<=max_area*(1+1e-10),'positive oriented mesh / declared area cap')
 edge=np.sort(np.concatenate([t[:,[0,1]],t[:,[1,2]],t[:,[2,0]]]),axis=1)
 unique,inverse,counts=np.unique(edge,axis=0,return_inverse=True,return_counts=True)
 need(np.isin(counts,[1,2]).all(),'manifold conforming triangle mesh')
 base=len(x);conn=np.column_stack([t,base+inverse[:len(t)],base+inverse[len(t):2*len(t)],base+inverse[2*len(t):]])
 x=np.vstack([x,x[unique].mean(1)]);lookup={tuple(e):base+i for i,e in enumerate(unique)}
 boundary=np.asarray(out['segments'],dtype=np.int64);mark=np.asarray(out['segment_markers']).ravel()
 declared={tuple(sorted(e))for e in boundary};observed={tuple(e)for e in unique[counts==1]}
 need(declared==observed,'all and only actual exterior/hole segments are mesh boundary')
 need(set(mark)==set([10,20,30,40]+list(range(101,100+len(loops)))),'all original declared hole boundary markers retained')
 boundary6=np.array([(a,b,lookup[tuple(sorted([a,b]))])for a,b in boundary],dtype=np.int64)
 target=abs(signed_area(loops[0]))-sum(abs(signed_area(v))for v in loops[1:])
 need(abs(area.sum()-target)/target<1e-10,'independent signed polygon material area versus complete FE mesh')
 centroids=x[t].mean(1)
 need(all(not np.any(points_inside(centroids,hole))for hole in loops[1:]),'no mesh triangle centroid inside a hole')
 return x,conn,boundary6,mark,area,target
def physical_inputs(case):
 g=read(case/'capture/trim_geometry_819.json');need(g['is_flat']and not g['is_rational']and g['trim_registered']and g['has_holes']and len(g['hole_loops'])==24,'same flat registered24-hole plate')
 cp=np.asarray(g['control_global_Vg']).reshape(g['controls_u'],g['controls_v'],3)
 origin=cp[0,0];A=np.column_stack([cp[-1,0]-origin,cp[0,-1]-origin])
 gu=np.array([np.mean(g['knots_u'][i+1:i+4])for i in range(g['controls_u'])]);gv=np.array([np.mean(g['knots_v'][i+1:i+4])for i in range(g['controls_v'])])
 exact=origin+gu[:,None,None]*A[:,0]+gv[None,:,None]*A[:,1]
 gap=float(np.max(np.linalg.norm(cp-exact,axis=2)));need(gap<1e-8 and np.max(np.abs(cp[:,:,2]))<1e-12 and np.max(np.abs(A-np.array([[2000,0],[0,800],[0,0]])))<1e-8,'verified affine physical map and planar membrane')
 loops=[np.asarray(v)@A[:2].T for v in [g['outer_loop']]+g['hole_loops']]
 need(np.max(np.abs(loops[0]-np.array([[0,0],[2000,0],[2000,800],[0,800]])))<1e-8,'unchanged outer boundary orientation/marker meaning')
 snapshots=[json.loads(l)for l in(case/'boundary_domain_probe.jsonl').read_text().splitlines()]
 bc=[r for r in snapshots if r['event']=='apply_snapshot']
 need(len(bc)==1 and bc[0]['surface']==819 and bc[0]['api_edge']==0 and bc[0]['prescribed_global']==[0]*6 and bc[0]['active_components']==[True]*6,'same x=0 homogeneous physical clamp')
 mat=read(case/'input_audit/bulk_measure_raw_bulk_before_support_819.json');need(mat['E_N_per_mm2']==206000 and mat['nu']==.3 and mat['t_mm']==5,'same actual material/thickness')
 ld=read(case/'input_audit/load_0_read_entity.json');need(ld['owner_shell_handle']==819 and ld['boundaryNum']==1 and ld['stored_force_payload']==[100,0,0,0,0,0],'same original right-edge line-load payload')
 force=np.loadtxt(case/'input_audit/pre_boundary_force.csv',delimiter=',',skiprows=1)[:,1].reshape(-1,3).sum(0)
 traction=np.array([500.,0.]);need(np.linalg.norm(force-np.array([400000,0,0]))<1e-7,'actual pre-BC total external force matches independently integrated 500N/mm over800mm')
 paths=[case/'capture/trim_geometry_819.json',case/'boundary_domain_probe.jsonl',case/'input_audit/bulk_measure_raw_bulk_before_support_819.json',case/'input_audit/load_0_read_entity.json',case/'input_audit/pre_boundary_force.csv']
 return loops,origin,traction,gap,[dict(path=str(f),sha256=sha(f))for f in paths]
def controls():
 original=p2.self_check()
 loops=[np.array([[0,0],[2,0],[2,2],[0,2]]),np.array([[.75,.75],[1.25,.75],[1.25,1.25],[.75,1.25]])]
 # A small annulus checks constrained holes and material area independently of FE solve.
 x,c,b,m,area,target=make_mesh(loops,.1)
 need(abs(target-3.75)<1e-14,'known annular area control')
 return dict(original_qualified_P2_MMS=original,known_square_hole_area=target,all_boundary_markers_preserved=True)
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--case',type=Path);ap.add_argument('--maximum-area-mm2',type=float);ap.add_argument('--out',type=Path);ap.add_argument('--self-check-only',action='store_true');a=ap.parse_args()
 need(triangle.__version__=='20250106','fixed observed independent mesh backend')
 if a.self_check_only:print(json.dumps(controls()));return
 protocol=read(HERE/'PREDECLARED_REFERENCE_PROTOCOL.json')
 need(a.maximum_area_mm2 in protocol['maximum_triangle_areas_mm2']and a.out.is_absolute()and not a.out.exists(),'one explicitly selected predeclared reference level / fresh output')
 start=time.perf_counter();loops,origin,traction,gap,bindings=physical_inputs(a.case)
 x,conn,boundary,markers,area,domain=make_mesh(loops,a.maximum_area_mm2)
 K,areas=p2.assemble(x,conn,E=206000.,nu=.3,t=5.);F=np.zeros(2*len(x))
 for aa,bb,mm in boundary[markers==20]:
  length=np.linalg.norm(x[bb]-x[aa])
  for node,w in [(aa,1/6),(bb,1/6),(mm,2/3)]:F[2*node:2*node+2]+=length*w*traction
 fixed=np.zeros(2*len(x),dtype=bool);fixed[(2*boundary[markers==40].ravel()[:,None]+np.arange(2)).ravel()]=True
 u=np.zeros(2*len(x));free=~fixed;u[free]=spsolve(K[free][:,free],F[free])
 residual=K@u-F;force=F.reshape(-1,2).sum(0);reaction=residual.reshape(-1,2)[fixed[::2]].sum(0)
 energy=float(.5*u@(K@u));work=float(.5*u@F);fr=float(np.linalg.norm(residual[free])/np.linalg.norm(F));fb=float(np.linalg.norm(force+reaction)/np.linalg.norm(force))
 moment=float(np.sum(x[:,0]*F[1::2]-x[:,1]*F[::2]));reaction_moment=float(np.sum(x[fixed[::2],0]*residual[1::2][fixed[::2]]-x[fixed[::2],1]*residual[::2][fixed[::2]]))
 mb=abs(moment+reaction_moment)/abs(moment)
 need(np.isfinite(u).all()and max(fr,fb,mb,abs(energy-work)/abs(work))<1e-8,'independent unshifted FE solve, load/reaction/work balance')
 peak=int(np.linalg.norm(u.reshape(-1,2),axis=1).argmax())
 a.out.mkdir();np.savez_compressed(a.out/'mesh_and_state.npz',points=x,triangles=conn,U=u.reshape(-1,2),F=F.reshape(-1,2),origin=origin,boundary6=boundary,boundary_markers=markers)
 q=dict(status='ONE_INDEPENDENT_REGISTERED_PLATE_P2_LEVEL_ONLY_NOT_CONVERGENCE',maximum_triangle_area_mm2=a.maximum_area_mm2,nodes=len(x),P2_elements=len(conn),dofs=len(u),registered_material_area_mm2=domain,mesh_area_mm2=float(area.sum()),affine_geometry_max_control_gap_mm=gap,E_N_per_mm2=206000,nu=.3,t_mm=5,traction_N_per_mm=traction.tolist(),independent_external_force_N=force.tolist(),support_reaction_N=reaction.tolist(),force_balance_relative=fb,moment_balance_relative=mb,free_residual_relative=fr,material_energy_Nmm=energy,half_external_work_Nmm=work,peak_U_mm=float(np.linalg.norm(u.reshape(-1,2)[peak])),peak_vector_mm=u.reshape(-1,2)[peak].tolist(),peak_world_mm=(x[peak]+origin[:2]).tolist(),registered_holes=24,excluded_holes=0,excluded_elements=0,independent_stiffness_exact_degree2_quadrature=True,no_Native_K_or_U_used=True,physical_clamp_is_strong_reference_to_Native_weak_BC=True,planar_in_plane_KL_membrane_only=True,finite_computed_reference_not_exact_continuum=True,source_sha256=sha(Path(__file__)),input_bindings=bindings,protocol_sha256=sha(HERE/'PREDECLARED_REFERENCE_PROTOCOL.json'),state_sha256=sha(a.out/'mesh_and_state.npz'),wall_seconds=time.perf_counter()-start)
 (a.out/'results.json').write_text(json.dumps(q,indent=2),encoding='utf-8');print(json.dumps(q))
if __name__=='__main__':main()

