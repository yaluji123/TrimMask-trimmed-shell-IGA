"""Independent raw-path audit; no production edits, geometric repair or host work."""
import hashlib
import json
import sys
from collections import Counter
from decimal import Decimal
from pathlib import Path

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
sys.path.insert(0, str(HERE.parent))
import owner_interval_classifier as c

CAPTURE = ROOT / 'runtime/runs/engineering_panel_input_only_v1/capture'
OWNERS = [812, 826, 827, 829]
ORIGINAL_RING = c.ring


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path, exact=False):
    return json.loads(path.read_text(encoding='utf-8-sig'),
                      **({'parse_float': Decimal} if exact else {}))


def raw(values):
    return [c.vec(p) for p in values]


def winding(r, p):
    result = 0
    for a, b in c.edges(r):
        if c.on(a, b, p):
            return None
        cross = c.cross2(c.sub(b, a), c.sub(p, a))
        if a[1] <= p[1] < b[1] and cross > 0:
            result += 1
        elif b[1] <= p[1] < a[1] and cross < 0:
            result -= 1
    return result


def meetings(r):
    result = []
    for i, (a, b) in enumerate(c.edges(r)):
        for j, (d, e) in enumerate(c.edges(r)):
            if j <= i or j == i + 1 or (i == 0 and j == len(r) - 1):
                continue
            if c.segments_meet(a, b, d, e):
                proper = (c.cross2(c.sub(b, a), c.sub(d, a)) *
                          c.cross2(c.sub(b, a), c.sub(e, a)) < 0 and
                          c.cross2(c.sub(e, d), c.sub(a, d)) *
                          c.cross2(c.sub(e, d), c.sub(b, d)) < 0)
                result.append({'edge_indices_zero_based': [i, j],
                               'kind': 'proper_crossing' if proper else 'touch_or_overlap'})
    return result


def guarded_ring(allowed):
    def accept(values):
        try:
            return ORIGINAL_RING(values)
        except c.Unsupported as error:
            r = raw(values)
            if (str(error) != 'self_intersecting_or_self_touching_ring' or
                    tuple(r) not in allowed):
                raise
            # Only the four hash-bound, exactly retraced paths are admitted.
            assert len(r) == 7 and r[3] == r[5] and r[3] != r[4]
            assert [x['edge_indices_zero_based'] for x in meetings(r)] == [[2, 4], [2, 5], [3, 5]]
            assert all(x['kind'] != 'proper_crossing' for x in meetings(r))
            return r
    return accept


def inventory(exact):
    values = [load(p, exact) for p in sorted(CAPTURE.glob('trim_geometry_*.json'))]
    allowed = {tuple(raw(g['outer_loop'])) for g in values if g['shell_handle'] in OWNERS}
    c.ring = guarded_ring(allowed)
    try:
        surfaces = {int(g['shell_handle']): c.Surface(g) for g in values}
        assert len(surfaces) == 36 and sum(s.controls for s in surfaces.values()) == 4081
        for g in values:
            s = surfaces[int(g['shell_handle'])]
            if g['has_outer']:
                assert s.outer == raw(g['outer_loop']), 'raw ring changed'
            assert s.holes == [raw(v) for v in g['hole_loops']], 'hole rings changed'
        registry = load(CAPTURE / 'couples_registry_input_only.json', exact)
        relations, clusters = c.relation_inventory(surfaces, registry)
    finally:
        c.ring = ORIGINAL_RING
    return surfaces, relations, clusters


def run():
    output_paths = [HERE / v for v in ['ring_audit.json', 'owner_inventory_raw_path_float.json',
                                       'owner_inventory_raw_path_exact_tokens.json']]
    assert all(not p.exists() for p in output_paths), 'refuse frozen evidence overwrite'
    bound = list(CAPTURE.glob('*.json')) + [HERE.parent / 'owner_interval_classifier.py',
            ROOT / 'candidate_source/IGAforCAD/Curves.cpp',
            ROOT / 'candidate_source/IGAforCAD/TrimmedUV.h',
            ROOT / 'candidate_source/IGAforCAD/OEBoundaryDomainDebugV2.h',
            ROOT / 'runtime/runs/engineering_panel_input_only_v1/source_runtime_manifest.json']
    before = {str(p): sha(p) for p in bound}
    checks = []

    # Controls distinguish parity from nonzero winding and preserve boundary unknowns.
    square = raw([[0, 0], [1, 0], [1, 1], [0, 1]])
    centre = c.vec([.5, .5])
    assert c.inside(square, centre) is True and winding(square, centre) == 1
    assert c.inside(square + square, centre) is False and winding(square + square, centre) == 2
    assert c.inside(square, c.vec([0, .5])) is None
    for crossing in [[[0, 0], [1, 1], [0, 1], [1, 0]],
                     [[0, 0], [1, 1], [0, 1], [.75, 0]]]:
        assert any(v['kind'] == 'proper_crossing' for v in meetings(raw(crossing)))
        try:
            guarded_ring(set())(crossing)
        except c.Unsupported:
            pass
        else:
            raise AssertionError('unapproved bow-tie admitted')
    checks += ['evenodd_distinct_from_nonzero_control', 'boundary_retains_unknown',
               'nonwhitelisted_selfintersection_remains_rejected']

    float_surfaces, float_relations, float_clusters = inventory(False)
    exact_surfaces, exact_relations, exact_clusters = inventory(True)
    baseline = load(HERE.parent / 'actual_panel_input_only_v1/owner_inventory.json')
    by_float = {r['couple_handle']: c.encode(r) for r in float_relations}
    baseline_supported = [r for r in baseline['relations'] if r['status'] != 'UNSUPPORTED']
    assert len(baseline_supported) == 59
    assert all(by_float[r['couple_handle']] == r for r in baseline_supported)
    checks += ['all36_paths_preserved_in_both_numeric_ingests',
               'previous59_supported_relation_records_exactly_unchanged_float_ingest']
    rings = []
    for h in OWNERS:
        path = CAPTURE / f'trim_geometry_{h}.json'
        g = load(path, True)
        r = raw(g['outer_loop'])
        assert g['has_outer'] and not g['has_holes'] and not g['hole_loops']
        assert r[3] == r[5] and len(r) == 7
        assert all(v['kind'] != 'proper_crossing' for v in meetings(r))
        s = exact_surfaces[h]
        # The calculation always retains all seven vertices and both retraced edges.
        probes = []
        a, b = r[3], r[4]
        mid = c.mul(c.add(a, b), c.F(1, 2))
        assert c.inside(r, mid) is None and winding(r, mid) is None
        d = c.sub(b, a)
        normal = (-d[1], d[0])
        for sign in [-1, 1]:
            p = c.add(mid, c.mul(normal, c.F(sign, 100)))
            state = c.inside(r, p)
            wn = winding(r, p)
            assert state is True and wn == 1
            probes.append({'point_uv': p, 'evenodd': state, 'winding': wn,
                           'nonzero': wn != 0})
        grid = Counter()
        for i in range(1, 20):
            for j in range(1, 20):
                p = (c.F(i, 20), c.F(j, 20))
                parity, wn = c.inside(r, p), winding(r, p)
                assert (parity is None) == (wn is None)
                if parity is not None:
                    assert parity == (wn != 0)
                    grid[str(wn)] += 1
                else:
                    grid['raw_path_boundary'] += 1
        rings.append({'shell_handle': h, 'file_sha256': sha(path),
            'raw_outer_exact_decimal_tokens': [[str(x) for x in p] for p in g['outer_loop']],
            'raw_vertex_count': len(r), 'raw_hole_count': 0,
            'reverse_edge_indices_zero_based': [3, 4],
            'nonadjacent_meetings': meetings(r), 'proper_crossing_count': 0,
            'nominal_affine_retraced_length_mm': c.norm(c.sub(s.point(a), s.point(b))),
            'signed_shoelace_uv_area': sum(c.cross2(x, y) for x, y in c.edges(r)) / 2,
            'control_hull_affine_defect_mm': s.defect,
            'two_limiting_sides_of_retrace': probes,
            'point_on_retrace_midpoint': {'point_uv': mid, 'evenodd': None,
                'interpretation': 'raw path support; boundary unknown retained, not one-sided material boundary'},
            'grid_winding_counts_checks_only_not_certificate': dict(grid),
            'fill_cancellation_certificate': 'Edges 3 A->B and 4 B->A have identical geometric support and opposite direction. Off their support, their ray-crossing parity contribution is two or zero and their signed winding contribution is zero. No path vertex or edge is removed for classification.',
            'mechanical_crack_boundary_inferred': False})
    checks += ['all4_exact_reverse_edges', 'all4_no_proper_crossing', 'all4_on_retrace_remain_unknown',
               'all4_two_sides_material_evenodd_and_nonzero', 'all4_offpath_grid_parity_winding_agree']

    for path, exact, surfaces, relations, clusters in [
            (output_paths[1], False, float_surfaces, float_relations, float_clusters),
            (output_paths[2], True, exact_surfaces, exact_relations, exact_clusters)]:
        packet = {'status': 'SCOPED_RAW_PATH_GEOMETRY_AUDIT_ONLY',
            'decimal_ingest': 'captured_lexical_decimal_tokens' if exact else 'existing_classifier_float_then_str',
            'surface_count': len(surfaces), 'control_count': sum(s.controls for s in surfaces.values()),
            'relations': relations, 'physical_line_clusters': clusters,
            'raw_rings_modified_or_removed': False, 'production_acceptance': False}
        path.write_text(json.dumps(c.encode(packet), indent=2), encoding='utf-8')
    assert before == {str(p): sha(p) for p in bound}
    checks.append('all_bound_capture_and_source_files_unchanged')
    relation_summary = {}
    for label, relations in [('float_ingest', float_relations), ('exact_token_ingest', exact_relations)]:
        relation_summary[label] = {'statuses': dict(Counter(r['status'] for r in relations)),
            'pair_topology_interval_counts': dict(Counter(x['topology'] for r in relations for x in r.get('pair_material_intervals', []))),
            'unsupported': [{'couple_handle': r['couple_handle'], 'reason': r.get('reason')} for r in relations if r['status'] == 'UNSUPPORTED']}
    receipt = {'schema': 'oe-panel-raw-retrace-topology-audit-v1',
        'status': 'SCOPED_RAW_PATH_GEOMETRY_AUDIT_ONLY', 'checks': checks,
        'ring_findings': rings, 'relation_inventory_summary': relation_summary,
        'admission_scope': 'Only these four exact raw paths; existing simple-ring classifier remains unchanged on disk. No generic self-intersection support asserted.',
        'old_supported_relation_count': 59,
        'old_supported_records_unchanged_float_ingest': True,
        'source_and_capture_sha256': before,
        'output_sha256': {p.name: sha(p) for p in output_paths[1:]},
        'script_sha256': sha(Path(__file__)), 'source_and_capture_rechecked_unchanged': True,
        'production_code_written_or_compiler_host_solver_started': False,
        'physical_CAD_accuracy_mapping_quadrature_or_mechanics_accepted': False}
    output_paths[0].write_text(json.dumps(c.encode(receipt), indent=2), encoding='utf-8')
    print(json.dumps({'receipt': str(output_paths[0]), 'checks': len(checks), 'relations': relation_summary}))


if __name__ == '__main__':
    run()
