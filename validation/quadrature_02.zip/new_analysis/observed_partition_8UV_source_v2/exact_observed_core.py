"""Source-only core. Measured partition is NOT independent raw-domain truth. No executable main."""
from fractions import Fraction as F
from math import comb
PAIRS=((0,0),(3,3),(2,6),(4,4),(6,2),(4,6),(5,5),(6,4))
FIXED_RECOVERY_ROWS=(0,5,30)  # zero-based Rule36 rows, fixed before reading results
UNIT_ROUNDOFF=F(1,2**53)
def gamma(n):return n*UNIT_ROUNDOFF/(1-n*UNIT_ROUNDOFF)
def q(x):return F.from_float(float(x))
def signed_area(p):return sum((a[0]*b[1]-b[0]*a[1]for a,b in zip(p,p[1:]+p[:1])),F(0))/2
def polygon_moment(p,a,b):
 """Exact Green boundary integral; works with concave/weakly-simple clipped paths."""
 if len(p)<3:return F(0)
 result=F(0)
 for A,B in zip(p,p[1:]+p[:1]):
  dx,dy=B[0]-A[0],B[1]-A[1]
  for i in range(a+2):
   for j in range(b+1):
    result+=dy*comb(a+1,i)*comb(b,j)*A[0]**(a+1-i)*dx**i*A[1]**(b-j)*dy**j/F((a+1)*(i+j+1))
 return result
def positive_moments(p):
 if signed_area(p)<0:p=list(reversed(p))
 return tuple(polygon_moment(p,a,b)for a,b in PAIRS)
def inverse3(m):
 """Exact3x3 only; never a global matrix/factorization."""
 a=[list(row)+[F(int(i==j))for j in range(3)]for i,row in enumerate(m)]
 for i in range(3):
  pivot=next(j for j in range(i,3)if a[j][i]);a[i],a[pivot]=a[pivot],a[i]
  scale=a[i][i];a[i]=[x/scale for x in a[i]]
  for j in range(3):
   if j!=i:
    scale=a[j][i];a[j]=[x-scale*y for x,y in zip(a[j],a[i])]
 return [row[3:]for row in a]
def interval_add(a,b):return(a[0]+b[0],a[1]+b[1])
def interval_sub(a,b):return(a[0]-b[1],a[1]-b[0])
def interval_mul(a,b):
 values=[x*y for x in a for y in b];return(min(values),max(values))
def decode_triangle(rule,uv):
 """Use exactly3 prescribed coordinate equations; all other nodes remain validation.

 Error boxes follow binary643-products/2-additions gamma5 bounds, not fitted
 tolerances. Serialized17-digit coordinates represent exact stored doubles.
 Subnormal/nonfinite inputs or invalid arithmetic contract must be OPEN upstream.
 """
 assert len(rule)==len(uv)==36
 matrix=[[q(x)for x in rule[i][:3]]for i in FIXED_RECOVERY_ROWS];inv=inverse3(matrix)
 norm=max(sum(map(abs,row),F(0))for row in inv)
 rowsum=max(sum(map(q,row[:3]),F(0))for row in rule)
 eta=norm*gamma(5)*rowsum;assert eta<1
 centers=[];radii=[]
 for axis in range(2):
  samples=[q(uv[i][axis])for i in FIXED_RECOVERY_ROWS]
  v=[sum((x*y for x,y in zip(row,samples)),F(0))for row in inv]
  radius=eta*max(map(abs,v))/(1-eta)
  centers.append(v);radii.append(radius)
 vertices=[(centers[0][i],centers[1][i])for i in range(3)]
 boxes=[[(centers[axis][i]-radii[axis],centers[axis][i]+radii[axis])for axis in range(2)]for i in range(3)]
 bad=[]
 for index,(bary,point)in enumerate(zip(rule,uv)):
  for axis in range(2):
   expected=(F(0),F(0));magnitude=F(0)
   for i in range(3):
    coefficient=q(bary[i]);expected=interval_add(expected,interval_mul((coefficient,coefficient),boxes[i][axis]));magnitude+=abs(coefficient)*max(map(abs,boxes[i][axis]))
   error=gamma(5)*magnitude;observed=q(point[axis]);bound=(expected[0]-error,expected[1]+error)
   if not bound[0]<=observed<=bound[1]:bad.append({'row':index,'axis':axis,'observed':str(observed),'format_bound':list(map(str,bound))})
 return{'vertices':vertices,'vertex_boxes':boxes,'coordinate_radii':radii,'coordinate_overconstraints_failed':bad,'scope':'measured execution triangle with explicit encoding uncertainty, not independent raw geometry'}
def triangle_area_interval(boxes):
 bx=interval_sub(boxes[1][0],boxes[0][0]);by=interval_sub(boxes[1][1],boxes[0][1]);cx=interval_sub(boxes[2][0],boxes[0][0]);cy=interval_sub(boxes[2][1],boxes[0][1])
 determinant=interval_sub(interval_mul(bx,cy),interval_mul(by,cx))
 if determinant[0]<=0<=determinant[1]:return None
 if determinant[1]<0:determinant=(-determinant[1],-determinant[0])
 # Seven elementary operations in the native determinant; conservative signed
 # term bound stays separate from the1e-13 moment criterion.
 magnitude=max(map(abs,interval_mul(bx,cy)))+max(map(abs,interval_mul(by,cx)))
 radius=gamma(7)*magnitude
 return(max(F(0),(determinant[0]-radius)/2),(determinant[1]+radius)/2)
def validate_uv_weights(rule,weights,area_interval):
 if area_interval is None:return {'status':'OPEN_TRIANGLE_AREA_ENCODING_RESOLUTION','failed_rows':[]}
 bad=[]
 for i,(row,w)in enumerate(zip(rule,weights)):
  scale=q(row[3]);expected=interval_mul(area_interval,(scale,scale));rounding=UNIT_ROUNDOFF*max(map(abs,expected));bound=(expected[0]-rounding,expected[1]+rounding)
  value=q(w)
  if not bound[0]<=value<=bound[1]:bad.append({'row':i,'actual_parametric_weight':str(value),'area_rule_bound':list(map(str,bound))})
 return {'status':'COORDINATE_AND_AREA_WEIGHT_ENCODING_CONTRACT_ONLY','failed_rows':bad}
def interval_pow(x,n):
 if n==0:return(F(1),F(1))
 if n%2:return(x[0]**n,x[1]**n)
 return(F(0)if x[0]<=0<=x[1]else min(x[0]**n,x[1]**n),max(x[0]**n,x[1]**n))
def triangle_moment_intervals(boxes,area_box):
 """Exact interval propagation of barycentric simplex identity, not fitted error."""
 if area_box is None:return None
 from math import factorial
 def composition(n):
  for i in range(n+1):
   for j in range(n+1-i):yield(i,j,n-i-j)
 output=[]
 for a,b in PAIRS:
  result=(F(0),F(0))
  for x in composition(a):
   cx=F(factorial(a),factorial(x[0])*factorial(x[1])*factorial(x[2]))
   for y in composition(b):
    coefficient=cx*F(factorial(b),factorial(y[0])*factorial(y[1])*factorial(y[2]))
    coefficient*=F(2*factorial(x[0]+y[0])*factorial(x[1]+y[1])*factorial(x[2]+y[2]),factorial(a+b+2))
    term=interval_mul(area_box,(coefficient,coefficient))
    for i in range(3):term=interval_mul(term,interval_mul(interval_pow(boxes[i][0],x[i]),interval_pow(boxes[i][1],y[i])))
    result=interval_add(result,term)
  output.append(result)
 return output
def clip_convex(subject,clip):
 """Exact halfplanes, concave subject permitted; bridges retain signed boundary."""
 if signed_area(clip)<0:clip=list(reversed(clip))
 for a,b in zip(clip,clip[1:]+clip[:1]):
  output=[]
  if not subject:return []
  for p,r in zip(subject,subject[1:]+subject[:1]):
   dp=(b[0]-a[0])*(p[1]-a[1])-(b[1]-a[1])*(p[0]-a[0]);dr=(b[0]-a[0])*(r[1]-a[1])-(b[1]-a[1])*(r[0]-a[0])
   pin,rin=dp>=0,dr>=0
   if pin:output.append(p)
   if pin!=rin:
    t=dp/(dp-dr);output.append((p[0]+t*(r[0]-p[0]),p[1]+t*(r[1]-p[1])))
  subject=output
 return subject
def triangle_set_encoding_bound(vertices,boxes):
 """Conservative symmetric-difference area from a convex Hausdorff bound."""
 radius=max(max(abs(box[0]-vertices[i][axis]),abs(box[1]-vertices[i][axis]))for i,b in enumerate(boxes)for axis,box in enumerate(b))
 delta=2*radius
 perimeter=sum((abs(a[0]-b[0])+abs(a[1]-b[1])for a,b in zip(vertices,vertices[1:]+vertices[:1])),F(0))
 return 2*perimeter*delta+8*delta*delta
