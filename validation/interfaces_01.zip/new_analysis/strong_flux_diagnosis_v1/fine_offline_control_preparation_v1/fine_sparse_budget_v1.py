"""Declared fine sparse capacity. No matrix, factor or solve is executed on import."""
LIMIT_BYTES = 512 * 1024**2
N = 6561
CAPTURE_ENTRY_CAP = 700000
CAPTURE_BYTES_CAP = 100 * 1024**2
NATIVE_REFERENCE_INPUT_NNZ = 630793
NATIVE_REFERENCE_LDLT_FACTOR_NNZ = 1360678


def state_factor_budget(actual_input_nnz, actual_L_plus_U_nnz=None):
    if not 0 < actual_input_nnz <= CAPTURE_ENTRY_CAP:
        raise ValueError("Actual fine input exceeds the fixed capture capacity")
    factor_cap = 3000000
    if actual_L_plus_U_nnz is not None and not 0 < actual_L_plus_U_nnz <= factor_cap:
        raise MemoryError("Actual SuperLU L+U fill exceeds the predeclared capacity")
    factor_bytes = factor_cap * (8+4)
    parts = {"interpreter_libraries": 128*1024**2,
             "simultaneous_input_and_reconstructed_sparse_buffers": 8*CAPTURE_ENTRY_CAP*16,
             "sparse_L_and_U": factor_bytes,
             "factor_workspace_reserve": 3*factor_bytes,
             "vectors_trace_rows_and_local_pencil": 32*1024**2,
             "streaming_parser_hash_and_misc_reserve": 16*1024**2}
    total = sum(parts.values())
    if total >= LIMIT_BYTES:
        raise MemoryError("Fine state simultaneous-buffer forecast exceeds 512 MiB")
    return {"n": N, "actual_input_nnz": actual_input_nnz,
            "reference_Native_LDLT_nnz_not_a_SuperLU_fill_proof": NATIVE_REFERENCE_LDLT_FACTOR_NNZ,
            "factor_L_plus_U_entry_cap": factor_cap, "actual_L_plus_U_nnz": actual_L_plus_U_nnz,
            "parts_bytes": parts, "forecast_bytes": total, "limit_bytes": LIMIT_BYTES,
            "requires_self_owned_OS_memory_job_before_numpy": True,
            "CPU_affinity_cores": 1, "BLAS_threads": 1,
            "actual_fill_must_be_measured_not_inferred_from_Native": True}


def riesz_factor_budget(actual_input_nnz, actual_L_plus_U_nnz=None):
    if not 0 < actual_input_nnz <= CAPTURE_ENTRY_CAP:
        raise ValueError("Actual physical G input exceeds the fixed capacity")
    factor_cap = 4000000
    if actual_L_plus_U_nnz is not None and not 0 < actual_L_plus_U_nnz <= factor_cap:
        raise MemoryError("Actual physical G fill exceeds the fixed capacity")
    parts = {"interpreter_libraries": 128*1024**2,
             "G_and_sparse_input_copies": 4*CAPTURE_ENTRY_CAP*16,
             "sparse_L_and_U": factor_cap*12,
             "factor_workspace_reserve": 3*factor_cap*12,
             "vectors_and_explicit_Z": 32*1024**2,
             "streaming_and_misc_reserve": 16*1024**2}
    total = sum(parts.values())
    if total >= LIMIT_BYTES:
        raise MemoryError("Fine Riesz forecast exceeds 512 MiB")
    return {"physical_free_n": 6237, "actual_input_nnz": actual_input_nnz,
            "factor_L_plus_U_entry_cap": factor_cap, "actual_L_plus_U_nnz": actual_L_plus_U_nnz,
            "forecast_bytes": total, "parts_bytes": parts, "limit_bytes": LIMIT_BYTES,
            "must_run_in_separate_process_after_state_factor_is_released": True}
