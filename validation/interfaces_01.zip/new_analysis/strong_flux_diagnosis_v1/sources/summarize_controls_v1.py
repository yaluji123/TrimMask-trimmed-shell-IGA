"""Independent saved-output checks and a complete fixed-control summary."""
from pathlib import Path
from datetime import datetime, timezone
import csv
import hashlib
import json
import sys
sys.dont_write_bytecode = True
from resource_guard import install, actual_budget

D = Path(__file__).resolve().parents[1]
ROOT = D.parents[1]
resources = install()
resources["preflight"] = actual_budget(729, 59921)
import numpy as np
from scipy import sparse


def norm(x):
    return float(np.linalg.norm(x.data if sparse.issparse(x) else x))


def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


protocol = read(D/"CONTROL_PROTOCOL.json")
baseline = read(D/"baseline_210_v1/results.json")
assert baseline["status"] == "QUALIFIED_RECONSTRUCTED_BASELINE_WITHIN_ORIGINAL_GATES"
base_state = np.load(D/"baseline_210_v1/state_and_scalar.npz")
F0, U0 = base_state["actual_F"], base_state["actual_U"]
lam = float(base_state["lambda_BC"])
K0 = sparse.load_npz(D/"baseline_210_v1/reconstructed_K.npz")
C = sparse.load_npz(D/"baseline_210_v1/KBC_consistency.npz")
P = sparse.load_npz(D/"baseline_210_v1/KBC_P.npz")
rows = []; controls = []; negative = []
for alpha in protocol["alphaB_values_fixed_before_any_control_solve"]:
    folder = D/f"alpha{int(alpha)}_v1"
    result = read(folder/"results.json")
    assert result["status"] == "COMPLETED_FIXED_ALPHA_CONTROL_NOT_STRONG_ACCEPTANCE"
    assert result["alphaB"] == alpha
    assert result["resources"]["OS_memory_job_installed"] and result["resources"]["CPU_affinity_cores"] == 1
    for path, digest in result["input_sha256"].items():
        assert hashlib.sha256(Path(path).read_bytes()).hexdigest() == digest
    state = np.load(folder/"controlled_state.npz")
    F, U = state["actual_unchanged_F"], state["U"]
    assert np.array_equal(F, F0)
    K = sparse.load_npz(folder/"controlled_K.npz")
    coefficient_delta = K-K0-(alpha-210.)*lam*P
    operation = norm(K)+norm(K0)+abs(alpha-210.)*lam*norm(P)
    assert norm(coefficient_delta) <= 1e-10*operation
    backward = norm(K@U-F)/(norm(K)*norm(U)+norm(F))
    assert backward <= protocol["baseline_gates"]["normwise_backward_error"]
    assert abs(backward-result["normwise_backward_error"]) < 1e-20
    if alpha == 210:
        assert norm(U-U0)/norm(U0) <= protocol["baseline_gates"]["actual_Native_vs_independent_U_relative"]
    strong = result["strong"]; boundary = result["boundary"]
    fixed = result["fixed_reference_response"]
    spatial = result["spatial"]
    row = {"alphaB": alpha, "BC_U_RMS_mm": boundary["displacement_RMS_mm"],
        "BC_theta_RMS_rad": boundary["rotation_RMS_rad"],
        "BC_consistency_work_Nmm": boundary["symmetric_consistency_quadratic_work_Nmm"],
        "BC_penalty_work_Nmm": boundary["penalty_quadratic_work_Nmm"],
        "BC_total_work_Nmm": boundary["BC_total_quadratic_work_Nmm"],
        "physical_weak_relative": result["complete_physical_weak_relative"],
        "raw_force_absolute_N_per_sqrt_mm": strong["effective_force_sum_L2_N_per_sqrt_mm"],
        "raw_force_relative_L2": strong["effective_force_sum_relative_L2"],
        "raw_axial_moment_absolute_N_sqrt_mm": strong["common_axis_moment_sum_L2_N_sqrt_mm"],
        "raw_axial_moment_relative_L2": strong["common_axis_moment_sum_relative_L2"],
        "first10_force_squared_fraction": (spatial["first10"]["force_abs_L2_N_per_sqrt_mm"]/spatial["whole"]["force_abs_L2_N_per_sqrt_mm"])**2,
        "first10_moment_squared_fraction": (spatial["first10"]["moment_abs_L2_N_sqrt_mm"]/spatial["whole"]["moment_abs_L2_N_sqrt_mm"])**2,
        "first_span_force_absolute_N_per_sqrt_mm": spatial["first_span"]["force_abs_L2_N_per_sqrt_mm"],
        "first_span_moment_absolute_N_sqrt_mm": spatial["first_span"]["moment_abs_L2_N_sqrt_mm"],
        "inner10to90_force_absolute_N_per_sqrt_mm": spatial["inner10to90"]["force_abs_L2_N_per_sqrt_mm"],
        "inner10to90_moment_absolute_N_sqrt_mm": spatial["inner10to90"]["moment_abs_L2_N_sqrt_mm"],
        "material_energy_Nmm": fixed["material_energy_Nmm"],
        "material_energy_signed_relative_to_finite_STRI3": fixed["material_energy_signed_relative_difference"],
        "fixed_PATCH2_vector_relative_to_finite_STRI3": fixed["fixed_vector_relative_difference"],
        "maximum_complete_weak_ledger_closure_normalized": result["maximum_normalized_complete_work_ledger_closure"],
        "independent_full_action_residual_L2_N": result["independent_full_action_residual_L2_N"],
        "backward_error": backward, "K_LU_factor_nnz": result["sparse_factor_nnz"],
        "peak_working_set_bytes": result["observed_memory"]["peak_working_set_bytes"],
        "peak_commit_bytes": result["observed_memory"]["peak_process_commit_bytes"]}
    assert row["peak_commit_bytes"] < 536870912 and row["peak_working_set_bytes"] < 536870912
    rows.append(row)
    controls.append({"alphaB": alpha, "folder": folder.name,
                     "results_sha256": hashlib.sha256((folder/"results.json").read_bytes()).hexdigest()})
    if alpha != 210:
        correct = C+alpha*lam*P
        wrong = (alpha/210.)*(C+210.*lam*P)
        relative = norm(wrong-correct)/norm(correct)
        assert relative > protocol["baseline_gates"]["actual_K_and_BC_relative_Frobenius"]
        negative.append({"alphaB": alpha, "forbidden_whole_BC_scaling_relative_matrix_difference": relative,
                         "rejected_at_original_1e10_matrix_gate": True, "wrong_control_state_solved": False})

reference_row = next(row for row in rows if row["alphaB"] == 210.)
for row in rows:
    row["energy_change_relative_to_alpha210"] = row["material_energy_Nmm"]/reference_row["material_energy_Nmm"]-1.
    row["raw_moment_relative_metric_change_vs_alpha210"] = row["raw_axial_moment_relative_L2"]/reference_row["raw_axial_moment_relative_L2"]-1.
    row["raw_force_relative_metric_change_vs_alpha210"] = row["raw_force_relative_L2"]/reference_row["raw_force_relative_L2"]-1.
with (D/"CONTROL_SUMMARY.csv").open("w", newline="", encoding="utf-8") as stream:
    writer = csv.DictWriter(stream, fieldnames=list(rows[0])); writer.writeheader(); writer.writerows(rows)
summary = {"created_utc": datetime.now(timezone.utc).isoformat(),
    "status": "ALL_THREE_PREDECLARED_CONTROLS_RECORDED_NO_PARAMETER_SELECTED",
    "baseline_reconstruction": {k: baseline[k] for k in ("boundary_lambda_reconstructed_without_fit",
        "boundary_matrix_relative_Frobenius", "full_K_relative_Frobenius", "coefficient_relative_to_actual_U",
        "original_coefficient_budget", "normwise_backward_error", "original_backward_budget")},
    "controls": controls, "rows": rows, "negative_matrix_checks": negative,
    "findings": [
        "The isolated change of weak-BC penalty changes the coarse axial-moment strong trace materially; H1 weak-boundary sensitivity is observed for this 729-DOF fixture.",
        "Increasing alpha tightens displacement/rotation traces but increases the axial-moment strong norm and the complete finite weak defect. It is not a monotone repair of physical strong balance.",
        "Raw force relative norms remain approximately 1.20; the original strong failure has not been fixed. No parameter is selected for publication or relabelled accepted.",
        "All three controls preserve the original F, Kbulk, interface consistency/penalty and point work. Source/actual-quadrature boundary reconstruction was verified against the actual exported BC and full K before the controls.",
        "The small material-energy and fixed-vector response changes coexist with substantial moment-trace changes. Global response agreement cannot decide this local issue.",
        "These h1 controls establish discrete weak-boundary sensitivity but do not identify a missing term, prove a continuum singularity, or decide the h4 mechanism."
    ],
    "all_bound_input_hashes_rechecked": True,
    "no_failed_control_omitted": True,
    "resources": resources,
    "summary_source_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
(D/"CONTROL_SUMMARY.json").write_text(json.dumps(summary, indent=2)+"\n", encoding="utf-8")
print(json.dumps({"status": summary["status"], "rows": rows, "negative_matrix_checks": negative}, indent=2))
