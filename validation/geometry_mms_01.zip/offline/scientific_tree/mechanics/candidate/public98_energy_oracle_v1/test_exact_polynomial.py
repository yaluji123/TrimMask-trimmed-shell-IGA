"""Exact algebra/energy/domain controls; not actual Native validation."""
from pathlib import Path
from fractions import Fraction as F
from itertools import combinations
import json,math
from exact_cell_polynomial import *

HERE=Path(__file__).resolve().parent;PREP=HERE.parents[2]
def unit_moments(hole=True):
    result={}
    for a in range(7):
        for b in range(7):
            x=F(1,(a+1)*(b+1))
            if hole:x-=((F(3,4)**(a+1)-F(1,4)**(a+1))/(a+1))*((F(3,4)**(b+1)-F(1,4)**(b+1))/(b+1))
            result[a,b]=x
    return result
def monomial_coeff(knots,i,power):
    values=[Q(x) for x in knots[i+1:i+4]]
    return sum((math.prod(c) for c in combinations(values,power)),F(0))/math.comb(3,power)

def main():
    g=json.loads((PREP/'runtime/runs/public98_duffy_reference_v5/input_audit/load_stage_geometry_819.json').read_text())
    ku=g['knots_u'];kv=g['knots_v'];bu=all_restrictions(ku,3);bv=all_restrictions(kv,3)
    basis_checks=0
    for au in (bu[0],bu[len(bu)//2],bu[-1]):
        for av in (bv[0],bv[len(bv)//2],bv[-1]):
            for p in range(4):
                for q in range(4):
                    c=[[monomial_coeff(ku,i,p)*monomial_coeff(kv,j,q)] for i in range(39) for j in range(39)]
                    den=lcm(v[0].denominator for v in c);integers=[[v[0].numerator*(den//v[0].denominator)] for v in c]
                    actual=restrict_field(au,av,integers,39,0,den)
                    expected=Poly.fractions({(i,j):math.comb(p,i)*au.lo**(p-i)*au.width**i*math.comb(q,j)*av.lo**(q-j)*av.width**j for i in range(p+1) for j in range(q+1)})
                    assert not (actual-expected).c;basis_checks+=1
    moments=unit_moments();M=MomentVector.fractions(moments);area=moments[0,0]
    E=F(206000);nu=F(3,10);t=F(5);Lx=F(2);Ly=F(3)
    a,b,c,d=F(1,100),F(2,100),F(3,100),F(-1,200)
    U=Poly.fractions({(1,0):a*Lx,(0,1):b*Ly});V=Poly.fractions({(1,0):c*Lx,(0,1):d*Ly})
    density,grad=membrane_half_density(U,V,Lx,Ly,E,nu,t)
    energy=M.integrate(density)*Lx*Ly
    hand=E*t/(2*(1-nu*nu))*(a*a+d*d+2*nu*a*d+(1-nu)*(b+c)**2/2)*area*Lx*Ly
    assert energy==hand
    omega=F(1,1000)
    rigidU=Poly.fractions({(0,0):F(1,10),(0,1):-omega*Ly});rigidV=Poly.fractions({(0,0):F(-1,5),(1,0):omega*Lx})
    rigid,rigid_grad=membrane_half_density(rigidU,rigidV,Lx,Ly,E,nu,t);assert M.integrate(rigid)==0
    # Degree-12 field norm term M66 is necessary even though energy degree<=10.
    high=Poly.fractions({(3,3):1});highEnergy,_=membrane_half_density(high,Poly({}),1,1,E,nu,t)
    handHigh=E*t/(2*(1-nu*nu))*9*(moments[4,6]+(1-nu)*moments[6,4]/2)
    assert M.integrate(highEnergy)==handHigh
    highNorm=M.integrate(high*high);assert highNorm==moments[6,6]
    oldMoments=MomentVector.fractions({k:v for k,v in moments.items() if sum(k)<=10})
    oldMoments.integrate(highEnergy)
    try:oldMoments.integrate(high*high)
    except ValueError:missing66=True
    else:raise AssertionError('incomplete energy moments cannot serve the field L2 norm')
    # Mixed bending test is NOMINAL AFFINE only; actual public98 uz is checked
    # separately and no Hessian mapping bound is inferred from this control.
    aa,bb,cc=F(1,100),F(1,200),F(-1,300)
    W=Poly.fractions({(2,0):aa*Lx*Lx,(1,1):bb*Lx*Ly,(0,2):cc*Ly*Ly})
    bend=bending_half_density(W,Lx,Ly,E,nu,t);D=E*t**3/(12*(1-nu*nu))
    handB=D/2*(4*aa*aa+4*cc*cc+8*nu*aa*cc+2*(1-nu)*bb*bb)*area*Lx*Ly
    assert M.integrate(bend)*Lx*Ly==handB
    # Exact affine geometry perturbation control, including the zero-nominal-
    # strain case. Relative-energy-only bounds would fail for this rigid field.
    eps=F(1,10**6);knots=[0]*4+[1]*4
    cp=[[Lx*(1+eps)*F(i,3),Ly*F(j,3),F(0)] for i in range(4) for j in range(4)]
    cert=jacobian_perturbation_certificate(cp,knots,knots,Lx,Ly)
    bound=membrane_geometry_energy_bound(rigid_grad,F(0),area,Lx,Ly,E,nu,t,cert)
    gamma=-omega+omega/(1+eps)
    trueRigidEnergy=E*t/(4*(1+nu))*gamma*gamma*Lx*(1+eps)*Ly*area
    assert trueRigidEnergy>0 and trueRigidEnergy<=bound
    try:jacobian_perturbation_certificate([[Lx*3*F(i,3),Ly*F(j,3),0] for i in range(4) for j in range(4)],knots,knots,Lx,Ly)
    except ValueError:badGeometry=True
    else:raise AssertionError('invalid inverse perturbation must reject')
    result=dict(schema='oe-exact-cell-polynomial-controls-v1',status='PASS_EXACT_ALGEBRA_DOMAIN_ENERGY_CONTROLS_ONLY',
        actual_knot_blossom_reproduction_checks=basis_checks,full_rectangle_minus_hole_area_exact=str(area),
        linear_mixed_membrane_energy_exact=str(energy),hand_linear_energy_exact=str(hand),
        rigid_membrane_energy_exact='0',degree10_membrane_energy_exact=str(handHigh),degree12_field_norm_M66_exact=str(highNorm),
        energy_moment_set_rejected_for_L2=missing66,mixed_bending_nominal_energy_exact=str(handB),
        affine_perturbation_actual_rigid_field_energy_exact=str(trueRigidEnergy),absolute_geometry_bound_exact=str(bound),
        invalid_inverse_perturbation_rejected=badGeometry,actual_public98_energy_computed=False,
        bending_control_is_not_actual_geometry_Hessian_certificate=True)
    (HERE/'exact_polynomial_controls.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(json.dumps({k:result[k] for k in ['status','actual_knot_blossom_reproduction_checks','energy_moment_set_rejected_for_L2','invalid_inverse_perturbation_rejected']},indent=2))

if __name__=='__main__':main()
