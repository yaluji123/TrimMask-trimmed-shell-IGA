"""Independent sparse KKT/state algebra reader. FEM/mesh accuracy remains separate."""
import argparse
import csv
import hashlib
import json
import math
from pathlib import Path
import numpy as np
from scipy import sparse

HERE = Path('runtime/preparation/final_paper_cases_20261107_v1/engineering_readers')
PREP = Path('投稿/二次修稿/准备工作')
POINT = PREP / 'mechanics/actual_hull4x_endpoint988_recovered_v1'
MAX_NNZ = 30000000


def sha(p):
    h = hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda: f.read(1024 * 1024), b''):
            h.update(b)
    return h.hexdigest()


def load(p, cap=8 << 20):
    assert p.is_file() and p.stat().st_size <= cap
    return json.loads(p.read_text(encoding='utf-8-sig'))


def rows(p, cap=128 << 20):
    assert p.is_file() and p.stat().st_size <= cap
    with p.open(encoding='utf-8-sig', newline='') as f:
        return list(csv.DictReader(f))


def matrix(p, n):
    assert p.is_file() and p.stat().st_size <= 2 << 30
    with p.open('rb') as f:
        count = sum(1 for _ in f) - 1
    assert 0 < count <= MAX_NNZ
    data = np.loadtxt(p, skiprows=1, delimiter=',', ndmin=2)
    assert data.shape == (count, 3) and np.isfinite(data).all()
    assert np.array_equal(data[:, :2], np.floor(data[:, :2])) and data[:, :2].min() >= 0 and data[:, :2].max() < n
    out = sparse.coo_matrix((data[:, 2], (data[:, 0].astype(np.int32), data[:, 1].astype(np.int32))), shape=(n, n)).tocsr()
    out.sum_duplicates()
    return out


def vector(p, n):
    data = np.loadtxt(p, skiprows=1, delimiter=',', ndmin=2)
    assert data.shape == (n, 2) and np.isfinite(data).all() and np.array_equal(data[:, 0], np.arange(n))
    return data[:, 1]


def norm_inf(a):
    return float(np.max(np.asarray(abs(a).sum(axis=1))))


def normalized_matrix_difference(a, b):
    error = norm_inf(a - b) / max(1., norm_inf(b))
    assert error <= 1e-10, ('independent sparse operator identity', error)
    return error


def kkt_check(a, b, x):
    residual = a @ x - b
    backward = float(np.linalg.norm(residual, np.inf) / max(1., norm_inf(a) * np.linalg.norm(x, np.inf) + np.linalg.norm(b, np.inf)))
    assert backward <= 1e-10, ('KKT normwise backward error', backward)
    return residual, backward


def selfcheck():
    a = sparse.csr_matrix([[2., 1.], [1., 0.]])
    x = np.array([1., -2.])
    b = np.array([0., 1.])
    assert kkt_check(a, b, x)[1] == 0.
    rejected = []
    for label, wrong in [('wrong_solution', x + .1), ('missing_reaction', np.array([1., 0.]))]:
        try:
            kkt_check(a, b, wrong)
        except AssertionError:
            rejected.append(label)
    assert len(rejected) == 2
    assert -x[1] * b[1] == x[0] * 2. * x[0]
    raw_c = sparse.csr_matrix([[1., -2.]])
    scale = .25
    assembled_c = sparse.csr_matrix([[.25, -.5]])
    assert normalized_matrix_difference(raw_c * scale, assembled_c) == 0.
    try:
        normalized_matrix_difference(raw_c, assembled_c)
    except AssertionError:
        rejected.append('omitted_constraint_scale')
    else:
        raise AssertionError('wrong raw-versus-assembled mapping accepted')
    assert float((raw_c @ np.array([2., 1.]))[0]) == 0.
    return dict(status='SPARSE_STATE_READER_SELF_CHECK_ONLY', negative_controls=rejected, FEM_or_engineering_accepted=False)


def audit(case, manifest_path, manifest_sha):
    assert sha(manifest_path) == manifest_sha
    manifest = load(manifest_path)
    assert manifest_sha == '50999199bb7bf6770b7446beae7c5e2600294276d6ba858ab7a616f873bf5a84'
    assert manifest['actual_source_binding_sha256'] == '90f72156bd9f1430e25177e91b6a69b89c4434f81934dfdee19b20eef2a96566' and manifest['actual_source_count'] == 1212
    assert sha(case / 'applied_source_binding.json') == '90f72156bd9f1430e25177e91b6a69b89c4434f81934dfdee19b20eef2a96566'
    modules = {x['name']: x['sha256'] for x in manifest['runtime']}
    assert modules['IGAforCAD.crx'] == 'd55a004bc4830d2ddadfad99b6e9ffd05511a5bf3f411c85a87179053a195f0b' and modules['JYH_IGAEntity.dbx'] == '3cf634b56ee449a15a4176e9c0e413bc17d65d99a19df9bfb6c2fd113f6b943d'
    assert sha(case / 'source_runtime_manifest.json') == manifest_sha
    artifacts = load(case / 'capture_artifact_manifest.json')['files']
    for r in artifacts:
        p = case / r['path']
        assert p.resolve().is_relative_to(case.resolve()) and p.stat().st_size == r['bytes'] and sha(p) == r['sha256']
    result = load(case / 'process_result.json')
    assert result['exit_code'] == 0 and result['natural_owned_child_exit']
    assert not load(case / 'actual_loaded_module_hashes.json')['errors'] and not load(case / 'actual_bootstrap_module_hashes.json')['errors']
    assert load(case / 'original_input_before_after.json')['exact_sha_and_mtime_unchanged']
    resources = load(case / 'owned_process_resource_observations.json')
    assert resources['within_declared_observed_memory'] and resources['declared_process_memory_bytes'] == 64 << 30
    state = case / 'derived_work/linear_state'
    done, layout = load(state / 'state_complete.json'), load(state / 'actual_layout.json')
    assert done['actual_Hull_linear_state_complete'] and done['global_K_assembled'] and done['actual_KKT_captured_and_solved']
    assert done['point_matrix_appended_once'] and done['old_capture_scope_ended_before_global']
    assert not done['independent_FEM_accuracy_or_PDE_stability_accepted']
    ns, nm, cb, nt = int(layout['structural']), int(layout['multiplier_base']), int(layout['master_constraint_base']), int(layout['total'])
    assert ns in (4086, 10611, 32841) and nm == ns + 12 and ns < cb < nt <= 40000
    selected = load(case / 'root_selected_window.json')
    profiles = {'mesh1x': (4086, 'c0bf2856a175986263cfefd40f7d434c96e6dc9a55b5439721b7b3153f0fd466'), 'mesh2x': (10611, '3d8feea6d136d43c56e8ce038d52b23a0c507466ce1a609fa737667cbdaf7c44'), 'state4x': (32841, 'e61b385ef49818614a8a460c1ba759b9808af1d999ea84ab183fa5737a984a6d')}
    assert selected['status'] == 'ROOT_SELECTED_ONE_MANUAL_ACTION' and selected['scope'] == 'OE_POINT_COMPLETE_90F_ONE_MANUAL_CASE_V7B'
    assert selected['action'] == 'hull' and selected['label'] == case.name and selected['runner_file'] == 'run_hull_once.py'
    assert selected['source_binding_sha256'] == '90f72156bd9f1430e25177e91b6a69b89c4434f81934dfdee19b20eef2a96566' and selected['runtime_manifest_sha256'] == '50999199bb7bf6770b7446beae7c5e2600294276d6ba858ab7a616f873bf5a84'
    assert set(selected['parameters']) == {'kind','analysis_profile_sha256','profile_recipe_receipt_sha256','profile_role'} and selected['parameters']['profile_role']=='engineering_mode4' and selected['parameters']['kind'] in profiles
    dofs, expected_input = profiles[selected['parameters']['kind']]
    assert ns == dofs and load(case / 'original_input_before_after.json')['before']['sha256'] == expected_input
    assert done['structural_dofs'] == ns and done['KKT_dofs'] == nt
    assert cb - nm == int(layout['constraint_rows']) and nt - cb == int(layout['master_constraints'])
    a = matrix(state / 'actual_KKT.csv', nt)
    k = matrix(state / 'structural_K.csv', ns)
    b, x = vector(state / 'actual_KKT_rhs.csv', nt), vector(state / 'actual_KKT_solution.csv', nt)
    f, u = vector(state / 'structural_rhs.csv', ns), vector(state / 'structural_solution.csv', ns)
    assert np.array_equal(x[:ns], u) and np.array_equal(b[:ns], f) and np.max(np.abs(f)) == 0.
    structural_block_error = normalized_matrix_difference(a[:ns, :ns], k)
    constraints = rows(state / 'actual_constraints.csv')
    master = rows(state / 'actual_master_constraints.csv')
    cr, cc, cv = [], [], []
    physical_residual = {}
    for r in constraints:
        row, col, value = int(r['constraint_index']), int(r['primal_col']), float(r['value'])
        assert 0 <= row < cb - nm and 0 <= col < nm and math.isfinite(value)
        cr += [nm + row, col]
        cc += [col, nm + row]
        assembled_value = value * float(r['coefficient_scale'])
        cv += [assembled_value, assembled_value]
        key = row
        data = physical_residual.setdefault(key, [0., float(r['coefficient_scale']), int(r['component'])])
        assert data[1] > 0 and math.isfinite(data[1])
        data[0] += value * x[col]
    prescribed = []
    for r in master:
        row, group, component, value = int(r['constraint_index']), int(r['group']), int(r['component']), float(r['prescribed_value'])
        primal = ns + 6 * group + component
        assert 0 <= row < nt - cb and 0 <= group < 2 and 0 <= component < 6 and b[cb + row] == value
        cr += [cb + row, primal]
        cc += [primal, cb + row]
        cv += [1., 1.]
        error = abs(x[primal] - value)
        assert error <= 1e-10, ('actual prescribed master', error)
        prescribed.append(error)
    expected_constraint = sparse.coo_matrix((cv, (cr, cc)), shape=(nt, nt)).tocsr()
    actual_constraint = a - sparse.block_diag((k, sparse.csr_matrix((nt - ns, nt - ns))), format='csr')
    constraint_operator_error = normalized_matrix_difference(actual_constraint, expected_constraint)
    physical_trans = max((abs(v[0]) for v in physical_residual.values() if v[2] < 3), default=0.)
    physical_rot = max((abs(v[0]) for v in physical_residual.values() if v[2] >= 3), default=0.)
    assert physical_trans <= 1e-4 and physical_rot <= 1e-5, 'same existing Native physical MPC criteria'
    residual, backward = kkt_check(a, b, x)
    assembled = .5 * float(u @ (k @ u))
    recorded = float(done['assembled_quadratic_energy_Nmm'])
    assert abs(assembled - recorded) <= 1e-9 * max(1., abs(assembled), abs(recorded))
    external_constraint_work = -float(b[nm:] @ x[nm:])
    energy_work_error = abs(2 * assembled - float(u @ f) - external_constraint_work) / max(1., abs(2 * assembled), abs(external_constraint_work))
    assert energy_work_error <= 1e-8, ('actual KKT reaction work identity', energy_work_error)
    qenergy = rows(state / 'patch_stored_H_energy.csv')
    assert len(qenergy) == 23 and all(r['quadrature_cache_valid'] == '1' and int(r['cached_GP_count']) > 0 for r in qenergy)
    stored = math.fsum(float(r['stored_H_quadratic_energy_Nmm']) for r in qenergy)
    assert abs(stored - float(done['stored_H_energy_Nmm'])) <= 1e-9 * max(1., abs(stored))
    number = rows(case / 'p4/numbering.csv')
    cpmap = {(int(r['owner']), int(r['local_cp'])): int(r['global_node']) - 1 for r in number}
    zero_rows = [r for r in rows(case / 'p4/support.csv') if r['exact_zero_cp'] == 'true']
    zero_dofs = [3 * cpmap[int(r['owner']), int(r['local_cp'])] + int(r['component']) for r in zero_rows]
    zero_u = float(np.max(np.abs(u[zero_dofs]))) if zero_dofs else 0.
    artificial = math.fsum(.5 * float(r['after_H_diag']) * u[3 * cpmap[int(r['owner']), int(r['local_cp'])] + int(r['component'])] ** 2 for r in zero_rows)
    stress_header = (state / 'actual_stress_quadrature.csv').open(encoding='utf-8').readline().strip().split(',')
    assert all(x in stress_header for x in ['patch_handle', 'surface', 'u', 'v', 'mises', 's11', 's22', 's33', 's12', 's13', 's23'])
    symbolic = load(state / 'pardiso_symbolic_memory.json')
    assert symbolic['reported_internal_peak_bytes'] > 0 and symbolic['process_limit_bytes'] == 64 << 30
    return dict(status='PASS_ACTUAL_STATE_SPARSE_ALGEBRA_CONSTRAINTS_AND_WORK_ONLY', Core_PID=result['pid'], actual_structural_dofs=ns, actual_KKT_dofs=nt, structural_nnz=int(k.nnz), KKT_nnz=int(a.nnz), structural_block_norm_difference=structural_block_error, actual_constraint_operator_norm_difference=constraint_operator_error, physical_translation_MPC_residual=physical_trans, physical_rotation_MPC_residual=physical_rot, prescribed_master_max_error=max(prescribed, default=0.), KKT_normwise_backward_error=backward, KKT_absolute_infinity_residual=float(np.max(np.abs(residual))), KKT_reaction_work_identity_relative_error=energy_work_error, assembled_quadratic_energy_Nmm=assembled, stored_H_quadratic_energy_Nmm=stored, exact_stored_H_zero_DOF_count=len(zero_dofs), Hzero_displacement_max_mm=zero_u, artificial_Hzero_diagonal_energy_Nmm=artificial, bulk_energy_after_exact_Hzero_diagonal_removal_Nmm=stored-artificial, native_stress_GP_records=int(done['stress_actual_GP_records']), native_stress_skipped_records=int(done['stress_skipped_records']), observed_process_peak_bytes=resources['sampled_maximum_of_private_OSpeakcommit_OSpeakWS'], symbolic_report=symbolic, h_convergence_FEM_accuracy_stress_recovery_colour_scales_or_paper_preparation_complete=False, reader_sha256=sha(Path(__file__)))


if __name__=='__main__':raise SystemExit('Use read_engineering_mode4_v7.py with current strict preflight')
