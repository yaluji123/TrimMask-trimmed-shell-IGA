from __future__ import annotations

import math


ABAQUS_12_RGB: tuple[tuple[int, int, int], ...] = (
    (0, 0, 225),
    (0, 93, 255),
    (0, 185, 255),
    (0, 255, 232),
    (0, 255, 131),
    (0, 255, 46),
    (46, 255, 0),
    (139, 255, 0),
    (232, 255, 0),
    (255, 185, 0),
    (255, 93, 0),
    (225, 0, 0),
)


def abaqus12_plotly_colorscale() -> tuple[tuple[float, str], ...]:
    """Return Abaqus' 12 colour nodes as a continuous Plotly scale."""

    denominator = len(ABAQUS_12_RGB) - 1
    return tuple(
        (
            index / denominator,
            f"rgb({red}, {green}, {blue})",
        )
        for index, (red, green, blue) in enumerate(ABAQUS_12_RGB)
    )


def abaqus12_plotly_banded_colorscale() -> tuple[tuple[float, str], ...]:
    """Return twelve constant Plotly bands in Abaqus' low-to-high order."""

    band_count = len(ABAQUS_12_RGB)
    scale: list[tuple[float, str]] = []
    for index, (red, green, blue) in enumerate(ABAQUS_12_RGB):
        colour = f"rgb({red}, {green}, {blue})"
        scale.append((index / band_count, colour))
        scale.append(((index + 1) / band_count, colour))
    return tuple(scale)


def abaqus12_matplotlib_colormap():
    """Return the same nodes with linear interpolation for Matplotlib."""

    from matplotlib.colors import LinearSegmentedColormap

    nodes = [tuple(channel / 255.0 for channel in rgb) for rgb in ABAQUS_12_RGB]
    return LinearSegmentedColormap.from_list(
        "AbaqusColorMap12-continuous", nodes, N=256
    )


def abaqus12_matplotlib_banded_colormap():
    """Return Abaqus' twelve colours as a discrete Matplotlib map."""

    from matplotlib.colors import ListedColormap

    nodes = [tuple(channel / 255.0 for channel in rgb) for rgb in ABAQUS_12_RGB]
    return ListedColormap(nodes, name="AbaqusColorMap12-discrete")


def abaqus_legend_boundaries(
    minimum: float,
    maximum: float,
) -> tuple[float, ...]:
    """Return the thirteen linear boundaries of an Abaqus 12-band legend."""

    lower = float(minimum)
    upper = float(maximum)
    if not math.isfinite(lower) or not math.isfinite(upper) or upper <= lower:
        raise ValueError("Abaqus legend limits must be finite and increasing")
    band_count = len(ABAQUS_12_RGB)
    span = upper - lower
    boundaries = [
        lower + span * index / band_count for index in range(band_count + 1)
    ]
    # Preserve the audited extrema bit-for-bit.  Repeated floating-point
    # addition/division can otherwise move the last value by one ulp even
    # though the printed legend label looks unchanged.
    boundaries[0] = lower
    boundaries[-1] = upper
    return tuple(boundaries)


def abaqus_legend_number(value: float) -> str:
    """Format a legend value like Abaqus, including an explicit sign."""

    numeric = float(value)
    if not math.isfinite(numeric):
        raise ValueError("Abaqus legend values must be finite")
    if numeric == 0.0:
        numeric = 0.0
    return f"{numeric:+.3e}"


def abaqus_legend_tick_labels(boundaries: tuple[float, ...]) -> tuple[str, ...]:
    return tuple(abaqus_legend_number(value) for value in boundaries)


def abaqus_field_title(field: str, units: str | None = None) -> str:
    """Return an Abaqus-like field heading without inventing section metadata."""

    key = "".join(str(field).upper().split())
    titles = {
        "U_MAG": "U, Magnitude",
        "U,MAGNITUDE": "U, Magnitude",
        "U1": "U, U1",
        "U2": "U, U2",
        "U3": "U, U3",
        "MISES": "S, Mises",
        "S,MISES": "S, Mises",
        "VONMISESSTRESS": "S, Mises",
        "S11": "S, S11",
        "S22": "S, S22",
        "S12": "S, S12",
        "PEEQ": "PEEQ",
        "PLASTIC": "Plastic zone",
    }
    title = titles.get(key, str(field).strip())
    normalized_units = str(units or "").strip()
    return f"{title}\n[{normalized_units}]" if normalized_units else title
