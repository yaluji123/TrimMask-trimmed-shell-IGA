"""Read-only owner inventory of captured active domains, not a coupling validator.

Unit-weight near-affine surfaces and monotone straight prepared curves only.
All topology decisions use exact rational arithmetic on captured decimal values.
Every line/polygon intersection splits the interval; midpoint membership labels
each resulting open interval, never the unsplit interface. Original CAD curve
approximation and near-affine physical defects remain explicitly bounded/unknown.
"""
from fractions import Fraction as F
from pathlib import Path
import argparse, hashlib, json, math

class Unsupported(ValueError): pass
def q(x):
    if isinstance(x,bool) or not math.isfinite(float(x)): raise Unsupported('nonfinite_or_boolean_scalar')
    return F(str(x))
def vec(x): return tuple(q(v) for v in x)
def add(a,b): return tuple(x+y for x,y in zip(a,b))
def sub(a,b): return tuple(x-y for x,y in zip(a,b))
def mul(a,t): return tuple(x*t for x in a)
def dot(a,b): return sum(x*y for x,y in zip(a,b))
def cross2(a,b): return a[0]*b[1]-a[1]*b[0]
def cross3(a,b): return (a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0])
def norm(a): return math.sqrt(float(dot(a,a)))
def encode(x):
    if isinstance(x,F): return {'exact':str(x),'value':float(x)}
    if isinstance(x,tuple): return [encode(v) for v in x]
    if isinstance(x,list): return [encode(v) for v in x]
    if isinstance(x,dict): return {k:encode(v) for k,v in x.items()}
    return x
def edges(r): return list(zip(r,r[1:]+r[:1]))
def on(a,b,p): return cross2(sub(b,a),sub(p,a))==0 and dot(sub(p,a),sub(p,b))<=0
def segments_meet(a,b,c,d):
    x=[cross2(sub(b,a),sub(c,a)),cross2(sub(b,a),sub(d,a)),cross2(sub(d,c),sub(a,c)),cross2(sub(d,c),sub(b,c))]
    return (x[0]*x[1]<0 and x[2]*x[3]<0) or any(v==0 and on(s,t,p) for v,s,t,p in [(x[0],a,b,c),(x[1],a,b,d),(x[2],c,d,a),(x[3],c,d,b)])
def ring(values):
    r=[vec(p) for p in values]
    if r and r[-1]==r[0]: r.pop()
    if len(r)<3 or any(len(p)!=2 for p in r): raise Unsupported('invalid_polygon_ring')
    if any(a==b for a,b in edges(r)): raise Unsupported('zero_polygon_edge')
    if sum(cross2(a,b) for a,b in edges(r))==0: raise Unsupported('zero_polygon_area')
    n=len(r)
    for i,(a,b) in enumerate(edges(r)):
        for j,(c,d) in enumerate(edges(r)):
            if j<=i or j==i+1 or (i==0 and j==n-1): continue
            if segments_meet(a,b,c,d): raise Unsupported('self_intersecting_or_self_touching_ring')
    return r
def inside(r,p):
    # None means boundary; caller must never silently choose its material side.
    parity=False
    for a,b in edges(r):
        if on(a,b,p): return None
        if (a[1]>p[1])!=(b[1]>p[1]):
            xx=a[0]+(p[1]-a[1])*(b[0]-a[0])/(b[1]-a[1])
            if xx>p[0]: parity=not parity
    return parity

class Surface:
    def __init__(self,g):
        self.g=g; self.h=int(g['shell_handle']);m=int(g['controls_u']);n=int(g['controls_v']);p=int(g['degree_u']);r=int(g['degree_v'])
        U=list(map(q,g['knots_u']));V=list(map(q,g['knots_v']));weights=list(map(q,g['weights']));xyz=list(map(q,g['control_global_Vg']))
        if not(p>=1 and r>=1 and m>p and n>r and len(U)==m+p+1 and len(V)==n+r+1 and len(weights)==m*n and len(xyz)==3*m*n): raise Unsupported('surface_storage_shape')
        if U!=sorted(U) or V!=sorted(V) or any(w!=1 for w in weights): raise Unsupported('nonmonotone_knots_or_nonunit_weights')
        self.lo=(U[p],V[r]);self.hi=(U[m],V[n])
        if any(a>=b for a,b in zip(self.lo,self.hi)): raise Unsupported('empty_surface_parameter_domain')
        if U.count(U[p])<p+1 or U.count(U[m])<p+1 or V.count(V[r])<r+1 or V.count(V[n])<r+1: raise Unsupported('nonclamped_surface')
        P=[tuple(xyz[3*i:3*i+3])for i in range(m*n)];self.O=P[0]
        self.A=mul(sub(P[(m-1)*n],self.O),1/(self.hi[0]-self.lo[0]));self.B=mul(sub(P[n-1],self.O),1/(self.hi[1]-self.lo[1]))
        aa=dot(self.A,self.A);ab=dot(self.A,self.B);bb=dot(self.B,self.B);self.det=aa*bb-ab*ab
        if self.det<=0: raise Unsupported('singular_affine_carrier')
        self.metric=(aa,ab,bb);self.normal=cross3(self.A,self.B)
        gu=[sum(U[i+1:i+p+1])/p for i in range(m)];gv=[sum(V[j+1:j+r+1])/r for j in range(n)]
        defect=max(norm(sub(P[i*n+j],self.point((gu[i],gv[j]))))for i in range(m)for j in range(n))
        scale=max(1,norm(sub(P[-1],P[0])),norm(self.A),norm(self.B));self.tol=max(1e-8,scale*1e-10)
        if not g.get('is_flat',False) or defect>self.tol: raise Unsupported('not_bounded_near_affine_flat_surface')
        self.defect=defect;self.controls=m*n;self.degree=[p,r]
        carrier=[self.lo,(self.hi[0],self.lo[1]),self.hi,(self.lo[0],self.hi[1])]
        self.rings=[carrier];self.outer=None;self.holes=[]
        if g.get('trim_registered'):
            if g.get('has_outer'): self.outer=ring(g['outer_loop']);self.rings.append(self.outer)
            elif g.get('outer_loop'): raise Unsupported('outer_flag_payload_disagreement')
            self.holes=[ring(v)for v in g.get('hole_loops',[])];self.rings+=self.holes
            if bool(self.holes)!=bool(g.get('has_holes')): raise Unsupported('hole_flag_payload_disagreement')
        elif g.get('has_outer')or g.get('has_holes')or g.get('outer_loop')or g.get('hole_loops'): raise Unsupported('unregistered_trim_payload')
    def point(self,uv): return add(self.O,add(mul(self.A,uv[0]-self.lo[0]),mul(self.B,uv[1]-self.lo[1])))
    def inverse(self,P):
        d=sub(P,self.O);aa,ab,bb=self.metric;x=dot(self.A,d);y=dot(self.B,d)
        uv=(self.lo[0]+(bb*x-ab*y)/self.det,self.lo[1]+(aa*y-ab*x)/self.det)
        residual=norm(sub(self.point(uv),P))
        if residual>self.tol: raise Unsupported('prepared_curve_off_surface_plane')
        return uv,residual
    def material(self,p):
        states=[inside(v,p)for v in self.rings]
        if any(v is None for v in states): return None
        return bool(states[0]and(self.outer is None or states[1])and not any(states[(2 if self.outer else 1):]))
    def summary(self): return {'shell_handle':self.h,'controls':self.controls,'degree':self.degree,'active_domain':[self.lo,self.hi],'affine_origin':self.O,'affine_U':self.A,'affine_V':self.B,'control_hull_affine_defect_mm':self.defect,'exact_decimal_affine_identity':self.defect==0,'physical_fit_tolerance_mm':self.tol,'unit_weights_observed':True,'material_domain':'carrier intersection registered normalized outer minus union holes','original_CAD_trim_curve_approximation_error':'unobserved','physical_certification':'nominal affine representation with control-hull defect reported; no mechanics or original-CAD accuracy acceptance'}

def curve_line(c,tol):
    if not c.get('extraction_complete')or c.get('rational'): raise Unsupported('incomplete_or_rational_prepared_curve')
    p=int(c['degree']);K=list(map(q,c['knots']));W=list(map(q,c['weights']));X=list(map(q,c['control_global_xyz']));n=len(W)
    if p<1 or n<=p or len(K)!=n+p+1 or len(X)!=3*n or K!=sorted(K)or any(w!=1 for w in W): raise Unsupported('curve_storage_or_unit_weights')
    if K.count(K[p])<p+1 or K.count(K[n])<p+1 or K[p]>=K[n]: raise Unsupported('curve_nonclamped_or_empty')
    P=[tuple(X[3*i:3*i+3])for i in range(n)];a=P[0];b=P[-1];D=sub(b,a);dd=dot(D,D)
    if dd==0: raise Unsupported('zero_length_curve')
    params=[dot(sub(x,a),D)/dd for x in P];defect=max(norm(sub(x,add(a,mul(D,s))))for x,s in zip(P,params))
    if defect>tol or params!=sorted(params)or params[0]!=0 or params[-1]!=1: raise Unsupported('curve_not_monotone_straight')
    return a,b,{'control_collinearity_defect_mm':defect,'nominal_length_mm':norm(D),'monotone_control_projection':True,'prepared_curve_representation':c.get('representation')}

def interval_owner(s,a,b):
    uv0,r0=s.inverse(a);uv1,r1=s.inverse(b);d=sub(uv1,uv0);dd=dot(d,d)
    if dd==0: raise Unsupported('zero_uv_length')
    e=(-d[1],d[0])
    # Exact invertible change of coordinates to (line fraction, signed transverse).
    def ts(p):
        x=sub(p,uv0);return(dot(x,d)/dd,cross2(d,x)/dd)
    rings=[[ts(p)for p in R]for R in s.rings];events={F(0),F(1)}
    for R in rings:
        for x,y in edges(R):
            if x[1]==0 and 0<=x[0]<=1:events.add(x[0])
            if y[1]==0 and 0<=y[0]<=1:events.add(y[0])
            if x[1]*y[1]<0:
                t=x[0]-x[1]*(y[0]-x[0])/(y[1]-x[1])
                if 0<=t<=1:events.add(t)
    E=sorted(events);segments=[]
    for left,right in zip(E,E[1:]):
        mid=(left+right)/2;distances=[]
        # Nearest nonzero intersection in the exact transverse section. This
        # keeps +/- probes in the local limiting sides, including narrow slivers.
        for R in rings:
            for x,y in edges(R):
                if min(x[0],y[0])<=mid<=max(x[0],y[0]):
                    if x[0]!=y[0]:
                        z=x[1]+(mid-x[0])*(y[1]-x[1])/(y[0]-x[0])
                        if z:distances.append(abs(z))
                    else:
                        if min(x[1],y[1])<=0<=max(x[1],y[1]): raise Unsupported('unexpected_unsplit_transverse_boundary')
                        distances.extend(abs(z)for z in(x[1],y[1])if z)
        step=min(distances+[F(1)])/2;centre=add(uv0,mul(d,mid));plus=s.material(add(centre,mul(e,step)));minus=s.material(sub(centre,mul(e,step)))
        if plus is None or minus is None: raise Unsupported('side_probe_on_unresolved_boundary')
        label='interior_two_sided'if plus and minus else('boundary_one_sided_plus'if plus else('boundary_one_sided_minus'if minus else'no_material_either_side'))
        segments.append({'t0':left,'t1':right,'classification':label,'positive_side_material':plus,'negative_side_material':minus,'exact_transverse_probe_step':step,'uv_start':add(uv0,mul(d,left)),'uv_end':add(uv0,mul(d,right))})
    return {'line_uv_start':uv0,'line_uv_end':uv1,'endpoint_plane_residual_mm':[r0,r1],'events':E,'segments':segments,'whole_interval_evidence':'all exact line/carrier/outer/hole events; topology constant on each reported open interval; endpoint events separate','physical_curve_approximation_scope':'nominal near-affine carrier/straight-curve model only; reported defects are not silently snapped or treated as zero'}

def identifier(x):return int(x['decimal'])if isinstance(x,dict)else int(x)
def pair_kind(classes):
    if len(classes)!=2:return 'unsupported_owner_count'
    if any(c=='no_material_either_side'for c in classes):return 'inactive_or_missing_material_side'
    boundary=[c.startswith('boundary_one_sided')for c in classes]
    if all(boundary):return 'two_boundary_one_sided_owners'
    if all(c=='interior_two_sided'for c in classes):return 'both_owners_interior_two_sided'
    if sum(boundary)==1 and classes.count('interior_two_sided')==1:return 'interior_carrier_plus_boundary_owner'
    return 'unsupported_material_side_combination'
def relation_inventory(surfaces,registry):
    rows=[];lines=[]
    for rel in registry.get('relations',[]):
        h=identifier(rel['couple_handle']);row={'couple_handle':h,'mode':rel.get('mode'),'n1':rel.get('n1'),'n2':rel.get('n2'),'stored_nitsche_type':rel.get('nitsche_type'),'selected_for_assembly':rel.get('selected_for_assembly'),'status':'SUPPORTED_NOMINAL_CAPTURED_GEOMETRY','sides':[]}
        try:
            if len(rel.get('sides',[]))!=2:raise Unsupported('relation_side_count')
            pairs=[]
            for side in rel['sides']:
                owner=identifier(side['surface_handle']);surface=surfaces[owner]
                a,b,proof=curve_line(side['curve'],surface.tol);inventory=interval_owner(surface,a,b)
                row['sides'].append({'surface_handle':owner,'boundary_number_metadata_only':side.get('boundary_number'),'curve_proof':proof,**inventory});pairs.append((a,b))
            a,b=pairs[0];d=sub(b,a);dd=dot(d,d);c,f=pairs[1]
            match=max(norm(sub(x,add(a,mul(d,dot(sub(x,a),d)/dd))))for x in(c,f))
            ts=[dot(sub(x,a),d)/dd for x in(c,f)];left=max(F(0),min(ts));right=min(F(1),max(ts))
            if match>max(surfaces[x['surface_handle']].tol for x in row['sides'])or left>=right:raise Unsupported('pair_curves_not_same_overlapping_physical_line')
            row['pair_common_interval_on_side0']=[left,right];row['pair_line_residual_mm']=match
            row['pair_endpoint_coverage_equal_within_tolerance']=max(norm(sub(c,a)),norm(sub(f,b)))<=max(surfaces[x['surface_handle']].tol for x in row['sides'])or max(norm(sub(c,b)),norm(sub(f,a)))<=max(surfaces[x['surface_handle']].tol for x in row['sides'])
            events={left,right};side1start=ts[0];side1span=ts[1]-ts[0]
            for side_i,side in enumerate(row['sides']):
                for t in side['events']:
                    mapped=t if side_i==0 else side1start+side1span*t
                    if left<=mapped<=right:events.add(mapped)
            row['pair_material_intervals']=[]
            for l,r in zip(sorted(events),sorted(events)[1:]):
                mid=(l+r)/2;classes=[]
                for side_i,side in enumerate(row['sides']):
                    t=mid if side_i==0 else(mid-side1start)/side1span
                    selected=[seg['classification']for seg in side['segments']if seg['t0']<t<seg['t1']]
                    if len(selected)!=1:raise Unsupported('pair_interval_cannot_bind_owner')
                    classes+=selected
                row['pair_material_intervals'].append({'t0':l,'t1':r,'physical_length_mm':float(r-l)*norm(d),'side_classes':classes,'topology':pair_kind(classes),'engineering_coverage_accepted':False})
            lines.append((h,a,b))
        except (Unsupported,KeyError,ValueError,TypeError)as error:row['status']='UNSUPPORTED';row['reason']=str(error)
        rows.append(row)
    # Candidate groups use every endpoint and an all-pairs line consistency check,
    # never owner n1/n2, shell labels, or one middle sample as geometric identity.
    groups=[]
    def same(x,y):
        _,a,b=x;_,c,d=y;ab=sub(b,a);cd=sub(d,c);tol=max(1e-8,max(norm(ab),norm(cd))*1e-10)
        return all(norm(sub(p,add(a,mul(ab,dot(sub(p,a),ab)/dot(ab,ab)))))<=tol for p in(c,d))and all(norm(sub(p,add(c,mul(cd,dot(sub(p,c),cd)/dot(cd,cd)))))<=tol for p in(a,b))
    for line in lines:
        candidates=[g for g in groups if any(same(line,x)for x in g)]
        if not candidates:groups.append([line])
        else:
            merged=[line]+[x for g in candidates for x in g]
            groups=[g for g in groups if g not in candidates]+[merged]
    clusters=[];byh={r['couple_handle']:r for r in rows}
    for group in groups:
        good=all(same(x,y)for x in group for y in group)
        cluster={'relation_handles':[x[0]for x in group],'status':'UNSUPPORTED_NONTRANSITIVE_LINE_TOLERANCE'if not good else'NOMINAL_COMMON_LINE_EVENTS','intervals':[]}
        if good:
            _,A,B=group[0];D=sub(B,A);DD=dot(D,D);events=set();entries=[]
            for h,a,b in group:
                for side,(aa,bb)in zip(byh[h]['sides'],[(a,b),curve_line(next(r for r in registry['relations']if identifier(r['couple_handle'])==h)['sides'][1]['curve'],max(surfaces[v['surface_handle']].tol for v in byh[h]['sides']))[:2]]):
                    tA=dot(sub(aa,A),D)/DD;tB=dot(sub(bb,A),D)/DD
                    for seg in side['segments']:
                        x=tA+(tB-tA)*seg['t0'];y=tA+(tB-tA)*seg['t1'];lo,hi=sorted((x,y));events.update((lo,hi));entries.append((lo,hi,h,side['surface_handle'],seg['classification']))
            for lo,hi in zip(sorted(events),sorted(events)[1:]):
                mid=(lo+hi)/2;active=[x for x in entries if x[0]<mid<x[1]]
                if not active:continue
                owners={};rels=set()
                for _,_,h,o,c in active:owners.setdefault(o,set()).add(c);rels.add(h)
                ownerrows=[{'surface_handle':o,'classes':sorted(c),'consistent_across_relations':len(c)==1}for o,c in sorted(owners.items())]
                cluster['intervals'].append({'s0':lo,'s1':hi,'physical_length_mm':float(hi-lo)*norm(D),'relation_handles':sorted(rels),'owners':ownerrows,'material_owner_count':sum(any(v!='no_material_either_side'for v in c)for c in owners.values()),'topology_only_not_mechanical_redundancy':True})
        clusters.append(cluster)
    return rows,clusters

def analyze(directory):
    files=sorted(directory.glob('trim_geometry_*.json'));surfaces={};errors=[];bindings=[]
    for path in files:
        g=json.loads(path.read_text(encoding='utf-8-sig'));bindings.append({'file':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
        try:
            s=Surface(g)
            if s.h in surfaces:raise Unsupported('duplicate_surface_handle')
            surfaces[s.h]=s
        except(Unsupported,KeyError,ValueError,TypeError)as error:errors.append({'file':str(path),'shell_handle':g.get('shell_handle'),'status':'UNSUPPORTED','reason':str(error)})
    rp=directory/'couples_registry_input_only.json'
    if not rp.exists():rp=directory/'couples_registry_before_dispatch.json'
    registry=json.loads(rp.read_text(encoding='utf-8-sig'));bindings.append({'file':str(rp),'sha256':hashlib.sha256(rp.read_bytes()).hexdigest()})
    rows,clusters=relation_inventory(surfaces,registry)
    companion=directory/'engineering_input_only_manifest.json';observed=None
    if companion.exists():
        observed=json.loads(companion.read_text(encoding='utf-8-sig'));bindings.append({'file':str(companion),'sha256':hashlib.sha256(companion.read_bytes()).hexdigest()})
        if not observed.get('capture_complete')or observed.get('assembly_called')is not False or observed.get('solve_called')is not False:errors.append({'file':str(companion),'reason':'input_only_manifest_incomplete_or_unexpected_execution','status':'UNSUPPORTED'})
        if observed.get('surface_count')!=len(files)or sorted(int(s['shell_handle'])for s in observed.get('surfaces',[]))!=sorted(surfaces):errors.append({'file':str(companion),'reason':'input_only_material_owner_count_mismatch','status':'UNSUPPORTED'})
    return encode({'schema':'oe-engineering-owner-interval-inventory-v1','status':'SCOPED_GEOMETRY_INVENTORY_ONLY','actual_capture':str(directory),'source_files':bindings,'surface_count_observed':len(files),'supported_surface_count':len(surfaces),'surfaces':[s.summary()for s in surfaces.values()],'unsupported_surfaces':errors,'fresh_material_method_override_companion':observed,'relation_count_observed':len(rows),'relations':rows,'physical_line_clusters':clusters,'native_registered_contains_used':False,'n1_n2_used_for_material_side':False,'assembly_mapping_success_or_numerical_acceptance_claimed':False,'endpoint_events_have_zero_length_but_corner_mechanics_unvalidated':True,'registry_selection_known':registry.get('selection_known'),'prepared_override_status':('observed in explicit input-only companion'if observed else('explicit companion manifest required'if registry.get('boundary_snapshot_overrides_not_inspected')else'observed in registry')),'physical_CAD_curve_error_bound':'unobserved; registered polygon and reported near-affine/straight defects only','whole_interval_physical_owner_certificate':'not asserted for nonzero surface/curve affine defects or unknown original CAD approximation; exact event topology is relative to the exported normalized polygon and nominal carrier'})

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('capture',type=Path);p.add_argument('--out',type=Path,required=True);args=p.parse_args()
    if args.out.exists():raise SystemExit('Refusing output collision')
    result=analyze(args.capture);args.out.parent.mkdir(parents=True,exist_ok=True);args.out.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps({'status':result['status'],'surfaces':result['surface_count_observed'],'relations':result['relation_count_observed'],'unsupported_relations':sum(x['status']=='UNSUPPORTED'for x in result['relations'])}))
if __name__=='__main__':main()
