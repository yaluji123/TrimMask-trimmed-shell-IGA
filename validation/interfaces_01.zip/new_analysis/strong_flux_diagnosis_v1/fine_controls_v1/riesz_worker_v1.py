import traceback
from boot_v1 import start, riesz_factor_budget
resources = start(riesz=True)
import numpy as np
from scipy import sparse
from scipy.sparse.linalg import splu
from common_v1 import *

OUT = HERE/"Riesz_v1"; OUT.mkdir(exist_ok=False)
result = {"status": "RIESZ_NOT_COMPLETED", "resources": resources}
try:
    assert read(HERE/"physical_fields_v1/results.json")["status"] == "ALL_FIXED_CONTROLS_PHYSICAL_FIELDS_COMPLETED_RIESZ_SEPARATE"
    G = sparse.load_npz(bind(PREP/"all_h4_complete_physical_sparse_packet_v2/independent_G.npz"))
    assert G.shape == (6237, 6237)
    lu = splu(G.tocsc(), permc_spec="MMD_AT_PLUS_A", diag_pivot_thresh=0., options={"SymmetricMode": True})
    fill = int(lu.nnz)
    save(OUT/"ACTUAL_FACTOR_PROFILE.json", {"actual_input_nnz": G.nnz, "actual_internal_factor_storage_nnz": fill,
        "fill_measure": "SuperLU.nnz without L/U copies", "memory_after_factor": memory()})
    riesz_factor_budget(G.nnz, fill)
    data = np.load(bind(HERE/"physical_fields_v1/Riesz_rhs_and_normalization.npz"))
    rows = []; arrays = {}
    for alpha in (105, 210, 420):
        r, energy = data[f"r{alpha}"], float(data[f"energy{alpha}"])
        z = lu.solve(r); value = float(r@z)
        assert value >= 0 and np.isfinite(value)
        backward = norm(G@z-r)/(norm(G)*norm(z)+norm(r))
        assert backward <= max(1e-14, 128*6237*np.finfo(float).eps)
        rows.append({"alphaB": alpha, "full_finite_dual_sqrt_Nmm": np.sqrt(value),
                     "bulk_energy_normalized_full_finite_dual": np.sqrt(value/energy),
                     "Riesz_sparse_backward": backward})
        arrays[f"z{alpha}"] = z
    np.savez_compressed(OUT/"Riesz_solutions.npz", **arrays)
    result.update(status="ALL_FIXED_CONTROLS_FULL_FINITE_PHYSICAL_DUALS_COMPLETED", actual_factor_nnz=fill,
                  rows=rows, no_state_K_factor_in_this_process=True, G_unshifted_unmodified=True)
except Exception as e:
    result.update(failure=repr(e), traceback=traceback.format_exc())
finally:
    verify_inputs(); result.update(input_sha256=PINS, observed_memory=memory())
    save(OUT/"results.json", result); print(__import__('json').dumps(clean({k:v for k,v in result.items() if k not in ("input_sha256","traceback")}), indent=2))
if result["status"] != "ALL_FIXED_CONTROLS_FULL_FINITE_PHYSICAL_DUALS_COMPLETED": raise SystemExit(2)
