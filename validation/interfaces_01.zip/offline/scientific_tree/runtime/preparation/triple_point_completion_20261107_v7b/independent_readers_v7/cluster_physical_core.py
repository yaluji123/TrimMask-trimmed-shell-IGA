"""Independent linear flat affine KL shell postprocessing; no Native solver calls."""
from __future__ import annotations
from dataclasses import dataclass
from math import comb,sqrt
import numpy as np

OWNERS=(0x1EBB,0x1EBC,0x1EBD)
RELATIONS={0x1EC2:(0,1),0x1EC5:(0,2),0x1EC8:(1,2)}
PAIRS=((0,1),(0,2),(1,2))

def cross(a):
    x,y,z=a;return np.array([[0.,-z,y],[z,0.,-x],[-y,x,0.]])

def basis_derivatives(knots,p,x,order=3):
    """Cox-de Boor values and analytic derivative recursion, one-sided at ends."""
    u=np.asarray(knots,float);n=len(u)-p-1
    if not np.all(np.isfinite(u)) or np.any(np.diff(u)<0) or n<=p:raise ValueError('invalid knots')
    if x<u[p] or x>u[n]:raise ValueError('parameter outside carrier')
    span=n-1 if x==u[n] else int(np.searchsorted(u,x,side='right')-1)
    base=np.zeros(len(u)-1);base[span]=1.;prev=np.zeros((order+1,len(base)));prev[0]=base
    for degree in range(1,p+1):
        size=len(u)-degree-1;cur=np.zeros((order+1,size))
        for i in range(size):
            a=u[i+degree]-u[i];b=u[i+degree+1]-u[i+1]
            if a:cur[0,i]+=(x-u[i])/a*prev[0,i]
            if b:cur[0,i]+=(u[i+degree+1]-x)/b*prev[0,i+1]
            for k in range(1,min(order,degree)+1):
                if a:cur[k,i]+=degree/a*prev[k-1,i]
                if b:cur[k,i]-=degree/b*prev[k-1,i+1]
        prev=cur
    return prev

def rational_tensor_derivatives(ku,kv,p,q,weights,u,v,order=3):
    nu=basis_derivatives(ku,p,u,order);nv=basis_derivatives(kv,q,v,order)
    w=np.asarray(weights,float).reshape(len(nu[0]),len(nv[0]));a={};ww={};r={}
    if not np.all(np.isfinite(w)) or np.any(w<=0):raise ValueError('invalid rational weights')
    for total in range(order+1):
        for i in range(total+1):
            j=total-i;a[i,j]=nu[i,:,None]*nv[j,None,:]*w;ww[i,j]=a[i,j].sum()
            value=a[i,j].copy()
            for k in range(i+1):
                for l in range(j+1):
                    if k or l:value-=comb(i,k)*comb(j,l)*ww[k,l]*r[i-k,j-l]
            if not ww[0,0]>0:raise ValueError('zero rational denominator')
            r[i,j]=value/ww[0,0]
    return {k:x.ravel() for k,x in r.items()}

def greville(knots,p,n):return np.array([sum(knots[i+1:i+p+1])/p for i in range(n)])

@dataclass
class Arm:
    handle:int;ku:np.ndarray;kv:np.ndarray;p:int;q:int;cp:np.ndarray;weights:np.ndarray
    E:float;nu:float;thickness:float;dofmap:np.ndarray;coeff:np.ndarray
    def __post_init__(self):
        self.ku=np.asarray(self.ku,float);self.kv=np.asarray(self.kv,float)
        self.m=len(self.ku)-self.p-1;self.n=len(self.kv)-self.q-1
        self.cp=np.asarray(self.cp,float).reshape(self.m*self.n,3);self.weights=np.asarray(self.weights,float)
        self.dofmap=np.asarray(self.dofmap,int);self.coeff=np.asarray(self.coeff,float).reshape(-1)
        if self.p!=3 or self.q!=3 or self.m<4 or self.n<4:raise ValueError('scope requires cubic shells')
        if self.cp.shape!=(self.m*self.n,3) or self.coeff.size!=3*self.m*self.n or self.dofmap.size!=self.coeff.size:raise ValueError('arm dimensions')
        if self.dofmap.min()<0 or self.dofmap.max()>=7000 or len(set(self.dofmap.tolist()))!=self.coeff.size:raise ValueError('invalid arm global numbering')
        if any(self.dofmap[3*k]%3 or not np.array_equal(self.dofmap[3*k:3*k+3],np.arange(self.dofmap[3*k],self.dofmap[3*k]+3)) for k in range(self.m*self.n)):raise ValueError('nontranslation global triplet')
        if not np.all(np.isfinite(self.cp)) or not np.all(np.isfinite(self.coeff)):raise ValueError('nonfinite arm')
        if self.weights.size!=self.m*self.n or not np.array_equal(self.weights,np.ones(self.m*self.n)):raise ValueError('actual model requires exact unit-weight affine carrier')
        if not(self.E>0 and self.thickness>0 and -1<self.nu<.5) or not np.all(np.isfinite([self.E,self.nu,self.thickness])):raise ValueError('invalid material')
        if not(np.all(self.ku[:4]==0) and np.all(self.ku[-4:]==1) and np.all(self.kv[:4]==0) and np.all(self.kv[-4:]==1)):raise ValueError('scope requires full clamped-open unit domain')
        self.origin=self.cp[0];self.du=self.cp[(self.m-1)*self.n]-self.origin;self.dv=self.cp[self.n-1]-self.origin
        self.length=np.linalg.norm(self.du);self.width=np.linalg.norm(self.dv)
        if min(self.length,self.width)<=0:raise ValueError('degenerate carrier')
        self.t=self.du/self.length;self.e2=self.dv-self.t*np.dot(self.t,self.dv);self.e2/=np.linalg.norm(self.e2)
        self.normal=np.cross(self.t,self.e2);self.mu=-self.e2
        self.J=np.array([[self.t@self.du,self.t@self.dv],[self.e2@self.du,self.e2@self.dv]])
        self.inverseJ=np.linalg.inv(self.J)
        gu=greville(self.ku,self.p,self.m);gv=greville(self.kv,self.q,self.n)
        expect=np.array([self.origin+self.du*a+self.dv*b for a in gu for b in gv])
        self.affine_residual=float(np.max(np.linalg.norm(expect-self.cp,axis=1)))
        if self.affine_residual>1e-8:raise ValueError('nonaffine actual carrier')
        if abs(self.t@self.dv)>1e-8:raise ValueError('scope requires orthogonal three-patch carrier')
        self.D=self.E*self.thickness**3/(12*(1-self.nu**2))
        self._u_basis_cache={};self._v_basis_cache={}
    def deriv(self,u,v,order=3):
        # Exact unit-weight NURBS specialization, after the strict carrier guard.
        if u not in self._u_basis_cache:self._u_basis_cache[u]=basis_derivatives(self.ku,self.p,u,3)
        if v not in self._v_basis_cache:self._v_basis_cache[v]=basis_derivatives(self.kv,self.q,v,3)
        nu=self._u_basis_cache[u];nv=self._v_basis_cache[v]
        r={(a,total-a):(nu[a,:,None]*nv[total-a,None,:]).ravel() for total in range(order+1) for a in range(total+1)}
        out={};ax=self.inverseJ[:,0];ay=self.inverseJ[:,1]
        for total in range(order+1):
            for a in range(total+1):
                b=total-a;z=np.zeros(self.m*self.n)
                for i in range(a+1):
                    for j in range(b+1):z+=comb(a,i)*comb(b,j)*ax[0]**i*ax[1]**(a-i)*ay[0]**j*ay[1]**(b-j)*r[i+j,total-i-j]
                out[a,b]=z
        return out
    def operators(self,u,v,mu=None,ell=1.):
        d=self.deriv(u,v);mu=self.mu if mu is None else np.asarray(mu,float)
        if abs(mu@self.normal)>1e-10 or abs(np.linalg.norm(mu)-1)>1e-10:raise ValueError('invalid physical conormal')
        op=lambda key,axis:(d[key][:,None]*axis).ravel()
        U=np.kron(d[0,0][None,:],np.eye(3));Ux=np.kron(d[1,0][None,:],np.eye(3))
        theta=-np.outer(np.cross(self.normal,self.t),op((1,0),self.normal))-np.outer(np.cross(self.normal,self.e2),op((0,1),self.normal))
        phi=np.outer(self.t,self.t)@theta+cross(self.t)@Ux
        ex=op((1,0),self.t);ey=op((0,1),self.e2);gam=op((0,1),self.t)+op((1,0),self.e2)
        factor=self.E*self.thickness/(1-self.nu**2)
        nxx=factor*(ex+self.nu*ey);nyy=factor*(ey+self.nu*ex);nxy=factor*(1-self.nu)*gam/2
        mx=float(mu@self.t);my=float(mu@self.e2)
        T=np.outer(self.t,mx*nxx+my*nxy)+np.outer(self.e2,mx*nxy+my*nyy)
        wx3=op((3,0),self.normal);wx2y=op((2,1),self.normal);wxy2=op((1,2),self.normal);wy3=op((0,3),self.normal)
        T+=np.outer(self.normal,-self.D*(mx*(wx3+wxy2)+my*(wx2y+wy3)))
        def moment(dx2,dy2,dxy):
            Mmu=-self.D*(np.outer(self.t,mx*(dx2+self.nu*dy2)+my*(1-self.nu)*dxy)
                +np.outer(self.e2,mx*(1-self.nu)*dxy+my*(dy2+self.nu*dx2)))
            return cross(self.normal)@Mmu
        m=moment(op((2,0),self.normal),op((0,2),self.normal),op((1,1),self.normal))
        ms=moment(wx3,wxy2,wx2y)
        N=np.vstack([U,ell*phi]);V=-np.vstack([T,m/ell])
        X=d[0,0]@self.cp
        return dict(U=U,theta=theta,phi=phi,N=N,V=V,T=T,m=m,ms=ms,X=X,
                    effective_force=T+cross(self.t)@ms)

def unique_cuts(arms):
    cuts=sorted({float(x) for a in arms for x in a.ku if 0<=x<=1})
    if cuts[0]!=0 or cuts[-1]!=1:raise ValueError('incomplete common segment')
    return cuts

def resultants(vector,positions,origin):
    f=np.asarray(vector).reshape(-1,3);x=np.asarray(positions).reshape(-1,3)-origin
    return np.sum(f,axis=0),np.sum(np.cross(x,f),axis=0)

def integrate_cluster(arms,betas,ell,gauss=8,origin=None):
    if len(arms)!=3 or not ell>0 or gauss<4 or gauss>16:raise ValueError('cluster integration settings')
    if len(betas) not in (2,3) or any(e not in PAIRS or not np.isfinite(b) or b<=0 for e,b in betas.items()) or set(i for e in betas for i in e)!={0,1,2}:raise ValueError('invalid selected graph weights')
    origin=np.zeros(3) if origin is None else np.asarray(origin,float)
    L=arms[0].length
    if any(np.linalg.norm(a.origin-arms[0].origin)>1e-8 or np.linalg.norm(a.du-arms[0].du)>1e-8 for a in arms):raise ValueError('owners do not share proven full v0 line')
    cuts=unique_cuts(arms);gx,gw=np.polynomial.legendre.leggauss(gauss)
    action=[np.zeros_like(a.coeff) for a in arms]
    pairs={e:dict(u2=0.,theta2=0.,max_u=0.,max_theta=0.,penalty=0.) for e in PAIRS}
    physicalForce=np.zeros(3);physicalMoment=np.zeros(3);effectiveForce=np.zeros(3);commonMoment=0.
    eff2=effDen=rot2=rotDen=0.;workSelf=workLift=workMean=consistency=penalty=0.;measure=0.
    for lo,hi in zip(cuts[:-1],cuts[1:]):
        if hi<=lo:continue
        for x,w in zip(gx,gw):
            u=(lo+hi)/2+(hi-lo)*x/2;ds=L*(hi-lo)*w/2
            ops=[a.operators(u,0.,ell=ell) for a in arms]
            z=[o['N']@a.coeff for o,a in zip(ops,arms)];f=[o['V']@a.coeff for o,a in zip(ops,arms)]
            th=[o['theta']@a.coeff for o,a in zip(ops,arms)];uu=[o['U']@a.coeff for o,a in zip(ops,arms)]
            Ts=[o['T']@a.coeff for o,a in zip(ops,arms)];ms=[o['m']@a.coeff for o,a in zip(ops,arms)]
            eff=[o['effective_force']@a.coeff for o,a in zip(ops,arms)]
            zb=sum(z)/3;fb=sum(f)/3;measure+=ds
            X=ops[0]['X'];physicalForce+=ds*sum(Ts);physicalMoment+=ds*sum((np.cross(X-origin,T)+m for T,m in zip(Ts,ms)))
            effectiveForce+=ds*sum(eff);common=[a.t@m for a,m in zip(arms,ms)];commonMoment+=ds*sum(common)
            eff2+=ds*np.dot(sum(eff),sum(eff));effDen+=ds*sum(v@v for v in eff)
            rot2+=ds*sum(common)**2;rotDen+=ds*sum(v*v for v in common)
            for i,(a,o) in enumerate(zip(arms,ops)):
                action[i]+=ds*(o['N'].T@(f[i]-fb)+o['V'].T@(z[i]-zb))
                consistency+=ds*np.dot(z[i]-zb,f[i]);workSelf+=ds*(Ts[i]@uu[i]+ms[i]@th[i])
                workLift+=ds*(Ts[i]@uu[i]+ms[i]@(o['phi']@a.coeff));workMean-=ds*f[i]@zb
            for e,stat in pairs.items():
                i,j=e;du=uu[i]-uu[j];dt=arms[i].t@th[i]-arms[j].t@th[j]
                stat['u2']+=ds*(du@du);stat['theta2']+=ds*dt*dt
                stat['max_u']=max(stat['max_u'],float(np.linalg.norm(du)));stat['max_theta']=max(stat['max_theta'],abs(float(dt)))
                if e in betas:
                    beta=betas[e];jump=z[i]-z[j];p=ds*beta*(jump@jump);stat['penalty']+=p;penalty+=p
                    action[i]+=ds*beta*ops[i]['N'].T@jump;action[j]-=ds*beta*ops[j]['N'].T@jump
    actionWork=sum(a.coeff@f for a,f in zip(arms,action));expectedWork=2*consistency+penalty
    H=[]
    for endpoint in (0.,1.):H.append(sum(np.cross(a.operators(endpoint,0.,ell=ell)['m']@a.coeff,a.t) for a in arms))
    jumps=[]
    for (i,j),s in pairs.items():
        beta=betas.get((i,j));jumps.append(dict(owners=[hex(arms[i].handle),hex(arms[j].handle)],selected_penalty=beta is not None,beta_N_per_mm2=beta,
            displacement_L2_mm_sqrt_mm=sqrt(max(0,s['u2'])),displacement_RMS_mm=sqrt(max(0,s['u2'])/measure),
            common_axis_rotation_L2_rad_sqrt_mm=sqrt(max(0,s['theta2'])),common_axis_rotation_RMS_rad=sqrt(max(0,s['theta2'])/measure),
            sampled_Gauss_max_displacement_mm=s['max_u'],sampled_Gauss_max_common_axis_rotation_rad=s['max_theta'],
            penalty_quadratic_work_N_mm=s['penalty'] if beta is not None else None,
            beta_weighted_displacement_RMS_mm=sqrt(max(0,s['u2'])/measure) if beta is not None else None,
            beta_ell2_weighted_common_axis_rotation_RMS_rad=sqrt(max(0,s['theta2'])/measure) if beta is not None else None))
    n=max(int(a.dofmap.max()) for a in arms)+1;glob=np.zeros(n);positions=np.full((n//3,3),np.nan)
    for a,f in zip(arms,action):
        np.add.at(glob,a.dofmap,f)
        for k in range(len(a.cp)):positions[a.dofmap[3*k]//3]=a.cp[k]
    nf,nm=resultants(glob,positions,origin)
    ratio=lambda a,b:float(a/b) if b>0 else (0. if a==0 else None)
    return dict(physical_length_mm=measure,quadrature_order=gauss,physical_span_count=len(cuts)-1,jumps=jumps,
        numerical_canonical_cluster_action_global=glob,numerical_action_force_sum_N=nf.tolist(),numerical_action_moment_sum_N_mm=nm.tolist(),
        raw_physical_joint_force_integral_N=physicalForce.tolist(),raw_physical_joint_moment_integral_N_mm=physicalMoment.tolist(),
        effective_joint_force_integral_N=effectiveForce.tolist(),common_axis_moment_integral_N_mm=commonMoment,
        effective_force_sum_L2_N_per_sqrt_mm=sqrt(max(0,eff2)),effective_force_sum_relative_L2=ratio(sqrt(max(0,eff2)),sqrt(max(0,effDen))),
        common_axis_moment_sum_L2_N_sqrt_mm=sqrt(max(0,rot2)),common_axis_moment_sum_relative_L2=ratio(sqrt(max(0,rot2)),sqrt(max(0,rotDen))),
        endpoint_twist_H_sum_start_N=H[0].tolist(),endpoint_twist_H_sum_end_N=H[1].tolist(),
        effective_force_integral_identity_residual_N=(effectiveForce-(physicalForce-H[1]+H[0])).tolist(),
        full_physical_self_work_N_mm=workSelf,lifted_physical_self_work_N_mm=workLift,common_mean_physical_work_N_mm=workMean,
        consistency_scalar_native_N_mm=consistency,penalty_quadratic_work_N_mm=penalty,
        reconstructed_cluster_quadratic_work_N_mm=actionWork,cluster_quadratic_energy_N_mm=.5*actionWork,
        work_identity_residual_N_mm=actionWork-expectedWork,
        full_vs_lifted_physical_work_difference_N_mm=workSelf-workLift,
        consistency_vs_physical_work_identity_residual_N_mm=consistency+workSelf-workMean)

def recovered_clamp_resultant(arm,gauss=8,origin=None):
    origin=np.zeros(3) if origin is None else np.asarray(origin,float)
    gx,gw=np.polynomial.legendre.leggauss(gauss);cuts=sorted(set(arm.kv));force=np.zeros(3);moment=np.zeros(3)
    for lo,hi in zip(cuts[:-1],cuts[1:]):
        if hi<=lo:continue
        for x,w in zip(gx,gw):
            v=(lo+hi)/2+(hi-lo)*x/2;o=arm.operators(0.,v,mu=-arm.t);ds=arm.width*(hi-lo)*w/2
            T=o['T']@arm.coeff;m=o['m']@arm.coeff;force+=ds*T;moment+=ds*(np.cross(o['X']-origin,T)+m)
    return force,moment

def integrate_bulk_action(arms,gauss=4,origin=None):
    """Independent flat no-hole KL membrane+bending action, no global matrix."""
    if gauss!=4:raise ValueError('bulk reference protocol fixes tensor GL4')
    origin=np.zeros(3) if origin is None else np.asarray(origin,float)
    n=max(int(a.dofmap.max()) for a in arms)+1;global_action=np.zeros(n)
    positions=np.full((n//3,3),np.nan);gx,gw=np.polynomial.legendre.leggauss(4)
    energy=0.;details=[]
    for a in arms:
        action=np.zeros((a.m*a.n,3));u=a.coeff.reshape(-1,3)
        ut=u@a.t;uv=u@a.e2;un=u@a.normal
        factor=a.E*a.thickness/(1-a.nu**2);area_jac=np.linalg.norm(np.cross(a.du,a.dv));measure=0.;quad=0.;count=0
        uc=sorted(set(a.ku));vc=sorted(set(a.kv))
        for u0,u1 in zip(uc[:-1],uc[1:]):
            if u1<=u0:continue
            for v0,v1 in zip(vc[:-1],vc[1:]):
                if v1<=v0:continue
                for x,wx in zip(gx,gw):
                    for y,wy in zip(gx,gw):
                        uu=(u0+u1)/2+(u1-u0)*x/2;vv=(v0+v1)/2+(v1-v0)*y/2
                        d=a.deriv(uu,vv,order=2);da=area_jac*(u1-u0)*(v1-v0)*wx*wy/4
                        ex=d[1,0]@ut;ey=d[0,1]@uv;gam=d[0,1]@ut+d[1,0]@uv
                        xx=d[2,0]@un;yy=d[0,2]@un;xy=d[1,1]@un
                        nxx=factor*(ex+a.nu*ey);nyy=factor*(ey+a.nu*ex);nxy=factor*(1-a.nu)*gam/2
                        bx=a.D*(xx+a.nu*yy);by=a.D*(yy+a.nu*xx);bxy=2*a.D*(1-a.nu)*xy
                        action+=da*((d[1,0]*nxx+d[0,1]*nxy)[:,None]*a.t
                            +(d[0,1]*nyy+d[1,0]*nxy)[:,None]*a.e2
                            +(d[2,0]*bx+d[0,2]*by+d[1,1]*bxy)[:,None]*a.normal)
                        quad+=da*(ex*nxx+ey*nyy+gam*nxy+xx*bx+yy*by+xy*bxy);measure+=da;count+=1
        action=action.ravel();np.add.at(global_action,a.dofmap,action)
        for k in range(len(a.cp)):positions[a.dofmap[3*k]//3]=a.cp[k]
        details.append(dict(owner=hex(a.handle),quadrature_points=count,physical_area_mm2=measure,
            material_quadratic_work_N_mm=quad,action_dot_displacement_N_mm=float(action@a.coeff),
            work_identity_difference_N_mm=float(action@a.coeff)-quad))
        energy+=quad
    f,m=resultants(global_action,positions,origin)
    return dict(global_action=global_action,owners=details,material_quadratic_work_N_mm=energy,
        material_strain_energy_N_mm=.5*energy,bulk_action_force_sum_N=f.tolist(),bulk_action_moment_sum_N_mm=m.tolist(),
        method='independent tensor GL4 at every actual u/v knot span; affine flat isotropic constant thickness; no global matrix')
