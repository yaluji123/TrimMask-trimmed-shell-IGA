"""Validate actual final-runtime timing artifacts; do not invent legacy metadata."""
from pathlib import Path
import argparse,json,csv,re,hashlib,math,importlib.util
import numpy as np
HERE=Path(__file__).resolve().parent;ROOT=Path('投稿/二次修稿/准备工作')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def run(case,output,selection_sha,context):
 a=argparse.Namespace(label=case.name,output=output);assert not a.output.exists();p=read(case/'process_result.json');plan=read(case/'launch_plan.json');window=read(case/'root_selected_window.json');selection=read(case/'accuracy_selection.json');assert sha(case/'accuracy_selection.json')==selection_sha and selection['source_binding_sha256']=='90f72156bd9f1430e25177e91b6a69b89c4434f81934dfdee19b20eef2a96566'and selection['runtime_manifest_sha256']=='50999199bb7bf6770b7446beae7c5e2600294276d6ba858ab7a616f873bf5a84';params=window['parameters'];assert params['timing']and p['exit_code']==0 and p['natural_owned_child_exit']and read(case/'owned_process_resource_observations.json')['within_declared_observed_memory']
 assert sha(case/'source_runtime_manifest.json')=='50999199bb7bf6770b7446beae7c5e2600294276d6ba858ab7a616f873bf5a84'and sha(case/'applied_source_binding.json')=='90f72156bd9f1430e25177e91b6a69b89c4434f81934dfdee19b20eef2a96566'
 assert sha(case/'executed_runner.py')==window['runner_sha256'];assert sha(case/'accuracy_selection.json')==window['accuracy_selection_sha256']and selection['status']=='PASS_FINAL1212_SAME_ACCURACY_TIMING_SELECTION'
 method=params['profile_variant'];qualified=selection['qualified_methods'][method];assert qualified['eligible']and sha(case/'executed_profile.json')==qualified['profile_sha256'];assert selection['fixed_interleaved_schedule'][params['timing_slot']-1]==method
 env=plan['explicit_IGA_child_environment']
 for key in ['IGA_SOLVER_STRICT_REPRODUCIBILITY','IGA_ASSEMBLY_THREADS','IGA_SOLVER_THREADS','IGA_PARDISO_THREADS']:assert env[key]=='1'
 for key in ['IGA_OE_EXTERNAL_LOAD_AUDIT_DIRECTORY','IGA_OE_BULK_MEASURE_AUDIT','IGA_OE_GEOMETRY_DIRECTORY','IGA_OE_COUPLE_GEOMETRY_DIRECTORY','IGA_OE_TRI_REFERENCE_DUFFY_GL6','IGA_OE_CUT_MOMENT_AUDIT']:assert key not in env
 assert env['IGA_OE_BOUNDARY_DOMAIN_V2']=='1'and env['IGA_OE_BOUNDARY_PROBE_JSONL']==str(case/'boundary_domain_probe.jsonl')
 script=(case/'executed.scr').read_text();assert 'oe_timing_start_ms'in script and 'solveAndExportCommandMs='in script
 decoder=read(case/'log_decode_receipt.json');assert all(decoder[k]['strict_decode']for k in ['stdout','stderr']);text=(case/'stdout.log').read_text(encoding='utf-8')
 clocks=re.findall(r'\[IGA\]\[TimingProtocol\] solveAndExportCommandMs=(-?[0-9]+)',text);assert len(clocks)==1 and int(clocks[0])>0
 traceTool=ROOT/'runtime/timing_protocol_v3/required_trace.py';spec=importlib.util.spec_from_file_location('frozen_real_required_trace',traceTool);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);trace=module.validate_trace(case/'boundary_domain_probe.jsonl',read(ROOT/'runtime/timing_protocol_v3/required_trace_expected_coverage.json'))
 diag=case/'source_diagnostics_after';summary={}
 with(diag/'trim_summary.csv').open(encoding='utf-8-sig',newline='')as f:
  for row in csv.reader(f):
   if len(row)==2 and row[0]!='metric':summary[row[0]]=row[1]
 assert int(summary['elemTotal'])==1296 and int(summary['elemCut'])==98
 for key in ['trimClassifyMs','trimClipTriMs','trimTotalMs']:assert math.isfinite(float(summary[key]))and float(summary[key])>=0
 with(diag/'trim_cell_diagnostics.csv').open(encoding='utf-8-sig',newline='')as f:cells=list(csv.DictReader(f))
 assert len(cells)==98
 sample=case/'derived_work/displacement_samples.csv';qcase=ROOT/'runtime/runs'/qualified['case'];qsample=qcase/'derived_work/displacement_samples.csv'
 with sample.open(encoding='utf-8-sig',newline='')as f:r=list(csv.DictReader(f))
 with qsample.open(encoding='utf-8-sig',newline='')as f:q=list(csv.DictReader(f))
 assert len(r)==len(q)==10280;meta=['element_id','shell_handle','vertex_count','local_vertex','sample_kind','u','v','x','y','z'];assert all(all(x[k]==y[k]for k in meta)for x,y in zip(r,q));U=np.array([[float(x[k])for k in ['ux','uy','uz']]for x in r]);V=np.array([[float(x[k])for k in ['ux','uy','uz']]for x in q]);assert np.isfinite(U).all()and np.allclose(U,V,atol=1e-8,rtol=1e-12)
 inputs=[case/n for n in ['process_result.json','launch_plan.json','root_selected_window.json','source_runtime_manifest.json','applied_source_binding.json','accuracy_selection.json','executed_profile.json','executed_runner.py','executed.scr','stdout.log','log_decode_receipt.json','boundary_domain_probe.jsonl']]+[diag/'trim_summary.csv',diag/'trim_cell_diagnostics.csv',sample,qsample,traceTool]
 result=dict(status='PASS_FINAL1212_CONTROLLED_SAME_ACCURACY_TIMING_OBSERVATION',case=a.label,slot=params['timing_slot'],method=method,solve_and_export_command_ms=int(clocks[0]),process_wall_seconds_not_kernel_benchmark=p['wall_seconds_instrumented_not_benchmark'],trimClassify_wall_ms=float(summary['trimClassifyMs']),trimClipTri_single_worker_elapsed_ms=float(summary['trimClipTriMs']),trimTotal_segment_wall_ms=float(summary['trimTotalMs']),raw_summary=summary,actual_cut_rules={str(k):sum(int(c['fallback'])==k for c in cells)for k in [0,1]},required_real_trace=trace,required_trace_overhead_not_subtracted=True,configured_threads_from_bound_source=1,OS_effective_thread_observation_claimed=False,qualified_response_U_relative_difference=float(np.linalg.norm(U-V)/np.linalg.norm(V)),observed_process_peak_bytes=read(case/'owned_process_resource_observations.json')['sampled_maximum_of_private_OSpeakcommit_OSpeakWS'],input_manifest=[dict(path=str(x),sha256=sha(x))for x in inputs],extractor_sha256=sha(Path(__file__)),not_new_continuum_accuracy_certification=True)
 for path in inputs:context.bind(path)
 result.update(source_binding_sha256='90f72156bd9f1430e25177e91b6a69b89c4434f81934dfdee19b20eef2a96566',runtime_manifest_sha256='50999199bb7bf6770b7446beae7c5e2600294276d6ba858ab7a616f873bf5a84');result['input_manifest']=context.finish()
 a.output.write_text(json.dumps(result,indent=2),encoding='utf-8');print(json.dumps(dict(status=result['status'],case=a.label,slot=result['slot'],command_ms=result['solve_and_export_command_ms'],trimTotal_ms=result['trimTotal_segment_wall_ms'])))
if __name__=='__main__':raise SystemExit('Use read_single_patch_v7.py')
