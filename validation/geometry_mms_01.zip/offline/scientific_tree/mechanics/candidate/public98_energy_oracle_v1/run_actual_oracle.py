"""Exact nominal-affine retained membrane energies and physical field norms.

Actual completed Duffy/ear7 fields only. No Native quadrature/ear triangulation,
no global matrix, no solve, and no deletion of inconvenient control values.
"""
from pathlib import Path
from fractions import Fraction as F
import os,sys,json,csv,hashlib,math,re,time
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1';os.environ['MKL_NUM_THREADS']='1'
if hasattr(sys,'set_int_max_str_digits'):sys.set_int_max_str_digits(0)
import numpy as np
from exact_cell_polynomial import *

HERE=Path(__file__).resolve().parent;PREP=HERE.parents[2]
CACHE=PREP/'geometry/native98/energy_moments_tensor49_v1/cell_local_tensor49_moments.json'
EXPECTED_CACHE_SHA='5881337f23e501816d2b9458cde757924801297b245ad8145ca4ec6abb71fc94'
GEOM_SHA='19fbf71b05130aedc741d5117f2cab829bfd09f2ec7be185ba099a1089d89b5b'
OUT=HERE/'actual_results_v1'
if OUT.exists():raise RuntimeError('fresh actual oracle output required; never overwrite evidence')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()

def load_case(case):
    run=PREP/'runtime/runs'/case;load=run/'input_audit';inputs=[]
    def j(p):inputs.append(p);return json.loads(p.read_text(encoding='utf-8-sig'))
    process=j(run/'process_result.json')
    if process['exit_code']!=0 or process['natural_exit'] is not True:raise RuntimeError('case not naturally complete')
    runtime=j(run/'source_runtime_manifest.json');plan=j(run/'launch_plan.json')
    geometry_path=run/'capture/trim_geometry_819.json';geom=j(geometry_path)
    if sha(geometry_path)!=GEOM_SHA:raise RuntimeError('actual captured registered domain mismatch')
    g=j(load/'load_stage_geometry_819.json')
    if (g['controls_u'],g['controls_v'],g['degree_u'],g['degree_v'],g['dofPN'])!=(39,39,3,3,3) or not g['is_flat'] or g['isVarThk']:raise RuntimeError('initial oracle requires actual 39x39 constant-t flat KL profile')
    cp=np.array(g['control_global_Vg']).reshape(-1,3)
    if np.count_nonzero(cp[:,2]) or not np.array_equal(np.array(g['weights']),np.ones(1521)):raise RuntimeError('actual geometry not exact z=0/unit-weight')
    p=load/'global_solution.csv';inputs.append(p)
    with p.open(encoding='utf-8-sig',newline='') as f:
        reader=csv.DictReader(f)
        if reader.fieldnames!=['global_dof_zero_based','value']:raise RuntimeError('actual solution schema')
        data=list(reader)
    if len(data)!=4563:raise RuntimeError('actual global vector dimension')
    globalU=np.zeros(4563);seen=set()
    for row in data:
        i=int(row['global_dof_zero_based']);v=float(row['value'])
        if i in seen or not 0<=i<4563 or not np.isfinite(v):raise RuntimeError('bad actual global coefficient')
        seen.add(i);globalU[i]=v
    p=load/'patch_external_819.csv';inputs.append(p)
    with p.open(encoding='utf-8-sig',newline='') as f:rows=list(csv.DictReader(f))
    if len(rows)!=4563:raise RuntimeError('actual Node map incomplete')
    localU=np.zeros((1521,3));mapping=np.zeros((1521,3),int);seen=set()
    for row in rows:
        i=int(row['local_cp']);c=int(row['component']);k=(i,c)
        if k in seen or not(0<=i<1521 and 0<=c<3) or int(row['shell_handle'])!=819 or int(row['control_i'])!=i//39 or int(row['control_j'])!=i%39:raise RuntimeError('actual owner/control mapping')
        seen.add(k);gdof=int(row['global_dof_zero_based'])
        if gdof!=3*(int(row['Node_one_based'])-1)+c or not 0<=gdof<4563:raise RuntimeError('actual Node/DOF mismatch')
        if not np.array_equal(np.array([float(row[k]) for k in ['cp_x','cp_y','cp_z']]),cp[i]):raise RuntimeError('actual geometry/Node CSV mismatch')
        mapping[i,c]=gdof;localU[i,c]=globalU[gdof]
    if np.count_nonzero(localU[:,2]):raise RuntimeError('actual uz is nonzero; initial MEMBRANE oracle cannot discard it or claim a Hessian geometry bound')
    if not np.all(np.isfinite(localU)):raise RuntimeError('nonfinite actual field')
    if not np.array_equal(np.array(g['knots_u']),np.array(geom['knots_u'])) or not np.array_equal(np.array(g['knots_v']),np.array(geom['knots_v'])):raise RuntimeError('actual knot identity')
    raw=(run/'stdout.log').read_bytes();text=raw.replace(b'\0',b'').decode('utf-8',errors='replace');inputs.append(run/'stdout.log')
    pattern=r'\[IGA\]\[OEEnergyComponents\] bulkQuadratic=([+\-0-9.eE]+) interfaceQuadratic=([+\-0-9.eE]+) boundaryQuadratic=([+\-0-9.eE]+) assembledQuadratic=([+\-0-9.eE]+) externalLoadWork=([+\-0-9.eE]+)'
    match=re.findall(pattern,text)
    if len(match)!=1:raise RuntimeError('missing/ambiguous observed energy record')
    energies=dict(zip(['after_support_bulk_half_quadratic','interface_half_quadratic','weak_boundary_half_quadratic','assembled_half_quadratic','external_work'],(float(v.rstrip('.')) for v in match[0])))
    return dict(name=case,run=run,g=g,geometry=geom,cp=cp,localU=localU,globalU=globalU,mapping=mapping,energies=energies,inputs=inputs,runtime=runtime,plan=plan)

def exact_report(q):
    q=Q(q);value=float(q)
    if not math.isfinite(value):raise RuntimeError('nonfinite numerical display')
    return dict(value=value,exact=str(q),display_rounding_abs_exact=str(abs(Q(value)-q)))

started=time.perf_counter();cases=[load_case('public98_duffy_reference_v5'),load_case('public98_ear7_v5')]
if cases[0]['runtime']['runtime'][0]['sha256']!=cases[1]['runtime']['runtime'][0]['sha256']:raise RuntimeError('actual cases not same binary')
g=cases[0]['g']
for case in cases[1:]:
    for key in ['knots_u','knots_v','weights','control_global_Vg','E','nu','constant_t','isVarThk']:
        if case['g'][key]!=g[key]:raise RuntimeError('cases do not share geometry/material input')
    if not np.array_equal(case['mapping'],cases[0]['mapping']):raise RuntimeError('different Node maps; explicit physical-key remapping required')
if sha(CACHE)!=EXPECTED_CACHE_SHA:raise RuntimeError('independent geometry moment cache changed or incomplete')
cache=json.loads(CACHE.read_text())
powers=[tuple(p) for p in cache['powers']]
if powers!=[(a,b) for a in range(7) for b in range(7)] or len(cache['cells'])!=1296 or cache['physical_Jacobian_included'] is not False or cache['weights_include_cell_du_dv'] is not True:raise RuntimeError('independent49 moment semantics')
ku=g['knots_u'];kv=g['knots_v'];bu=all_restrictions(ku,3);bv=all_restrictions(kv,3)
umap={(b.lo,b.hi):b for b in bu};vmap={(b.lo,b.hi):b for b in bv}
control,controlDen=shared_binary_controls([c['localU'][:,:2].tolist() for c in cases])
Lx=F(2000);Ly=F(800);J=Lx*Ly;E=Q(g['E']);nu=Q(g['nu']);t=Q(g['constant_t'])
cert=jacobian_perturbation_certificate(cases[0]['cp'].tolist(),ku,kv,Lx,Ly)
names=['duffy','ear7','difference'];totals={name:dict(half_energy=F(0),field_norm_squared=F(0),geometry_energy_abs_bound=F(0)) for name in names}
uv_area=F(0);cellrows=[];classes={};max_degree_energy=0;max_degree_norm=0
for step,cell in enumerate(sorted(cache['cells'],key=lambda x:x['element'])):
    bounds=list(map(F,cell['bounds_exact']));uc=umap[tuple(bounds[:2])];vc=vmap[tuple(bounds[2:])]
    if uc.width*vc.width!=F(cell['cellUVArea_exact']):raise RuntimeError('cell/actual knot bound mismatch')
    A=F(cell['retainedUVArea_exact']);uv_area+=A;kind=cell['reference_class'];classes[kind]=classes.get(kind,0)+1
    row=dict(element=cell['element'],row=cell['row'],col=cell['col'],reference_class=kind,retained_UV_area=float(A))
    if A==0:
        if kind!='out':raise RuntimeError('positive class with zero retained measure')
        for name in names:
            for metric in ['half_energy_N_mm','field_norm_squared_mm4','geometry_energy_abs_bound_N_mm']:row[name+'_'+metric]=0.
        cellrows.append(row);continue
    if kind=='in':moments={p:F(cell['cellUVArea_exact'])/((p[0]+1)*(p[1]+1)) for p in powers}
    elif kind=='cut':moments=dict(zip(powers,map(F,cell['moments_uv_weighted_exact'])))
    else:raise RuntimeError('unknown independent cell class')
    if moments[0,0]!=A:raise RuntimeError('M00/reference area inconsistency')
    M=MomentVector.fractions(moments)
    field=[]
    for c in control:field.append([restrict_field(uc,vc,c,39,comp,controlDen) for comp in (0,1)])
    field.append([field[1][i]-field[0][i] for i in (0,1)])
    for name,(U,V) in zip(names,field):
        density,grad=membrane_half_density(U,V,Lx*uc.width,Ly*vc.width,E,nu,t)
        normpoly=displacement_squared(U,V);degreeE=density.maximum_degrees();degreeS=normpoly.maximum_degrees()
        if degreeE[0]>6 or degreeE[1]>6 or degreeE[2]>10 or degreeS[0]>6 or degreeS[1]>6 or degreeS[2]>12:raise RuntimeError('actual polynomial degree exceeds proved moment coverage')
        max_degree_energy=max(max_degree_energy,degreeE[2]);max_degree_norm=max(max_degree_norm,degreeS[2])
        energy=J*M.integrate(density);norm2=J*M.integrate(normpoly)
        if energy<0 or norm2<0:raise RuntimeError('negative exact physical quadratic integral; do not clamp or abs it')
        bound=membrane_geometry_energy_bound(grad,energy,A,Lx,Ly,E,nu,t,cert)
        totals[name]['half_energy']+=energy;totals[name]['field_norm_squared']+=norm2;totals[name]['geometry_energy_abs_bound']+=bound
        row[name+'_half_energy_N_mm']=float(energy);row[name+'_field_norm_squared_mm4']=float(norm2);row[name+'_geometry_energy_abs_bound_N_mm']=float(bound)
    cellrows.append(row)
    if step%64==0:print(json.dumps(dict(event='exact_oracle_progress',completed=step+1,total=1296,elapsed_seconds=round(time.perf_counter()-started,2))),flush=True)
area=J*uv_area;d=cert['det_relative_bound'];e=cert['spectral_upper_bound']
summaries={}
for name,values in totals.items():
    energy=values['half_energy'];norm2=values['field_norm_squared'];bound=values['geometry_energy_abs_bound']
    summaries[name]=dict(nominal_affine_material_half_energy_N_mm=exact_report(energy),
        geometry_perturbation_abs_energy_bound_N_mm=exact_report(bound),
        actual_flat_membrane_energy_interval_exact=[str(max(F(0),energy-bound)),str(energy+bound)],
        nominal_retained_field_L2_squared_mm4=exact_report(norm2),nominal_retained_field_L2_mm2=math.sqrt(float(norm2)),
        nominal_retained_RMS_displacement_mm=math.sqrt(float(norm2/area)),
        actual_geometry_field_L2_squared_interval_exact=[str((1-d)*norm2),str((1+d)*norm2)])
coeffdiff=cases[1]['globalU']-cases[0]['globalU'];rawCoeffRel=float(np.linalg.norm(coeffdiff)/np.linalg.norm(cases[0]['globalU']))
E0=totals['duffy']['half_energy'];Ed=totals['difference']['half_energy'];S0=totals['duffy']['field_norm_squared'];Sd=totals['difference']['field_norm_squared']
for i,name in enumerate(['duffy','ear7']):
    native=cases[i]['energies']['after_support_bulk_half_quadratic'];nominal=float(totals[name]['half_energy'])
    summaries[name]['observed_Native_after_support_bulk_half_quadratic_N_mm']=native
    summaries[name]['observed_after_support_minus_nominal_N_mm']=native-nominal
    summaries[name]['observed_after_support_minus_nominal_relative']=native/nominal-1
result=dict(schema='oe-public98-exact-retained-membrane-field-oracle-v1',
    status='COMPLETED_EXACT_NOMINAL_MEMBRANE_ORACLE_WITH_CAPTURED_GEOMETRY_BOUNDS',
    domain_scope='Same captured full-frame registered polygons minus24 disjoint holes; not original CAD exact-curve certification',
    actual_case_names=[c['name'] for c in cases],actual_binary=cases[0]['runtime']['runtime'][0],
    actual_out_of_plane_coefficients_exactly_zero=True,actual_geometry_z_exactly_zero=True,
    actual_controls=[39,39],global_dofs=4563,independent_domain_cell_counts=classes,
    physical_material_area_nominal_mm2=exact_report(area),physical_material_parameter_area_UV=exact_report(uv_area),
    maximum_actual_energy_polynomial_total_degree=max_degree_energy,maximum_field_norm_polynomial_total_degree=max_degree_norm,
    moment_tensor_49_covers_M66=True,polynomial_arithmetic='Exact actual-float rational input, integer common-denominator cubic restrictions/convolutions, exact Fraction moments/sums',
    material_input_interpretation='Captured finite E/nu/t treated as exact input numbers; displayed floating values rounded with exact reporting residual retained',
    geometry_model=dict(nominal_J_mm=[[2000,0],[0,800]],delta_J_component_abs_bounds_exact=[[str(x) for x in row] for row in cert['delta_J_component_bounds']],
        deltaJ_times_nominal_inverse_spectral_upper_exact=str(e),inverse_relative_bound_exact=str(cert['inverse_relative_bound']),det_relative_bound_exact=str(d),
        applicable_only_to_actual_flat_inplane_membrane_fields=True,Hessian_geometry_bound_claimed=False),
    fields=summaries,
    comparisons=dict(raw_control_coefficient_relative_L2=rawCoeffRel,raw_control_metric_is_not_physical_field_error=True,
        nominal_retained_field_difference_relative_L2=math.sqrt(float(Sd/S0)),
        nominal_energy_seminorm_difference_sqrt_N_mm=math.sqrt(float(2*Ed)),
        nominal_energy_seminorm_difference_relative_to_duffy=math.sqrt(float(Ed/E0)),
        physical_difference_metrics_compare_two_computed_fields_not_true_solution_error=True,
        field_relative_L2_squared_geometric_interval_exact=[str(Sd*(1-d)/(S0*(1+d))),str(Sd*(1+d)/(S0*(1-d)))],
        difference_half_energy_computed_directly_from_difference_field_not_large_energy_subtraction=True),
    native_comparison_scope='Observed Native bulkQuadratic is after-support half quadratic; a discrepancy is not automatically attributed solely to quadrature without the raw/support ledger',
    source_ear_triangulation_or_native_rule_reused=False,global_matrix_constructed=False,new_solver_Host_compiler_started=False,
    error_from_original_CAD_polyline_approximation_or_actual_solution_discretization_bounded=False,
    general_method_or_ear7_accuracy_accepted=False,elapsed_seconds=time.perf_counter()-started)
sources=[CACHE,HERE/'exact_cell_polynomial.py',Path(__file__)]+[p for c in cases for p in c['inputs']]
result['input_manifest']=[dict(path=str(p),sha256=sha(p)) for p in dict.fromkeys(sources)]
OUT.mkdir()
(OUT/'oracle_results.json').write_text(json.dumps(result,indent=2,allow_nan=False),encoding='utf-8')
with (OUT/'cell_energy_and_field_difference.csv').open('w',newline='',encoding='utf-8-sig') as f:
    writer=csv.DictWriter(f,fieldnames=list(cellrows[0]));writer.writeheader();writer.writerows(cellrows)
print(json.dumps(dict(status=result['status'],elapsed_seconds=result['elapsed_seconds'],
    raw_control_relative_L2=rawCoeffRel,retained_field_relative_L2=result['comparisons']['nominal_retained_field_difference_relative_L2'],
    retained_RMS_difference_mm=summaries['difference']['nominal_retained_RMS_displacement_mm'],
    energy_seminorm_relative=result['comparisons']['nominal_energy_seminorm_difference_relative_to_duffy'],
    nominal_energies=[float(totals[n]['half_energy']) for n in names],
    geometric_energy_bounds=[float(totals[n]['geometry_energy_abs_bound']) for n in names]),indent=2),flush=True)
