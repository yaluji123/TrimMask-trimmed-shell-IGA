"""Area-weighted field comparison on the complete independent reference mesh."""
from pathlib import Path
import argparse,json,hashlib,time
import numpy as np
from prepare_physical_field_data import evaluate
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def rule(order):
 z,w=np.polynomial.legendre.leggauss(order);z=(z+1)/2;w=w/2;t,r=np.meshgrid(z,z,indexing='ij');wt,wr=np.meshgrid(w,w,indexing='ij');L=np.column_stack([((1-t)*(1-r)).ravel(),t.ravel(),((1-t)*r).ravel()]);W=(2*wt*wr*(1-t)).ravel();assert abs(W.sum()-1)<1e-14 and np.all(W>0);return L,W
def p2(L):
 N=np.column_stack([L*(2*L-1),4*L[:,0]*L[:,1],4*L[:,1]*L[:,2],4*L[:,2]*L[:,0]]);assert np.max(np.abs(N.sum(1)-1))<1e-14;return N
def run(a):
 assert not a.output.exists();start=time.perf_counter()
 s=np.load(a.native_state);f=np.load(a.reference_state);g=json.loads(a.geometry.read_text());m,n=g['controls_u'],g['controls_v'];cp=s['cp'].reshape(m,n,3);coeff=np.concatenate([cp,s['U'].reshape(m,n,3)],axis=2);points=f['points']+f['origin'];conn=f['triangles'];J=s['J'];B=np.linalg.inv(J[:2]);tolerance=max(1e-8,max(np.linalg.norm(J[:,0]),np.linalg.norm(J[:,1]))*1e-10)
 P=points[conn[:,:3]];area=.5*np.abs(np.cross(P[:,1]-P[:,0],P[:,2]-P[:,0]));assert np.all(area>0);sol=f['U'];results=[]
 for order in [6,8]:
  L,W=rule(order);N=p2(L);totals=np.zeros(3);maxgap=0.;count=0
  for begin in range(0,len(conn),1024):
   ids=conn[begin:begin+1024];pos=P[begin:begin+len(ids)];xy=np.einsum('qa,eac->eqc',L,pos,optimize=True);uv=((xy.reshape(-1,2)-cp[0,0,:2])@B.T);assert uv.min()>-512*np.finfo(float).eps and uv.max()<1+512*np.finfo(float).eps
   vals,_=evaluate(np.clip(uv,0,1),s['knots_u'],s['knots_v'],coeff);world=np.column_stack([xy.reshape(-1,2),np.zeros(len(uv))]);gap=np.linalg.norm(vals[:,:3]-world,axis=1);maxgap=max(maxgap,float(gap.max()));assert gap.max()<=tolerance
   iga=vals[:,3:].reshape(len(ids),len(L),3);fem=np.einsum('qa,eac->eqc',N,sol[ids],optimize=True);fem=np.concatenate([fem,np.zeros((*fem.shape[:2],1))],axis=2);weight=area[begin:begin+len(ids),None]*W[None,:]
   for i,v in enumerate([iga-fem,fem,iga]):totals[i]+=float(np.sum(weight*np.sum(v*v,axis=2)))
   count+=len(uv)
  assert totals[1]>0 and totals[2]>0
  results.append(dict(Duffy_GL_order=order,points=count,vector_L2_relative=float(np.sqrt(totals[0]/totals[1])),vector_RMS_difference_mm=float(np.sqrt(totals[0]/area.sum())),difference_integral_mm4=float(totals[0]),reference_integral_mm4=float(totals[1]),IGA_integral_mm4=float(totals[2]),max_physical_mapping_gap_mm=maxgap))
 change=abs(results[1]['vector_L2_relative']-results[0]['vector_L2_relative'])/results[1]['vector_L2_relative'];assert change<.001
 result=dict(status='PASS_WHOLE_RETAINED_TRIANGLE_AREA_WEIGHTED_FIELD_NORMS',P2_elements=len(conn),excluded_elements=0,area_mm2=float(area.sum()),quadrature_comparison=results,GL6_to_GL8_relative_norm_change=change,predeclared_norm_integration_relative_tolerance=.001,original_physical_mapping_tolerance_mm=tolerance,reference_is_finite_converged_P2_not_exact_continuum=True,wall_seconds=time.perf_counter()-start,inputs={k:sha(getattr(a,k))for k in ['native_state','geometry','reference_state']},source_sha256=sha(Path(__file__)))
 a.output.write_text(json.dumps(result,indent=2),encoding='utf-8');print(json.dumps(result))
if __name__=='__main__':raise SystemExit('Use read_single_patch_v7.py strict current identity')
