# Independent retained-field oracle: first completed Ear7 comparison

This packet operates on the **actual computed coefficient vectors** and the
same captured registered UV polygons. It does not reuse Native ear triangles,
Native quadrature points, Native moments or K*U to construct a reference.
No Host/compiler/solver was started and no source/master or prior evidence was
changed.

Both actual public98 fields have all 1521 out-of-plane coefficients **exactly
zero**, and the captured geometry is exactly z=0 with unit weights. Therefore
the actual energy calculation is restricted to flat membrane material energy.
The mixed-bending controls are nominal-affine tests; no actual Hessian-geometry
certificate is claimed or inferred from a Jacobian area bound.

## Calculation and arithmetic

Each cubic B-spline is restricted analytically to a knot cell in local (s,t)
coordinates by exact Cox–de Boor polynomial recursion. Actual finite input
floats are treated as exact rational numbers. Integer common-denominator
polynomial convolution forms the membrane half-energy density directly.
The nominal physical map is 2000 by 800 mm. Half-energy is

`Et/[2(1-nu²)] * [ux²+vy²+2*nu*ux*vy+(1-nu)/2*(uy+vx)²]`.

It has degree <=6 in each variable and total degree <=10 (46 possible terms).
Squared displacement has degree (6,6), total degree 12; **49 tensor moments**
are needed. The former 46/66 total-degree10 moments cannot integrate every
retained displacement L2 term.

The independent geometry agent supplied exact Fraction UV-weighted local
moments for all 1296 cells: 1149 in, 98 cut, 49 out. Rectangles are integrated
analytically; cut moments use exact clipping and Green line integrals, full
carrier minus the mutually disjoint registered holes. M00 and the old 784
selected controls were independently cross-checked. The cache is hash-bound.
No outside material is included simply because its control coefficient is large;
conversely no positive material region is removed to improve a norm.

The difference field is formed by **exact subtraction of the two actual input
fields**, then squared/differentiated. Its energy is not the difference of two
large total energies. All exact nonnegative integrals and exact totals are
retained; negative values would abort, not be abs/clamped to make them pass.

## Captured-geometry perturbation bound

For the actual planar membrane problem only, residual CP controls from the
nominal affine map bound each first geometry derivative by positive B-spline
control hulls. With `e >= ||deltaJ*J0^-1||2`, e<1,

`||J0*J^-1-I||` is represented consistently by the displacement-gradient
right-factor bound `r=e/(1-e)`, and `|det(J)/det(J0)-1|<=d=2e+e²`.

For nominal gradient G and symmetric strain epsilon, local coefficient-l1
bounds give `Gmax` and `epsmax`, delta-epsilon <=Gmax*r. Plane-stress tensor
operator norm is bounded by `Cmax=Et/(1-|nu|)`. Thus density difference is
bounded by `Cmax*(epsmax*delta + delta²/2)`. Integrating this constant bound over
the retained UV area and adding `d*E_nominal` bounds the actual flat membrane
energy difference. This is an absolute bound, including zero-nominal-strain
rigid fields. It is not a full curved-shell or actual bending mapping bound.

The displacement squared-norm geometry interval is `(1±d)*S_nominal`. Exact
integrals/bounds are stored as fractions; displayed floating values retain their
exact reporting-rounding residual. Original CAD-curve/polyline approximation,
the computed solution's mesh error and Native floating assembly error are not
silently included in this geometry-model certificate.

## First actual results: Ear7 versus computed Duffy reference

| Metric | Actual result |
| --- | ---: |
| Raw control-coefficient relative L2 difference | 0.2289141580 (22.8914%) |
| Retained physical displacement L2 relative difference | 0.0003547376651 (0.0354738%) |
| Retained RMS difference / mm | 0.0002312639138 |
| Energy-seminorm relative difference | 0.02746637279 (2.74664%) |
| Duffy field nominal physical membrane half-energy / N mm | 223667.0809721 |
| Ear7 field nominal physical membrane half-energy / N mm | 223793.1050690 |
| Direct difference-field nominal half-energy / N mm | 168.7348114 |

The retained L2 norm itself has units **mm²** for a two-dimensional surface;
RMS displacement has units mm. The energy seminorm is sqrt(2*half-energy), with
units sqrt(N mm). Relative metrics are dimensionless. These compare two
computed fields, not an unknown exact continuum solution. The original 22.9%
coefficient result is preserved under its own name, never relabelled physical
displacement error.

The absolute captured-geometry energy bounds are approximately
0.0001096 / 0.0012662 / 0.0017218 N mm for Duffy / Ear7 / difference, much smaller
than the direct difference-field energy. The observed Native **after-support**
Ear7 half-quadratic is 223645.7256129 N mm; that scalar's proximity to the
Duffy Native value does not establish energy-field agreement. A discrepancy
between independent physical energy and after-support Native energy is not
automatically assigned solely to quadrature without the raw/support ledger.

Controls passed: 144 exact actual-knot monomial/blossom reproductions; constant
linear/shear membrane energy; rigid zero energy; nominal mixed bending; exact
rectangle-minus-hole moments; missing M66 rejection; and an exactly solvable
affine-perturbation bound including a rigid nominal field. This does not promote
the actual Ear7 result to an accuracy or general-method PASS.
