"""Future one-capture sparse readback, source-only and not yet run on fine data."""
from pathlib import Path
import argparse
import csv
import hashlib
import json
import math
import sys
sys.dont_write_bytecode = True
from fine_sparse_budget_v1 import N, CAPTURE_ENTRY_CAP, CAPTURE_BYTES_CAP, state_factor_budget

HERE = Path(__file__).resolve().parent
SOURCE_BINDING = "2287e11f31f0703ed928b78e8d8462a76a96dae88349fcf48e64672775304371"


def sha(path):
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024*1024), b""):
            h.update(block)
    return h.hexdigest()


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--capture", type=Path, required=True)
    ap.add_argument("--identity-receipt", type=Path, required=True)
    ap.add_argument("--identity-receipt-sha256", required=True)
    ap.add_argument("--out", type=Path, required=True)
    a = ap.parse_args()
    # Reuse the already exercised self-owned CPU1/512MiB guard without modifying it.
    sys.path.insert(0, str(HERE.parent/"sources"))
    from resource_guard import install
    resources = install()
    if not resources["OS_memory_job_installed"]:
        raise RuntimeError("Fine packet requires an actual OS process-memory Job")
    if sha(a.identity_receipt) != a.identity_receipt_sha256:
        raise ValueError("Exact Root-verified source/runtime/loaded-module receipt required")
    receipt = json.loads(a.identity_receipt.read_text(encoding="utf-8-sig"))
    if receipt["source_binding_sha256"] != SOURCE_BINDING:
        raise ValueError("Wrong diagnostic source binding")
    for key in ("actual_loaded_modules_qualified", "same_input_profile_and_model_qualified",
                "natural_Core_exit_0", "within_observed_resource_declaration"):
        if receipt[key] is not True:
            raise ValueError("Unqualified capture identity gate: "+key)
    audit = a.capture/"input_audit"
    scope_path = audit/"patch_order_operator_scope.json"
    scope = json.loads(scope_path.read_text(encoding="utf-8-sig"))
    if (scope["schema"] != "oe_patch_order_actual_solver_input_fine_capture_v1"
            or scope["rows"] != N or scope["exported"] is not True
            or scope["matrix_is_actual_solver_argument"] is not True):
        raise ValueError("Missing actual fine solver K export")
    nnz = scope["exported_nonzero_entries"]
    if not 0 < nnz <= scope["stored_nnz"] <= CAPTURE_ENTRY_CAP:
        raise ValueError("Fine actual stored/exported count mismatch or overcap")
    kpath, fpath = audit/"patch_order_global_K.csv", audit/"patch_order_global_F.csv"
    if kpath.stat().st_size+fpath.stat().st_size != scope["actual_KF_export_bytes"]:
        raise ValueError("Actual K/F byte count mismatch")
    if scope["actual_KF_export_bytes"] > CAPTURE_BYTES_CAP:
        raise MemoryError("Actual K/F exceeds 100MiB")
    budget = state_factor_budget(scope["stored_nnz"])
    import numpy as np
    from scipy import sparse
    ri = np.empty(nnz, dtype=np.int32); ci = np.empty(nnz, dtype=np.int32)
    data = np.empty(nnz, dtype=np.float64)
    count = 0
    with kpath.open(encoding="utf-8-sig", newline="") as stream:
        rows = csv.reader(stream)
        if next(rows) != ["global_row_zero_based", "global_col_zero_based", "value_N_per_mm"]:
            raise ValueError("Actual K CSV schema")
        for row in rows:
            if count >= nnz:
                raise ValueError("Actual K rows exceed recorded count")
            i, j, value = int(row[0]), int(row[1]), float(row[2])
            if not 0 <= i < N or not 0 <= j < N or not math.isfinite(value) or value == 0.:
                raise ValueError("Bad actual K entry")
            ri[count], ci[count], data[count] = i, j, value
            count += 1
    if count != nnz:
        raise ValueError("Incomplete actual K")
    K = sparse.coo_matrix((data, (ri, ci)), shape=(N, N)).tocsr()
    if K.nnz != nnz:
        raise ValueError("Duplicate K row/column identity")
    F = np.empty(N)
    with fpath.open(encoding="utf-8-sig", newline="") as stream:
        rows = csv.reader(stream)
        if next(rows) != ["global_dof_zero_based", "value"]:
            raise ValueError("Actual F CSV schema")
        count = 0
        for row in rows:
            if count >= N or int(row[0]) != count or not math.isfinite(float(row[1])):
                raise ValueError("Actual F index/value")
            F[count] = float(row[1]); count += 1
    if count != N:
        raise ValueError("Incomplete F")
    node_path = audit/"patch_numbering_observed.csv"
    with node_path.open(encoding="utf-8-sig") as stream:
        nodes = list(csv.DictReader(stream))
    if len(nodes) != N//3:
        raise ValueError("Incomplete actual DOF map")
    for index, row in enumerate(nodes):
        if int(row["Node_one_based"]) != index+1 or int(row["global_dof_x_zero_based"]) != 3*index:
            raise ValueError("Actual Node/DOF numbering mismatch")
    a.out.mkdir(exist_ok=False)
    sparse.save_npz(a.out/"actual_K.npz", K)
    np.savez_compressed(a.out/"actual_F.npz", F=F)
    result = {"status": "IDENTITY_BOUND_ACTUAL_FINE_SPARSE_PACKET_NOT_BASELINE_ACCEPTANCE",
              "n": N, "stored_nnz": scope["stored_nnz"], "nonzero_nnz": K.nnz,
              "resources": resources, "pre_factor_budget": budget,
              "actual_factor_fill_observed": False, "state_solve_executed": False,
              "source_binding_sha256": SOURCE_BINDING,
              "bound_inputs": {str(p): sha(p) for p in
                  (a.identity_receipt, scope_path, kpath, fpath, node_path)}}
    (a.out/"results.json").write_text(json.dumps(result, indent=2)+"\n", encoding="utf-8")


if __name__ == "__main__":
    main()
