"""Metadata-only all-graph norm linkage; no G/factor/solver evaluation.

Backend private files are replayed by the already-qualified Context, never by
expanding the series Identity's exact8-runtime external whitelist.
"""
from pathlib import Path
from types import SimpleNamespace
import importlib.util,math,os,sys
for key in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS']:os.environ[key]='1'
from series_context_v7 import SOURCE,RUNTIME,DOFS,require,read,sha
FREE={1:621,2:1845,3:3717,4:6237}
BASE_CONTEXT_SHA='534a97a960bb7bc664195e9864ee4846c3984a2571c7e45ed289f2e0062510e3'
BACKEND_CONTEXT_SHA='0fb4fa156ae94c277e691909a8a6981390ab310939def370b3e503fda264d982'
BACKEND_PROTOCOL_SHA='51f6ccff583db26489fd11eb6b06924bbe5ee2a5966be83c0c6fb302596920e1'
CPP_SHA='f72a0b30c9a1a481b539940505f3517aa230ac8e633124ac5309fade6380eb3a'
EXE_SHA='095fa382b85ce62c85e84dff864aaba7c68e53a86339d53a301ec859ad4bccd0'
BUILD_SHA='63d59abfc309cd732e6f3060a5a1f63ef670d573cc52b9a7c402e6512e2c3f55'
SELFTEST_SHA='54e3ecea53174e253470733c71eb44dca3ac5bab9a76e3f3c3c54c62fc6496eb'
CHECKER_SHA='85c1c944af7a5e066abc46ea2c759968949a342459bd4a86cb081f192ecdac0d'
STREAM_SHA='f7610c0f0555ca651ce15694e41186ab5358ac67318191e8553ca1c605a82201'
CAP=536870912

def req(obj,key):
    require(isinstance(obj,dict)and key in obj and obj[key]is not None,'missing mandatory norm linkage '+key)
    return obj[key]

def arguments(parser):
    for name in ['weak-backend-tools','weak-backend-protocol','weak-backend-source','weak-backend-exe','weak-build-receipt','weak-selftest-report']:
        parser.add_argument('--'+name,type=Path,required=True)
    for name in ['weak-backend-protocol-sha256','weak-backend-exe-sha256','weak-build-receipt-sha256','weak-selftest-report-sha256']:
        parser.add_argument('--'+name,required=True)

def validate_links(links):
    require(isinstance(links,list)and len(links)==4,'exactly four actual all-graph norm references')
    by_h={}
    for entry in links:
        h=req(entry,'refine_factor')
        require(type(h)is int and h in FREE and h not in by_h,'unique declared all-graph h1..4 norm reference')
        require(req(entry,'omit')=='all'and req(entry,'boundary_gauss')==4 and req(entry,'cyclic_order')is False,'no tree/q5/cyclic norm substitution')
        reference=req(entry,'independent_check_report');path=Path(req(reference,'path'))
        require(path.is_absolute()and isinstance(req(reference,'sha256'),str)and len(reference['sha256'])==64,'absolute independent norm report path/SHA')
        by_h[h]=entry
    require(set(by_h)==set(FREE),'all four norm levels required')
    return by_h

def qualified_backend(args):
    require(sha(Path(__file__).with_name('series_context_v7.py'))==BASE_CONTEXT_SHA,'unaltered Gamma-v2 series Context/runtime8 policy')
    for name in ['weak_backend_tools','weak_backend_protocol','weak_backend_source','weak_backend_exe','weak_build_receipt','weak_selftest_report']:
        require(getattr(args,name).is_absolute(),'absolute qualified backend argument '+name)
    require(args.weak_backend_protocol_sha256==BACKEND_PROTOCOL_SHA and args.weak_backend_exe_sha256==EXE_SHA and
      args.weak_build_receipt_sha256==BUILD_SHA and args.weak_selftest_report_sha256==SELFTEST_SHA,'exact actual qualified backend receipts/exe')
    path=args.weak_backend_tools/'backend_bridge_common.py'
    require(sha(path)==BACKEND_CONTEXT_SHA,'qualified backend Context v2, never a generic external-path fallback')
    spec=importlib.util.spec_from_file_location('qualified_backend_context_for_allgraph_metadata',path)
    module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module;spec.loader.exec_module(module)
    require(Path(module.__file__).resolve()==path.resolve(),'exact qualified backend Context import')
    a=SimpleNamespace(prep=args.prep,source_root=args.source_root,source_binding=args.source_binding,
      runtime_manifest=args.runtime_manifest,reader_dir=args.reader_dir,out_dir=args.out_dir,
      source_binding_sha256=args.source_binding_sha256,runtime_manifest_sha256=args.runtime_manifest_sha256,
      protocol=args.weak_backend_protocol,protocol_sha256=args.weak_backend_protocol_sha256,
      backend_source=args.weak_backend_source,backend_exe=args.weak_backend_exe,backend_exe_sha256=args.weak_backend_exe_sha256,
      build_receipt=args.weak_build_receipt,build_receipt_sha256=args.weak_build_receipt_sha256,
      selftest_report=args.weak_selftest_report,selftest_report_sha256=args.weak_selftest_report_sha256)
    backend=module.Context(a)
    require(backend.protocol['cpp_source_sha256']==CPP_SHA,'same actual qualified sourcef72')
    backend.id.bind(path,BACKEND_CONTEXT_SHA)
    backend.id.bind(Path(__file__))
    backend.id.bind(Path(__file__).with_name('series_context_v7.py'),BASE_CONTEXT_SHA)
    return module,backend

def validate_check(report,h,run,packet,post):
    n=FREE[h]
    status='QUALIFIED_FIXED_CAPACITY_BACKEND_ON_ACTUAL621_AND_SMALL_CONTROLS_ONLY'if h==1 else'OBSERVED_FULL_FINITE_PHYSICAL_DUAL_FIXED_CAPACITY_ORIGINAL_G'
    require(req(report,'status')==status and req(report,'source_binding_sha256')==SOURCE and req(report,'runtime_manifest_sha256')==RUNTIME,'actual independently qualified same90f norm report')
    require(req(report,'backend_source_sha256')==CPP_SHA and req(report,'backend_executable_sha256')==EXE_SHA and
      req(report,'n')==n and Path(req(report,'actual_run')).is_absolute()and Path(report['actual_run']).resolve()==run,
      'same actual all-graph run/free DOF/source/exe; no tree borrowing')
    require(Path(req(report,'physical_packet')).is_absolute()and Path(report['physical_packet']).resolve()==packet,'same declared physical norm packet')
    for field in ['matrix_shift_symmetrization_or_pinv','full_continuous_dual_or_true_solution_error_bound','R3_2_4_or_full_revision_accepted','scientific_revision_ready']:
        require(req(report,field)is False,'original norm nonacceptance/unmodified-G flag '+field)
    for field in ['no_dense_global_Q_or_Z','minimum_D_is_not_min_eigenvalue','raw_strong_FAIL_preserved','original_jumps_and_point_ledger_bound_to_packet']:
        require(req(report,field)is True,'preserve complete scope/raw evidence '+field)
    relation=req(report,'all_original_factor_relation');fill=req(relation,'all_actual_factor_entries_visited')
    require(type(fill)is int and fill>0 and 2*fill+n<=12000000 and req(relation,'minimum_positive_D_pivot_not_eigenvalue')>0 and
      0<=req(relation,'U_minus_D_LT_relative')<1e-10 and req(relation,'unit_diagonal_L_is_implicit')is True and req(relation,'full_factor_loaded')is False,
      'all actual factors/positiveD/original relation and fill budget')
    predicted=20*req(report,'original_G_nnz')+28*fill+2048*n+(32<<20)
    require(0<report['original_G_nnz']<=2000000 and predicted==req(report,'helper_major_buffer_preflight_bytes')<=CAP and
      0<req(report,'reader_major_buffer_preflight_bytes')<=CAP,'unchanged helper/reader512MiB and input2M budgets')
    epsilon=sys.float_info.epsilon;back_budget=min(1e-10,max(1e-14,128*n*epsilon));repeat=max(1e-12,64*n*epsilon)
    errors=req(report,'independent_original_G_backward_errors');gaps=req(report,'same_factor_ordered_solution_gaps')
    require(isinstance(errors,list)and len(errors)==6 and all(math.isfinite(v)and 0<=v<=back_budget for v in errors),'original independent all-factor/ORIGINAL-G backward gates')
    require(isinstance(gaps,list)and len(gaps)==2 and all(math.isfinite(v)and 0<=v<=repeat for v in gaps),'same-factor independent ordered-solve gates')
    for key in ['full_finite_physical_dual_sqrt_Nmm','energy_normalized_full_finite_physical_dual','COO_direct_action_perturbation_dual_sqrt_Nmm']:
        require(math.isfinite(req(report,key))and report[key]>=0,'finite observed norm, no new accuracy threshold '+key)
    raw={'original_raw_force_absolute_L2':'effective_force_sum_L2_N_per_sqrt_mm','original_raw_force_relative_L2':'effective_force_sum_relative_L2',
      'original_raw_common_axis_moment_absolute_L2':'common_axis_moment_sum_L2_N_sqrt_mm','original_raw_common_axis_moment_relative_L2':'common_axis_moment_sum_relative_L2'}
    for key,postkey in raw.items():require(req(report,key)==post['cluster'][postkey],'original raw strong unchanged '+key)
    hashes={req(item,'sha256')for item in req(report,'input_manifest')}
    require({CHECKER_SHA,STREAM_SHA}<=hashes,'actual full independent readback source, not raw helper result')
    if h==1:
        proof=req(report,'actual621_crosscheck')
        require(req(proof,'old_inconclusive_limit')==1e-4 and 0<=req(proof,'coefficient_relative_difference')<=req(proof,'coefficient_perturbation_budget')<1e-4 and
          0<=req(proof,'dual_relative_difference')<=req(proof,'dual_energy_perturbation_budget')<1e-4,'actual621 qualification and unchanged perturbation/inconclusive contract')

def manifest_reference(items,path):
    path=Path(path).resolve();matches=[item for item in items if Path(req(item,'path')).resolve()==path]
    require(len(matches)==1,'exact independently bound norm producer report path')
    return dict(path=str(path),sha256=req(matches[0],'sha256'))

def same_reference(left,right):
    a=Path(req(left,'path'));b=Path(req(right,'path'))
    return a.is_absolute()and b.is_absolute()and a.resolve()==b.resolve()and req(left,'sha256')==req(right,'sha256')

def validate_producer(producer,h,value,post):
    space=req(producer,'complete_finite_physical_space')
    require(req(producer,'source_binding_sha256')==SOURCE and req(producer,'runtime_manifest_sha256')==RUNTIME and
      req(space,'global_dofs')==DOFS[h]and req(space,'free_dofs')==FREE[h]and req(space,'complete_kernel_qualified')is True and
      req(space,'dense_Z_pinv_shift_used')is False and req(space,'no_membrane_normal_derivative_constraint')is True and req(space,'actual_ell_mm')==1.,'complete SAME declared physical space/global/free/ell')
    require(Path(req(producer,'actual_run')).resolve()==value['run']and Path(req(producer,'actual_packet')).resolve()==value['packet'],'producer actual case/packet linkage')
    require(req(producer,'normalization_material_quadratic_work_Nmm')==post['bulk']['material_quadratic_work_N_mm']>0,'original stable material quadratic normalization, never change denominator')
    require(req(producer,'physical_residual_equation')=='r=Z^T(Kbulk_independent*actualU-actual_externalF), stable direct full-span GL4 operator application','same original physical residual definition')
    budget=req(producer,'major_buffer_preflight')
    require(req(budget,'major_buffer_budget_bytes')==CAP and 0<req(budget,'major_buffer_preflight_bytes')<=CAP and
      req(budget,'max_local_stencil_entries')==4096 and req(budget,'actual_largest_physical_stencil_entries')<=4096 and
      req(budget,'dense_global_K_or_Z_allocated')is False,'original capacityv2 producer budgets, no new experiment')
    require(req(producer,'raw_strong_FAIL_preserved')is True and req(producer,'fixed_eight_max_not_substituted')is True and
      req(producer,'R3_2_4_or_all_h_graph_reference_accepted')is False,'producer keeps raw/fixed8/full finite-space distinctions')
    if h==1:
        solve=req(producer,'unshifted_full_G_solver')
        require(req(solve,'full_unshifted_G_numeric_SPD')is True and req(solve,'matrix_solved_unmodified')is True and
          req(solve,'symmetric_part_used_for_diagnosis_only')is True and req(solve,'min_eigenvalue')>req(solve,'roundoff_margin'),'original unmodified dense621 solve only uses sympart for diagnosis')

def merge_manifests(*collections):
    result={}
    for collection in collections:
        for item in collection:
            path=Path(req(item,'path'));require(path.is_absolute(),'absolute merged input')
            key=str(path.resolve());h=req(item,'sha256')
            if key in result:
                require(result[key]['sha256']==h,'same input path conflicting SHA, do not discard provenance')
                if 'bytes'in result[key]and 'bytes'in item:require(result[key]['bytes']==item['bytes'],'same input path conflicting byte count')
                result[key].update(item)
            else:result[key]=dict(item,path=key)
    return [result[k]for k in sorted(result)]

def attach_all_graph_duals(context,index,cache,rows):
    links=validate_links(req(index,'all_graph_complete_physical_weak_dual_reports'))
    module,backend=qualified_backend(context.args);observations=[];coarse_reference=links[1]['independent_check_report']
    for row in rows:
        row['all_graph_complete_physical_weak_dual']=None
        row['complete_physical_weak_dual_scope']='not observed for this tree; no all-graph norm borrowed'if row['omit']!='all'else'all-graph q4 only'
    for h in range(1,5):
        value=cache['all',h];post=value['post'];reference=links[h]['independent_check_report']
        checked=read(backend.id.bind(reference['path'],reference['sha256']))
        physical_packet=Path(req(checked,'physical_packet'));require(physical_packet.is_absolute(),'absolute physical norm packet')
        validate_check(checked,h,value['run'],physical_packet.resolve(),post)
        backend.inherited(req(checked,'input_manifest')) # qualified private whitelist, not series.bind
        producer_ref=manifest_reference(checked['input_manifest'],physical_packet/'results.json')
        producer,packet_files=module.packet(backend,physical_packet,producer_ref['sha256'],'coarse'if h==1 else'fine')
        validate_producer(producer,h,value,post)
        expected_post=manifest_reference(producer['input_manifest'],producer['actual_post_report'])
        require(same_reference(expected_post,value['record']['postprocess_reference']),'norm packet must bind exact current indexed postprocess')
        if h>1:
            require(same_reference(manifest_reference(checked['input_manifest'],coarse_reference['path']),coarse_reference),'every fine result binds the same actual621 source/exe crosscheck')
        primary_eta=producer['full_finite_physical_dual_sqrt_Nmm']if h==1 else checked['full_finite_physical_dual_sqrt_Nmm']
        primary_relative=producer['energy_normalized_full_finite_physical_dual']if h==1 else checked['energy_normalized_full_finite_physical_dual']
        require(math.isfinite(primary_eta)and primary_eta>=0 and math.isfinite(primary_relative)and primary_relative>=0,'existing primary norm scalar only')
        observation=dict(omit='all',refinement=h,case=value['run'].name,global_DOF=DOFS[h],physical_free_DOF=FREE[h],
          eta_sqrt_Nmm=primary_eta,energy_normalized_eta=primary_relative,
          primary_value_source='original dense621 observation with actual backend crosscheck'if h==1 else'independent fixed-capacity original-G readback',
          backend_eta_sqrt_Nmm=checked['full_finite_physical_dual_sqrt_Nmm'],backend_energy_normalized_eta=checked['energy_normalized_full_finite_physical_dual'],
          arithmetic_delta_dual_sqrt_Nmm=checked['COO_direct_action_perturbation_dual_sqrt_Nmm'],
          original_material_quadratic_normalization_Nmm=producer['normalization_material_quadratic_work_Nmm'],
          independent_check_reference=reference,physical_packet_reference=producer_ref,
          complete_physical_space=producer['complete_finite_physical_space'],original_G_factor_and_backward_qualification=checked,
          primary_coarse_dense_solver=producer['unshifted_full_G_solver']if h==1 else None,
          raw_force_absolute_L2=checked['original_raw_force_absolute_L2'],raw_force_relative_L2=checked['original_raw_force_relative_L2'],
          raw_common_axis_moment_absolute_L2=checked['original_raw_common_axis_moment_absolute_L2'],raw_common_axis_moment_relative_L2=checked['original_raw_common_axis_moment_relative_L2'],
          full_continuous_error_bound_or_tree_norm_inferred=False,raw_physical_flux_accepted=False)
        value['record']['all_graph_complete_physical_weak_dual']=observation
        observations.append(observation)
    require(len(observations)==4 and all(r['all_graph_complete_physical_weak_dual']is None for r in rows if r['omit']!='all'),'exactly four all-graph observations; all twelve tree slots unfilled')
    return dict(scope='all-graph q4 h1..4 ONLY, never propagated to alternative trees',observations=observations,
      qualified_backend_context_sha256=BACKEND_CONTEXT_SHA,backend_protocol_sha256=BACKEND_PROTOCOL_SHA,
      backend_source_sha256=CPP_SHA,backend_executable_sha256=EXE_SHA,actual_build_receipt_sha256=BUILD_SHA,actual_small_control_sha256=SELFTEST_SHA,
      no_G_factor_or_norm_recomputed=True,no_new_thresholds_or_normalizations=True,private_backend_inputs_verified_by_existing_Context=True,
      additional_input_manifest=backend.finish())
