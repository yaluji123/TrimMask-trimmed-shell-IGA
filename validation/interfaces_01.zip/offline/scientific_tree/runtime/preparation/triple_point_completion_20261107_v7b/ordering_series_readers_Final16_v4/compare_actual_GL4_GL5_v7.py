"""Current actual q4/q5 coarse control; original thresholds, completed boundary B."""
from pathlib import Path
import argparse,csv,json,math,os
for key in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS']:os.environ[key]='1'
import numpy as np
from series_context_v7 import Context,common_arguments,require,read,sha,clean,SOURCE,RUNTIME

def relative(a, b):
    denominator = max(float(np.linalg.norm(a)), float(np.linalg.norm(b)))
    return float(np.linalg.norm(np.asarray(a) - np.asarray(b))) / denominator if denominator else 0.

def coo(path, n, fields, cap):
    matrix = np.zeros((n, n))
    seen = set()
    with path.open(encoding='utf-8-sig', newline='') as stream:
        reader = csv.DictReader(stream)
        require(reader.fieldnames == fields, 'actual COO schema')
        for row in reader:
            i, j, value = int(row[fields[0]]), int(row[fields[1]]), float(row[fields[2]])
            require(0 <= i < n and 0 <= j < n and (i, j) not in seen and math.isfinite(value) and value != 0,
                    'COO duplicate/index/nonfinite/zero')
            seen.add((i, j))
            require(len(seen) <= cap, 'original COO cap')
            matrix[i, j] = value
    return matrix

def perturbation(a, b, tau, protocol):
    singular = np.linalg.svd(a['K'], compute_uv=False)
    require(np.isfinite(singular).all() and singular[-1] > 0, 'original K singular-value bound unavailable')
    ra = a['K'] @ a['X'] - a['F']
    rb = b['K'] @ b['X'] - b['F']
    bound = (float(np.linalg.norm(b['F'] - a['F'])) +
             float(np.linalg.norm(b['K'] - a['K'])) * float(np.linalg.norm(b['X'])) +
             float(np.linalg.norm(ra)) + float(np.linalg.norm(rb))) / (singular[-1] * float(np.linalg.norm(a['X'])))
    tolerance = max(tau, 8 * bound)
    return dict(original_linear_perturbation_bound=float(bound), original_X_comparison_tolerance=float(tolerance),
                inconclusive=tolerance >= protocol['X_bound_inconclusive_if_tolerance_greater_equal'],
                mapped_coefficient_relative_difference=float(np.linalg.norm(b['X'] - a['X']) / np.linalg.norm(a['X'])))

def load(context,entry,q):
    value=context.load_case(entry,q,require_flux=False);n=len(value['coefficients']);require(n==729,'coarse729 only before dense controls')
    require(40*n*n*8+8*n*8<=512*1024**2,'original bounded major-buffer preflight')
    packet=value['packet'];run=value['run'];permutation=np.concatenate([a.dofmap for a in value['arms']]);require(len(set(permutation.tolist()))==729,'actual coarse physical key coverage')
    scope=read(context.bind(packet/'patch_order_operator_scope.json'))
    require(scope['rows']==729 and scope['matrix_is_actual_solver_argument']is True and scope['no_symmetrization_shift_or_regularization_by_exporter']is True and scope['exported']is True and scope['stage']=='immediately_before_IGA_SolveSparseWithRigidBasis','unmodified actual solver matrix')
    kp=context.bind(packet/'patch_order_global_K.csv');fp=context.bind(packet/'patch_order_global_F.csv')
    context.bind(run/'input_audit/patch_order_global_K.csv',sha(kp));context.bind(run/'input_audit/patch_order_global_F.csv',sha(fp))
    K=coo(kp,n,['global_row_zero_based','global_col_zero_based','value_N_per_mm'],200000);F=context.reader.vector_csv(fp,n)
    B=np.zeros_like(K);measures={}
    for arm in value['arms']:
        bp=context.bind(packet/f'boundary_delta_H_{arm.handle}.csv')
        block=coo(bp,len(arm.coeff),['local_row_zero_based','local_col_zero_based','value_N_per_mm'],2000000)
        B[np.ix_(arm.dofmap,arm.dofmap)]+=block
        for stage in ['raw_bulk_before_support','bulk_after_support']:
            measure=read(context.bind(packet/f'bulk_measure_{stage}_{arm.handle}.json'))
            require(measure['valid']is True and measure['actual_bulk_rectangular_gauss_order']==4,'actual original bulk GL4')
            keys=['matrix_stored_nnz','Qx_N_mm','Qy_N_mm','Qbiaxial_N_mm','areaX_mm2','areaY_mm2','areaBiaxial_mm2','rigid1_N_mm','rigid2_N_mm']
            measures[hex(arm.handle)+'/'+stage]=[measure[key]for key in keys]
    # B is completed physical boundary: original BC plus actual essential point groups.
    B+=(value['points']['essential_joint_a']+value['points']['essential_PATCH0_far_corner']).toarray()
    value.update(K=K[np.ix_(permutation,permutation)],B=B[np.ix_(permutation,permutation)],F=F[permutation],X=value['coefficients'][permutation],
      external=value['external'][permutation],measures=measures,
      geometry=[(a.handle,a.cp.tolist(),a.ku.tolist(),a.kv.tolist(),a.weights.tolist(),a.E,a.nu,a.thickness)for a in value['arms']])
    return value

def compare(left,right,tau):
    require(left['geometry']==right['geometry'],'different actual geometry/material/physical basis')
    external_difference=relative(left['external'],right['external']);beta_difference=relative(left['cluster']['selected_beta'],right['cluster']['selected_beta'])
    lambda_difference=relative([a['lambda_practical_union_metric']for a in left['cluster']['arms']],[a['lambda_practical_union_metric']for a in right['cluster']['arms']])
    measurements_equal=left['measures']==right['measures']
    physical_norm=float(np.linalg.norm(right['K']-right['B']));require(physical_norm>0 and math.isfinite(physical_norm),'original physical operator normalization')
    values=dict(actual_pure_external_F_relative_difference=external_difference,selected_beta_relative_difference=beta_difference,owner_lambda_relative_difference=lambda_difference,
      raw_and_supported_bulk_three_probe_records_exactly_equal=measurements_equal,
      boundary_B_relative_difference=float(np.linalg.norm(left['B']-right['B'])/np.linalg.norm(right['B'])),
      coefficient_X_relative_difference=float(np.linalg.norm(left['X']-right['X'])/np.linalg.norm(right['X'])),
      full_K_difference_over_bulk_plus_joint_norm=float(np.linalg.norm(left['K']-right['K']))/physical_norm)
    gates=dict(same_pure_external_F=external_difference<=tau,same_calibration_beta=beta_difference<=1e-10,same_calibration_lambda=lambda_difference<=1e-10,
      same_recorded_raw_supported_bulk=measurements_equal,boundary_B_GL4_GL5=values['boundary_B_relative_difference']<1e-10,
      K_GL4_GL5=values['full_K_difference_over_bulk_plus_joint_norm']<1e-10,X_GL4_GL5=values['coefficient_X_relative_difference']<1e-8)
    return {k:bool(v)for k,v in gates.items()},values

def main():
    ap=argparse.ArgumentParser(description=__doc__);common_arguments(ap)
    ap.add_argument('--left-entry',type=Path,required=True);ap.add_argument('--right-entry',type=Path,required=True);ap.add_argument('--output',type=Path,required=True)
    args=ap.parse_args();context=Context(args);require(not args.output.exists(),'fresh control report')
    protocol=read(context.bind(context.prep/'runtime/actual_patch_order_v1/postprocess_v1/comparison_protocol.json','71abe866b266ac7b1d6448a915799480547df8ff8c6b96db8e48b02947e85e0f'))
    require(protocol['calibration_relative_tolerance']==1e-10 and protocol['X_bound_inconclusive_if_tolerance_greater_equal']==1e-4,'original thresholds unchanged')
    left_entry=read(context.bind(args.left_entry));right_entry=read(context.bind(args.right_entry))
    require(left_entry['omit']==right_entry['omit']and left_entry['omit']in['all','1ec8']and left_entry['refine_factor']==right_entry['refine_factor']==1,'original two-graph coarse GL4/5 scope')
    left=load(context,left_entry,4);right=load(context,right_entry,5)
    context.identity.fresh_output(args.output,[left['run'],right['run'],left['packet'],right['packet']])
    context.bind(context.prep/'mechanics/candidate/trace_scale_alpha_sensitivity_v1/boundary_quadrature_v1/PREDECLARED_PROTOCOL.md','343aa1de4371483be0a015ac0581de7c05ceaa2e0f29d625a935663dd169be5d')
    component=read(context.bind(context.prep/'mechanics/candidate/trace_scale_alpha_sensitivity_v1/boundary_quadrature_v1/quadrature_summary.json','97da85a1c3d9828997eba0244a05be66364289a49b9a181dc227cd1dda6ae506'))
    require(component['GL4_GL5_agreement_passed']is True,'original independent ABC/pencil qualification')
    tau=max(1e-12,64*729*np.finfo(float).eps);gates,values=compare(left,right,tau)
    result=dict(status='PASS_BOUNDED_CURRENT90F_THREEPATCH_BC4_VS5_ONLY'if all(gates.values())else'FAIL_OR_INCONCLUSIVE_THREEPATCH_CONTROL_OBSERVATIONS_PRESERVED',
      kind='bc4-vs5',omit=left_entry['omit'],left_case=left['run'].name,right_case=right['run'].name,source_binding_sha256=SOURCE,runtime_manifest_sha256=RUNTIME,
      gates=gates,values=values,original_order_repeatability_tolerance=tau,boundary_B_role='original_BC+essential_a+essential_far',K_minus_B_role='bulk+line+natural_b',
      left_weak_balance=left['post']['numerical_total_balance'],right_weak_balance=right['post']['numerical_total_balance'],
      left_raw_force_relative_L2=left['post']['cluster']['effective_force_sum_relative_L2'],right_raw_force_relative_L2=right['post']['cluster']['effective_force_sum_relative_L2'],
      raw_strong_flux_not_accepted_or_relabelled=True,no_new_accuracy_thresholds=True,general_method_or_continuum_accuracy_accepted=False,
      individual_new_Native_ABC_lambdaBC_exports_claimed=False,Host_or_external_solver_started=False)
    context.bind(Path(__file__));result['input_manifest']=context.finish()
    with args.output.open('x',encoding='utf-8')as f:json.dump(clean(result),f,indent=2,allow_nan=False)
    print(json.dumps(dict(status=result['status'],path=str(args.output))));return 0 if all(gates.values())else 2

if __name__=='__main__':raise SystemExit(main())

