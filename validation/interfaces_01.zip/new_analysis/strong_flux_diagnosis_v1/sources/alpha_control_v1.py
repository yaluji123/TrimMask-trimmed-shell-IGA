"""One predeclared alphaB control on the qualified unchanged 729-DOF operators."""
from pathlib import Path
import ctypes
from ctypes import wintypes
import csv
import hashlib
import importlib.util
import json
import sys
import traceback
sys.dont_write_bytecode = True
from resource_guard import install, actual_budget

D = Path(__file__).resolve().parents[1]
ROOT = D.parents[1]
PREP = ROOT/"runtime/preparation/triple_point_completion_20261107_v7b"
RUN = ROOT/"runtime/runs/final90f_cluster_gl4_all_h1_v1"
alpha = float(sys.argv[1])
assert alpha in (105., 210., 420.)
OUT = D/f"alpha{int(alpha)}_v1"
OUT.mkdir(exist_ok=False)
resources = install()
resources["preflight"] = actual_budget(729, 59921)
(OUT/"resource_preflight.json").write_text(json.dumps(resources, indent=2)+"\n")
import numpy as np
from scipy import sparse
from scipy.sparse.linalg import splu

inputs = {}


def bind(path):
    inputs[str(path)] = hashlib.sha256(path.read_bytes()).hexdigest()
    return path


def read(path):
    return json.loads(bind(path).read_text(encoding="utf-8-sig"))


def norm(x):
    return float(np.linalg.norm(x.data if sparse.issparse(x) else x))


def clean(x):
    if isinstance(x, dict):
        return {k: clean(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [clean(v) for v in x]
    if isinstance(x, np.ndarray):
        return x.tolist()
    if isinstance(x, np.generic):
        return x.item()
    return x


def peak_memory():
    class Counters(ctypes.Structure):
        _fields_ = [("cb", wintypes.DWORD), ("faults", wintypes.DWORD)] + [
            (name, ctypes.c_size_t) for name in ("peak_working_set", "working_set",
            "quota_peak_paged", "quota_paged", "quota_peak_nonpaged", "quota_nonpaged",
            "pagefile", "peak_pagefile", "private_usage")]
    kernel = ctypes.WinDLL("kernel32", use_last_error=True)
    kernel.GetCurrentProcess.restype = wintypes.HANDLE
    api = ctypes.WinDLL("psapi", use_last_error=True)
    api.GetProcessMemoryInfo.argtypes = [wintypes.HANDLE, ctypes.c_void_p, wintypes.DWORD]
    counters = Counters(); counters.cb = ctypes.sizeof(counters)
    if not api.GetProcessMemoryInfo(kernel.GetCurrentProcess(), ctypes.byref(counters), counters.cb):
        return {"observed": False, "error": ctypes.get_last_error()}
    return {"observed": True, "peak_working_set_bytes": counters.peak_working_set,
            "current_private_bytes": counters.private_usage,
            "peak_process_commit_bytes": counters.peak_pagefile}


result = {"status": "CONTROL_NOT_COMPLETED", "alphaB": alpha,
          "resources": resources, "baseline_case_unchanged": True,
          "scientific_strong_acceptance_claimed": False}
try:
    protocol = read(D/"CONTROL_PROTOCOL.json")
    baseline_freeze = read(D/"BASELINE_210_GATE_FREEZE.json")
    for entry in baseline_freeze["files"]:
        assert hashlib.sha256((D/entry["path"]).read_bytes()).hexdigest() == entry["sha256"]
    base = D/"baseline_210_v1"
    gate = read(base/"results.json")
    assert gate["status"] == "QUALIFIED_RECONSTRUCTED_BASELINE_WITHIN_ORIGINAL_GATES"
    assert gate["control_protocol_sha256"] == hashlib.sha256((D/"CONTROL_PROTOCOL.json").read_bytes()).hexdigest()
    scalar = np.load(bind(base/"state_and_scalar.npz"))
    F = scalar["actual_F"]; original_U = scalar["actual_U"]
    lam = float(scalar["lambda_BC"])
    matrices = {name: sparse.load_npz(bind(base/(name+".npz"))) for name in
                ("reconstructed_K", "Kbulk", "Kline", "Knatural_b", "Kessential_a",
                 "Kessential_far", "KBC_consistency", "KBC_P")}
    K = matrices["reconstructed_K"]+(alpha-210.)*lam*matrices["KBC_P"]
    BC = matrices["KBC_consistency"]+alpha*lam*matrices["KBC_P"]
    assert K.shape == (729, 729) and np.isfinite(K.data).all()
    factor = splu(K.tocsc())
    U = factor.solve(F)
    backward = norm(K@U-F)/(norm(K)*norm(U)+norm(F))
    assert np.isfinite(U).all() and backward <= protocol["baseline_gates"]["normwise_backward_error"]
    source = bind(PREP/"independent_readers_v7/cluster_physical_core.py")
    assert inputs[str(source)] == gate["input_sha256"][str(source)]
    spec = importlib.util.spec_from_file_location("control_physical_core", source)
    core = importlib.util.module_from_spec(spec); sys.modules[spec.name] = core
    spec.loader.exec_module(core)
    cluster = read(RUN/"triple_cluster.json")
    arms = []; positions = np.zeros((243, 3))
    for entry in sorted(cluster["arms"], key=lambda x: int(x["handle"], 16)):
        owner = int(entry["handle"], 16)
        geo = read(RUN/f"input_audit/load_stage_geometry_{owner}.json")
        mapping = np.array(entry["global_dofmap"], dtype=int)
        arm = core.Arm(owner, np.array(geo["knots_u"]), np.array(geo["knots_v"]),
                       3, 3, np.array(geo["control_global_Vg"]), np.array(geo["weights"]),
                       geo["E"], geo["nu"], geo["constant_t"], mapping, U[mapping])
        arms.append(arm)
        positions[mapping[::3]//3] = arm.cp
    selected = sorted((int(r["handle"], 16), tuple(core.OWNERS.index(int(x, 16)) for x in r["owners"]))
                      for r in cluster["relations"] if r["selected_penalty"])
    betas = {pair: float(beta) for (_, pair), beta in zip(selected, cluster["selected_beta"])}
    physical_cluster = core.integrate_cluster(arms, betas, 1., gauss=8)
    physical_cluster.pop("numerical_canonical_cluster_action_global")
    bulk = core.integrate_bulk_action(arms)
    bulk_action = bulk.pop("global_action")
    state_energy = bulk["material_quadratic_work_N_mm"]
    assert state_energy > 0
    actions = {name: matrices[name]@U for name in
               ("Kline", "Knatural_b", "Kessential_a", "Kessential_far", "KBC_consistency")}
    actions["KBC_penalty"] = alpha*lam*(matrices["KBC_P"]@U)
    actions["KBC"] = BC@U
    action_closure = bulk_action+actions["Kline"]+actions["Knatural_b"]+actions["Kessential_a"]+actions["Kessential_far"]+actions["KBC"]-F
    packet = PREP/"all_h1_complete_physical_weak_dual_v2"
    Z = sparse.load_npz(bind(packet/"Z.npz")); G = sparse.load_npz(bind(packet/"independent_G.npz"))
    r = Z.T@(bulk_action-F)
    riesz = splu(G.tocsc()).solve(r)
    quadratic = float(r@riesz)
    assert quadratic >= 0 and np.isfinite(quadratic)
    weak = np.sqrt(quadratic/state_energy)
    scale = np.sqrt(G.diagonal()*state_energy)
    ledger = {name: Z.T@action for name, action in actions.items()}
    complete_closure = Z.T@action_closure
    np.savez_compressed(OUT/"complete_physical_work_ledger.npz", physical_r=r,
                        normalization=scale, closure=complete_closure, **ledger)
    boundary = np.load(bind(base/"boundary_reconstruction.npz"))
    traces = np.einsum("qij,j->qi", boundary["N"], U[arms[0].dofmap])
    fluxes = np.einsum("qij,j->qi", boundary["V"], U[arms[0].dofmap])
    w = boundary["weight_ds"]
    length = float(sum(w))
    boundary_work = float(np.sum(w*np.sum(traces*fluxes, axis=1)))
    boundary_metrics = {"length_mm": length,
        "displacement_RMS_mm": float(np.sqrt(np.sum(w*np.sum(traces[:, :3]**2, axis=1))/length)),
        "rotation_RMS_rad": float(np.sqrt(np.sum(w*np.sum(traces[:, 3:]**2, axis=1))/length)),
        "GP_max_displacement_mm": float(np.max(np.linalg.norm(traces[:, :3], axis=1))),
        "GP_max_rotation_rad": float(np.max(np.linalg.norm(traces[:, 3:], axis=1))),
        "physical_full_line_work_Nmm": boundary_work,
        "symmetric_consistency_quadratic_work_Nmm": float(U@actions["KBC_consistency"]),
        "penalty_quadratic_work_Nmm": float(U@actions["KBC_penalty"]),
        "BC_total_quadratic_work_Nmm": float(U@actions["KBC"])}
    assert abs(boundary_metrics["symmetric_consistency_quadratic_work_Nmm"]+2*boundary_work) <= 1e-10*max(1., abs(boundary_work))
    np.savez_compressed(OUT/"actual_boundary_point_readback.npz", uv=boundary["uv"],
                        weight_ds_mm=w, scaled_trace=traces, physical_dual=fluxes)
    cuts = core.unique_cuts(arms)
    intervals = {"whole": (0., 100.), "first1": (0., 1.), "first2p5": (0., 2.5),
                 "first5": (0., 5.), "first10": (0., 10.), "inner10to90": (10., 90.),
                 "last10": (90., 100.), "first_span": (0., 100.*cuts[1])}
    nodes, weights = np.polynomial.legendre.leggauss(8)
    spatial = {}
    for name, (start, end) in intervals.items():
        f2 = fd = m2 = md = mint = 0.; fint = np.zeros(3)
        for left, right in zip(cuts[:-1], cuts[1:]):
            a, b = max(start, 100.*left), min(end, 100.*right)
            if b <= a:
                continue
            for x, weight in zip(nodes, weights):
                xx = (a+b)*.5+(b-a)*x*.5; ds = (b-a)*weight*.5
                ops = [arm.operators(xx/100., 0., ell=1.) for arm in arms]
                gs = [op["effective_force"]@arm.coeff for op, arm in zip(ops, arms)]
                ms = [float(arm.t@(op["m"]@arm.coeff)) for op, arm in zip(ops, arms)]
                force = sum(gs); moment = sum(ms)
                f2 += ds*(force@force); fd += ds*sum(g@g for g in gs)
                m2 += ds*moment**2; md += ds*sum(m*m for m in ms)
                fint += ds*force; mint += ds*moment
        spatial[name] = {"range_mm": [start, end], "force_abs_L2_N_per_sqrt_mm": np.sqrt(f2),
                         "moment_abs_L2_N_sqrt_mm": np.sqrt(m2),
                         "force_relative_L2": np.sqrt(f2/fd), "moment_relative_L2": np.sqrt(m2/md),
                         "signed_force_integral_N": fint, "signed_moment_integral_Nmm": mint}
    assert abs(spatial["whole"]["force_relative_L2"]-physical_cluster["effective_force_sum_relative_L2"]) < 1e-10
    assert abs(spatial["whole"]["moment_relative_L2"]-physical_cluster["common_axis_moment_sum_relative_L2"]) < 1e-10
    with (OUT/"strong_trace_GL8.csv").open("w", newline="", encoding="utf-8") as stream:
        writer = csv.writer(stream)
        writer.writerow(["span", "x_mm", "weight_ds_mm", "sum_gx_N_per_mm", "sum_gy_N_per_mm", "sum_gz_N_per_mm", "sum_mt_N"])
        for span, (a, b) in enumerate(zip(cuts[:-1], cuts[1:])):
            for x, weight in zip(nodes, weights):
                u = (a+b)*.5+(b-a)*x*.5
                op = [arm.operators(u, 0., ell=1.) for arm in arms]
                g = sum(o["effective_force"]@arm.coeff for o, arm in zip(op, arms))
                m = sum(float(arm.t@(o["m"]@arm.coeff)) for o, arm in zip(op, arms))
                writer.writerow([span, 100.*u, 100.*(b-a)*weight*.5, *g, m])
    endpoint = []
    for u in (0., 1.):
        endpoint.append({"u": u, "x_mm": 100.*u,
            "owners": [{"handle": hex(arm.handle),
                        "U_mm": op["U"]@arm.coeff, "theta_rad": op["theta"]@arm.coeff,
                        "g_N_per_mm": op["effective_force"]@arm.coeff,
                        "m_N": op["m"]@arm.coeff,
                        "H_N": np.cross(op["m"]@arm.coeff, arm.t)}
                       for arm, op in [(a, a.operators(u, 0., ell=1.)) for a in arms]]})
    reference_path = PREP/"final16_Gamma_and_allgraph_duals_v2/final16_graph_h_and_finite_reference.json"
    reference = read(reference_path)
    final_reference = reference["seven_level_STRI3_reference"]["rows"][-1]
    ref_vector = np.asarray(reference["actual_FEM_peak_U_vector_mm"])
    peak = arms[2].operators(1., 1.)["U"]@arms[2].coeff
    material_energy = .5*state_energy
    fixed_response = {"material_energy_Nmm": material_energy,
        "finite_STRI3_material_energy_Nmm": final_reference["ALLSE_Nmm"],
        "material_energy_signed_relative_difference": material_energy/final_reference["ALLSE_Nmm"]-1.,
        "fixed_PATCH2_point_mm": [100., -42., 42.], "U_vector_mm": peak,
        "finite_STRI3_U_vector_mm": ref_vector,
        "fixed_vector_relative_difference": norm(peak-ref_vector)/norm(ref_vector),
        "fixed_vector_magnitude_mm": norm(peak), "not_global_peak_or_stress_certificate": True}
    support = -(actions["KBC"]+actions["Kessential_a"]+actions["Kessential_far"])
    rf, rm = core.resultants(support, positions, np.zeros(3))
    ef, em = core.resultants(F, positions, np.zeros(3))
    reactions = {"support_force_N": rf, "support_moment_Nmm": rm,
                 "force_relative_closure": norm(rf+ef)/(norm(rf)+norm(ef)),
                 "moment_relative_closure": norm(rm+em)/(norm(rm)+norm(em)),
                 "actual_point_reaction_from_matrix_products": True}
    result.update(status="COMPLETED_FIXED_ALPHA_CONTROL_NOT_STRONG_ACCEPTANCE",
        normwise_backward_error=backward,
        coefficient_relative_change_from_original_U=norm(U-original_U)/norm(original_U),
        matrix_delta_is_only_BC_penalty=True, lambda_BC_unchanged=lam,
        boundary=boundary_metrics, strong=physical_cluster, spatial=spatial,
        complete_physical_weak_relative=float(weak), complete_finite_test_count=G.shape[0],
        maximum_normalized_complete_work_ledger_closure=float(np.max(abs(complete_closure)/scale)),
        material_full_work_Nmm=state_energy, external_work_Nmm=float(U@F),
        action_quadratic_work_Nmm={name: float(U@action) for name, action in actions.items()},
        independent_bulk_COO_vs_direct_action_L2_N=norm(matrices["Kbulk"]@U-bulk_action),
        independent_full_action_residual_L2_N=norm(action_closure),
        fixed_reference_response=fixed_response, reactions=reactions, endpoint_traces=endpoint,
        sparse_factor_nnz=int(factor.L.nnz+factor.U.nnz),
        sparse_factor_success_is_not_SPD_or_scientific_acceptance=True,
        observations_only_no_parameter_selected_for_publication=True)
    sparse.save_npz(OUT/"controlled_K.npz", K)
    np.savez_compressed(OUT/"controlled_state.npz", actual_unchanged_F=F, U=U)
except Exception as error:
    result["failure"] = str(error)
    result["traceback"] = traceback.format_exc()
finally:
    result["observed_memory"] = peak_memory()
    result["input_sha256"] = inputs
    result["source_sha256"] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    for path, digest in inputs.items():
        assert hashlib.sha256(Path(path).read_bytes()).hexdigest() == digest
    (OUT/"results.json").write_text(json.dumps(clean(result), indent=2, allow_nan=False)+"\n", encoding="utf-8")
    brief = {key: result[key] for key in ("status", "alphaB", "failure", "boundary",
             "complete_physical_weak_relative", "fixed_reference_response", "observed_memory") if key in result}
    if "strong" in result:
        brief["raw_force_relative_L2"] = result["strong"]["effective_force_sum_relative_L2"]
        brief["raw_moment_relative_L2"] = result["strong"]["common_axis_moment_sum_relative_L2"]
    print(json.dumps(clean(brief), indent=2))
if result["status"] != "COMPLETED_FIXED_ALPHA_CONTROL_NOT_STRONG_ACCEPTANCE":
    raise SystemExit(2)
