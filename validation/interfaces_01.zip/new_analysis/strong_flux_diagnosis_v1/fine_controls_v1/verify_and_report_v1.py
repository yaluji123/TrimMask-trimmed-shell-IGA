from datetime import datetime, timezone
import csv
from boot_v1 import start
resources = start()
import numpy as np
from scipy import sparse
from common_v1 import *

coarse = read(HERE/"coarse_rowaudit_v1/results.json")
fine = read(HERE/"fine_rowaudit_v1/results.json")
assert coarse["status"] == fine["status"] == "INDEPENDENT_COMPLETE_PHYSICAL_ROW_MATRIX_MATCHED"
assert coarse["Kactual_not_used_to_derive_any_reconstructed_component"]
assert fine["Kactual_not_used_to_derive_any_reconstructed_component"]
Ka = sparse.load_npz(bind(HERE/"actual_packet_v1/actual_K.npz"))
P = sparse.load_npz(bind(HERE/"fine_rowaudit_v1/PBC.npz")); lam = fine["lambda_BC"]
physical = read(HERE/"physical_fields_v1/results.json")
duals = read(HERE/"Riesz_v1/results.json")
assert physical["status"] == "ALL_FIXED_CONTROLS_PHYSICAL_FIELDS_COMPLETED_RIESZ_SEPARATE"
assert duals["status"] == "ALL_FIXED_CONTROLS_FULL_FINITE_PHYSICAL_DUALS_COMPLETED"
weak = {r["alphaB"]: r for r in duals["rows"]}
rows = []; metadata = []; Fhashes = set(); peak = 0
for record in physical["states"]:
    alpha = int(record["alphaB"]); folder = HERE/f"alpha{alpha}_mmd_v2"
    state_meta = read(folder/"results.json"); metadata.append(state_meta)
    assert state_meta["status"] == "QUALIFIED_UNSHIFTED_ACTUAL_SPARSE_STATE"
    K = sparse.load_npz(bind(folder/"controlled_K.npz")); data = np.load(bind(folder/"state.npz"))
    U, F = data["U"], data["F"]
    difference = K-Ka-(alpha-210.)*lam*P
    assert norm(difference) <= 1e-10*(norm(K)+norm(Ka)+abs(alpha-210.)*lam*norm(P))
    backward = norm(K@U-F)/(norm(K)*norm(U)+norm(F))
    assert backward <= state_meta["original_backward_tolerance"]
    Fhashes.add(state_meta["F_array_sha256"])
    peak = max(peak, state_meta["observed_memory"]["peak_pagefile"])
    q8, q10 = record["cluster_quadratures"]
    assert abs(q8["effective_force_sum_relative_L2"]-q10["effective_force_sum_relative_L2"]) < 1e-10
    assert abs(q8["common_axis_moment_sum_relative_L2"]-q10["common_axis_moment_sum_relative_L2"]) < 1e-10
    s = record["spatial"]
    rows.append({"alphaB": alpha, "boundary_U_RMS_mm": record["boundary_U_RMS_mm"],
        "boundary_theta_RMS_rad": record["boundary_theta_RMS_rad"],
        "raw_force_relative_L2": q8["effective_force_sum_relative_L2"],
        "raw_force_absolute_N_per_sqrt_mm": q8["effective_force_sum_L2_N_per_sqrt_mm"],
        "raw_axial_moment_relative_L2": q8["common_axis_moment_sum_relative_L2"],
        "raw_axial_moment_absolute_N_sqrt_mm": q8["common_axis_moment_sum_L2_N_sqrt_mm"],
        "first10_force_squared_fraction": (s["first10"]["force_abs_L2_N_per_sqrt_mm"]/s["whole"]["force_abs_L2_N_per_sqrt_mm"])**2,
        "first10_moment_squared_fraction": (s["first10"]["moment_abs_L2_N_sqrt_mm"]/s["whole"]["moment_abs_L2_N_sqrt_mm"])**2,
        "inner10to90_force_abs_N_per_sqrt_mm": s["inner10to90"]["force_abs_L2_N_per_sqrt_mm"],
        "inner10to90_moment_abs_N_sqrt_mm": s["inner10to90"]["moment_abs_L2_N_sqrt_mm"],
        "material_energy_Nmm": record["material_energy_Nmm"],
        "material_energy_signed_relative_to_finite_STRI3": record["material_energy_signed_relative_to_finite_STRI3"],
        "fixed_PATCH2_vector_relative_difference": record["fixed_vector_relative_difference"],
        "full_finite_physical_dual_relative": weak[alpha]["bulk_energy_normalized_full_finite_dual"],
        "maximum_complete_weak_ledger_closure_normalized": record["max_normalized_complete_weak_ledger_closure"],
        "numerical_flux_sum_scaled_max_algebraic_only": record["numeric_flux_sum_scaled_max_algebraic_only"],
        "state_backward": backward, "actual_factor_storage_nnz": state_meta["actual_factor_profile"]["actual_L_plus_U_nnz"],
        "state_peak_commit_bytes": state_meta["observed_memory"]["peak_pagefile"]})
assert len(rows) == 3 and len(Fhashes) == 1 and peak < 536870912
baseline = next(r for r in rows if r["alphaB"] == 210)
for row in rows:
    row["energy_change_relative_to_alpha210"] = row["material_energy_Nmm"]/baseline["material_energy_Nmm"]-1.
with (HERE/"FINE_CONTROL_SUMMARY.csv").open("w", newline="", encoding="utf-8") as stream:
    writer = csv.DictWriter(stream, fieldnames=list(rows[0])); writer.writeheader(); writer.writerows(rows)
native = read(HERE/"alpha210_mmd_v2/results.json")
report = {"status": "FINE_OFFLINE_BASELINE_AND_ALL_FIXED_CONTROLS_COMPLETED_RAW_STRONG_NOT_FIXED",
    "completed_utc": datetime.now(timezone.utc).isoformat(),
    "coarse_complete_independent_row_gap": coarse["full_actual_K_relative_Frobenius"],
    "fine_complete_independent_row_gap": fine["full_actual_K_relative_Frobenius"],
    "fine_independent_BC_gap": fine["BC_relative_Frobenius"], "fine_lambda_BC_without_fit": lam,
    "independent_all_nine_consistency_blocks_and_points": True,
    "actual_K_not_subtracted_to_construct_interface": True,
    "same_actual_K_native_sparse_U_comparison": native["spectral_and_native_reproduction"],
    "controls": rows, "same_unchanged_F_hash": next(iter(Fhashes)),
    "original_COLAMD_memory_failure_preserved": "alpha210_v1/results.json",
    "successful_sparse_ordering_amendment": "ORDERING_AMENDMENT_v2.json",
    "observed_maximum_successful_state_commit_bytes": peak,
    "observed_Riesz_commit_bytes": duals["observed_memory"]["peak_pagefile"],
    "hard512MiB_CPU1_enforced_each_worker": True,
    "resource_forecast_limit": "418149376/421349376 are forecasts, actual successful state commit approached the 536870912 hard cap. The failed COLAMD attempt remains separate; no cap was increased.",
    "numerical_flux_formula": "With physical p=-Vd, z=Nd, Powner=I-11^T/3, pnum=Powner*p-Lbeta*z. Kline*d=sum_i[-Ni^T*pnum_i+Vi^T*(Powner*z)_i]. All quantities use the actual six-row work-conjugate lift and ell=1mm.",
    "numerical_flux_scope": "sum pnum=0 follows algebraically from 1^T Powner=0 and 1^T Lbeta=0, for any state. It is a numerical work flux including penalty, not the raw physical g=T+t cross partial_s(m), t dot m, and it excludes separately accounted point terms. No mean-subtracted raw acceptance is used.",
    "mechanical_interpretation": [
        "The independently assembled complete 729 and6561 matrices match actual captured K within original1e-10 gates, including all9 line blocks, selected penalty, independent point incidences, material bulk and reconstructed BC. Together with the independent continuous-load MMS this supports the tested finite implementation and virtual-work identities.",
        "The fine weak-BC bracket tightens clamp traces but changes raw strong moment only within0.09624-0.10726 and leaves raw force0.74218-0.76456. Weak-clamp sensitivity exists, but this fixed bracket does not fix or uniquely explain the ordinary strong defect.",
        "The fixed controls retain the full line, original GP sets, endpoint/essential point work and all6237 physical tests. First10mm still contains about99.1% force and96.0% axial-moment squared norms. No endpoint region or unselected pair is removed.",
        "Independent finite-reference energy/vector responses and full finite weak defects change little. These cannot be promoted to pointwise strong balance or a proved continuum singularity.",
        "No alpha is chosen for publication, no C++/model/load/scientific tolerance changed, no Native/compile started by this stage. AcQMod14084 is untouched and no all-process natural-exit claim is made."
    ],
    "source_and_input_sha256": PINS, "old_diagnostic_reports_not_rewritten": True,
    "new_scientific_acceptance_or_general_PDE_certificate": False}
save(HERE/"FINE_CONTROL_REPORT.json", report)
lines = ["# Fine 完整物理矩阵与固定惩罚控制", "", f"完成时间 UTC {report['completed_utc']}", "",
    "已完成真实6561 DOF K/F的独立稀疏重解、原210基线和完整物理行重建，以及固定105/210/420控制。矩阵/状态门槛通过；普通解原强通量FAIL没有被修复或改标签。", "",
    "## 独立性与基线门槛", "",
    f"729和fine完整物理矩阵相对Frobenius差分别为{report['coarse_complete_independent_row_gap']:.8g}和{report['fine_complete_independent_row_gap']:.8g}，原门槛1e-10。fine BC单独差{report['fine_independent_BC_gap']:.8g}，无拟合得到λB={lam:.12g}。", "",
    "每个原GL4 span用独立物理N/V稀疏逐GP累加全部9个一致性块和记录β的选图penalty，再加独立material Kbulk及独立符号point矩阵。三个point矩阵分别与实际COO核对。BC直接复用实际96个carrier-integration点/权重，A/C/P稀疏累加，活动216阶pencil用稀疏广义特征计算。没有密集2187/6561矩阵，也没有以Kactual减BC来定义接口。接口GL4点由原确定规则和实际knots重现，未伪称捕获了不存在的完整N/V行。", "",
    f"实际K的独立稀疏U相对Native为{native['spectral_and_native_reproduction']['coefficient_relative_difference']:.8g}。Backward={native['normwise_backward']:.8g}；按原公式得到系数比较界{native['spectral_and_native_reproduction']['original_rule_coefficient_bound']:.8g}，低于原inconclusive界1e-4。σmin数值由稀疏逆算子的最大奇异值获得，先在729上对已存精确数值复核；没有fine密集SVD，也不声称区间谱证书。", "",
    "## 全部预定控制", "", "| αB | 夹持U RMS mm | 夹持θ RMS rad | raw合力相对L2 | raw轴矩相对L2 | raw轴矩绝对 N√mm | 完整有限弱缺陷 |",
    "|---:|---:|---:|---:|---:|---:|---:|"]
for row in rows:
    lines.append(f"| {row['alphaB']} | {row['boundary_U_RMS_mm']:.7g} | {row['boundary_theta_RMS_rad']:.7g} | {row['raw_force_relative_L2']:.7g} | {row['raw_axial_moment_relative_L2']:.7g} | {row['raw_axial_moment_absolute_N_sqrt_mm']:.7g} | {100*row['full_finite_physical_dual_relative']:.7g}% |")
lines += ["", "控制只用实际K210+(α−210)λP，所有F、其余接口/point/bulk/BC一致项保持不变。单独的物理完整矩阵审计先通过，独立性不来自这条控制公式。", "",
    "| αB | 能量对有限STRI3差 | 固定PATCH2向量差 | 对210能量变化 | 完整功账本最大归一化闭合 |",
    "|---:|---:|---:|---:|---:|"]
for row in rows:
    lines.append(f"| {row['alphaB']} | {100*row['material_energy_signed_relative_to_finite_STRI3']:+.7g}% | {100*row['fixed_PATCH2_vector_relative_difference']:.7g}% | {100*row['energy_change_relative_to_alpha210']:+.7g}% | {row['maximum_complete_weak_ledger_closure_normalized']:.7g} |")
lines += ["", "## 原物理迹与数值通量", "", report["numerical_flux_formula"], "", report["numerical_flux_scope"], "",
    "数值通量零和约1e-14仅作代数读数；实际完整矩阵和全部6237测试功账本、独立MMS才是本次一致性依据。原raw g/m、整条界面、固定端区、首span、内段和完整line/point/BC功均保留。前10mm约占99.1%合力和96.0%轴矩平方范数，不能删掉后求通过。", "",
    "## 资源与失败", "",
    f"每进程CPU1与512MiB Job硬限额实际启用。COLAMD首次因分配拒绝失败，保留alpha210_v1；改MMD排序和内部nnz计数未改K/F、阈值或内存限额。成功state内部factor storage2644664<原3M上限，最大commit={peak}字节，已接近536870912硬上限；Riesz另进程storage={duals['actual_factor_nnz']}<原4M，commit={duals['observed_memory']['peak_pagefile']}字节。没有同时保留state与G的factor。预估418/421MB不足以单独证明峰值，真实硬限额/实测和失败记录一并保留。", "",
    "## 可成立的结论", ""]
lines += ["- "+item for item in report["mechanical_interpretation"]]
lines += ["", "完整数据见FINE_CONTROL_SUMMARY.csv、physical_fields_v1、Riesz_v1；源与输入哈希见最终清单。此前报告和ordinary rawFAIL不覆盖。", ""]
(HERE/"FINE_CONTROL_REPORT.md").write_text("\n".join(lines), encoding="utf-8", newline="\n")
verify_inputs()
print(__import__('json').dumps({"status": report["status"], "rows": rows, "max_state_commit": peak}, indent=2))
