"""Independent flat-KL fiber/tensor audit, preserving raw Native surface labels."""
import csv
import hashlib
import importlib.util
import json
from pathlib import Path
import numpy as np
from scipy.interpolate import BSpline

HERE=Path(__file__).resolve().parent;PREP=HERE.parents[2]
CASE=PREP/'runtime/runs/native_panel1x_actual_linear_state_v1'
STATE=CASE/'derived_work/panel_state'
REFERENCE=PREP/'mechanics/candidate/endpoint_vertex988_source_v1/checker/check_actual_endpoint_capture.py'


def sha(p):
    h=hashlib.sha256()
    with p.open('rb')as f:
        for b in iter(lambda:f.read(1<<20),b''):h.update(b)
    return h.hexdigest()


def load(p):return json.loads(p.read_text(encoding='utf-8-sig'))


def rows(p):
    with p.open(newline='',encoding='utf-8-sig')as f:yield from csv.DictReader(f)


def mises(s):
    dev=s-np.trace(s)*np.eye(3)/3.
    return float(np.sqrt(1.5*np.sum(dev*dev)))


def tensor(v):
    x,y,z,xy,xz,yz=v
    return np.array([[x,xy,xz],[xy,y,yz],[xz,yz,z]])


def independent_components(g,L,U,u,v,physics):
    m,n=g['controls_u'],g['controls_v'];X=np.asarray(g['control_global_Vg']).reshape(-1,3)
    bu=[BSpline(g['knots_u'],np.eye(m),g['degree_u'])(u,nu=d)for d in range(2)]
    bv=[BSpline(g['knots_v'],np.eye(n),g['degree_v'])(v,nu=d)for d in range(2)]
    d=np.column_stack((np.outer(bu[1],bv[0]).ravel(),np.outer(bu[0],bv[1]).ravel()))
    grad=d@np.linalg.inv((X@L[:2].T).T@d)
    _,_,_,H,_=physics.kinematics(g,u,v,L)
    local=U@L.T;G=local.T@grad;W=np.einsum('iab,i->ab',H,local[:,2])
    membrane=np.array([G[0,0],G[1,1],G[0,1]+G[1,0]])
    curvature=np.array([W[0,0],W[1,1],2*W[0,1]])
    return membrane,curvature


def stress(membrane,curvature,z,E,nu,sign):
    D=E/(1-nu*nu)*np.array([[1.,nu,0.],[nu,1.,0.],[0.,0.,(1-nu)/2]])
    return D@(membrane+sign*z*curvature)


def main():
    out=OUTPUT;assert not out.exists()
    assert sha(REFERENCE)=='c4892fb0b822bbee5ab43f97dde4010e5664ecb7bc347dccaa07599e823f33ff'
    assert sha(CASE/'applied_source_binding.json')=='c10c9fdfb0e11d84522e88fa2f10b422f69d5b0dfc910766318dfd92450f71db'
    algebra=load(ALGEBRA)
    assert algebra['status']=='PASS_ACTUAL_PANEL_STATE_SPARSE_DECOMPOSITION_MATERIAL_ENERGY_AND_WORK_ONLY' and algebra['reader_sha256']=='fcc3cfab8c8990d41694ea45f8b51f27e861ceec7931364aca79eb2052607767'
    assert algebra['Core_PID']==load(CASE/'process_result.json')['pid']
    spec=importlib.util.spec_from_file_location('frozen_independent_inverse_cartesian_kinematics',REFERENCE)
    physics=importlib.util.module_from_spec(spec);spec.loader.exec_module(physics)
    geometry={int(p.stem.rsplit('_',1)[1]):load(p)for p in(CASE/'capture').glob('trim_geometry_*.json')};assert len(geometry)==36
    properties={int(r['shell_handle']):r for r in load(CASE/'capture/engineering_input_only_manifest.json')['surfaces']}
    meta=PREP/'runtime/runs/native_panel1x_endpoint1493_passive_v1/capture/endpoint_metadata.jsonl'
    frames={}
    for line in meta.read_text().splitlines():
        r=json.loads(line)
        if 'L3_rows'not in r:continue
        L=np.asarray(r['L3_rows']);owner=r['owner'];assert np.linalg.norm(L@L.T-np.eye(3))<1e-10
        if owner in frames:assert np.linalg.norm(frames[owner]-L)<1e-10
        frames[owner]=L
    assert frames.keys()==geometry.keys()
    fields={owner:np.empty((g['controls_u']*g['controls_v'],3))for owner,g in geometry.items()}
    counts={owner:0 for owner in geometry}
    for r in rows(STATE/'control_point_solution.csv'):
        owner=int(r['owner']);fields[owner][int(r['local_cp'])]=[float(r[k])for k in('ux','uy','uz')];counts[owner]+=1
    assert all(counts[o]==len(fields[o])for o in geometry)
    raw=STATE/'actual_stress_quadrature.csv';qcounts={};record_count=0
    max_tensor_error=max_mises_error=max_local_mises_error=0.;bad_tensor=bad_global_mises=0
    for r in rows(raw):
        owner=int(r['patch_handle'],16);q=int(r['quadrature_index']);record_count+=1
        qcounts.setdefault(owner,set()).add(q)
        local=np.array([[float(r['local_s11']),float(r['local_s12']),0.],[float(r['local_s12']),float(r['local_s22']),0.],[0.,0.,0.]])
        expected=frames[owner].T@local@frames[owner]
        actual=tensor([float(r[k])for k in('s11','s22','s33','s12','s13','s23')])
        error=float(np.linalg.norm(actual-expected)/max(1.,np.linalg.norm(expected)))
        vm_error=abs(mises(actual)-float(r['mises']))/max(1.,abs(float(r['mises'])))
        local_vm_error=abs(mises(local)-float(r['mises']))/max(1.,abs(float(r['mises'])))
        assert local_vm_error<=1e-9, ('local tensor Mises',owner,q,local_vm_error)
        max_local_mises_error=max(max_local_mises_error,local_vm_error)
        bad_tensor+=int(error>1e-9);bad_global_mises+=int(vm_error>1e-9)
        max_tensor_error=max(max_tensor_error,error);max_mises_error=max(max_mises_error,vm_error)
    assert record_count==EXPECTED_RECORDS and set(qcounts)==set(geometry)
    selected={(o,q)for o,ids in qcounts.items()for q in [sorted(ids)[i]for i in(0,(len(ids)-1)//2,len(ids)-1)]}
    checks=[]
    for r in rows(raw):
        owner=int(r['patch_handle'],16);q=int(r['quadrature_index'])
        if(owner,q)not in selected:continue
        prop=properties[owner];L=frames[owner]
        eps,kappa=independent_components(geometry[owner],L,fields[owner],float(r['u']),float(r['v']),physics)
        fiber=-.5 if r['surface']=='SNEG'else .5
        native=stress(eps,kappa,prop['constant_t']*fiber,prop['E'],prop['nu'],-1.)
        actual=np.array([float(r[k])for k in('local_s11','local_s22','local_s12')])
        error=float(np.linalg.norm(actual-native)/max(1.,np.linalg.norm(native)))
        assert error<=1e-9, ('independent raw local stress',owner,q,r['surface'],error)
        physical=stress(eps,kappa,prop['constant_t']*fiber,prop['E'],prop['nu'],-1.)
        assert np.array_equal(native,physical)
        checks.append(dict(owner=owner,quadrature_index=q,raw_surface_label=r['surface'],raw_normalizedFiber=fiber,
                           physical_z_over_t_along_actual_L3_normal=fiber,
                           physical_face_along_L3_normal=r['surface'],
                           raw_local_stress_norm_error=error))
    assert len(checks)==216
    # Kirchhoff kinematics u(x,y,z)=u0(x,y)-z*grad(w)+w*n gives epsilon=epsilon0-z*H(w).
    pure=np.array([2.,0.,0.]);zero=np.zeros(3)
    top=stress(zero,pure,.5,1.,0.,-1.)
    native_top=stress(zero,pure,.5,1.,0.,+1.)
    assert top[0]==-1. and native_top[0]==1. and np.array_equal(top,-native_top)
    for owner in geometry:
        g=geometry[owner];X=np.asarray(g['control_global_Vg']).reshape(-1,3)
        rigid=np.cross(np.array([.1,.2,.3]),X)+np.array([1.,2.,3.])
        u=.5*(g['knots_u'][3]+g['knots_u'][g['controls_u']]);v=.5*(g['knots_v'][3]+g['knots_v'][g['controls_v']])
        eps,kappa=independent_components(g,frames[owner],rigid,u,v,physics)
        assert max(np.linalg.norm(eps),np.linalg.norm(kappa))<1e-10
    assert bad_tensor==0 and bad_global_mises==0, 'every actual corrected global tensor must pass the original1e-9 gates'
    result=dict(status='QUALIFIED_ACTUAL_PHYSICAL_KL_FIBER_GLOBAL_TENSORS_AND_SELECTED_LOCAL_STRESS_ONLY',mesh_level=LEVEL,expected_original_model_sha256=EXPECTED_INPUT,Core_PID=algebra['Core_PID'],
                all_raw_records_checked=record_count,raw_global_tensor_failed_records=bad_tensor,raw_global_Mises_failed_records=bad_global_mises,local_Mises_max_error=max_local_mises_error,raw_global_tensor_accepted=True,independent_local_stress_probes=216,
                probe_rule='first, middle and last quadrature index of every owner, both raw faces, fixed before reading stress magnitudes',
                max_global_tensor_error=max_tensor_error,max_global_Mises_error=max_mises_error,
                max_independent_local_stress_error=max(r['raw_local_stress_norm_error']for r in checks),
                physical_KL_fiber_kinematics='epsilon(z)=epsilon0-z*Hessian(w), z along actual L3 row2 normal',
                actual_raw_Native_formula='epsilon(normalizedFiber)=epsilon0-t*normalizedFiber*Hessian(w)',
                physical_z_over_t_equals_raw_normalizedFiber=True,
                raw_labels_preserved=True,physical_SNEG_SPOS_mapping_must_also_account_for_FEM_normal_orientation=True,
                pure_bending_wrong_fiber_sign_control_rejected=True,all36_rigid_rotation_controls_passed=True,
                stress_accuracy_or_stress_convergence_or_peak_acceptance_claimed=False,
                checks=checks,frames={str(k):v.tolist()for k,v in frames.items()},
                source_raw_sha256=sha(raw),source_control_U_sha256=sha(STATE/'control_point_solution.csv'),
                independent_kinematics_sha256=sha(REFERENCE),script_sha256=sha(Path(__file__)),
                primary_manual_links=['https://docs.software.vt.edu/abaqusv2025/English/SIMACAEELMRefMap/simaelm-c-shelloverview.htm','https://docs.software.vt.edu/abaqusv2025/English/SIMACAETHERefMap/simathe-c-transshearshells.htm'])
    out.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:v for k,v in result.items()if k not in('checks','frames')}))


if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('case',type=Path);p.add_argument('--level',required=True,choices=['1x','2x','4x']);p.add_argument('--algebra',type=Path,required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args();LEVEL=a.level;CASE=a.case;STATE=CASE/'derived_work/panel_state';ALGEBRA=a.algebra;OUTPUT=a.out;FAILURE=OUTPUT.with_name('FAILED_'+OUTPUT.name)
    EXPECTED_INPUT={'1x':'d77d03506e0a18e27f65a6d63aee6271f7440c87074cb551dd17c859dc23ad80','2x':'09d9365998dfb033c505e4ab20c37a36c151ddea6305153ac2e0cfbcf42e2e2d','4x':'f87d695f623053dd09f355c559621fd62f079dfeae43c09589d442929016bee3'}[LEVEL]
    assert load(CASE/'original_input_before_after.json')['before']['sha256']==EXPECTED_INPUT
    done=load(STATE/'state_complete.json');EXPECTED_RECORDS=done['stress_actual_GP_records'];assert EXPECTED_RECORDS==2*done['stress_cached_GP'] and done['stress_skipped_records']==0
    try:main()
    except Exception as exc:
        assert not FAILURE.exists();FAILURE.write_text(json.dumps(dict(status='FAILED_NOT_QUALIFIED',error=repr(exc),script_sha256=sha(Path(__file__))),indent=2)+'\n',encoding='utf-8');raise
