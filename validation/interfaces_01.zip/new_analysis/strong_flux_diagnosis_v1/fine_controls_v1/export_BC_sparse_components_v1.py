"""Retain the already-audited sparse primitive A/C/P; no factor or state solve."""
from boot_v1 import start
resources = start()
import json
import numpy as np
from scipy import sparse
from common_v1 import *

OUT = HERE/"BC_sparse_components_v1"; OUT.mkdir(exist_ok=False)
rows = []
for level in (1, 4):
    run, cluster, arms, _, _, _ = load(level)
    nd = len(arms[0].dofmap)
    A = sparse.csr_matrix((nd, nd)); C = A.copy(); P = A.copy()
    purpose = None; count = 0
    for line in bind(run/"boundary_domain_probe.jsonl").read_text(encoding="utf-8-sig").splitlines():
        event = json.loads(line)
        if event["event"] == "probe_purpose": purpose = event["purpose"]
        elif event["event"] == "point_probe" and purpose == "carrier_integration":
            op = arms[0].operators(*event["uv"], mu=-arms[0].t, ell=1.)
            N = sparse.csr_matrix(np.vstack([op["U"], op["theta"]]))
            V = sparse.csr_matrix(np.vstack([op["T"], op["m"]]))
            w = event["physical_line_weight"]
            A += w*(V.T@V); C += w*(V.T@N); P += w*(N.T@N); count += 1
    audit_dir = HERE/("coarse_rowaudit_v1" if level == 1 else "fine_rowaudit_v1")
    audit = read(audit_dir/"results.json")
    BC = -C-C.T+210*audit["lambda_BC"]*P
    actualBC = matrix(run/"input_audit/boundary_delta_H_7867.csv", nd, 200000)
    gap = norm(BC-actualBC)/norm(actualBC)
    assert count == 24*level and gap <= 1e-10
    globalP = scatter(P, arms[0].dofmap, cluster["actual_global_dofs"])
    savedP = sparse.load_npz(bind(audit_dir/("PBC.npz")))
    assert norm(globalP-savedP) == 0.
    for name, value in (("A", A), ("C", C), ("P", P)):
        sparse.save_npz(OUT/f"h{level}_{name}_local.npz", value)
    rows.append({"level": level, "BC_points": count, "local_dimension": nd,
                 "lambda_from_separate_sparse_pencil": audit["lambda_BC"],
                 "actual_BC_relative_gap": gap, "global_P_identical_to_control_operand": True})
verify_inputs()
save(OUT/"results.json", {"status": "AUDITED_SPARSE_PRIMITIVES_RETAINED_NO_STATE_SOLVE",
     "rows": rows, "resources": resources, "input_sha256": PINS, "observed_memory": memory()})
print(json.dumps(rows, indent=2))
