"""Independent cell-polynomial flat KL Green kernel. No matrix, solve or API.
All source-level functions are inert until an explicitly selected worker calls them.
"""
import math
import numpy as np
FIT_NODES=np.array([-.75,-.25,.25,.75])
VAND=np.array([[x**i for i in range(4)]for x in FIT_NODES])
KEYS=[(0,0),(1,0),(0,1),(2,0),(1,1),(0,2),(3,0),(2,1),(1,2),(0,3),(4,0),(3,1),(2,2),(1,3),(0,4)]

def cox_values(knots,p,x):
 u=np.asarray(knots,float);n=len(u)-p-1;assert u[p]<=x<=u[n]
 value=np.zeros(len(u)-1);i=n-1 if x==u[n]else int(np.searchsorted(u,x,side='right')-1);value[i]=1.
 for d in range(1,p+1):
  z=np.zeros(len(u)-d-1)
  for k in range(len(z)):
   left=u[k+d]-u[k];right=u[k+d+1]-u[k+1]
   if left:z[k]+=(x-u[k])/left*value[k]
   if right:z[k]+=(u[k+d+1]-x)/right*value[k+1]
  value=z
 return value

def interpolate_cell(value,s0,s1,r0,r1):
 hs=(s1-s0)/2;hr=(r1-r0)/2;data=np.array([[value((s0+s1)/2+hs*x,(r0+r1)/2+hr*y)for y in FIT_NODES]for x in FIT_NODES]);assert data.shape==(4,4,3)
 tmp=np.linalg.solve(VAND,data.reshape(4,-1)).reshape(4,4,3)
 return np.linalg.solve(VAND,tmp.transpose(1,0,2).reshape(4,-1)).reshape(4,4,3).transpose(1,0,2)

def dmat(x,k,h):
 out=np.zeros((len(x),4))
 for i in range(k,4):out[:,i]=math.factorial(i)/math.factorial(i-k)*np.asarray(x)**(i-k)/h**k
 return out

def derivatives(C,x,y,hs,hr):
 ds={k:dmat(x,k,hs)for k in range(5)};dr={k:dmat(y,k,hr)for k in range(5)}
 return {(i,j):np.einsum('xa,abk,yb->xyk',ds[i],C,dr[j],optimize=False)for i,j in KEYS}

def quadrature(order,sub):
 x,w=np.polynomial.legendre.leggauss(order);nodes=[];weights=[]
 for j in range(sub):
  lo=-1.+2.*j/sub;hi=-1.+2.*(j+1)/sub;nodes.extend(((lo+hi)/2+(hi-lo)*x/2).tolist());weights.extend(((hi-lo)*w/2).tolist())
 return np.array(nodes),np.array(weights)

def state_fields(d,frame):
 t,e,n=frame['t'],frame['e'],frame['n'];A=frame['E']*frame['thickness']/(1-frame['nu']**2);D=frame['D'];nu=frame['nu']
 project=lambda key,v:d[key]@v
 ex=project((1,0),t);ey=project((0,1),e);ga=project((0,1),t)+project((1,0),e)
 ss=project((2,0),n);rr=project((0,2),n);sr=project((1,1),n)
 w30=project((3,0),n);w21=project((2,1),n);w12=project((1,2),n);w03=project((0,3),n)
 Nss=A*(ex+nu*ey);Nrr=A*(ey+nu*ex);Nsr=A*(1-nu)*ga/2
 Mss=-D*(ss+nu*rr);Mrr=-D*(rr+nu*ss);Msr=-D*(1-nu)*sr
 divNs=A*(project((2,0),t)+(1-nu)/2*project((0,2),t)+(1+nu)/2*project((1,1),e))
 divNr=A*(project((0,2),e)+(1-nu)/2*project((2,0),e)+(1+nu)/2*project((1,1),t))
 divMs=-D*(w30+w12);divMr=-D*(w03+w21)
 bnormal=D*(project((4,0),n)+2*project((2,2),n)+project((0,4),n))
 body=-divNs[...,None]*t-divNr[...,None]*e+bnormal[...,None]*n
 return dict(Nss=Nss,Nrr=Nrr,Nsr=Nsr,Mss=Mss,Mrr=Mrr,Msr=Msr,divNs=divNs,divNr=divNr,divMs=divMs,divMr=divMr,bnormal=bnormal,body=body,w30=w30,w21=w21,w12=w12,w03=w03)

def test_fields(d,frame):
 t,e,n=frame['t'],frame['e'],frame['n']
 return dict(u=d[0,0],theta=(d[0,1]@n)[...,None]*t-(d[1,0]@n)[...,None]*e,ex=d[1,0]@t,ey=d[0,1]@e,ga=d[0,1]@t+d[1,0]@e,ss=d[2,0]@n,rr=d[0,2]@n,sr=d[1,1]@n)

def tractions(f,frame,mu):
 t,e,n=frame['t'],frame['e'],frame['n'];nu=frame['nu'];D=frame['D'];ms=float(mu@t);mr=float(mu@e);tau=np.cross(n,mu);ts=float(tau@t);tr=float(tau@e)
 Nmu=(ms*f['Nss']+mr*f['Nsr'])[...,None]*t+(ms*f['Nsr']+mr*f['Nrr'])[...,None]*e
 Mmu=(ms*f['Mss']+mr*f['Msr'])[...,None]*t+(ms*f['Msr']+mr*f['Mrr'])[...,None]*e
 Tb=(ms*f['divMs']+mr*f['divMr'])[...,None]*n;T=Nmu+Tb;m=np.cross(n,Mmu);H=np.cross(m,tau)
 Mss_s=-D*(f['w30']+nu*f['w12']);Mss_r=-D*(f['w21']+nu*f['w03']);Mrr_s=-D*(f['w12']+nu*f['w30']);Mrr_r=-D*(f['w03']+nu*f['w21']);Msr_s=-D*(1-nu)*f['w21'];Msr_r=-D*(1-nu)*f['w12']
 ss=ts*Mss_s+tr*Mss_r;rr=ts*Mrr_s+tr*Mrr_r;sr=ts*Msr_s+tr*Msr_r
 dMmu=(ms*ss+mr*sr)[...,None]*t+(ms*sr+mr*rr)[...,None]*e;dH=np.cross(np.cross(n,dMmu),tau)
 Q=-f['divMs'][...,None]*t-f['divMr'][...,None]*e
 return dict(T=T,m=m,H=H,g=T-dH,tau=tau,Q=Q,Nmu=Nmu,Tb=Tb)

EDGES=('s0','s1','r0','r1')
def edge_grid(edge,x):
 if edge=='s0':return np.array([-1.]),x
 if edge=='s1':return np.array([1.]),x
 if edge=='r0':return x,np.array([-1.])
 return x,np.array([1.])
def normal(edge,frame):return {'s0':-frame['t'],'s1':frame['t'],'r0':-frame['e'],'r1':frame['e']}[edge]
def oriented_corners(edge):return {'s0':((-1.,1.),(-1.,-1.)),'s1':((1.,-1.),(1.,1.)),'r0':((-1.,-1.),(1.,-1.)),'r1':((1.,1.),(-1.,1.))}[edge]

def volume(cell,frame,rule):
 x,w=quadrature(*rule);d=derivatives(cell['state'],x,x,cell['hs'],cell['hr']);v=test_fields(derivatives(cell['test'],x,x,cell['hs'],cell['hr']),frame);f=state_fields(d,frame);weights=w[:,None]*w[None,:]*cell['hs']*cell['hr']
 membrane=f['Nss']*v['ex']+f['Nrr']*v['ey']+f['Nsr']*v['ga'];bending=-(f['Mss']*v['ss']+f['Mrr']*v['rr']+2*f['Msr']*v['sr']);bm=(-f['divNs'][...,None]*frame['t']-f['divNr'][...,None]*frame['e']);bn=f['bnormal'][...,None]*frame['n'];bodym=np.sum(bm*v['u'],axis=-1);bodyb=np.sum(bn*v['u'],axis=-1)
 return {'material':float(np.sum(weights*(membrane+bending))),'body_membrane':float(np.sum(weights*bodym)),'body_bending':float(np.sum(weights*bodyb)),'operation':float(np.sum(weights*(abs(membrane)+abs(bending)+abs(bodym)+abs(bodyb)))),'max_divN':float(np.max(np.sqrt(f['divNs']**2+f['divNr']**2))),'max_bending_body':float(np.max(abs(f['bnormal'])))}

def edge_values(cell,frame,edge,rule):
 x,w=quadrature(*rule);xx,yy=edge_grid(edge,x);f=state_fields(derivatives(cell['state'],xx,yy,cell['hs'],cell['hr']),frame);v=test_fields(derivatives(cell['test'],xx,yy,cell['hs'],cell['hr']),frame);z=tractions(f,frame,normal(edge,frame));flatten=lambda q:np.asarray(q).reshape((-1,3))
 z={k:flatten(val)if k!='tau'else val for k,val in z.items()};v={k:flatten(val)if k in('u','theta')else np.asarray(val).ravel()for k,val in v.items()};ds=w*(cell['hr']if edge[0]=='s'else cell['hs']);full=np.sum(z['T']*v['u'],axis=1)+np.sum(z['m']*v['theta'],axis=1);reduced=np.sum(z['g']*v['u'],axis=1)+(z['m']@z['tau'])*(v['theta']@z['tau']);operation=float(np.sum(ds*(abs(np.sum(z['Nmu']*v['u'],axis=1))+abs(np.sum(z['Tb']*v['u'],axis=1))+abs(np.sum(z['m']*v['theta'],axis=1)))))
 ss=cell['s0']+cell['hs']*(xx+1);rr=cell['r0']+cell['hr']*(yy+1);sg,rg=np.meshgrid(ss,rr,indexing='ij')
 return dict(full=float(ds@full),reduced=float(ds@reduced),operation=operation,z=z,v=v,ds=ds,s_mm=sg.ravel(),r_mm=rg.ravel(),full_density=full,reduced_density=reduced)

def corner_values(cell,frame,edge):
 records=[]
 for sign,(x,y)in zip((-1,1),oriented_corners(edge)):
  f=state_fields(derivatives(cell['state'],np.array([x]),np.array([y]),cell['hs'],cell['hr']),frame);v=test_fields(derivatives(cell['test'],np.array([x]),np.array([y]),cell['hs'],cell['hr']),frame);z=tractions(f,frame,normal(edge,frame));H=z['H'].reshape(3);u=v['u'].reshape(3);s=cell['s0']+cell['hs']*(x+1);r=cell['r0']+cell['hr']*(y+1);records.append(dict(s_mm=float(s),r_mm=float(r),sign=sign,H_N=H.tolist(),virtual_u_mm=u.tolist(),H_work_Nmm=float(sign*H@u)))
 return records

def facet_jump(left,right,frame,edgeL,edgeR,rule):
 a=edge_values(left,frame,edgeL,rule);b=edge_values(right,frame,edgeR,rule);jumpT=a['z']['T']+b['z']['T'];jumpm=a['z']['m']+b['z']['m'];ds=a['ds'];u=a['v']['u'];theta=a['v']['theta'];work=float(ds@(np.sum(jumpT*u,axis=1)+np.sum(jumpm*theta,axis=1)));Qjump=a['z']['Q']-b['z']['Q'];continuity=max(float(np.max(np.linalg.norm(a['v']['u']-b['v']['u'],axis=1))),float(np.max(np.linalg.norm(a['v']['theta']-b['v']['theta'],axis=1))))
 return {'work':work,'moment_jump_L2':float(np.sqrt(ds@np.sum(jumpm*jumpm,axis=1))),'T_jump_L2':float(np.sqrt(ds@np.sum(jumpT*jumpT,axis=1))),'Q_jump_L2':float(np.sqrt(ds@np.sum(Qjump*Qjump,axis=1))),'virtual_continuity':continuity,'cell_edge_sum':a['full']+b['full'],'operation':a['operation']+b['operation']}

def evaluate_owner(cells,frame,nu,nv,rule,corner_sink=None,facet_sink=None,label=None,boundary_sink=None):
 totals=dict(material=0.,body_membrane=0.,body_bending=0.,internal_cell_edges=0.,internal_explicit=0.,Gamma=0.,other_outer=0.,all_reduced_edges=0.,corners=0.,operation=0.,edge_reduction_defect_max=0.,virtual_continuity_max=0.,Q_jump_L2_max=0.,moment_jump_L2_max=0.,max_divN=0.,max_bending_body=0.)
 for (i,j),cell in cells.items():
  vol=volume(cell,frame,rule)
  for k in('material','body_membrane','body_bending','operation'):totals[k]+=vol[k]
  for k in('max_divN','max_bending_body'):totals[k]=max(totals[k],vol[k])
  for edge in EDGES:
   q=edge_values(cell,frame,edge,rule);cs=corner_values(cell,frame,edge);cw=sum(r['H_work_Nmm']for r in cs)
   outer=(edge=='s0'and i==0)or(edge=='s1'and i==nu-1)or(edge=='r0'and j==0)or(edge=='r1'and j==nv-1);role='Gamma'if edge=='r0'and j==0 else'other_outer'if outer else'internal_cell_edges';totals[role]+=q['full'];totals['all_reduced_edges']+=q['reduced'];totals['corners']+=cw;totals['operation']+=q['operation'];totals['edge_reduction_defect_max']=max(totals['edge_reduction_defect_max'],abs(q['full']-q['reduced']-cw))
   if boundary_sink is not None and outer:
    for qi in range(len(q['ds'])):
     z=q['z'];v=q['v'];boundary_sink(dict(label or{},cell=[i,j],edge=edge,edge_role=role,s_mm=float(q['s_mm'][qi]),r_mm=float(q['r_mm'][qi]),ds_weight_mm=float(q['ds'][qi]),physical_T_N_per_mm=z['T'][qi].tolist(),physical_m_N=z['m'][qi].tolist(),m_dot_tau_N=float(z['m'][qi]@z['tau']),tau=z['tau'].tolist(),H_N=z['H'][qi].tolist(),physical_g_N_per_mm=z['g'][qi].tolist(),Q_native_N_per_mm=z['Q'][qi].tolist(),virtual_u_mm=v['u'][qi].tolist(),virtual_theta_rad=v['theta'][qi].tolist(),full_power_density_N=float(q['full_density'][qi]),reduced_power_density_N=float(q['reduced_density'][qi]),Native_Q_not_FEM_reference=True))
   if corner_sink is not None:
    for record in cs:corner_sink(dict(label or{},cell=[i,j],edge=edge,edge_role=role,**record))
 for i in range(1,nu):
  for j in range(nv):
   z=facet_jump(cells[i-1,j],cells[i,j],frame,'s1','s0',rule);totals['internal_explicit']+=z['work'];totals['virtual_continuity_max']=max(totals['virtual_continuity_max'],z['virtual_continuity']);totals['Q_jump_L2_max']=max(totals['Q_jump_L2_max'],z['Q_jump_L2']);totals['moment_jump_L2_max']=max(totals['moment_jump_L2_max'],z['moment_jump_L2'])
   if facet_sink is not None:facet_sink(dict(label or{},axis='s',facet=[i,j],**z))
 for i in range(nu):
  for j in range(1,nv):
   z=facet_jump(cells[i,j-1],cells[i,j],frame,'r1','r0',rule);totals['internal_explicit']+=z['work'];totals['virtual_continuity_max']=max(totals['virtual_continuity_max'],z['virtual_continuity']);totals['Q_jump_L2_max']=max(totals['Q_jump_L2_max'],z['Q_jump_L2']);totals['moment_jump_L2_max']=max(totals['moment_jump_L2_max'],z['moment_jump_L2'])
   if facet_sink is not None:facet_sink(dict(label or{},axis='r',facet=[i,j],**z))
 body=totals['body_membrane']+totals['body_bending'];boundary=totals['Gamma']+totals['other_outer']+totals['internal_explicit'];totals['Green_defect']=totals['material']-body-boundary;totals['internal_pair_vs_cell_edge_defect']=totals['internal_explicit']-totals['internal_cell_edges'];totals['full_vs_reduced_corner_defect']=boundary-totals['all_reduced_edges']-totals['corners'];totals['scale']=max(1.,totals['operation']);totals['negative_omit_facets_defect']=totals['material']-body-totals['Gamma']-totals['other_outer'];totals['negative_wrong_bending_body_sign_defect']=totals['material']-(totals['body_membrane']-totals['body_bending'])-boundary
 return totals
