"""Original affine triangle monomial and absolute-L1 functions."""
from fractions import Fraction as F
from math import factorial

def determinant(v):
    return (v[1][0] - v[0][0]) * (v[2][1] - v[0][1]) - (v[2][0] - v[0][0]) * (v[1][1] - v[0][1])

def compositions(n):
    for i in range(n + 1):
        for j in range(n + 1 - i):
            yield (i, j, n - i - j)

def exact_affine_moment_and_L1(v, a, b):
    """Independent simplex-beta integral of expanded barycentric polynomial, all exact Fraction.

    Integral(lambda0^i lambda1^j lambda2^k) = |det| i!j!k!/(i+j+k+2)!.
    L1 sums absolute expansion-term integrals; no relative division by a cancelled signed moment.
    No Duffy transform or generation of quadrature nodes/weights is used.
    """
    exact = F(0); scale = F(0); det = abs(determinant(v))
    for x in compositions(a):
        cx = F(factorial(a), factorial(x[0]) * factorial(x[1]) * factorial(x[2]))
        for i in range(3): cx *= v[i][0] ** x[i]
        for y in compositions(b):
            coefficient = cx * F(factorial(b), factorial(y[0]) * factorial(y[1]) * factorial(y[2]))
            for i in range(3): coefficient *= v[i][1] ** y[i]
            beta = det * F(factorial(x[0] + y[0]) * factorial(x[1] + y[1]) * factorial(x[2] + y[2]), factorial(a + b + 2))
            term = coefficient * beta
            exact += term; scale += abs(term)
    assert scale > 0
    return exact, scale
