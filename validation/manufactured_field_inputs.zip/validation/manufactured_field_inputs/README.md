# Coarse manufactured-field inputs and saved-data check

After `python prepare_data.py --validation`, run:

```powershell
python validation/manufactured_field_inputs/check_saved_mms.py
```

The reader uses NumPy and SciPy. It checks the two recorded 729-DOF graphs and four continuous manufactured families from the archived exact coefficients, independently assembled physical RHS vectors and original residual vectors. It also recomputes the weighted summaries from all 60 saved GL8/GL10 trace files, including all fourteen evaluator controls. It does not solve a state, repeat an eigendecomposition or start a proprietary host.

`geometry/` preserves the three exact recorded carrier control nets, knots, weights, material and thickness fields. `graphs/` preserves the actual owner-to-global DOF maps, graph selections, physical frames and calibration inputs. `K_omit1ec8.npz` contains the recorded tree-graph matrix in lossless sparse storage. The full-graph matrix and the common natural corner matrix are reused from the extracted `new_analysis/strong_flux_diagnosis_v1/baseline_210_v1/actual_K.npz` and `Knatural_b.npz`; they are not duplicated here.

The positive physical RHS vectors were originally obtained from continuous body, boundary and corner loads, not by multiplying the numerical matrix by the exact coefficients. Their generating formulas and original physical load ledgers remain in the extracted scientific tree. This command checks saved matrix actions and trace-summary arithmetic; it does not repeat the original independent RHS quadrature or turn the ordinary unsourced strong-flux failures into passes. Historical execution workers remain method references and are not required by this reader.
