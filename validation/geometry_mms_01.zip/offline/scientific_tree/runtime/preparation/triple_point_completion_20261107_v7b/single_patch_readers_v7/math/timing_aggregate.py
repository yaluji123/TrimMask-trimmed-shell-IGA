"""Aggregate nine fixed-slot validated timings. Read-only inputs; no Host or solve."""
from pathlib import Path
from collections import Counter
import argparse
import csv
import hashlib
import importlib.util
import json
import math
import statistics

SOURCE_SHA = '90f72156bd9f1430e25177e91b6a69b89c4434f81934dfdee19b20eef2a96566'
RUNTIME_SHA = '50999199bb7bf6770b7446beae7c5e2600294276d6ba858ab7a616f873bf5a84'
# Selection SHA is mandatory from current independently qualified oracle output.
EXTRACTOR_SHA = 'b08612b5689143637a6e1e2e440fda848f9cc098e1a6e923c1e866e4b6b73560'
TRACE_TOOL_SHA = 'b1ca774cc0fb41cc349ccf52520ad37865b7a10c23dd0a7440f18d2dbc816a8a'
TRACE_EXPECTED_SHA = '9fedc8b7f85046d3dcf525d9faaa33b728a603c475b1ea46cbded4c4e85257b3'
OBSERVATION_STATUS = 'PASS_FINAL1212_CONTROLLED_SAME_ACCURACY_TIMING_OBSERVATION'
SCHEDULE = ['automatic_clipper7', 'clipper7', 'fixed_mask12', 'fixed_mask12',
            'automatic_clipper7', 'clipper7', 'clipper7', 'fixed_mask12', 'automatic_clipper7']
METHODS = ['automatic_clipper7', 'clipper7', 'fixed_mask12']
COUNT_KEYS = ['elemTotal', 'elemIn', 'elemCut', 'elemOut', 'standardQuadraturePoints',
              'subCellCandidatePoints', 'subCellAcceptedPoints', 'triangleIntegrationPoints',
              'candidateQuadraturePoints', 'activeQuadraturePoints', 'policySubcell',
              'policyTriangle', 'policyFallback']
CELL_KEYS = ['shellH', 'element', 'row', 'col', 'subCellDiv', 'triGaussN', 'visibleTriangles',
             'candidateIntegrationPoints', 'acceptedIntegrationPoints', 'backend',
             'policyReason', 'fallback', 'integrationPoints']
METRICS = ['solve_and_export_command_ms', 'trimTotal_segment_wall_ms',
           'trimClassify_wall_ms', 'trimClipTri_single_worker_elapsed_ms']


def require(ok, message):
    if not ok:
        raise ValueError(message)


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1 << 20), b''):
            h.update(block)
    return h.hexdigest()


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def stats(values):
    require(len(values) == 3 and all(type(v) in (int, float) and math.isfinite(v) and v >= 0
                                    for v in values), 'three finite nonnegative timings required')
    mean = statistics.mean(values)
    sd = statistics.stdev(values)
    return dict(n=3, mean=mean, sample_SD_ddof1=sd, median=statistics.median(values),
                minimum=min(values), maximum=max(values), range=max(values) - min(values),
                CV_fraction=sd / mean if mean else None,
                CV_percent=100 * sd / mean if mean else None, all_values=values)


def validate_slots(rows):
    require(len(rows) == 9 and len({r['case'] for r in rows}) == 9, 'nine unique cases required')
    require(all(type(r['slot']) is int for r in rows) and
            {r['slot'] for r in rows} == set(range(1, 10)), 'nine unique slots 1..9 required')
    require(all(r['method'] == SCHEDULE[r['slot'] - 1] for r in rows), 'frozen slot order changed')
    require(Counter(r['method'] for r in rows) == Counter({m: 3 for m in METHODS}),
            'exactly three repetitions per eligible family required')


def summary_counts(path):
    with path.open(encoding='utf-8-sig', newline='') as stream:
        rows = [r for r in csv.reader(stream) if len(r) == 2 and r[0] != 'metric']
    require(len(rows) == len({r[0] for r in rows}), 'duplicate summary metric')
    summary = dict(rows)
    counts = {key: int(summary[key]) for key in COUNT_KEYS}
    require(all(v >= 0 for v in counts.values()), 'negative reported work count')
    return summary, counts


def cell_work(path, counts):
    with path.open(encoding='utf-8-sig', newline='') as stream:
        rows = list(csv.DictReader(stream))
    require(len(rows) == 98 and len({(r['shellH'], r['element']) for r in rows}) == 98,
            '98 unique owner/element cut cells required')
    configuration = sorted(tuple(r[key] for key in CELL_KEYS) for r in rows)
    require(all(r['backend'] in ('triangle', 'subcell') and int(r['fallback']) in (0, 1)
                for r in rows), 'unsupported actual backend/fallback')
    for row in rows:
        numbers = [int(row[k]) for k in ['subCellDiv', 'triGaussN', 'visibleTriangles',
                    'candidateIntegrationPoints', 'acceptedIntegrationPoints', 'integrationPoints']]
        require(all(v >= 0 for v in numbers) and numbers[4] <= numbers[3] and numbers[4] == numbers[5],
                'invalid candidate/accepted/integration count')
    total = lambda key, backend=None: sum(int(r[key]) for r in rows
                                         if backend is None or r['backend'] == backend)
    require(counts['elemTotal'] == 1296 and counts['elemCut'] == 98 and
            counts['elemIn'] + counts['elemCut'] + counts['elemOut'] == 1296, 'cell census mismatch')
    require(counts['candidateQuadraturePoints'] == counts['standardQuadraturePoints'] + total('candidateIntegrationPoints')
            and counts['activeQuadraturePoints'] == counts['standardQuadraturePoints'] + total('acceptedIntegrationPoints'),
            'global/cut work totals disagree')
    require(counts['subCellCandidatePoints'] == total('candidateIntegrationPoints', 'subcell') and
            counts['subCellAcceptedPoints'] == total('acceptedIntegrationPoints', 'subcell') and
            counts['triangleIntegrationPoints'] == total('acceptedIntegrationPoints', 'triangle') and
            counts['policyFallback'] == total('fallback'), 'backend work totals disagree')
    rules = Counter((r['backend'], int(r['subCellDiv']), int(r['triGaussN']), r['policyReason'],
                     int(r['fallback'])) for r in rows)
    work = dict(reported_summary_counts=counts, cut_visible_triangles_reported=total('visibleTriangles'),
                cut_candidate_points_reported=total('candidateIntegrationPoints'),
                cut_accepted_kernel_visits_reported=total('acceptedIntegrationPoints'),
                cut_rejected_candidates=total('candidateIntegrationPoints') - total('acceptedIntegrationPoints'),
                all_accepted_bulk_kernel_visits_reported=counts['activeQuadraturePoints'],
                subcell_rejected_candidates=counts['subCellCandidatePoints'] - counts['subCellAcceptedPoints'],
                actual_rule_configuration_counts=[dict(backend=k[0], subdivision=k[1], triangular_rule=k[2],
                     policy_reason=k[3], fallback=k[4], cells=n) for k, n in sorted(rules.items())],
                independent_trial_clip_tri_call_count=None, trial_call_count_observed=False,
                potential_triangle_rule_work_relabelled_as_actual_calls=False,
                trial_generation_costs_retained_in_unmodified_command_trimTotal_and_trimClipTri_timers=True)
    return configuration, work


def aggregate(prep, observations_dir, selection_path, SELECTION_SHA, context):
    inputs = {}

    def bind(path, expected=None):
        path=context.bind(path,expected);inputs[path]=sha(path);return path

    final = prep / 'runtime/preparation/final_paper_cases_20261107_v1'
    bind(Path(__file__).with_name('timing_extract.py'), EXTRACTOR_SHA)
    bind(selection_path, SELECTION_SHA)
    selection = read(selection_path)
    require(selection['status'] == 'PASS_FINAL1212_SAME_ACCURACY_TIMING_SELECTION' and
            selection['source_binding_sha256'] == SOURCE_SHA and selection['runtime_manifest_sha256'] == RUNTIME_SHA,
            'wrong final-runtime accuracy selection')
    require(selection['fixed_interleaved_schedule'] == SCHEDULE and selection['physical_thresholds_not_lowered'] is True
            and selection['timing_not_seen_or_used_to_select'] is True and set(selection['qualified_methods']) == set(METHODS),
            'frozen eligibility or schedule mismatch')
    trace_tool = bind(prep / 'runtime/timing_protocol_v3/required_trace.py', TRACE_TOOL_SHA)
    trace_expected = bind(prep / 'runtime/timing_protocol_v3/required_trace_expected_coverage.json', TRACE_EXPECTED_SHA)
    expected = read(trace_expected)
    require(expected['row_count'] == 723, 'mandatory real trace is not the frozen 723 rows')
    spec = importlib.util.spec_from_file_location('pinned_required_trace_only', trace_tool)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    paths = [observations_dir / f'TIMING_SLOT{i:02d}_VALIDATED.json' for i in range(1, 10)]
    require(set(observations_dir.glob('TIMING_SLOT*_VALIDATED.json')) == set(paths),
            'exact nine named validated slot records required; missing/extra records preserved')
    rows = []
    for slot, path in enumerate(paths, 1):
        bind(path)
        row = read(path)
        require(row['status'] == OBSERVATION_STATUS and row['slot'] == slot and
                row['extractor_sha256'] == EXTRACTOR_SHA, 'invalid slot observation or producer')
        rows.append(row)
    validate_slots(rows)
    qualified = {}
    raw_runs = []
    runner_hashes, model_hashes = set(), set()
    for row in rows:
        method = row['method']
        case = prep / 'runtime/runs' / row['case']
        manifest = {Path(x['path']).resolve(): x['sha256'] for x in row['input_manifest']}
        require(len(manifest) == len(row['input_manifest']), 'duplicate extractor input binding')
        for path, digest in manifest.items():
            bind(path, digest)
        required = [case / n for n in ['process_result.json', 'launch_plan.json', 'root_selected_window.json',
                    'source_runtime_manifest.json', 'applied_source_binding.json', 'accuracy_selection.json',
                    'executed_profile.json', 'executed_runner.py', 'executed.scr', 'stdout.log',
                    'log_decode_receipt.json', 'boundary_domain_probe.jsonl']]
        require(all(p.resolve() in manifest for p in required), 'extractor omitted a mandatory input')
        bind(case / 'source_runtime_manifest.json', RUNTIME_SHA)
        bind(case / 'applied_source_binding.json', SOURCE_SHA)
        bind(case / 'accuracy_selection.json', SELECTION_SHA)
        q = selection['qualified_methods'][method]
        require(q['eligible'] is True and all(v is True for v in q['eligibility_gates'].values()),
                'family is not independently accuracy eligible')
        bind(case / 'executed_profile.json', q['profile_sha256'])
        runner_hashes.add(sha(bind(case / 'executed_runner.py')))
        window = read(case / 'root_selected_window.json')
        require(window['parameters'] == dict(profile_variant=method, duffy_reference=False, timing=True, timing_slot=row['slot'])
                and window['accuracy_selection_sha256'] == SELECTION_SHA and
                window['runner_sha256'] == sha(case / 'executed_runner.py'), 'actual slot/window/profile mismatch')
        require(row['required_trace_overhead_not_subtracted'] is True and
                row['configured_threads_from_bound_source'] == 1 and row['OS_effective_thread_observation_claimed'] is False
                and row['not_new_continuum_accuracy_certification'] is True, 'timing scope or thread claim changed')
        trace = module.validate_trace(case / 'boundary_domain_probe.jsonl', expected)
        require(trace == row['required_real_trace'] and trace['overhead_subtracted'] is False, 'real trace receipt mismatch')
        require(math.isfinite(row['qualified_response_U_relative_difference']) and
                row['qualified_response_U_relative_difference'] >= 0, 'invalid qualified response diagnostic')
        resource_path = bind(case / 'owned_process_resource_observations.json')
        resource = read(resource_path)
        require(resource['within_declared_observed_memory'] is True and
                resource['sampled_maximum_of_private_OSpeakcommit_OSpeakWS'] == row['observed_process_peak_bytes'],
                'resource receipt mismatch')
        original_path = bind(case / 'original_input_before_after.json')
        original = read(original_path)
        require(original['exact_sha_and_mtime_unchanged'] is True and original['before'] == original['after'],
                'original model identity changed')
        bind(case / 'input_model.dwg', original['before']['sha256'])
        model_hashes.add(original['before']['sha256'])
        diag = case / 'source_diagnostics_after'
        for name in ['trim_summary.csv', 'trim_cell_diagnostics.csv']:
            require((diag / name).resolve() in manifest, 'extractor omitted work diagnostics')
        summary, counts = summary_counts(diag / 'trim_summary.csv')
        require(summary == row['raw_summary'], 'raw summary differs from validated observation')
        for metric in METRICS:
            require(type(row[metric]) in (int, float) and math.isfinite(row[metric]) and row[metric] >= 0,
                    'missing/nonfinite timing metric: ' + metric)
        require(row['solve_and_export_command_ms'] > 0 and row['trimTotal_segment_wall_ms'] > 0,
                'actual command and trimTotal clocks must be positive')
        configuration, work = cell_work(diag / 'trim_cell_diagnostics.csv', counts)
        qcase = prep / 'runtime/runs' / q['case']
        sample = case / 'derived_work/displacement_samples.csv'
        qsample = qcase / 'derived_work/displacement_samples.csv'
        require(sample.resolve() in manifest and qsample.resolve() in manifest,
                'timing CSV or qualified same-profile CSV was not checked by the extractor')
        bind(qcase / 'source_runtime_manifest.json', RUNTIME_SHA)
        bind(qcase / 'applied_source_binding.json', SOURCE_SHA)
        bind(qcase / 'executed_profile.json', q['profile_sha256'])
        bind(qcase / 'input_model.dwg', original['before']['sha256'])
        if method not in qualified:
            qdiag = qcase / 'source_diagnostics_after'
            bind(qdiag / 'trim_summary.csv')
            bind(qdiag / 'trim_cell_diagnostics.csv')
            _, qcounts = summary_counts(qdiag / 'trim_summary.csv')
            qconfiguration, qwork = cell_work(qdiag / 'trim_cell_diagnostics.csv', qcounts)
            qualified[method] = (qconfiguration, qwork)
        require((configuration, work) == qualified[method], 'actual per-cell rules/work changed from qualified same-profile data')
        raw_runs.append(dict(slot=row['slot'], case=row['case'], method=method,
                    **{k: row[k] for k in METRICS},
                    process_wall_seconds_context_only_not_substituted=row['process_wall_seconds_not_kernel_benchmark'],
                    qualified_response_U_relative_difference_diagnostic=row['qualified_response_U_relative_difference'],
                    response_agreement_checked_by_pinned_extractor_and_inputs_unchanged=True,
                    actual_rules_and_work_match_qualified_same_profile=True, work=work))
    require(len(runner_hashes) == len(model_hashes) == 1, 'runner or original model changed across repetitions')
    table = [dict(method=method, metric=metric, **stats([r[metric] for r in raw_runs if r['method'] == method]))
             for method in METHODS for metric in METRICS]
    for path, digest in inputs.items():
        require(sha(path) == digest, 'input changed during aggregation: ' + str(path))
    return dict(status='PASS_FINAL1212_NINE_FIXED_SLOT_TIMING_RESPONSE_AND_REPORTED_WORK',
                fixed_interleaved_schedule=SCHEDULE, repetitions_per_family=3, timing_summary=table,
                raw_runs=raw_runs, raw_validated_observations=rows,
                qualified_same_profile_work={m: qualified[m][1] for m in METHODS},
                source_binding_sha256=SOURCE_SHA, runtime_manifest_sha256=RUNTIME_SHA,
                accuracy_selection_sha256=SELECTION_SHA, extractor_sha256=EXTRACTOR_SHA,
                required_real_trace_rows=723, required_trace_overhead_not_subtracted=True,
                independent_trial_clip_tri_call_count=None, trial_call_count_observed=False,
                trial_generation_costs_retained_in_unmodified_timers=True,
                process_wall_used_as_command_clock=False, no_outliers_removed=True,
                observed_effective_OS_threads_claimed=False, configured_threads_source_bound=1,
                new_continuum_structural_accuracy_or_paper_acceptance_claimed=False,
                Host_compiler_solver_or_process_scan_started=False,
                no_new_physical_accuracy_threshold_or_oracle=True,
                input_manifest=[dict(path=str(p), sha256=h) for p, h in sorted(inputs.items())],
                aggregator_source_sha256=sha(Path(__file__)))


def write_csv(path, fields, rows):
    with path.open('x', encoding='utf-8-sig', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        writer.writerows({k: row[k] for k in fields} for row in rows)


if __name__=='__main__':raise SystemExit('Use read_single_patch_v7.py explicit identity/selection')
