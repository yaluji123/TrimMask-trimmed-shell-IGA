"""Compare the preselected quantities; no mesh/penalty fitting or new acceptance limit."""
import csv
import hashlib
import importlib.util
import json
from pathlib import Path
import numpy as np
from scipy.interpolate import BSpline

HERE = Path('new_analysis/actual_inputs/prep/mechanics/candidate/actual_hull_linear_state_v1')
PREP = Path('投稿/二次修稿/准备工作')
CASE = PREP / 'runtime/runs/native_hull4x_actual_linear_state_v1'
STATE = CASE / 'derived_work/linear_state'


def load(p):
    return json.loads(p.read_text(encoding='utf-8-sig'))


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def rows(p):
    with p.open(encoding='utf-8-sig', newline='') as f:
        return list(csv.DictReader(f))


def main():
    report = load(REPORT)
    assert report['status'] == 'PASS_ACTUAL_STATE_SPARSE_ALGEBRA_CONSTRAINTS_AND_WORK_ONLY'
    preselected = load(PROBES)
    summary = load(PREP / 'runtime/engineering_stri3_three_level_summary_v1/summary_data.json')
    table = summary['tables']['metrics_by_level']
    selected = [dict(zip(table['header'], r)) for r in table['rows'] if r[0] == 'hull' and r[1] == '4x']
    fem = {r['metric']: r for r in selected}
    done = load(STATE / 'state_complete.json')
    masters = {(int(r['master_node']), int(r['component'])): r for r in rows(STATE / 'actual_master_results.csv')}
    comparison = []
    ref = float(fem['material_ALLSE_Nmm']['value_1'])
    energy = float(report['bulk_energy_after_exact_Hzero_diagonal_removal_Nmm'])
    comparison.append(dict(metric='material_bulk_energy_Nmm', Native=energy, FEM4x=ref, relative_difference=(energy-ref)/abs(ref), error_definition='stored H quadratic minus measured artificial exact-Hzero diagonal energy, not assembled/interface energy'))
    for i in (1, 2):
        value = float(masters[i, 5]['external_KKT_sign_reaction'])
        ref = float(fem[f'RP{i}_signed_RM3_Nmm']['value_1'])
        comparison.append(dict(metric=f'RP{i}_signed_RM3_Nmm', Native=value, FEM4x=ref, relative_difference=(value-ref)/abs(ref), error_definition='external KKT sign reaction=-stored prescription multiplier; both signed values retained'))
    reader_path = PREP / 'mechanics/candidate/endpoint_vertex988_source_v1/checker/check_actual_endpoint_capture.py'
    assert sha(reader_path) == 'c4892fb0b822bbee5ab43f97dde4010e5664ecb7bc347dccaa07599e823f33ff'
    spec = importlib.util.spec_from_file_location('unchanged_registered_closure_for_selected_probe', reader_path)
    reader = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(reader)
    fields = {}
    for r in rows(STATE / 'control_point_solution.csv'):
        fields.setdefault(int(r['owner']), {})[int(r['local_cp'])] = [float(r[k]) for k in ('ux', 'uy', 'uz')]
    geos = {int(p.stem.rsplit('_',1)[1]): load(p) for p in (CASE / 'capture').glob('trim_geometry_*.json')}
    probes = []
    for node, point in preselected['probes'].items():
        world = np.asarray(point, float)
        accepted = []
        for owner, g in sorted(geos.items()):
            m, n = g['controls_u'], g['controls_v']
            control = np.asarray(g['control_global_Vg'], float).reshape(m,n,3)
            lo = np.array([g['knots_u'][g['degree_u']], g['knots_v'][g['degree_v']]], float)
            hi = np.array([g['knots_u'][m], g['knots_v'][n]], float)
            jac = np.column_stack(((control[-1,0]-control[0,0])/(hi[0]-lo[0]), (control[0,-1]-control[0,0])/(hi[1]-lo[1])))
            uv = lo + np.linalg.lstsq(jac, world-control[0,0], rcond=None)[0]
            if np.any(uv < lo) or np.any(uv > hi):
                continue
            basis_u = BSpline(g['knots_u'], np.eye(m), g['degree_u'])(uv[0])
            basis_v = BSpline(g['knots_v'], np.eye(n), g['degree_v'])(uv[1])
            basis = np.outer(basis_u,basis_v).ravel()
            location = basis @ control.reshape(-1,3)
            residual = float(np.linalg.norm(location-world))
            if residual > 1e-8 or not reader.registered_closure(g,uv):
                continue
            assert len(fields[owner]) == m*n
            displacement = basis @ np.asarray([fields[owner][i] for i in range(m*n)])
            accepted.append(dict(owner=owner, uv=uv.tolist(), actual_world_residual_mm=residual, U_vector_mm=displacement.tolist(), partition_error=abs(float(basis.sum())-1.)))
        assert accepted, ('preselected FEM point has no retained Native owner', node)
        reference = fem[f'original_node_{node}_global_U_vector_mm']
        fv = np.array([reference[f'value_{i}'] for i in (1,2,3)], float)
        for a in accepted:
            value = np.asarray(a['U_vector_mm'])
            a.update(FEM4x_U_vector_mm=fv.tolist(), component_difference_mm=(value-fv).tolist(), relative_vector_difference=float(np.linalg.norm(value-fv)/np.linalg.norm(fv)))
        probes.append(dict(original_FEM_node=int(node), original_world_xyz_mm=point, all_retained_owner_traces=accepted, chosen_or_best_component=False))
    groups = load(CASE / 'capture/rp_collected_samples.json')['groups']
    force = np.zeros(3);moment = np.zeros(3)
    for g in groups:
        label = int(g['master_node_label'])
        reaction = np.array([float(masters[label,i]['external_KKT_sign_reaction']) for i in range(6)])
        force += reaction[:3]
        moment += reaction[3:] + np.cross(np.asarray(g['reference_point_xyz']), reaction[:3])
    result = dict(status='FIRST_IGA4x_VERSUS_CONVERGED_FIXED_FEM4x_COMPARISON_ONLY', scalar_metrics=comparison, internal_probes=probes, RP_reaction_total_force_N=force.tolist(), RP_reaction_total_moment_about_world_origin_Nmm=moment.tolist(), assembled_energy_Nmm=float(done['assembled_quadratic_energy_Nmm']), material_bulk_energy_Nmm=energy, interface_and_any_boundary_quadratic_energy_Nmm=float(done['assembled_quadratic_energy_Nmm'])-energy, no_new_FEM_or_mesh_or_parameter_change=True, IGA_h_convergence_or_geometry_equivalence_or_stress_convergence_accepted=False, FEM4x_is_adjacent_converged_reference_not_exact_truth=True)
    out = OUTPUT
    assert not out.exists()
    out.write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(result))


if __name__=='__main__':raise SystemExit('Use read_engineering_mode4_v7.py with current strict preflight')
