"""Read one finished bound STRI3 job; do not launch a solver or modify ODB."""
from __future__ import print_function
import hashlib
import ctypes
import json
import math
import os
import re
import sys

from odbAccess import openOdb


ROOT='runtime'
sys.path.insert(0,ROOT)
from inspect_odb_readonly import digest,numeric_data
LEVEL=sys.argv[1]if len(sys.argv)>1 else'0p0625mm'
assert LEVEL=='0p0625mm'
_manifest_folder='stri3_reference_candidates_'+LEVEL if LEVEL=='0p0625mm'else'stri3_reference_candidates'
with open(os.path.join(ROOT,_manifest_folder,'conversion_checks.json'))as _stream:BINDING=json.load(_stream)[LEVEL]
CASE=os.path.join('oe_round2_stage_20261104','stri3_'+LEVEL+'_v1')
ODB=os.path.join(CASE,'oe_r2_stri3_'+LEVEL+'_v1.odb')
INP=os.path.join(CASE,'model.inp')
OUT=os.path.abspath(sys.argv[sys.argv.index('--out')+1])

def own_memory(stage):
    class PMC(ctypes.Structure):
        _fields_=[('cb',ctypes.c_ulong),('faults',ctypes.c_ulong)]+[(x,ctypes.c_size_t)for x in('peak_ws','working','quota_peak_paged','quota_paged','quota_peak_nonpaged','quota_nonpaged','pagefile','peak_commit','private')]
    memory=PMC();memory.cb=ctypes.sizeof(memory);kernel=ctypes.windll.kernel32;kernel.GetCurrentProcess.restype=ctypes.c_void_p
    kernel.K32GetProcessMemoryInfo.argtypes=[ctypes.c_void_p,ctypes.POINTER(PMC),ctypes.c_ulong];kernel.K32GetProcessMemoryInfo.restype=ctypes.c_int
    assert kernel.K32GetProcessMemoryInfo(kernel.GetCurrentProcess(),ctypes.byref(memory),memory.cb)
    record=dict(stage=stage,private_bytes=int(memory.private),working_bytes=int(memory.working),OS_peak_commit_bytes=int(memory.peak_commit),OS_peak_working_bytes=int(memory.peak_ws),declared_process_bytes=96*(1<<30))
    assert max(record[k]for k in('private_bytes','working_bytes','OS_peak_commit_bytes','OS_peak_working_bytes'))<=96*(1<<30),"Read-only stress extraction memory declaration exceeded"
    return record

def cross(a,b):return[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]]
def dot(a,b):return sum(x*y for x,y in zip(a,b))
def norm(a):return math.sqrt(dot(a,a))
def add(a,b):return[x+y for x,y in zip(a,b)]

def parse_deck(text):
    blocks=[]
    for line in text.splitlines():
        if not line.strip()or line.startswith('**'):continue
        if line.startswith('*'):blocks.append([line,[]])
        else:blocks[-1][1].append(line)
    nodes={};elements={};sets={};bc=[];loads=[];elastic=[];sections=[]
    for h,body in blocks:
        low=h.lower();tag=low.split(',',1)[0]
        assert tag not in ('*plastic','*buckle','*transform','*system','*dload','*dsload','*equation','*mpc','*coupling','*tie')
        if tag=='*node':
            for line in body:
                a=line.split(',');nodes[int(a[0])]=[float(x)for x in a[1:]]
        elif tag=='*element':
            assert 'type=stri3'in low
            for line in body:
                a=[int(x)for x in line.split(',')];assert len(a)==4;elements[a[0]]=a[1:]
        elif tag=='*nset':
            name=next(x.split('=',1)[1].strip()for x in h.split(',')if x.strip().lower().startswith('nset='))
            if 'generate'in low:
                sets[name]=[]
                for line in body:
                    first,last,inc=[int(x)for x in line.split(',')if x.strip()]
                    sets[name].extend(range(first,last+1,inc))
            else:sets[name]=[int(x)for line in body for x in line.split(',')if x.strip()]
        elif tag=='*boundary':
            for line in body:bc.append([x.strip()for x in line.split(',')])
        elif tag=='*cload':
            for line in body:
                a=line.split(',');loads.append((int(a[0]),int(a[1]),float(a[2])))
        elif tag=='*elastic':elastic.extend([[float(x)for x in line.split(',')]for line in body])
        elif tag=='*shell section':sections.append({'keyword':h,'values':body})
        elif tag=='*step':assert'nlgeom=no'in low
    assert len(nodes)==BINDING['nodes']and len(elements)==BINDING['candidate_STRI3_triangles']
    assert elastic==[[210000.0,0.3]]
    constrained=set()
    for row in bc:
        assert len(row)in(3,4)and(len(row)==3 or float(row[3])==0.)
        nodeids=sets[row[0]]if row[0]in sets else[int(row[0])]
        for nid in nodeids:
            for dof in range(int(row[1]),int(row[2])+1):constrained.add((nid,dof))
    parent={n:n for n in nodes}
    def find(n):
        while parent[n]!=n:parent[n]=parent[parent[n]];n=parent[n]
        return n
    for conn in elements.values():
        for n in conn[1:]:parent[find(n)]=find(conn[0])
    components=len(set(find(n)for n in nodes))
    assert components==1
    return nodes,elements,loads,constrained,sections

def main():
    assert not os.path.exists(OUT)
    resources=[own_memory('before_deck_and_ODB_read')]
    assert not os.path.exists(os.path.join(CASE,'oe_r2_stri3_'+LEVEL+'_v1.lck'))
    before=os.stat(ODB);before_input=os.stat(INP);odb_hash=digest(ODB);inp_hash=digest(INP)
    assert inp_hash==BINDING['candidate_sha256']
    with open(INP)as f:text=f.read()
    nodes,elements,loads,constrained,sections=parse_deck(text)
    force=[0.,0.,0.];moment=[0.,0.,0.]
    for nid,dof,value in loads:
        if dof<=3:
            f=[0.,0.,0.];f[dof-1]=value;force=add(force,f);moment=add(moment,cross(nodes[nid],f))
        else:moment[dof-4]+=value
    odb=openOdb(path=ODB,readOnly=True)
    try:
        assert len(odb.steps)==1
        step=odb.steps['LOAD'];frame=step.frames[-1]
        instances=odb.rootAssembly.instances
        assert len(instances)==1
        resources.append(own_memory('after_ODB_open_and_deck_parse'))
        instance=next(iter(instances.values()))
        assert len(instance.nodes)==len(nodes)and len(instance.elements)==len(elements)
        types=sorted(set(e.type for e in instance.elements));assert types==['STRI3']
        field={};field_precision={}
        for quantity in ('U','UR','RF','RM'):
            assert quantity in frame.fieldOutputs
            if len(frame.fieldOutputs[quantity].values):
                field_precision[quantity]=str(frame.fieldOutputs[quantity].values[0].precision)
            vals={}
            for value in frame.fieldOutputs[quantity].values:
                data=[float(x)for x in numeric_data(value)]
                assert len(data)==3 and all(not(math.isnan(x)or math.isinf(x))for x in data)
                assert value.nodeLabel not in vals
                vals[value.nodeLabel]=data
            assert set(vals)==set(nodes)
            field[quantity]=vals
        resources.append(own_memory('after_all_U_UR_RF_RM_fields'))
        reaction=[0.,0.,0.];reaction_moment=[0.,0.,0.]
        for nid in nodes:
            reaction=add(reaction,field['RF'][nid])
            reaction_moment=add(reaction_moment,add(cross(nodes[nid],field['RF'][nid]),field['RM'][nid]))
        work=0.
        for nid,dof,value in loads:work+=.5*value*field['U'if dof<=3 else'UR'][nid][(dof-1)%3]
        histories={}
        for region_name,region in step.historyRegions.items():
            for q in ('ALLSE','ALLIE','ALLWK','ALLPD','ALLAE'):
                if q in region.historyOutputs:histories[q]=[list(x)for x in region.historyOutputs[q].data]
        final={q:rows[-1][1]for q,rows in histories.items()}
        peak_node=max(nodes,key=lambda n:norm(field['U'][n]));peak=norm(field['U'][peak_node])
        # Fixed BEFORE reading U: independent common-junction end, not the global peak.
        gamma_world=[100.0,0.0,0.0];point_tolerance=1e-8
        gamma_nodes=[nid for nid,xyz in nodes.items()if norm([xyz[k]-gamma_world[k]for k in range(3)])<=point_tolerance]
        assert len(gamma_nodes)==1,'fixed common Gamma end must be one actual shared FEM node'
        gamma_node=gamma_nodes[0]
        fixed_world_displacements=[dict(point_name='common_Gamma_b',requested_world_xyz_mm=gamma_world,
             actual_world_xyz_mm=nodes[gamma_node],node_label=gamma_node,
             physical_residual_mm=norm([nodes[gamma_node][k]-gamma_world[k]for k in range(3)]),
             position_tolerance_mm=point_tolerance,U_vector_mm=field['U'][gamma_node],UR_vector_rad=field['UR'][gamma_node],
             selection='unique original-deck physical coordinate fixed before U; no closest/peak-value selection')]
        nonzero_free_reactions=[(nid,dof+1,vec[dof])for nid,vec in field['RF'].items()for dof in range(3)if(nid,dof+1)not in constrained and abs(vec[dof])>1e-8]
        material={}
        for name,mat in odb.materials.items():
            material[name]={'elastic':[list(x)for x in mat.elastic.table],
                            'hasPlastic':hasattr(mat,'plastic')}
            assert not hasattr(mat,'plastic')
        result={'read_only':True,'new_solver_executed_by_this_script':False,
                'source_odb':ODB,'source_odb_sha256':odb_hash,'input_sha256':inp_hash,
                'job_version':str(odb.jobData.version),'job_precision':str(odb.jobData.precision),
                'nodal_field_precision':field_precision,
                'nodes':len(nodes),'elements':len(elements),'element_types':types,
                'nodal_component_count_6N':6*len(nodes),'prescribed_nodal_components':len(constrained),
                'unprescribed_nodal_components_6N_minus_BC':6*len(nodes)-len(constrained),
                'dof_count_scope':'Nodal bookkeeping; solver equation count must be read separately from the MSG',
                'mesh_connected_components':1,'shared_node_junction':'Unchanged FEM deck common node labels; no ties/MPCs/transforms',
                'material':material,'sections':sections,'step_procedure':str(step.procedure),
                'step_nlgeom':str(step.nlgeom)if hasattr(step,'nlgeom')else'not_exposed',
                'maximum_displacement_mm':peak,'maximum_displacement_node':peak_node,
                'maximum_displacement_location_mm':nodes[peak_node],
                'maximum_displacement_vector_mm':field['U'][peak_node],
                'fixed_world_displacements':fixed_world_displacements,
                'rotation_at_maximum_displacement_node_rad':field['UR'][peak_node],
                'applied_force_N':force,'reaction_force_N':reaction,
                'compensated_reaction_force_N':[math.fsum(field['RF'][nid][k]for nid in nodes)for k in range(3)],
                'force_closure_N':add(force,reaction),
                'force_relative_closure':norm(add(force,reaction))/max(norm(force),1.),
                'applied_moment_about_origin_Nmm':moment,'reaction_moment_about_origin_Nmm':reaction_moment,
                'moment_closure_Nmm':add(moment,reaction_moment),
                'moment_relative_closure':norm(add(moment,reaction_moment))/max(norm(moment),1.),
                'moment_definition':'Sum r cross RF plus RM at all nodes; source-deck coordinates; no coordinate transforms',
                'one_half_nodal_load_dot_displacement_Nmm':work,
                'energy_histories':histories,'energy_final_Nmm':final,
                'free_translation_reactions_over_1e_minus8_N':nonzero_free_reactions,
                'reference_convergence_established':False,
                'mesh_level':LEVEL,
                'scope':'Single '+LEVEL+' pure-elastic linear-static STRI3 result; not an equivalence or convergence claim'}
        if 'ALLWK'in final:result['nodal_work_vs_ALLWK_relative_difference']=abs(work-final['ALLWK'])/max(abs(work),abs(final['ALLWK']),1e-30)
        if 'ALLSE'in final:result['nodal_work_vs_ALLSE_relative_difference']=abs(work-final['ALLSE'])/max(abs(work),abs(final['ALLSE']),1e-30)
        if 'ALLAE'in final and'ALLIE'in final:result['ALLAE_over_ALLIE']=final['ALLAE']/final['ALLIE']
    finally:odb.close()
    after=os.stat(ODB);after_input=os.stat(INP)
    assert(before.st_size,before.st_mtime)==(after.st_size,after.st_mtime)
    assert(before_input.st_size,before_input.st_mtime)==(after_input.st_size,after_input.st_mtime)
    odb_hash_after=digest(ODB);input_hash_after=digest(INP)
    assert odb_hash_after==odb_hash and input_hash_after==inp_hash
    resources.append(own_memory('after_ODB_close'))
    result['own_process_resource_observations']=resources
    result['producer_PID']=os.getpid()
    result['producer_executable']=sys.executable
    result['OS_hardcap_installed']=False
    result['source_hash_size_mtime_unchanged']=True
    result['source_before_after']={
        'ODB':dict(path=ODB,before=dict(bytes=before.st_size,mtime=before.st_mtime,sha256=odb_hash),after=dict(bytes=after.st_size,mtime=after.st_mtime,sha256=odb_hash_after)),
        'INP':dict(path=INP,before=dict(bytes=before_input.st_size,mtime=before_input.st_mtime,sha256=inp_hash),after=dict(bytes=after_input.st_size,mtime=after_input.st_mtime,sha256=input_hash_after))}
    result['fixed_world_readback_producer_sha256']=digest(os.path.abspath(__file__))
    result['fixed_world_readback_scope']='same closed finest STRI3 ODB; Gamma endpoint and original true-peak fields separate; no new solve'
    with open(OUT,'w')as f:json.dump(result,f,indent=2,sort_keys=True)
    print(json.dumps({k:result[k]for k in('maximum_displacement_mm','force_relative_closure','moment_relative_closure','energy_final_Nmm','source_hash_size_mtime_unchanged')}))

if __name__=='__main__':main()
