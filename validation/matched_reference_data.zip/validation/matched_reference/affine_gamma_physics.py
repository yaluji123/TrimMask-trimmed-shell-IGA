"""Physical affine-IP recovery kernel. No ODB, state solve or IGA fitting.

All tensors entering fit_section are global physical Cauchy tensors. The
separate actual-ODB frame and IP-number conventions must be bound first.
"""
import numpy as np

def unit(x):
    x = np.asarray(x, dtype=float)
    q = np.linalg.norm(x)
    assert np.isfinite(q) and q > 0
    return x / q

def physical_frame(vertices):
    x = np.asarray(vertices, dtype=float)
    assert x.shape == (3, 3)
    t = np.array([1., 0., 0.])
    gamma = [i for i in range(3) if np.linalg.norm(x[i, 1:]) <= 1e-8]
    assert len(gamma) == 2
    third = next(i for i in range(3) if i not in gamma)
    inward = unit(x[third] - t * x[third, 0])
    normal = unit(np.cross(x[1] - x[0], x[2] - x[0]))
    assert abs(float(normal @ t)) <= 1e-10
    assert abs(float(normal @ inward)) <= 1e-10
    ab = sorted(float(x[i, 0]) for i in gamma)
    assert 0 <= ab[0] < ab[1] <= 100
    return t, inward, normal, -inward, ab

def fit_section(vertices, ip_to_barycentric, sigma_bottom, sigma_top, thickness):
    """Three actual IPs, already transformed to global axes; M has units N."""
    t, inward, normal, mu, interval = physical_frame(vertices)
    x = np.asarray(vertices, dtype=float)
    bary = np.asarray(ip_to_barycentric, dtype=float)
    sb, st = np.asarray(sigma_bottom), np.asarray(sigma_top)
    assert bary.shape == (3, 3) and sb.shape == st.shape == (3, 3, 3)
    assert np.max(abs(bary.sum(axis=1) - 1.)) <= 1e-12
    assert np.min(bary) >= 0 and np.isfinite(bary).all()
    assert thickness > 0 and np.isfinite(thickness)
    assert max(np.max(abs(sb - sb.transpose(0, 2, 1))),
               np.max(abs(st - st.transpose(0, 2, 1)))) <= 1e-10 * max(1., np.max(abs(sb)), np.max(abs(st)))
    locations = bary @ x
    a = np.column_stack([np.ones(3), locations @ t, locations @ inward])
    assert abs(np.linalg.det(a)) > 1e-14
    samples_M = thickness**2 / 12. * (st - sb)
    samples_N = thickness / 2. * (st + sb)
    coeff_M = np.linalg.solve(a, samples_M.reshape(3, 9)).reshape(3, 3, 3)
    coeff_N = np.linalg.solve(a, samples_N.reshape(3, 9)).reshape(3, 3, 3)
    return {'t': t, 'inward': inward, 'n': normal, 'mu': mu, 'interval': interval,
            'M': coeff_M, 'N': coeff_N, 'thickness': thickness}

def evaluate(fit, s, Q_sign=-1., retain_twist=True):
    """Q=-divM, T=Nmu-n(Q.mu), m=n x Mmu, g=T-d_s(m x t)."""
    n, mu, t, r = (fit[k] for k in ('n', 'mu', 't', 'inward'))
    M, N = fit['M'], fit['N']
    mm, nn = M[0] + s*M[1], N[0] + s*N[1]
    divM = M[1] @ t + M[2] @ r
    Q = Q_sign * divM
    traction = nn @ mu - n * float(Q @ mu)
    m = np.cross(n, mm @ mu)
    dm = np.cross(n, M[1] @ mu)
    H = np.cross(m, t)
    dH = np.cross(dm, t)
    return {'M': mm, 'N': nn, 'Q': Q, 'T': traction, 'm': m,
            'H': H, 'g': traction - (dH if retain_twist else 0.),
            'mt': float(t @ m)}

def integrated_classical_g(fit, a, b):
    return (b-a) * .5 * (evaluate(fit, a)['g'] + evaluate(fit, b)['g'])

def broken_line_identity(fits):
    """Do not discard H jumps of a discontinuous elementwise moment trace."""
    fs = sorted(fits, key=lambda x: x['interval'][0])
    total_g = np.zeros(3); total_T = np.zeros(3); jumps = np.zeros(3)
    for i, f in enumerate(fs):
        a, b = f['interval']; va, vb = evaluate(f, a), evaluate(f, b)
        total_g += integrated_classical_g(f, a, b)
        total_T += .5*(b-a)*(va['T']+vb['T'])
        if i:
            old = fs[i-1]
            assert abs(old['interval'][1]-a) <= 1e-10
            jumps += va['H'] - evaluate(old, a)['H']
    ends = evaluate(fs[-1], fs[-1]['interval'][1])['H'] - evaluate(fs[0], fs[0]['interval'][0])['H']
    # integral(classical g) = integral(T) - H_end + H_start + sum(H_jumps).
    return {'classical_integral': total_g, 'traction_integral': total_T,
            'end_H_difference': ends, 'internal_H_jump_sum': jumps,
            'identity_defect': total_g-(total_T-ends+jumps),
            'distributional_integral': total_g-jumps}

def require_actual_mapping(mapping):
    assert mapping['status'] == 'BOUND_TO_PRIMARY_SOURCE_AND_REVIEWED', 'Official actual IP numbering/coordinates still unbound'
    assert mapping['primary_source_sha256'] and mapping['primary_source_locator']
    assert mapping['local_frame_convention_primary_source_sha256']
    pairs = mapping['actual_integration_point_to_barycentric']
    assert set(pairs) == {'1', '2', '3'}
    return np.array([pairs[str(i)] for i in (1, 2, 3)], dtype=float)

def source_only():
    print('SOURCE_ONLY_NO_ODB_NO_RECOVERY_EXECUTED')

if __name__ == '__main__':
    source_only()
