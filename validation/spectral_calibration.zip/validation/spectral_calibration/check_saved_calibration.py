"""Check saved LP64 outputs, input identities and calibration arithmetic.

No eigendecomposition, mechanics solve, compiler or proprietary host is called.
"""
from pathlib import Path
import csv, hashlib, json, math, re

HERE = Path(__file__).resolve().parent

def need(ok, message):
    if not ok:
        raise ValueError(message)

def comparison(actual,independent):
    need(math.isfinite(actual)and math.isfinite(independent),'original finite compare')
    error=abs(actual-independent)/(1+abs(independent))
    return dict(actual=actual,independent=independent,normalized_difference=error,original_tolerance=2e-12,passed=error<=2e-12)

def calibration(a,b,mode,form,divisor,multiplier):
    need(all(math.isfinite(x)and abs(x)>1e-14 for x in (a,b)),'original nonzero magnitude')
    d=1/(1/a+1/b);g1=(1/a)*d;g2=(1/b)*d
    if mode==1:d=a;g1,g2=1.,0.
    elif mode==2:d=b;g1,g2=0.,1.
    elif mode==3:g1,g2=0.,0.
    need(mode in (0,1,2,3),'original flux mode')
    if form=='Skew':d/=divisor if math.isfinite(divisor)and divisor>1e-12 else 1.
    elif form=='Sym':d*=multiplier
    else:raise ValueError('unsupported original form')
    need(d>0 and all(math.isfinite(v)for v in (d,g1,g2)),'original final arithmetic')
    return dict(d=d,gamma1=g1,gamma2=g2)

def main():
    need(comparison(1., 2.)['normalized_difference'] == 1./3., 'comparison self-check')
    need(calibration(2., 3., 1, 'Skew', 2., 2.) == dict(d=1., gamma1=1., gamma2=0.), 'calibration self-check')
    raw = [json.loads(line) for line in (HERE/'pencils.jsonl').read_text(encoding='utf-8').splitlines()]
    need(len(raw) == 292, 'all 292 saved pencils required')
    values = {}; matrix_files = set()
    for row in raw:
        match = re.fullmatch(r'e(\d+)_a(\d+)_m(\d+)_s([01])', row['id'])
        need(match is not None, 'complete pencil identity')
        key = tuple(map(int, match.groups()))
        need(key not in values and row['status'] == 'PUBLIC_LP64_QZ_COMPUTED', 'unique successful saved pencil')
        q = row['QZ']; n = row['n']
        need(q['info'] == 0 and len(q['alphaR']) == len(q['alphaI']) == len(q['beta']) == n, 'complete homogeneous arrays')
        ratios = []
        for a, im, b in zip(q['alphaR'], q['alphaI'], q['beta']):
            need(all(math.isfinite(x) for x in (a, im, b)), 'finite homogeneous data')
            if abs(b) < 1e-8 or abs(im) > 1e-10:
                continue
            value = a/b
            need(math.isfinite(value), 'finite ratio')
            if value > 0:
                ratios.append(value)
        need(ratios and q['finite_positive_estimate'] is True, 'original positive filter')
        values[key] = max(ratios)
        need(values[key] == q['lambda'], 'saved eigenvalue filter arithmetic')
        for side in ('A', 'B'):
            name = row['id']+'_'+side+'.npy'; path = HERE/'matrices'/name
            need(path.is_file(), 'missing matrix '+name)
            need(hashlib.sha256(path.read_bytes()).hexdigest() == row[side+'_sha256'], 'matrix identity '+name)
            matrix_files.add(name)
    need(len(matrix_files) == 584 and matrix_files == {p.name for p in (HERE/'matrices').glob('*.npy')}, 'exact 584 input matrices')
    group = lambda r: (int(r['entry']), int(r['attempt']), int(r['row_mask']))
    params = [json.loads(line) for line in (HERE/'calibration_parameters.jsonl').read_text(encoding='ascii').splitlines()]
    parameters = {group(r): r for r in params}
    with (HERE/'blocks.csv').open(encoding='ascii', newline='') as stream:
        block_rows = list(csv.DictReader(stream))
    blocks = {group(r): r for r in block_rows}
    report = json.loads((HERE/'recorded_comparisons.json').read_text(encoding='utf-8'))
    targets = {group(r): r for r in report['groups']}
    need(len(params) == len(parameters) == len(block_rows) == len(blocks) == len(targets) == 146, 'all original groups')
    need(set(parameters) == set(blocks) == set(targets), 'same calibration group identities')
    differences = []; scalars = 0
    for key, target in targets.items():
        p = parameters[key]; block = blocks[key]
        a, b = values[(*key, 0)], values[(*key, 1)]
        calculated = calibration(a, b, p['flux_mode'], block['form'], p['skew_divisor'], p['sym_multiplier'])
        calculated.update(d1=a, d2=b)
        for name, independent in calculated.items():
            actual = float(block[name]) if name in ('d', 'gamma1', 'gamma2') else target['comparisons'][name]['actual']
            check = comparison(actual, independent)
            need(check == target['comparisons'][name], 'recorded comparison arithmetic '+str(key)+' '+name)
            need(check['passed'], 'original tolerance failed')
            differences.append(check['normalized_difference']); scalars += 1
    need(scalars == 730 and report['original_tolerance'] == 2e-12, 'original scalar count and tolerance')
    controls = json.loads((HERE/'controls.json').read_text(encoding='utf-8'))
    need(len(controls['controls']) == 7, 'all seven recorded controls')
    named = {r['name']: r['QZ'] for r in controls['controls']}
    need(set(named) == {'known2', 'negativeA', 'zeroB', 'complex', 'finitePlusInfinite', 'known81', 'firstActual81'}, 'original control identities')
    need(all(named[k]['finite_positive_estimate'] is False for k in ('negativeA', 'zeroB', 'complex')), 'recorded rejection controls remain rejected')
    need(named['known2']['lambda'] == 3 and named['known81']['lambda'] == 81 and named['finitePlusInfinite']['lambda'] == 2 and named['finitePlusInfinite']['infinite'] == 1, 'known saved control values')
    failures = {}
    for name, expected in [('cross_backend_direct_H', 31), ('cross_backend_reconstructed_H', 35)]:
        parent = json.loads((HERE/(name+'.json')).read_text(encoding='utf-8'))
        need(parent['status'].startswith('OPEN_') and len(parent['pencils']) == 292 and len(parent['calibration_comparisons']) == 146, 'original open parent retained')
        failed = sum(not row['passed'] for row in parent['calibration_comparisons'])
        need(failed == expected, 'original failed groups retained')
        failures[name] = failed
    print(json.dumps(dict(status='SAVED_LP64_ARITHMETIC_AND_INPUT_IDENTITIES_CHECKED', matrices=584, pencils=292, groups=146, scalars=scalars, maximum_normalized_difference=max(differences), recorded_controls=7, preserved_failed_groups=failures, eigendecomposition_executed=False), indent=2))

if __name__ == '__main__':
    main()
