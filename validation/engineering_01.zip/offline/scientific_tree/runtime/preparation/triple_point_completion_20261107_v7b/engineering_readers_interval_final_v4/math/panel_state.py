"""Independent Panel sparse operators, material energy, boundary reaction and work."""
import argparse,csv,hashlib,importlib.util,json,math,os
for _key in ("OMP_NUM_THREADS","MKL_NUM_THREADS","OPENBLAS_NUM_THREADS"):os.environ[_key]="1"
from pathlib import Path
import numpy as np
from scipy import sparse
HERE=Path(r'D:\BaiduSyncdisk\CODEX\投稿\二次修稿\准备工作\mechanics\candidate\panel_mesh_family_v1');ROOT=Path(r'D:\BaiduSyncdisk\CODEX\投稿\二次修稿\准备工作')
PARENT=ROOT/'mechanics/candidate/actual_hull_linear_state_v1/check_state_algebra_v2.py'
assert hashlib.sha256(PARENT.read_bytes()).hexdigest()=='603f5e853599fb7e247b091a4ed7dc85687c9a064789f1ae9a19e897e8b1750f'
spec=importlib.util.spec_from_file_location('frozen_sparse_algebra_thresholds',PARENT);base=importlib.util.module_from_spec(spec);spec.loader.exec_module(base)
sha,rows,matrix,vector,norm_inf,identity,backward=base.sha,base.rows,base.matrix,base.vector,base.norm_inf,base.normalized_matrix_difference,base.kkt_check

def csvmatrix(path,n,cols=(0,1,2),mask=None):
 assert path.stat().st_size<=2<<30
 a=np.loadtxt(path,skiprows=1,delimiter=',',usecols=cols,ndmin=2)
 assert len(a)<=base.MAX_NNZ and a.shape[1]==3 and np.isfinite(a).all() and np.array_equal(a[:,:2],np.floor(a[:,:2])) and a[:,:2].min()>=0 and a[:,:2].max()<n
 if mask is not None:a=a[mask]
 return sparse.coo_matrix((a[:,2],(a[:,0].astype(np.int32),a[:,1].astype(np.int32))),shape=(n,n)).tocsr()

def work_check(kb,line,point,ghost,p,f,g,u):
 n=len(u);k=kb+line+point+ghost+p;res,bwd=backward(k,f,u)
 eb=.5*float(u@(kb@u));eg=.5*float(u@(ghost@u));el=.5*float(u@(line@u));ep=.5*float(u@(point@u));gap=g-u;ev=.5*float(gap@(p@gap));r=f-p@u;w=float(g@r)
 err=abs(w-2*(eb+eg+el+ep+ev))/max(1.,abs(w),abs(2*(eb+eg+el+ep+ev)));assert err<=1e-8,('same work identity criterion',err)
 return dict(material_energy_Nmm=eb,ghost_diagonal_energy_Nmm=eg,line_energy_Nmm=el,point_energy_Nmm=ep,boundary_violation_energy_Nmm=ev,prescribed_boundary_reaction_work_Nmm=w,reaction_work_identity_error=err,normwise_backward_error=bwd,absolute_infinity_residual=float(np.max(np.abs(res)))),r

def selfcheck():
 kb=sparse.csr_matrix([[2.,-2.],[-2.,2.]]);p=sparse.diags([100.,100.],format='csr');z=sparse.csr_matrix((2,2));g=np.array([0.,-.5]);f=p@g;u=np.linalg.solve((kb+p).toarray(),f)
 r,_=work_check(kb,z,z,z,p,f,g,u);assert r['material_energy_Nmm']>0 and r['boundary_violation_energy_Nmm']>0
 neg=[]
 for name,kk,ff,uu in [('missing_surface_operator',kb,f,u),('wrong_RHS',kb+p,f+.1,u),('wrong_solution',kb+p,f,u+.1)]:
  try:backward(kk,ff,uu)
  except AssertionError:neg.append(name)
 assert len(neg)==3
 try:identity(kb+p,kb)
 except AssertionError:neg.append('missing_boundary_decomposition')
 assert len(neg)==4
 return dict(status='SELF_CHECK_ONLY',negative_controls=neg,thresholds_inherited_unchanged=True)

def audit(case):
 assert sha(case/'applied_source_binding.json')=='90f72156bd9f1430e25177e91b6a69b89c4434f81934dfdee19b20eef2a96566' and base.load(case/'original_input_before_after.json')['before']['sha256']==EXPECTED_INPUT,'exact final family source and original mesh'
 for r in base.load(case/'capture_artifact_manifest.json')['files']:
  p=case/r['path'];assert p.resolve().is_relative_to(case.resolve()) and p.stat().st_size==r['bytes'] and sha(p)==r['sha256']
 result=base.load(case/'process_result.json');assert result['exit_code']==0 and result['natural_owned_child_exit']
 for name in ('actual_loaded_module_hashes.json','actual_bootstrap_module_hashes.json'):assert not base.load(case/name)['errors']
 assert base.load(case/'original_input_before_after.json')['exact_sha_and_mtime_unchanged']
 resources=base.load(case/'owned_process_resource_observations.json');assert resources['within_declared_observed_memory'] and resources['declared_process_memory_bytes']==64<<30
 state=case/'derived_work/panel_state';done=base.load(state/'state_complete.json');assert done['actual_Panel_linear_state_complete'] and done['point_matrix_appended_once'] and done['capture_scopes_ended_before_global'] and done['no_RP_or_KKT']
 n=done['structural_dofs'];assert n==EXPECTED_DOF
 k=matrix(state/'structural_K.csv',n);u=vector(state/'structural_solution.csv',n);f=vector(state/'structural_rhs.csv',n)
 cp={(int(r['owner']),int(r['local_cp'])):int(r['global_node'])-1 for r in rows(case/'p4/numbering.csv')};assert len(cp)==EXPECTED_CP and len(set(cp.values()))==EXPECTED_CP
 def gd(owner,dof):return 3*cp[int(owner),int(dof)//3]+int(dof)%3
 raw=case/'raw_bulk_surface';bdone=base.load(raw/'complete.json');assert bdone['capture_complete'] and bdone['raw_bulk_owners']==36 and bdone['actual_surface_boundaries']==2
 mapping=np.full((36,MAX_PATCH_DOF),-1,dtype=np.int32)
 for (owner,localcp),node in cp.items():
  for component in range(3):mapping[owner-812,3*localcp+component]=3*node+component
 def local_matrix(path):
  assert path.stat().st_size<=2<<30
  with path.open(encoding='utf-8-sig')as stream:header=stream.readline().strip().split(',')
  usecols=[header.index(k)for k in ('owner','row','col','value')]
  a=np.loadtxt(path,skiprows=1,delimiter=',',usecols=usecols,ndmin=2)
  assert 0<len(a)<=MAX_RAW_ENTRIES and a.shape[1]==4 and np.isfinite(a).all()
  assert np.array_equal(a[:,:3],np.floor(a[:,:3])) and np.all((a[:,0]>=812)&(a[:,0]<=847)) and np.all((a[:,1:3]>=0)&(a[:,1:3]<MAX_PATCH_DOF))
  owner=a[:,0].astype(np.int32)-812;rr=mapping[owner,a[:,1].astype(np.int32)];cc=mapping[owner,a[:,2].astype(np.int32)];assert rr.min()>=0 and cc.min()>=0
  return sparse.coo_matrix((a[:,3],(rr,cc)),shape=(n,n)).tocsr()
 kb=local_matrix(raw/'raw_bulk_H.csv');p=local_matrix(raw/'surface_delta_K.csv')
 assert p.nnz==EXPECTED_BOUNDARY_DOF and identity(p,sparse.diags(p.diagonal(),format='csr'))==0
 expectedf=np.zeros(n)
 for r in rows(raw/'surface_delta_F.csv'):expectedf[gd(r['owner'],r['local_dof'])]+=float(r['value'])
 assert np.array_equal(f,expectedf) and np.max(np.abs(f))>0
 g=np.zeros(n);pd=p.diagonal();on=pd!=0;g[on]=f[on]/pd[on]
 support=rows(case/'p4/support.csv');d=np.zeros(n);zd=[]
 for r in support:
  i=3*cp[int(r['owner']),int(r['local_cp'])]+int(r['component']);d[i]+=float(r['after_H_diag'])-float(r['raw_H_diag'])
  if r['exact_zero_cp']=='true':zd.append(i)
 ghost=sparse.diags(d,format='csr');line=csvmatrix(case/'p4/coupling_triplets.csv',n,cols=(3,4,5))
 vals=rows(case/'point/actual_point_matrices.csv');v=[r for r in vals if r['channel']=='Skew'];point=sparse.coo_matrix(([float(r['value'])for r in v],([int(r['row'])for r in v],[int(r['col'])for r in v])),shape=(n,n)).tocsr()
 operator_error=identity(k,kb+ghost+p+line+point);point_skew_error=identity(point+point.T,sparse.csr_matrix((n,n)))
 energies,reaction=work_check(kb,line,point,ghost,p,f,g,u)
 assert float(np.max(np.abs(u[zd])))==0 and energies['ghost_diagonal_energy_Nmm']==0
 assembled=.5*float(u@(k@u));assert abs(assembled-done['assembled_quadratic_energy_Nmm'])<=1e-9*max(1.,abs(assembled))
 post=.5*float(u@((kb+ghost+p)@u));assert abs(post-done['postboundary_H_energy_Nmm'])<=1e-9*max(1.,abs(post))
 fields=rows(state/'control_point_solution.csv');assert len(fields)==EXPECTED_CP
 xyz=np.zeros((EXPECTED_CP,3));uv=np.zeros((EXPECTED_CP,3));owner=np.zeros(EXPECTED_CP,dtype=int)
 for r in fields:
  j=int(r['global_node'])-1;assert cp[int(r['owner']),int(r['local_cp'])]==j;xyz[j]=[float(r[c])for c in('x','y','z')];uv[j]=[float(r[c])for c in('ux','uy','uz')];owner[j]=int(r['owner'])
 assert np.array_equal(uv.reshape(-1),u)
 expected_g=np.zeros((EXPECTED_CP,3));expected_g[owner==830,2]=-.5;assert np.array_equal(g.reshape(-1,3),expected_g),'same actual surface prescription required'
 rr=reaction.reshape(-1,3);force=rr.sum(axis=0);moment=np.cross(xyz,rr).sum(axis=0);scale=max(1.,float(np.linalg.norm(rr,axis=1).sum()));length=max(1.,float(np.linalg.norm(xyz,axis=1).max()));balance=max(np.linalg.norm(force)/scale,np.linalg.norm(moment)/(scale*length));assert balance<=1e-8,('predeclared global force/moment balance',balance)
 boundary={}
 for o in(830,831):
  sel=owner==o;err=uv[sel]-g.reshape(-1,3)[sel];boundary[str(o)]=dict(reaction_N=rr[sel].sum(axis=0).tolist(),reaction_moment_Nmm=np.cross(xyz[sel],rr[sel]).sum(axis=0).tolist(),maximum_translation_residual_mm=float(np.max(np.abs(err))))
 return dict(status='PASS_ACTUAL_PANEL_STATE_SPARSE_DECOMPOSITION_MATERIAL_ENERGY_AND_WORK_ONLY',Core_PID=result['pid'],structural_DOF=n,global_operator_decomposition_error=operator_error,point_skew_error=point_skew_error,energies=energies,postboundary_H_energy_Nmm=post,assembled_quadratic_energy_Nmm=assembled,Hzero_DOF=len(zd),Hzero_U_max=0.,surface_boundaries=boundary,global_reaction_force_N=force.tolist(),global_reaction_moment_Nmm=moment.tolist(),global_balance_relative=balance,stress_actual_GP_records=done['stress_actual_GP_records'],stress_skipped_records=done['stress_skipped_records'],FEM_or_h_accuracy_or_general_PDE_or_paper_complete=False,reader_sha256=sha(Path(__file__)))

if __name__=='__main__':raise SystemExit('Use read_engineering_mode4_v7.py with current strict preflight')
