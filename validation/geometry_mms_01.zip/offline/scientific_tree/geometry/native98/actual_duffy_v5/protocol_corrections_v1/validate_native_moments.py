"""Independent Fraction moment checks for actual signed cut-cell calls.
Never starts Host/compiler. PASS is confined to bound metadata/rule/moment scope.
"""
from pathlib import Path
from fractions import Fraction as F
from decimal import Decimal
import argparse, copy, csv, hashlib, json, math, re

HERE=Path(r"D:\BaiduSyncdisk\CODEX\投稿\二次修稿\准备工作\geometry\native98\duffy_reference_proposal\safety_api_increment_v3")  # Frozen criteria/source/reference directory, not this checker-copy directory
REFERENCE=HERE.parent/'results/actual98_cell_local_polynomial_controls.json'
NATIVE98=HERE.parents[1]
POWERS=[(0,0),(3,3),(2,6),(4,4),(6,2),(4,6),(5,5),(6,4)]

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def bad_constant(s):raise ValueError('nonfinite JSON constant '+s)
def pairs_unique(pairs):
    d={}
    for k,v in pairs:
        if k in d:raise ValueError('duplicate JSON key '+k)
        d[k]=v
    return d
def parse(s):return json.loads(s,parse_float=Decimal,parse_constant=bad_constant,object_pairs_hook=pairs_unique)
def load(p):return parse(p.read_text(encoding='utf-8-sig'))
def integer(x):return isinstance(x,int)and not isinstance(x,bool)
def finite(x):
    try:return not isinstance(x,bool)and math.isfinite(float(x))
    except(TypeError,ValueError,OverflowError):return False
def ieee(o):
    # Captured geometry is binary64; distinct round-trip decimal spellings are
    # equivalent only if they reconstruct the same binary64. No coordinate snap.
    if isinstance(o,Decimal):return float(o)
    if isinstance(o,list):return[ieee(x)for x in o]
    if isinstance(o,dict):return{k:ieee(v)for k,v in o.items()}
    return o
def audit_log_errors(case):
    errors=[];stdout=case/'stdout.log'
    if not stdout.is_file():return['missing stdout audit-failure scan evidence']
    patterns=('MappingRejected','MapCoverageUnsupported','CouplingAssemblyFailed','LinearSolveFailed','[IGA][ValidationAudit][ERR]')
    for p in(stdout,case/'stderr.log'):
        if not p.is_file():continue
        raw=p.read_bytes()
        encoding='utf-16'if raw.startswith((b'\xff\xfe',b'\xfe\xff'))else'utf-16-le'if raw.count(b'\0')>len(raw)//5 else'utf-8-sig'
        text=raw.decode(encoding,errors='replace')
        for word in patterns:
            if word in text:errors.append('fatal runtime audit marker '+word+' in '+p.name)
    return errors

def truths():
    doc=load(REFERENCE);out={}
    assert [tuple(p)for p in doc['powers']]==POWERS
    for r in doc['rows']:out.setdefault(int(r['element']),[]).append(r)
    assert len(out)==98 and all(len(x)==8 for x in out.values())
    return out

def inspect_records(records,csvrows,require_reference=False,bulk_order=4):
    truth=truths();errors=[];comparisons=[];seen=set();backend_counts={};rule_counts=set();maximum=F(0)
    diagnostics={}
    for r in csvrows:
        key=(int(r['shellH']),int(r['element']))
        if key in diagnostics:errors.append('duplicate diagnostic cell')
        diagnostics[key]=r
    for r in records:
        if not integer(r.get('shellH'))or not integer(r.get('element')):errors.append('noninteger shell/cell');continue
        key=(r['shellH'],r['element']);e=r['element']
        if key in seen:errors.append('duplicate or multiple-phase moment cell');continue
        seen.add(key)
        if key[0]!=819 or e not in truth or key not in diagnostics:errors.append('unknown model owner/cell');continue
        d=diagnostics[key];expected=truth[e]
        if r.get('schema')!='oe_cut_cell_polynomial_moments_v1'or r.get('phase')!='stiffness_cut':errors.append('unbound moment schema/phase')
        if r.get('scope')!='accepted_signed_UV_calls_not_material_point_membership':errors.append('incorrect signed-call semantics')
        if r.get('valid')is not True:errors.append('invalid moment record')
        for field in('row','col'):
            if not integer(r.get(field))or r[field]!=int(d[field]):errors.append('cell index binding '+field)
        b=r.get('bounds',[]);wanted=[expected[0][k]for k in('u0','u1','v0','v1')]
        if len(b)!=4 or any(not finite(v)for v in b)or[float(v)for v in b]!=[float(v)for v in wanted]:errors.append('cell knot bounds mismatch')
        count_fields=('points','candidatePoints','acceptedPoints','actualTriangleRulePoints','actualSubcellRectangularGaussOrder','actual_bulk_rectangular_gauss_order')
        if any(not integer(r.get(f))for f in count_fields):errors.append('missing/noninteger actual rule/count metadata');continue
        if r['actual_bulk_rectangular_gauss_order']!=bulk_order:errors.append('actual bulk rectangular order mismatch')
        cp=int(d['candidateIntegrationPoints']);ap=int(d['acceptedIntegrationPoints'])
        if r['points']!=ap or r['acceptedPoints']!=ap or r['candidatePoints']!=cp or cp<ap or ap<0:errors.append('accepted kernel-call count mismatch')
        backend=r.get('backend');backend_counts[backend]=backend_counts.get(backend,0)+1
        if backend!=d['backend']:errors.append('backend differs from actual diagnostic')
        if backend=='triangle':
            nt=int(d['visibleTriangles'])
            if nt<=0 or cp%nt or cp!=ap or r['actualTriangleRulePoints']!=cp//nt or r['actualSubcellRectangularGaussOrder']!=0:errors.append('triangle rule/count binding failed')
            else:rule_counts.add(r['actualTriangleRulePoints'])
            if r['actualTriangleRulePoints']not in(1,3,7,36):errors.append('unsupported actual triangle rule')
            if require_reference and(r['actualTriangleRulePoints']!=36 or d['fallback']!='0'):errors.append('reference is not unconditional Duffy36 ear-only')
        elif backend in('subcell','fallback-subcell'):
            if r['actualTriangleRulePoints']!=0 or r['actualSubcellRectangularGaussOrder']<=0:errors.append('missing actual subcell order')
            if require_reference:errors.append('masking cannot stand in for Duffy reference')
        elif backend=='inactive':
            if ap or require_reference:errors.append('unexpected inactive reference cut cell')
        else:errors.append('unknown cut backend')
        vals=r.get('signedLocalMoments',[])
        if len(vals)!=8 or any(not finite(v)for v in vals)or not finite(r.get('absoluteUVWeight')):errors.append('nonfinite/missing moment vector');continue
        if F(r['absoluteUVWeight'])<0 or F(r['absoluteUVWeight'])+F(1,10**14)<abs(F(vals[0])):errors.append('invalid absolute/signed weight relationship')
        area=F(str(expected[0]['cell_parametric_area']))
        for value,t,(a,b)in zip(vals,expected,POWERS):
            exact=F(t['reference_signed_UV_weighted_local_moment_exact']);delta=F(value)-exact;error=abs(delta)/area;maximum=max(maximum,error)
            comparisons.append({'shellH':819,'element':e,'power_s':a,'power_t':b,'observed_moment':str(value),'reference_exact':str(exact),'absolute_error':float(abs(delta)),'cell_area_normalized_absolute_error':float(error)})
    if seen!={(819,e)for e in truth}:errors.append('actual 98 cell moment coverage incomplete or foreign')
    if set(diagnostics)!={(819,e)for e in truth}:errors.append('actual 98 diagnostic coverage incomplete or foreign')
    if len(comparisons)!=784:errors.append('actual784 scalar controls incomplete')
    if require_reference and maximum>F(1,10**10):errors.append('Duffy reference moment target1e-10 not met')
    return {'status':'REJECTED_MOMENT_PROTOCOL'if errors else'PASS_REFERENCE_784_MOMENTS_ONLY'if require_reference else'PASS_ACTUAL_784_MOMENTS_CAPTURE_ONLY','errors':sorted(set(errors)),'actual_cells':len(seen),'scalar_comparisons':len(comparisons),'max_cell_area_normalized_moment_error':float(maximum),'actual_backend_counts':backend_counts,'actual_triangle_rule_point_counts':sorted(rule_counts),'structural_accuracy_accepted':False,'all_quadrature_points_in_material_claim':False,'comparisons':comparisons}

def inspect_case(case,contract_path,reference):
    errors=audit_log_errors(case)
    req=[case/'source_runtime_manifest.json',case/'launch_plan.json',case/'process_result.json',case/'trim_cell_diagnostics.csv',case/'input_audit/cut_cell_polynomial_moments_819.jsonl',case/'capture/trim_geometry_819.json',case/'input_audit/load_stage_geometry_819.json',contract_path]
    missing=[str(p)for p in req if not p.is_file()]
    if missing:return {'status':'REJECTED_MISSING_EVIDENCE','errors':missing,'structural_accuracy_accepted':False,'comparisons':[]}
    contract=load(contract_path);manifest=load(case/'source_runtime_manifest.json');launch=load(case/'launch_plan.json');process=load(case/'process_result.json')
    if contract.get('fresh_process')is not True or contract.get('mesh_refinement_executed')is not False or contract.get('optimization_cache_active')is not False:errors.append('fresh/fixed-mesh/cache contract missing')
    if contract.get('IGA_SKIP_USER_COM_REGISTRATION')!='1':errors.append('registration skip contract missing')
    if contract.get('source_runtime_manifest_sha256')!=sha(case/'source_runtime_manifest.json'):errors.append('actual source manifest binding missing')
    crx=[x['sha256']for x in manifest['runtime']if x['name']=='IGAforCAD.crx']
    if len(crx)!=1 or contract.get('crx_sha256')!=crx[0]:errors.append('actual binary binding missing')
    if launch.get('input_sha256')!='96478f849637db80e7ca03dbf5900e6878db8c77cd69aec84a7661e6abd9bc23':errors.append('original input DWG mismatch')
    if contract.get('executed_profile_sha256')!=launch.get('profile_sha256'):errors.append('variant profile binding missing')
    moment_requested=contract.get('IGA_OE_CUT_MOMENT_AUDIT')=='1'or contract.get('IGA_OE_TRI_REFERENCE_DUFFY_GL6')=='1'
    if contract.get('surface_GaussN')!=4 or not moment_requested:errors.append('moment/bulk-order contract missing')
    if reference and(contract.get('IGA_OE_TRI_REFERENCE_DUFFY_GL6')!='1'or contract.get('TrimQuadratureMode')!=1):errors.append('Duffy reference contract missing')
    if process.get('exit_code')!=0 or process.get('natural_exit')is not True:errors.append('non-natural or failed process')
    files={}
    def walk(o):
        if isinstance(o,dict):
            if isinstance(o.get('path'),str):
                digest=o.get('after_sha256',o.get('sha256'))
                if isinstance(digest,str):
                    path=o['path'].replace('\\','/')
                    if path in files and files[path]!=digest:errors.append('conflicting executed source images '+path)
                    files[path]=digest
            for v in o.values():walk(v)
        elif isinstance(o,list):
            for v in o:walk(v)
    walk(manifest)
    for name in('Curves.cpp','OEConstantStrainBilinearProbe.h','OECutCellPolynomialMomentAudit.h','OETriangleReferenceDuffy6.h'):
        if files.get('IGAforCAD/'+name)!=sha(HERE/'combined'/name):errors.append('executed candidate source mismatch '+name)
    geo=load(case/'capture/trim_geometry_819.json');ref=load(NATIVE98/'raw/trim_geometry_819.json');active=load(case/'input_audit/load_stage_geometry_819.json')
    fields=('degree_u','degree_v','controls_u','controls_v','knots_u','knots_v','weights','control_global_Vg','outer_loop','hole_loops','outer_is_full_frame','outer_nontrivial')
    for field in fields:
        if ieee(geo.get(field))!=ieee(ref.get(field)):errors.append('registered geometry/domain mismatch '+field)
    for field in fields[:8]:
        if ieee(active.get(field))!=ieee(ref.get(field)):errors.append('actual load-stage geometry mismatch '+field)
    for stage in('raw_bulk_before_support','bulk_after_support'):
        f=case/'input_audit'/('bulk_measure_'+stage+'_819.json')
        if not f.is_file():errors.append('missing actual bulk order observation '+stage);continue
        d=load(f)
        if d.get('schema')!='oe_bulk_measure_probe_v1'or d.get('valid')is not True or d.get('actual_bulk_rectangular_gauss_order')!=4 or d.get('shell_handle')!=819 or d.get('stage')!=stage:errors.append('valid actual bulk rectangular order not observed '+stage)
    records=[parse(line)for line in(case/'input_audit/cut_cell_polynomial_moments_819.jsonl').read_text(encoding='utf-8-sig').splitlines()if line.strip()]
    rows=list(csv.DictReader((case/'trim_cell_diagnostics.csv').open(encoding='utf-8-sig')))
    r=inspect_records(records,rows,reference)
    r['errors']=sorted(set(errors+r['errors']))
    if r['errors']:r['status']='REJECTED_BOUND_NATIVE_MOMENT_PROTOCOL'
    r.update(case=str(case),contract_sha256=sha(contract_path),actual_CRX_sha256=crx[0]if len(crx)==1 else None,reference_Fraction_file_sha256=sha(REFERENCE),cad_curve_exactness_accepted=False,full_linear_solve_accepted=False)
    return r

def self_test(logdir):
    # Synthetic validator controls only, never Native measurements or run results.
    records=[];rows=[]
    for e,ts in truths().items():
        records.append({'schema':'oe_cut_cell_polynomial_moments_v1','phase':'stiffness_cut','scope':'accepted_signed_UV_calls_not_material_point_membership','shellH':819,'element':e,'row':e//36,'col':e%36,'backend':'triangle','actualTriangleRulePoints':36,'actualSubcellRectangularGaussOrder':0,'actual_bulk_rectangular_gauss_order':4,'points':36,'candidatePoints':36,'acceptedPoints':36,'valid':True,'bounds':[ts[0][k]for k in('u0','u1','v0','v1')],'absoluteUVWeight':Decimal('1'),'signedLocalMoments':[Decimal(F(t['reference_signed_UV_weighted_local_moment_exact']).numerator)/Decimal(F(t['reference_signed_UV_weighted_local_moment_exact']).denominator)for t in ts]})
        rows.append({'shellH':'819','element':str(e),'row':str(e//36),'col':str(e%36),'backend':'triangle','visibleTriangles':'1','candidateIntegrationPoints':'36','acceptedIntegrationPoints':'36','fallback':'0'})
    base=inspect_records(records,rows,True);assert not base['errors'],base['errors']
    mutations={}
    def mutated(name,mutate):
        r=copy.deepcopy(records);d=copy.deepcopy(rows);mutate(r,d);out=inspect_records(r,d,True);assert out['errors'],name;mutations[name]=out['errors']
    mutated('missing_cell',lambda r,d:r.pop())
    mutated('duplicate_cell',lambda r,d:r.append(copy.deepcopy(r[0])))
    mutated('wrong_phase',lambda r,d:r[0].update(phase='torsion'))
    mutated('wrong_shell',lambda r,d:r[0].update(shellH=820))
    mutated('wrong_point_count',lambda r,d:r[0].update(points=35))
    mutated('policy7_misreported_as_actual36',lambda r,d:r[0].update(actualTriangleRulePoints=7))
    mutated('missing_actual_bulk_order',lambda r,d:r[0].update(actual_bulk_rectangular_gauss_order=None))
    mutated('wrong_bounds',lambda r,d:r[0]['bounds'].__setitem__(0,Decimal('0')))
    mutated('nonfinite_moment',lambda r,d:r[0]['signedLocalMoments'].__setitem__(0,Decimal('NaN')))
    mutated('moment_failure_not_clamped',lambda r,d:r[0]['signedLocalMoments'].__setitem__(1,r[0]['signedLocalMoments'][1]+Decimal('.001')))
    for text in('{"x":NaN}','{"x":1,"x":2}'):
        try:parse(text)
        except ValueError:pass
        else:raise AssertionError('malformed JSON was accepted')
    logdir.mkdir(parents=True,exist_ok=False)
    fatal=('MappingRejected','MapCoverageUnsupported','CouplingAssemblyFailed','LinearSolveFailed','[IGA][ValidationAudit][ERR]')
    for i,word in enumerate(fatal):
        d=logdir/str(i);d.mkdir();(d/'stdout.log').write_text('[RESULT] u=0.008290 close_numeric_control_only\n'+word,encoding='utf-8');assert audit_log_errors(d),word
    utf16=logdir/'utf16le_without_BOM';utf16.mkdir();(utf16/'stdout.log').write_bytes(('good numeric control\n'+fatal[0]).encode('utf-16-le'));assert audit_log_errors(utf16)
    return {'status':'PASS_VALIDATOR_SYNTHETIC_CONTROLS_ONLY','real_Native_case_executed_or_accepted':False,'positive_synthetic_cells':98,'positive_synthetic_moments':784,'negative_controls_rejected':mutations,'malformed_NaN_and_duplicate_JSON_key_rejected':True,'fatal_runtime_markers_reject_even_with_close_numeric_line':list(fatal),'UTF16LE_without_BOM_fatal_marker_rejected':True}

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--case',type=Path);p.add_argument('--contract',type=Path);p.add_argument('--reference',action='store_true');p.add_argument('--self-test',action='store_true');p.add_argument('--output',type=Path,required=True);a=p.parse_args();a.output.mkdir(parents=True,exist_ok=False)
    if a.self_test:r=self_test(a.output/'synthetic_log_controls')
    else:
        if not a.case or not a.contract:p.error('--case and --contract required')
        try:r=inspect_case(a.case,a.contract,a.reference)
        except(Exception)as e:r={'status':'REJECTED_MALFORMED_EVIDENCE','errors':[str(e)],'structural_accuracy_accepted':False}
        comparisons=r.pop('comparisons',[])
        if comparisons:
            with(a.output/'784_actual_moment_comparisons.csv').open('w',newline='',encoding='utf-8-sig')as f:w=csv.DictWriter(f,fieldnames=list(comparisons[0]));w.writeheader();w.writerows(comparisons)
    (a.output/'validation_result.json').write_text(json.dumps(r,indent=2,ensure_ascii=False),encoding='utf-8');print(json.dumps(r,ensure_ascii=False));return 0 if r['status'].startswith('PASS_')else 1
if __name__=='__main__':raise SystemExit(main())
