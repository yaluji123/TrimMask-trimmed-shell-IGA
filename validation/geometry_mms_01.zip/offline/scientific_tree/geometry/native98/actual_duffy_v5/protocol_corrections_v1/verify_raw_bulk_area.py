"""Three independent material-area recoveries from actual raw-bulk JSON.
No force construction, f=Ku control, Host, compiler or solver.
"""
from pathlib import Path
from fractions import Fraction as F
from decimal import Decimal
import argparse, copy, json
from validate_native_moments import HERE, NATIVE98, load, sha, finite, ieee, audit_log_errors

TARGET=F(1,10**8)  # Declared before inspecting the future actual V5 case.
FIELDS=('E_N_per_mm2','nu','t_mm','epsilon','Qx_N_mm','Qy_N_mm','Qbiaxial_N_mm','areaX_mm2','areaY_mm2','areaBiaxial_mm2','rigid1_N_mm','rigid2_N_mm','planeResidual_mm')
def reference():
    r=load(NATIVE98/'results/reference_summary.json');c=load(NATIVE98/'results/affine_jacobian_certificate.json')
    area=F(r['global_uv_reference_frame_exact']);J=F(c['exact_nominal_Jacobian_fraction']);dJ=F(str(c['global_Jacobian_absolute_bound']))
    return area*J,area*(J-dJ),area*(J+dJ)
def examine(d,g,stage):
    errors=[];results={};centre,lo,hi=reference()
    if d.get('schema')!='oe_bulk_measure_probe_v1'or d.get('stage')!=stage or d.get('shell_handle')!=819 or d.get('valid')is not True:errors.append('invalid probe identity/stage/valid flag')
    if(d.get('m'),d.get('n'),d.get('dofPN'),d.get('matrix_rows'),d.get('matrix_cols'))!=(39,39,3,4563,4563):errors.append('actual matrix/owner dimensions mismatch')
    if any(not finite(d.get(k))for k in FIELDS):return{'status':'REJECTED_MALFORMED_RAW_BULK_PROTOCOL','errors':errors+['13 numeric Result fields missing or nonfinite']}
    if d.get('actual_bulk_rectangular_gauss_order')!=4:errors.append('actual raw rectangular bulk order not observed as4')
    if g.get('is_flat')is not True or g.get('isVarThk')is not False or g.get('dofPN')!=3:errors.append('unsupported material/geometry scope')
    E,nu,t,eps=(F(d[k])for k in('E_N_per_mm2','nu','t_mm','epsilon'))
    if not(E>0 and t>0 and eps>0 and -1<nu<F(1,2)):errors.append('invalid material or probe strain')
    if tuple(float(x)for x in(E,nu,t))!=tuple(float(g[k])for k in('E','nu','constant_t')):errors.append('actual probe/load-stage material mismatch')
    if errors:return{'status':'REJECTED_RAW_BULK_BINDING','errors':errors}
    densities={'X':E*t*eps**2/(1-nu**2),'Y':E*t*eps**2/(1-nu**2),'Biaxial':2*E*t*eps**2/(1-nu)}
    for name,q,a in(('X','Qx_N_mm','areaX_mm2'),('Y','Qy_N_mm','areaY_mm2'),('Biaxial','Qbiaxial_N_mm','areaBiaxial_mm2')):
        actual=F(d[q])/densities[name];printed=F(d[a]);delta=actual-centre
        outside=max(F(0),lo-actual,actual-hi);distance=outside/centre
        # Only checks the printed recovery formula; independent truth is Fraction geometry.
        if abs(printed-actual)/centre>F(1,10**13):errors.append('reported area/formula mismatch '+name)
        if distance>TARGET:errors.append('raw bilinear material-area target1e-8 failed '+name)
        results[name]={'recovered_area_from_actual_Q_mm2':float(actual),'reported_recovered_area_mm2':float(printed),'signed_relative_error_to_independent_centre':float(delta/centre),'signed_relative_error_interval':[float((actual-hi)/hi),float((actual-lo)/lo)],'relative_distance_outside_independent_Jacobian_interval':float(distance),'within_predeclared_bilinear_area_target':distance<=TARGET}
    return{'status':'REJECTED_RAW_BILINEAR_AREA_INVARIANT'if errors else'PASS_THREE_RAW_BILINEAR_AREAS_ONLY','errors':errors,'stage':stage,'definition':'u^T H u; not half-energy; no external force','independent_physical_reference_centre_mm2':float(centre),'independent_physical_reference_near_affine_interval_mm2':[float(lo),float(hi)],'declared_matrix_area_relative_target':float(TARGET),'recoveries':results,'rigid_energy_observations_N_mm':{k:float(d[k])for k in('rigid1_N_mm','rigid2_N_mm')},'rigid_energy_general_nullspace_certification':False,'global_solution_accuracy_accepted':False,'load_balance_or_boundary_consistency_accepted':False,'cad_curve_exactness_accepted':False}
def inspect(case):
    assert(case/'process_result.json').is_file(),'Do not inspect unfinished case'
    errors=audit_log_errors(case);proc=load(case/'process_result.json')
    if proc.get('exit_code')!=0 or proc.get('natural_exit')is not True:errors.append('actual process failed or did not exit naturally')
    plan=load(case/'launch_plan.json');manifest=load(case/'source_runtime_manifest.json');sources={}
    def walk(o):
        if isinstance(o,dict):
            if isinstance(o.get('path'),str):
                digest=o.get('after_sha256',o.get('sha256'))
                if isinstance(digest,str):
                    path=o['path'].replace('\\','/')
                    if path in sources and sources[path]!=digest:errors.append('conflicting executed source images '+path)
                    sources[path]=digest
            for v in o.values():walk(v)
        elif isinstance(o,list):
            for v in o:walk(v)
    walk(manifest)
    for name in('Curves.cpp','OEConstantStrainBilinearProbe.h'):
        if sources.get('IGAforCAD/'+name)!=sha(HERE/'combined'/name):errors.append('actual raw-probe source binding mismatch '+name)
    if plan.get('input_sha256')!='96478f849637db80e7ca03dbf5900e6878db8c77cd69aec84a7661e6abd9bc23':errors.append('actual raw-probe DWG identity mismatch')
    gfile=case/'input_audit/load_stage_geometry_819.json';g=load(gfile);f=case/'input_audit/bulk_measure_raw_bulk_before_support_819.json';d=load(f)
    original=load(NATIVE98/'raw/trim_geometry_819.json')
    for key in('shell_handle','degree_u','degree_v','controls_u','controls_v','knots_u','knots_v','control_global_Vg','weights'):
        if ieee(g.get(key))!=ieee(original.get(key)):errors.append('actual geometry no longer matches independent reference '+key)
    captured=load(case/'capture/trim_geometry_819.json')
    for key in('outer_loop','hole_loops','outer_is_full_frame','outer_nontrivial'):
        if ieee(captured.get(key))!=ieee(original.get(key)):errors.append('actual registered domain mismatch '+key)
    r=examine(d,g,'raw_bulk_before_support');r['errors']=errors+r['errors']
    if r['errors']:r['status']='REJECTED_BOUND_RAW_BULK_AREA_PROTOCOL'
    r.update(actual_case=str(case),actual_source_manifest_sha256=sha(case/'source_runtime_manifest.json'),actual_raw_probe_sha256=sha(f),actual_load_stage_geometry_sha256=sha(gfile),reference_summary_sha256=sha(NATIVE98/'results/reference_summary.json'),Jacobian_certificate_sha256=sha(NATIVE98/'results/affine_jacobian_certificate.json'))
    after=case/'input_audit/bulk_measure_bulk_after_support_819.json'
    if after.is_file():r['after_support_observations_only']={k:load(after).get(k)for k in('stage','actual_bulk_rectangular_gauss_order','areaX_mm2','areaY_mm2','areaBiaxial_mm2','rigid1_N_mm','rigid2_N_mm')}
    return r
def self_test():
    centre,lo,hi=reference();E=F(206000);nu=F(3,10);t=F(5);eps=F(1,10000)
    d={'schema':'oe_bulk_measure_probe_v1','stage':'raw_bulk_before_support','shell_handle':819,'m':39,'n':39,'dofPN':3,'matrix_rows':4563,'matrix_cols':4563,'valid':True,'actual_bulk_rectangular_gauss_order':4,'E_N_per_mm2':E,'nu':nu,'t_mm':t,'epsilon':eps,'Qx_N_mm':centre*E*t*eps**2/(1-nu**2),'Qy_N_mm':centre*E*t*eps**2/(1-nu**2),'Qbiaxial_N_mm':centre*2*E*t*eps**2/(1-nu),'areaX_mm2':centre,'areaY_mm2':centre,'areaBiaxial_mm2':centre,'rigid1_N_mm':F(0),'rigid2_N_mm':F(0),'planeResidual_mm':F(0)}
    g={'is_flat':True,'isVarThk':False,'dofPN':3,'E':E,'nu':nu,'constant_t':t}
    assert not examine(d,g,'raw_bulk_before_support')['errors']
    out={}
    for name,field,value in(('wrong_x_Q','Qx_N_mm',d['Qx_N_mm']*F(101,100)),('unknown_order','actual_bulk_rectangular_gauss_order',None),('wrong_stage','stage','pre_boundary_H_possible_support'),('nonfinite','Qx_N_mm',None)):
        changed=copy.deepcopy(d);changed[field]=value;r=examine(changed,g,'raw_bulk_before_support');assert r['errors'],name;out[name]=r['errors']
    return{'status':'PASS_SYNTHETIC_BILINEAR_AREA_PROTOCOL_CONTROLS_ONLY','actual_Native_raw_matrix_accepted':False,'target_predeclared_before_actual_V5_inspection':float(TARGET),'negative_controls_rejected':out,'no_external_f_or_f_equals_Ku_control':True}
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--case',type=Path);p.add_argument('--self-test',action='store_true');p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    audit_root=Path(__file__).resolve().parent.parent
    assert a.output.resolve().is_relative_to(audit_root);assert not a.output.exists();a.output.parent.mkdir(parents=True,exist_ok=True)
    if a.self_test:r=self_test()
    else:
        try:r=inspect(a.case)
        except Exception as e:r={'status':'REJECTED_MISSING_OR_MALFORMED_RAW_BULK_EVIDENCE','errors':[str(e)],'global_solution_accuracy_accepted':False}
    def exact_metadata_decimal(value):
        if isinstance(value,Decimal):return str(value)
        raise TypeError('Not JSON serializable: '+type(value).__name__)
    a.output.write_text(json.dumps(r,indent=2,ensure_ascii=False,default=exact_metadata_decimal),encoding='utf-8')
    print(json.dumps(r,ensure_ascii=False,default=exact_metadata_decimal));return 0 if r['status'].startswith('PASS_')else 1
if __name__=='__main__':raise SystemExit(main())
