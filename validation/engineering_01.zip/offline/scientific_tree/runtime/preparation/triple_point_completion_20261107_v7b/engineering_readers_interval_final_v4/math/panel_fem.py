"""Fixed-world full-vector comparison; no solved-value probe selection."""
import argparse,csv,hashlib,importlib.util,json
from pathlib import Path
import numpy as np
from scipy.interpolate import BSpline
HERE=Path('new_analysis/actual_inputs/prep/mechanics/candidate/panel_mesh_family_v1');PREP=Path('投稿/二次修稿/准备工作')
def load(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def rows(p):
 with p.open(encoding='utf-8-sig',newline='')as f:return list(csv.DictReader(f))
def probes_at_fixed_world(CASE,STATE,preselected,fem):
    reader_path = PREP / 'mechanics/candidate/endpoint_vertex988_source_v1/checker/check_actual_endpoint_capture.py'
    assert sha(reader_path) == 'c4892fb0b822bbee5ab43f97dde4010e5664ecb7bc347dccaa07599e823f33ff'
    spec = importlib.util.spec_from_file_location('unchanged_registered_closure_for_selected_probe', reader_path)
    reader = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(reader)
    fields = {}
    for r in rows(STATE / 'control_point_solution.csv'):
        fields.setdefault(int(r['owner']), {})[int(r['local_cp'])] = [float(r[k]) for k in ('ux', 'uy', 'uz')]
    geos = {int(p.stem.rsplit('_',1)[1]): load(p) for p in (CASE / 'capture').glob('trim_geometry_*.json')}
    probes = []
    for node, point in preselected['probes'].items():
        world = np.asarray(point, float)
        accepted = []
        for owner, g in sorted(geos.items()):
            m, n = g['controls_u'], g['controls_v']
            control = np.asarray(g['control_global_Vg'], float).reshape(m,n,3)
            lo = np.array([g['knots_u'][g['degree_u']], g['knots_v'][g['degree_v']]], float)
            hi = np.array([g['knots_u'][m], g['knots_v'][n]], float)
            jac = np.column_stack(((control[-1,0]-control[0,0])/(hi[0]-lo[0]), (control[0,-1]-control[0,0])/(hi[1]-lo[1])))
            uv = lo + np.linalg.lstsq(jac, world-control[0,0], rcond=None)[0]
            if np.any(uv < lo) or np.any(uv > hi):
                continue
            basis_u = BSpline(g['knots_u'], np.eye(m), g['degree_u'])(uv[0])
            basis_v = BSpline(g['knots_v'], np.eye(n), g['degree_v'])(uv[1])
            basis = np.outer(basis_u,basis_v).ravel()
            location = basis @ control.reshape(-1,3)
            residual = float(np.linalg.norm(location-world))
            if residual > 1e-8 or not reader.registered_closure(g,uv):
                continue
            assert len(fields[owner]) == m*n
            displacement = basis @ np.asarray([fields[owner][i] for i in range(m*n)])
            accepted.append(dict(owner=owner, uv=uv.tolist(), actual_world_residual_mm=residual, U_vector_mm=displacement.tolist(), partition_error=abs(float(basis.sum())-1.)))
        assert accepted, ('preselected FEM point has no retained Native owner', node)
        reference = fem[f'original_node_{node}_global_U_vector_mm']
        fv = np.array([reference[f'value_{i}'] for i in (1,2,3)], float)
        for a in accepted:
            value = np.asarray(a['U_vector_mm'])
            a.update(FEM4x_U_vector_mm=fv.tolist(), component_difference_mm=(value-fv).tolist(), relative_vector_difference=float(np.linalg.norm(value-fv)/np.linalg.norm(fv)))
        probes.append(dict(original_FEM_node=int(node), original_world_xyz_mm=point, all_retained_owner_traces=accepted, chosen_or_best_component=False))
    return probes

def main(case,report_path,output_path):
 a=argparse.Namespace(case=case,report=report_path,out=output_path);assert not a.out.exists()
 report=load(a.report);assert report['status']=='PASS_ACTUAL_PANEL_STATE_SPARSE_DECOMPOSITION_MATERIAL_ENERGY_AND_WORK_ONLY'
 pre=load(HERE/'PRESELECTED_FEM_INTERNAL_PROBES.json');table=load(PREP/'runtime/engineering_stri3_three_level_summary_v1/summary_data.json')['tables']['metrics_by_level'];fem={r[2]:dict(zip(table['header'],r))for r in table['rows']if r[0]=='panel'and r[1]=='4x'}
 energy=report['energies']['material_energy_Nmm'];values=[('raw_material_bulk_energy_Nmm',energy,float(fem['material_ALLSE_Nmm']['value_1']))]
 for owner,fe in [('831','SET-6'),('830','SET-8')]:values.append((owner+'_signed_RF3_N',report['surface_boundaries'][owner]['reaction_N'][2],float(fem[fe+'_signed_RF3_N']['value_1'])))
 scalars=[dict(metric=name,Native=value,FEM4x=ref,relative_difference=(value-ref)/abs(ref))for name,value,ref in values]
 probes=probes_at_fixed_world(a.case,a.case/'derived_work/panel_state',pre,fem)
 result=dict(status='ACTUAL_PANEL_STATE_VERSUS_FIXED_FEM4X_COMPARISON_ONLY',scalar_metrics=scalars,internal_probes=probes,comparison_protocol_sha256=sha(HERE/'PRESELECTED_FEM_INTERNAL_PROBES.json'),state_report_sha256=sha(a.report),reader_sha256=sha(Path(__file__)),FEM4x_is_adjacent_converged_reference_not_exact_truth=True,IGA_h_or_penalty_stress_CAD_equivalence_or_general_PDE_accepted=False)
 a.out.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8');print(json.dumps(result))
if __name__=='__main__':raise SystemExit('Use read_engineering_mode4_v7.py with current strict preflight')
